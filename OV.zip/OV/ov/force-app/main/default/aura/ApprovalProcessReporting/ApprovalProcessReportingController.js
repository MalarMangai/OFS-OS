/**
 * Created by venkatkarri on 9/26/18.
 */
({
    //================================================================================
    // INIT
    //================================================================================

    initialize: function(cmp, event, helper) {
        helper.getInitialConfigDetails(cmp, function() {
            var columnSize = (100/cmp.get('v.tableColumns').length);
            cmp.set('v.dynamicColumnWidth', 'width:' + columnSize + '%');
            helper.getData(cmp, function() {
                cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
                cmp.set('v.isComponentReady', true);
            });
        });
    },

    //================================================================================
    // UI ACTIONS
    //================================================================================

    handleViewMoreClick: function(cmp, event, helper) {
        cmp.set('v.isExtendedView', true);
        helper.getData(cmp, function() {
          helper.setupPagination(cmp, 2);
        });
      },

    handlePageSelected: function(cmp, event, helper) {
        var selectedPage = event.getParam('pageNumber');
        helper.displayPage(cmp, selectedPage);
    },

    handleTableHeaderClick: function(cmp, event, helper) {
        var currentFieldName = event.currentTarget.dataset.fieldName;

        var isSortable = event.currentTarget.dataset.isSortable;
        if (isSortable === 'true') {

            var filteringDetailsReq = cmp.get('v.filteringDetails');

            var sortDirection = '';
            var sortByFieldName = '';

            if(filteringDetailsReq != null && filteringDetailsReq.sortBy != null){
                sortDirection = filteringDetailsReq.sortBy.direction;
                sortByFieldName = filteringDetailsReq.sortBy.fieldName;
            }

            if (sortByFieldName === currentFieldName)
                  sortDirection = (sortDirection === 'ASC'? 'DESC' : 'ASC');
           else
              sortDirection = 'DESC';

            if(filteringDetailsReq != null){
                filteringDetailsReq.sortBy = {
                    fieldName : currentFieldName,
                    direction: sortDirection
                };
            }
            else
                filteringDetailsReq = {
                    searchText: '',
                    sortBy: {
                        fieldName : currentFieldName,
                        direction: sortDirection
                    }
                };

            cmp.set('v.filteringDetails', filteringDetailsReq);

            helper.getData(cmp, function() {
                cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
                helper.setupPagination(cmp, 1);
            });
        }
    },

    exportToCSV: function(cmp, event, helper){
        helper.getExportData(cmp, function() {
            var csvResultString = helper.exportData(cmp);
            if(csvResultString){
                var hiddenDownloadLink = document.createElement('a');
                hiddenDownloadLink.href = 'data:text/csv;charset=utf-8,' + encodeURI(csvResultString);
                hiddenDownloadLink.target = '_self';
                hiddenDownloadLink.download = 'ExportData.csv';
                document.body.appendChild(hiddenDownloadLink);
                hiddenDownloadLink.click();
            }
        });
    }
})