/**
 * Created by venkatkarri on 9/26/18.
 */
({
    //================================================================================
    // DATA LOAD
    //================================================================================

    getInitialConfigDetails: function(cmp, callback) {
        var helper = this;
        cmp.set('v.exceptionMessage', '');
        var action = cmp.get('c.getInitialConfig');
        action.setParams({
            objectName: cmp.get('v.objectName'),
            fieldsToDisplay: cmp.get('v.fieldsToDisplay')
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.tableColumns', responseObj.tableColumns);
                if (callback) {
                    callback();
                }
            } else {
                console.error('Initial config retrieval failed!', response.getError());
                cmp.set('v.exceptionMessage', 'Sorry, something went wrong. Please try again or contact the administrator');
                // showHideMessage(cmp, true, 'Error occurred while Initializing the Bulletin Board', 'ERROR');
            }
        });

        $A.enqueueAction(action);
    },

    getData: function(cmp, callback) {
        var helper = this;
        cmp.set('v.exceptionMessage', '');
        cmp.set('v.isLoadingRecords', true);

        var action = cmp.get('c.getRecords');
        var params = {
            fieldsToDisplay: cmp.get('v.fieldsToDisplay'),
            recordLimit: (cmp.get('v.isExtendedView')? 200 : cmp.get('v.recordsPerPage')),
            objectName: cmp.get('v.objectName'),
            filteringDetails: cmp.get('v.filteringDetails'),
            defaultConditions: cmp.get('v.defaultConditions') ? cmp.get('v.defaultConditions') : ''
        };
        action.setParams({
            paramsJSON: JSON.stringify(params)
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.recordList', responseObj.records);console.log(responseObj.records);
                cmp.set('v.hasMoreRecords', responseObj.hasMoreRecords);
            } else {
                cmp.set('v.recordList', []);
                console.error('Records retrieval failed!', response.getError());

                cmp.set('v.exceptionMessage', 'Sorry, something went wrong. Please try again or contact the administrator');
                // showHideMessage(cmp, true, 'Error occurred while retrieving details', 'ERROR');
            }

            if (callback) {
                callback();
            }
            cmp.set('v.isLoadingRecords', false);
        });

        $A.enqueueAction(action);
    },

    getExportData: function(cmp, callback){
        cmp.set('v.exceptionMessage', '');
        cmp.set('v.isLoadingRecords', true);
        var action = cmp.get('c.getRecords');
        var params = {
            fieldsToDisplay: cmp.get('v.fieldsToDisplay'),
            recordLimit: 200,
            objectName: cmp.get('v.objectName'),
            filteringDetails: cmp.get('v.filteringDetails'),
            defaultConditions: cmp.get('v.defaultConditions') ? cmp.get('v.defaultConditions') : ''
        };
        action.setParams({
            paramsJSON: JSON.stringify(params)
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.exportRecordList', responseObj.records);
            } else {
                cmp.set('v.exportRecordList', []);
                console.error('Records retrieval failed for export!', response.getError());
            }

            if (callback) {
                callback();
            }
            cmp.set('v.isLoadingRecords', false);
        });

        $A.enqueueAction(action);
    },

    exportData: function(cmp){
        var csvResultString = '';
        if(cmp.get('v.exportRecordList')){
            var columnDivider = ',';
            var lineDivider = '\n';
            var tableColumns = cmp.get('v.tableColumns');

            tableColumns.forEach(function(ele, index){
                csvResultString +=  '\"' + ele.label + '\"' + columnDivider;
            });

            csvResultString = csvResultString.slice(0, -1);
            // csvResultString += lineDivider;

            var exportResultSet = cmp.get('v.exportRecordList');
            exportResultSet.forEach(function(row, rowIndex){
                csvResultString += lineDivider;
                var fieldCollection = row.recordFields;
                fieldCollection.forEach(function(field, colIndex){
                    csvResultString += '\"' + field.displayValue + '\"' + columnDivider;
                });

                csvResultString = csvResultString.slice(0, -1);
            });
        }

        return csvResultString;
    },

    //================================================================================
    // PAGINATION
    //================================================================================

    setupPagination: function(cmp, pageToSet) {
        var recordList = cmp.get('v.recordList');

        var pageCount = Math.ceil(recordList.length / cmp.get('v.recordsPerPage'));
        cmp.set('v.recordPageCount', pageCount);

        if (pageCount > 0) {
            var newPageNumber = (pageToSet <= pageCount? pageToSet : 1);
            if(cmp.find('pagination') != null)
                cmp.find('pagination').selectPage(newPageNumber);
        }
    },

    displayPage: function(cmp, pageNumber) {
        var recordList = cmp.get('v.recordList');
        var recordsPerPage = cmp.get('v.recordsPerPage');
        var startIndex = (pageNumber - 1) * recordsPerPage;

        var currentPageRecordList = recordList.slice(startIndex, startIndex + recordsPerPage);
        cmp.set('v.currentPageRecordList', currentPageRecordList);
    },

    getCurrentPage: function(cmp) {
        var pagination = cmp.find('pagination');
        if (pagination) {
            return cmp.find('pagination').get('v.selectedPage');
        }
        return 1;
    },
})