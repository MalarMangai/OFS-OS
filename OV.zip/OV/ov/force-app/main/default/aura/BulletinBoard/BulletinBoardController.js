({
    //================================================================================
    // INIT
    //================================================================================
    
    initialize: function(cmp, event, helper) {
        var statusesList = cmp.get('v.statuses').split(',');

        cmp.set('v.filterStatuses', statusesList);
        if(cmp.get('v.defaultSearchStatus'))
            cmp.set('v.searchByStatus', cmp.get('v.defaultSearchStatus'));

        helper.getInitialConfigDetails(cmp, function() {
            helper.getBulletinRecords(cmp, function() {
                cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
                cmp.set('v.isComponentReady', true);
            });
        });
    },

    //================================================================================
    // UI ACTIONS
    //================================================================================

    handleViewMoreClick: function(cmp, event, helper) {
        cmp.set('v.isExtendedView', true);
        helper.getBulletinRecords(cmp, function() {
          helper.setupPagination(cmp, 2);
        });
      },

    handlePageSelected: function(cmp, event, helper) {
        var selectedPage = event.getParam('pageNumber');
        helper.displayPage(cmp, selectedPage);
    },

    handleTableHeaderClick: function(cmp, event, helper) {
        var currentFieldName = event.currentTarget.dataset.fieldName;

        var isSortable = event.currentTarget.dataset.isSortable;
        if (isSortable === 'true') {

            var filteringDetailsReq = cmp.get('v.filteringDetails');

            var sortDirection = '';
            var sortByFieldName = '';

            if(filteringDetailsReq != null && filteringDetailsReq.sortBy != null){
                sortDirection = filteringDetailsReq.sortBy.direction;
                sortByFieldName = filteringDetailsReq.sortBy.fieldName;
            }

            if (sortByFieldName === currentFieldName)
                  sortDirection = (sortDirection === 'ASC'? 'DESC' : 'ASC');
           else
              sortDirection = 'DESC';

            if(filteringDetailsReq != null){
                filteringDetailsReq.sortBy = {
                    fieldName : currentFieldName,
                    direction: sortDirection
                };
            }
            else
                filteringDetailsReq = {
                    searchText: '',
                    sortBy: {
                        fieldName : currentFieldName,
                        direction: sortDirection
                    }
                };

            cmp.set('v.filteringDetails', filteringDetailsReq);

            helper.getBulletinRecords(cmp, function() {
                cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
            });
        }
    },
    
      /* handleApplyCriteria: function(cmp, event, helper) {
        var eventParams = event.getParams();
        cmp.set('v.filteringDetails', {
          criteriaList: event.getParam('criteriaList'),
          sortBy: event.getParam('sortBy')
        }); */
    
    showHideMoreDetails: function(cmp, event, helper){
        var moreDetailsRow = event.currentTarget.parentElement.nextSibling;
        moreDetailsRow.classList.contains("hideDetails") ? 
            moreDetailsRow.classList.remove("hideDetails") :
        	moreDetailsRow.classList.add("hideDetails");
    },

    searchRecords: function(cmp, event, helper){
        helper.showHideMessage(cmp, false, '', '');
        var searchTerm = cmp.get('v.searchText');
        if(searchTerm.trim().length > 2 || searchTerm.trim().length == 0){
            var filteringDetailsReq = cmp.get('v.filteringDetails');
            if(filteringDetailsReq != null)
                filteringDetailsReq.searchText = searchTerm;
            else
                filteringDetailsReq = {searchText: searchTerm};

            cmp.set('v.filteringDetails', filteringDetailsReq);

            helper.getBulletinRecords(cmp, function() {
                cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
                helper.setupPagination(cmp, 1);
            });
        }
    },

    searchRecordsByStatus: function(cmp, event, helper){
        helper.showHideMessage(cmp, false, '', '');
        var searchStatus = cmp.get('v.searchByStatus');

        var filteringDetailsReq = cmp.get('v.filteringDetails');
        if(filteringDetailsReq != null)
            filteringDetailsReq.searchStatus = searchStatus;
        else
            filteringDetailsReq = {searchStatus: searchStatus};

        cmp.set('v.filteringDetails', filteringDetailsReq);

        helper.getBulletinRecords(cmp, function() {
            cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
            helper.setupPagination(cmp, 1);
        });
    },

    submitAuditRecord: function(cmp, event, helper){
        helper.showHideMessage(cmp, false, '', '');
        var currentRecord = event.currentTarget;
        var currentRecordDetails = currentRecord.getAttribute('id');
        var currentRecordArray = currentRecordDetails.split('_');
        if(currentRecordArray.length == 3 && currentRecordArray[2] == 'false'){
            var modalConfirmationHtml = cmp.get('v.modalMessage') ? cmp.get('v.modalMessage') :
                                            '<div class="modalMessage">'
                                              + '<p>Please ensure that you have read and understand all the details for this bulletin item, '
                                                   + 'including the contents inside the associated links, if any.</p>'
                                                    + '<p>Items once completed, cannot be reverted without the System Administrator\'s intervention</p>'
                                                    + '<p>Are you sure you want to acknowledge this item as Complete?</p></div>';
            $A.get('e.c:ST_Modal_EVTDisplay').setParams({
                cmpIdentifier: 'BulletinBoard' + (cmp.get('v.showPopOutLink') ? 'ModalWindow' : 'NewWindow'),
                header: 'Confirm Completion',
                html: modalConfirmationHtml,
                buttonsVariant: 'CONFIRM_CANCEL',
                showCloseButton: true,
                confirmCallback: function() {
                    helper.submitAuditRecord(cmp, currentRecordDetails, function(){
                          helper.getBulletinRecords(cmp, function() {
                             cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
                             helper.setupPagination(cmp, 1);
                             helper.showHideMessage(cmp, true, 'Great Work, Bulletin item is successfully acknowledged as complete.', 'SUCCESS');
                             $A.get('e.c:BulletinNotification_EVT_Change').fire();
                             setTimeout(function(){
                                 helper.showHideMessage(cmp, false, '', '');
                             }, 5000);
                         });
                    });
                },
                confirmButtonLabel: 'Complete'
             }).fire();
        }
        else{
            helper.showHideMessage(cmp, true, 'Bulletin item already acknowledged as Complete', 'ERROR');
            setTimeout(function(){
                helper.showHideMessage(cmp, false, '', '');
            }, 5000);
        }
    },

    handleNewWindowClick: function(cmp, event, helper){
        cmp.set('v.closeParentModal', false);
        var bulletinBoardUrl = cmp.get('v.bulletinBoardUrl');
        if(bulletinBoardUrl){
            window.open(bulletinBoardUrl, '_target');
            cmp.set('v.closeParentModal', true);
        }
    },

    reloadRecords: function(cmp, event, helper){
         helper.getBulletinRecords(cmp, function() {
            cmp.set('v.currentPageRecordList', cmp.get('v.recordList'));
            helper.setupPagination(cmp, 1);
        });
    }
})