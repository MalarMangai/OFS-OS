({
    //================================================================================
    // DATA LOAD
    //================================================================================
    
    getInitialConfigDetails: function(cmp, callback) {
        var helper = this;
        
        var action = cmp.get('c.getInitialConfig');
        action.setParams({
            objectName: cmp.get('v.objectName'),
            fieldsToDisplay: cmp.get('v.fieldsToDisplay'),
            calculatedField: cmp.get('v.calculatedField') ? cmp.get('v.calculatedField') : ''
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.tableColumns', responseObj.tableColumns);
                if (callback) {
                    callback();
                }
            } else {
                console.error('Initial config retrieval failed!', response.getError());

                showHideMessage(cmp, true, 'Error occurred while Initializing the Bulletin Board', 'ERROR');
            }
        });
        
        $A.enqueueAction(action);
    },
    
    getBulletinRecords: function(cmp, callback) {
        var helper = this;
        cmp.set('v.isLoadingRecords', true);
        
        var action = cmp.get('c.getRecords');
        var params = {
            fieldsToDisplay: cmp.get('v.fieldsToDisplay'),
            fieldsToExcludeFromTableView: cmp.get('v.fieldsToExcludeFromTableView') ? cmp.get('v.fieldsToExcludeFromTableView') : '',
            calculatedField: cmp.get('v.calculatedField') ? cmp.get('v.calculatedField') : '',
            recordLimit: (cmp.get('v.isExtendedView')? 200 : cmp.get('v.recordsPerPage')),
            defaultConditions: cmp.get('v.defaultConditions') ? cmp.get('v.defaultConditions') : '',
            objectName: cmp.get('v.objectName'),
            filteringDetails: cmp.get('v.filteringDetails'),
            auditBulletinObjectName: cmp.get('v.bulletinObjectName')
        };
        action.setParams({
            paramsJSON: JSON.stringify(params)
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.recordList', responseObj.records);console.log(responseObj.records);
                cmp.set('v.hasMoreRecords', responseObj.hasMoreRecords);
            } else {
                cmp.set('v.recordList', []);
                console.error('Records retrieval failed!', response.getError());

                showHideMessage(cmp, true, 'Error occurred while retrieving details', 'ERROR');
            }
            
            if (callback) {
                callback();
            }
            cmp.set('v.isLoadingRecords', false);
        });
        
        $A.enqueueAction(action);
    },

    submitAuditRecord: function(cmp, currentRecordDetails, callback) {
        var helper = this;
        var submitDetailsArray = currentRecordDetails.split('_');

        var action = cmp.get('c.submitBulletin');
        action.setParams({//String bulletinId, String auditObjName, Integer dueInDays
            bulletinId: submitDetailsArray[0],
            auditObjName: cmp.get('v.bulletinObjectName'),
            dueInDays: submitDetailsArray[1],
            auditCriteria: cmp.get('v.auditCriteria')
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                if (callback) {
                    callback();
                }
            } else {
                console.error('Submit Bulletin failed!', response.getError());
            }
        });

        $A.enqueueAction(action);
    },
    
    
    //================================================================================
    // PAGINATION
    //================================================================================
    
    setupPagination: function(cmp, pageToSet) {
        var recordList = cmp.get('v.recordList');
        
        var pageCount = Math.ceil(recordList.length / cmp.get('v.recordsPerPage'));
        cmp.set('v.recordPageCount', pageCount);
        
        if (pageCount > 0) {
            var newPageNumber = (pageToSet <= pageCount? pageToSet : 1);
            if(cmp.find('pagination') != null)
                cmp.find('pagination').selectPage(newPageNumber);
        }
    },
    
    displayPage: function(cmp, pageNumber) {
        var recordList = cmp.get('v.recordList');
        var recordsPerPage = cmp.get('v.recordsPerPage');
        var startIndex = (pageNumber - 1) * recordsPerPage;
        
        var currentPageRecordList = recordList.slice(startIndex, startIndex + recordsPerPage);
        cmp.set('v.currentPageRecordList', currentPageRecordList);
    },
    
    getCurrentPage: function(cmp) {
        var pagination = cmp.find('pagination');
        if (pagination) {
            return cmp.find('pagination').get('v.selectedPage');
        }
        return 1;
    },

    showHideMessage: function(cmp, showMessageDiv, messageText, messageType){
        var informationDivId = 'message' + (cmp.get('v.showPopOutLink') ? 'ModalWindow' : 'NewWindow');
        var informationDiv = document.getElementById(informationDivId);
        cmp.set('v.messageText', messageText);
        if(informationDiv != null){
            var messageClasses = ["success", "failure", "hideDetails"];
            if(showMessageDiv){
                messageClasses.forEach(function(currentClass, index){
                    if(currentClass == "hideDetails" && informationDiv.classList.contains(currentClass))
                        informationDiv.classList.remove(currentClass);
                    if(messageType == "SUCCESS" && currentClass == "success"){
                        if(informationDiv.classList.contains("failure"))
                            informationDiv.classList.remove("failure");
                        informationDiv.classList.add(currentClass);
                    }

                    if(messageType == "ERROR" && currentClass == "failure"){
                        if(informationDiv.classList.contains("success"))
                            informationDiv.classList.remove("success");
                        informationDiv.classList.add(currentClass);
                    }
                });
            }
            else {
               messageClasses.forEach(function(currentClass, index){
                    if(currentClass == "hideDetails") {
                        if(!informationDiv.classList.contains(currentClass))
                            informationDiv.classList.add(currentClass);
                    }
                    else if(informationDiv.classList.contains(currentClass))
                        informationDiv.classList.remove(currentClass);
               });
            }
        }
    }
})