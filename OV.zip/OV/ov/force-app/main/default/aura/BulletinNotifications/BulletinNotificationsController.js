/**
 * Created by venkatkarri on 6/21/18.
 */
({
    //================================================================================
    // INIT
    //================================================================================

    initialize: function(cmp, event, helper) {
        setTimeout(function() {
            helper.getRecordCount(cmp, function() {
                cmp.set('v.isComponentReady', true);
                helper.addBulletinNotificationToHeader(cmp);
            });
        }, 500);
    },


    //================================================================================
    // UI ACTIONS
    //================================================================================

    openBulletinBoard: function(cmp, event, helper) {

       helper.getRecordCount(cmp, function() {
             cmp.set('v.isComponentReady', true);
             helper.addBulletinNotificationToHeader(cmp);
         });

         var bulletinComponent = cmp.find('bulletin');
         if(bulletinComponent != null)
            bulletinComponent.reloadRecords();

          helper.showHideElement(cmp, 'bulletinBoardModal', true);
     },

     handleCancelClick: function(cmp, event, helper){
          helper.showHideElement(cmp, 'bulletinBoardModal', false);
     },

     handleModalOutsideClick: function(cmp, event, helper){
         //Uncomment below code, if we wish to implement this functionality

        /* var modal = document.getElementById('bulletinBoardModal');
         if(modal && modal.style.display == 'block'){
               var header = cmp.find('header').getElement();
               var body = cmp.find('body').getElement();
               var footer = cmp.find('footer').getElement();

               // check if click is really outside
               if (!header.contains(event.target) && !body.contains(event.target) && !footer.contains(event.target)) {
                   helper.showHideElement(cmp, 'bulletinBoardModal', false);
               }
         } */
     },

     closeBulletinModal: function(cmp, event, helper){
         if(cmp.get('v.closeModalWindow'))
            helper.showHideElement(cmp, 'bulletinBoardModal', false);
     },

     updateBulletinNotificationCount: function(cmp, event, helper){
         helper.getRecordCount(cmp, function() {
             cmp.set('v.isComponentReady', true);
             helper.addBulletinNotificationToHeader(cmp);
         });
     },


     //================================================================================
     // IGNORE FOR NOW - MAYBE NEEDED IN FUTURE
     //================================================================================

         // MODAL

         /* $A.createComponent('c:BulletinBoard',{}, function(content, status){
                 if(status == 'SUCCESS'){
                     cmp.find('overlayLib').showCustomModal({
                         header: 'Bulletin Board',
                         body: content,
                         showCloseButton: true
                     })
                 }
             }) */

            //$("#dialog").dialog("open");

         // RELOAD EVERY TIME THE MODAL IS OPENED

            /*helper.getRecordCount(cmp, function() {
                cmp.set('v.isComponentReady', true);
                helper.addBulletinNotificationToHeader(cmp);
            });

            var bulletinComponent = cmp.find('bulletin');
            if(bulletinComponent != null)
               bulletinComponent.reloadRecords(); */

})