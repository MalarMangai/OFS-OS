/**
 * Created by venkatkarri on 6/21/18.
 */
({
    //================================================================================
    // DATA LOAD
    //================================================================================

    getRecordCount: function(cmp, callback) {
        var helper = this;

        var action = cmp.get('c.getRecordCount');
        action.setParams({
            objectName: cmp.get('v.objectName'),
            bulletinAuditObjectName: cmp.get('v.bulletinAuditObjectName'),
            defaultConditions: cmp.get('v.defaultConditions') ? cmp.get('v.defaultConditions') : '',
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.recordCount', responseObj.recordCount);
            } else
                console.error('Records retrieval failed!', response.getError());

            if (callback) {
                callback();
            }
        });

        $A.enqueueAction(action);
    },

    addBulletinNotificationToHeader: function(cmp){
         var header = document.getElementById('oneHeader');
         if(header){
             var headerItemsList = header.querySelectorAll('ul.slds-global-header__item');
             if(headerItemsList.length > 0){
                 var bulletinItem = document.createElement("li");
                 bulletinItem.className = 'slds-dropdown-trigger';

                 var bulletinDiv = document.getElementById('bulletinNotificationHeader');
                 var bulletinCountSpan = bulletinDiv.getElementsByClassName('countDot');

                 if(bulletinCountSpan.length){
                     bulletinDiv.removeChild(bulletinCountSpan[0]);
                 }

                 if(cmp.get('v.recordCount')){
                     bulletinDiv.innerHTML += '<span class="countDot" style="right:-.05rem;"><span class = "counterLabel" style="text-align:center;">'
                                                    + cmp.get('v.recordCount') + '</span></span>'
                 }

                 var bulletinNotificationsDiv = document.getElementById('bulletinNotifications');
                 bulletinItem.appendChild(bulletinNotificationsDiv);
                 headerItemsList[0].insertBefore(bulletinItem, headerItemsList[0].childNodes[0]);
             }
         }
    },

    showHideElement: function(cmp, elementId, isVisible){
        var modal = document.getElementById(elementId);
        if(modal){
            modal.style.display = isVisible ? 'block' : 'none';
        }
    },
})