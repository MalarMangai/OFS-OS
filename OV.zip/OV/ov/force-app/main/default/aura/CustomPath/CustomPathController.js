/**
 * Created by venkatkarri on 7/12/18.
 */
({
    initialize: function(cmp, event, helper){
        var currentUserId = $A.get("$SObjectType.CurrentUser.Id");
        cmp.set('v.currentUserId', currentUserId);
    },

    recordUpdated: function(cmp, event, helper){
        if(cmp.get('v.exitStages')){
            var changeType = event.getParams().changeType;

            //if (changeType === "ERROR") { /* handle error; do this first! */ }

            if (changeType === "CHANGED") {
                var coachingRecord = cmp.get('v.coachingRecord');
                var exitStages = cmp.get('v.exitStages').split(',');
                // console.log('Owner', coachingRecord.OwnerId == cmp.get('v.currentUserId'));
                if(exitStages.includes(coachingRecord.Stage__c))
                    helper.navigateToObjectView(cmp);
            }
        }
    }
})