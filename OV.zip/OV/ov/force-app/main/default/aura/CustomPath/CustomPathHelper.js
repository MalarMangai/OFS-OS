/**
 * Created by venkatkarri on 7/12/18.
 */
({
    navigateToObjectView: function(cmp){
        var navigateEvent;
        if(cmp.get('v.objectViewId')){
            navigateEvent = $A.get('e.force:navigateToList');
            navigateEvent.setParams({
                "listViewId": cmp.get('v.objectViewId'),
                "scope": cmp.get('v.objectName')
            });
        }
        else{
            navigateEvent = $A.get('e.force:navigateToObjectHome');
            navigateEvent.setParams({
                "scope": cmp.get('v.objectName'),
            });
        }

        navigateEvent.fire();
    }

    /*
    var evt = $A.get("e.force:navigateToComponent");
            evt.setParams({
                componentDef: "namespace:MyComponent",
                componentAttributes: {
                    myAttribute: component.get("v.someAttribute")
                }
            });
        evt.fire();



         var navigationSObject = $A.get("e.force:navigateToSObject");
                navigationSObject.setParams({
                    "recordId": cmp.get("v.recordId")
                });
                navigationSObject.fire();

        */
})