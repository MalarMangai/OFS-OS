/**
 * Created by venkatkarri on 8/15/18.
 */
({
    initializeSearch: function(cmp, event, helper){
        cmp.set('v.isComponentReady', false);
        helper.getInitialSearchAttributes(cmp, function(){
            cmp.set('v.isComponentReady', true);
        });
    },

    searchRecords: function(cmp, event, helper){
        cmp.set('v.resultSet', null);
        if(cmp.get('v.searchText').length > 2){
            cmp.set('v.isLoadingRecords', true);

            helper.searchRecords(cmp, function(){
                cmp.set('v.isLoadingRecords', false);
            });
        }
    },

    handleInputKeyPress: function(cmp, event, helper) {
        helper.handleInputKeyPress(cmp, event);
    },


    selectRecord: function(cmp, event, helper){
        helper.selectRecord(cmp, event);
    },

    updateFilters: function(cmp, event, helper){
        helper.getFilteredResults(cmp, event);
    },

    handleRemoveClick: function(cmp, event, helper){
        helper.clearAttributes(cmp);
    },

    clearSearchResults: function(cmp, event, helper){
        helper.clearSearchResults(cmp);
    },

    redirectToRecordView: function(cmp, event, helper){
        var selectedRecord = event.currentTarget;
        var navigateEvent = $A.get("e.force:navigateToSObject");
        navigateEvent.setParams({
            "recordId": selectedRecord.getAttribute('data-element')
        });

        navigateEvent.fire();

        event.stopPropagation();
        return false;
    },

    toggleVisibility: function(cmp, event, helper){
        var headerObject = event.currentTarget;
        var detailsObject = headerObject.nextSibling;
        var visibility = detailsObject.style.display == 'none' ? 'block' : 'none';
        detailsObject.style.display = visibility;
    }
})