/**
 * Created by venkatkarri on 8/15/18.
 */
({
    getInitialSearchAttributes: function(cmp, callback){
        var helper = this;
        var objectArray = new Array();
        var objectInfo = {};

        if(cmp.get('v.queryObjects')){
            var objectDetailsArray = cmp.get('v.queryObjects').split('^');
            if(objectDetailsArray){
                objectDetailsArray.forEach(function(ele,index){
                    var objectDetails = ele.split('|');
                    if(objectDetails.length == 2){
                        objectInfo = {
                            objectName: objectDetails[0],
                            objectFields: objectDetails[1]
                        }
                    } else{
                        objectInfo = {
                            objectName: objectDetails[0]
                        }
                    }

                    objectArray.push(objectInfo);
                });
            }
        }
        else if(cmp.get('v.sObjectName')){
            objectInfo = {
                objectName: cmp.get('v.sObjectName')
            }

            objectArray.push(objectInfo);
        }

        var params = {
            objectInfo: objectArray
        }

        var action = cmp.get('c.getInitialConfiguration');
        action.setParams({
            objDetails: JSON.stringify(params)
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue();
                cmp.set('v.formattedQuerySets', responseObj);
                if (callback) {
                    callback();
                }
            } else {
                console.error('Initial Configuration failed!', response.getError());
            }
        });

        $A.enqueueAction(action);
    },

    searchRecords: function(cmp, callback){
        var helper = this;

        var fieldNameCollection = cmp.get('v.formattedQuerySets');
        var filteringCollection = cmp.get('v.filteringDetailsRequest');

        if(filteringCollection){
            var filteringObjectNames = Object.keys(filteringCollection);
            fieldNameCollection.map(function(ele, index){
                if(filteringObjectNames.includes(ele.objectName)){
                    ele.filterDetails = {
                        sortInfo: {
                            fieldName: filteringCollection[ele.objectName].sortBy.fieldName,
                            sortDirection: filteringCollection[ele.objectName].sortBy.direction
                        }
                    }
                }
            });

            cmp.set('v.formattedQuerySets', fieldNameCollection);

            // console.log('Object Info: ', fieldNameCollection);
        }

        var params = {
            objectInfo: fieldNameCollection
        }

        var action = cmp.get('c.getSearchResults');
        action.setParams({
            objDetails: JSON.stringify(params),
            searchText: cmp.get('v.searchText')
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                var responseObj = response.getReturnValue(); console.log(responseObj);
                cmp.set('v.resultSet', responseObj);
                if (callback) {
                    callback();
                }
            } else {
                console.error('Retrieval failed!', response.getError());
            }
        });

        $A.enqueueAction(action);
    },

    selectRecord: function(cmp, event){
        cmp.set('v.clickedSearch', false);
        var selectedRecord = event.currentTarget;
        cmp.set('v.selectedRecord', selectedRecord.innerHTML);

        var selectedRecordActionDetails = selectedRecord.getAttribute('data-element').split(',');

        var resultSet = cmp.get('v.resultSet');
        var recordInfo = resultSet[selectedRecordActionDetails[0]];

        var fieldNames = new Array(); //recordInfo.columnNames;
        var fieldDisplayNames = new Array(); //recordInfo.fieldDisplayNames;

        var fieldDetails = recordInfo.fieldInfo;

        var selectedRecordDetails = recordInfo.results[selectedRecordActionDetails[1]].details;

        var columnNames = Object.keys(selectedRecordDetails);
        var columnValues = columnNames.map(e => selectedRecordDetails[e]);

        var reAssignedColumnValues = new Array();

        fieldDetails.forEach(function(col, colIndex){
            fieldNames.push(col.name);
            fieldDisplayNames.push(col.displayName);

           /* if(columnNames.includes(col.name)){
                reAssignedColumnValues.push(selectedRecordDetails[col.name]);
            }
            else{
                reAssignedColumnValues.push('');
            } */

            var objColData = {
                colId: '',
                colValue: ''
            };

            if(columnNames.includes(col.name)){
                objColData = {
                    colId: '',
                    colValue: selectedRecordDetails[col.name]
                }
            }
            else if(col.name.includes('.')){
                var refColumnCollection = col.name.split('.');
                var refColumnValue = {};
                switch(refColumnCollection[1].toUpperCase()){
                    case 'NAME' :
                        objColData = {
                            colId: (refColumnCollection[0].toUpperCase() == 'RECORDTYPE') ? '' :
                                    selectedRecordDetails[refColumnCollection[0]].Id,
                            colValue: selectedRecordDetails[refColumnCollection[0]].Name
                        }
                        break;
                    case 'CASENUMBER':
                        objColData = {
                            colId: selectedRecordDetails[refColumnCollection[0]].Id,
                            colValue: selectedRecordDetails[refColumnCollection[0]].CaseNumber
                        }
                        break;
                    case 'CONTRACTNUMBER':
                        objColData = {
                            colId: selectedRecordDetails[refColumnCollection[0]].Id,
                            colValue: selectedRecordDetails[refColumnCollection[0]].ContractNumber
                        }
                        break;
                    default:
                        break;
                }
            }

            reAssignedColumnValues.push(objColData);
        });

        cmp.set('v.selectedRecordColumns', fieldDisplayNames ? fieldDisplayNames : fieldNames);
        cmp.set('v.selectedRecordValues', reAssignedColumnValues);

        cmp.set('v.redirectObjectName', selectedRecordActionDetails[2]);
        cmp.set('v.redirectRecordId', selectedRecordActionDetails[3]);

        var columnSize = (100/cmp.get('v.selectedRecordColumns').length);
        cmp.set('v.dynamicColumnWidth', 'width:' + columnSize + '%');

        cmp.set('v.resultSet', null);
    },

    getFilteredResults: function(cmp, event){
        var helper = this;

        var expandCollapseAttribute = event.getParam('expandCollapse');
        if(expandCollapseAttribute){
            var collapsedObjects = cmp.get('v.collapsedObjects') ? cmp.get('v.collapsedObjects') : {};
            collapsedObjects[expandCollapseAttribute.objectName] = expandCollapseAttribute;

            cmp.set('v.collapsedObjects', collapsedObjects);
        }
        else{
            var currentFilter = event.getParam('filterDetails');
            //var filterObjectExists = false;
            var allFilterDetails = cmp.get('v.filteringDetailsRequest') ? cmp.get('v.filteringDetailsRequest') : {};

            allFilterDetails[currentFilter.objectName] = currentFilter;

            cmp.set('v.filteringDetailsRequest', allFilterDetails);

            this.searchRecords(cmp, function(){
                cmp.set('v.clickedSearch', true);
                cmp.set('v.searchResultSet', cmp.get('v.resultSet'));
                cmp.set('v.resultSet', null);
            });

        }

       /* var objectNamesForFilters = Object.keys(allFilterDetails);
        var objectValueForFilters = objectNamesForFilters.map(e => allFilterDetails[e]);

        console.log('Keys: ', objectNamesForFilters);
        objectValueForFilters.forEach(function(ele, index){
            console.log('Values: ', ele.sortBy.fieldName, ele.sortBy.direction);
        }); */

    },

    handleInputKeyPress: function(cmp, event){
        switch (event.keyCode) {
          case 13: //enter
            if (cmp.get('v.resultSet')) {
              cmp.set('v.clickedSearch', true);
              cmp.set('v.searchResultSet', cmp.get('v.resultSet'));
              cmp.set('v.resultSet', null);
            }
            else{
                this.searchRecords(cmp, function(){
                    cmp.set('v.clickedSearch', true);
                    cmp.set('v.searchResultSet', cmp.get('v.resultSet'));
                    cmp.set('v.resultSet', null);
                });
            }
            break;
        }
    },

    clearAttributes: function(cmp){
        cmp.set('v.selectedRecord', '');
        cmp.set('v.resultSet', null);
        cmp.set('v.selectedRecordColumns', null);
        cmp.set('v.selectedRecordValues', null);
        cmp.set('v.redirectObjectName', null);
        cmp.set('v.redirectRecordId', null);
        cmp.set('v.dynamicColumnWidth', null);
    },

    clearSearchResults: function(cmp){
        this.clearAttributes(cmp);
        cmp.set('v.clickedSearch', false);
        cmp.set('v.searchResultSet', null);
    }
})