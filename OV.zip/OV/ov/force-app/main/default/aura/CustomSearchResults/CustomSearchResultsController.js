/**
 * Created by venkatkarri on 9/4/18.
 */
({
    setResultDetails: function(cmp, event, helper){
        var response = cmp.get('v.responseDetails');
        var resultDetails = response.results;
        var columnValueSet = new Array();
        var allFilterDetails = cmp.get('v.filteringDetailsRequest');
        var currentObjectName = response.objectName;
        var fieldInfo = response.fieldInfo;
        var collapsedObjects = cmp.get('v.collapsedObjects');

        if(allFilterDetails){
            var objectNamesForFilters = Object.keys(allFilterDetails);
            if(objectNamesForFilters.includes(currentObjectName)){
                var filterInfo = {
                    objectName: currentObjectName,
                    sortBy: {
                        fieldName : allFilterDetails[currentObjectName].sortBy.fieldName,
                        direction: allFilterDetails[currentObjectName].sortBy.direction
                    }
                }

                cmp.set('v.filteringDetails', filterInfo);
            }
        }

        if(collapsedObjects){
            var objectNamesForAccordion = Object.keys(collapsedObjects);
            if(objectNamesForAccordion.includes(currentObjectName)){
                var accordionInfo = {
                    objectName: currentObjectName,
                    collapsed: collapsedObjects[currentObjectName].collapsed
                }

                cmp.set('v.accordionInfo', accordionInfo);
                cmp.set('v.collapsed', accordionInfo.collapsed);
            }
        }

        var columnSize = (100/fieldInfo.length);
        cmp.set('v.dynamicColumnWidth', 'width:' + columnSize + '%');

        resultDetails.forEach(function(currentResult, index){
            var currentResultDetails = currentResult.details;
            var currentResultId = currentResultDetails.Id;
            var columnNames = Object.keys(currentResultDetails);

            var reAssignedColumnValues = new Array();

            fieldInfo.forEach(function(col, colIndex){
                var objColData = {
                    colId: '',
                    colValue: ''
                };

                if(columnNames.includes(col.name)){
                    objColData = {
                        colId: '',
                        colValue: currentResultDetails[col.name]
                    }
                }
                else if(col.name.includes('.')){
                    var refColumnCollection = col.name.split('.');
                    var refColumnValue = {};
                    switch(refColumnCollection[1].toUpperCase()){
                        case 'NAME' :
                            objColData = {
                                colId: (refColumnCollection[0].toUpperCase() == 'RECORDTYPE') ? '' :
                                        currentResultDetails[refColumnCollection[0]].Id,
                                colValue: currentResultDetails[refColumnCollection[0]].Name
                            }
                            break;
                        case 'CASENUMBER':
                            objColData = {
                                colId: currentResultDetails[refColumnCollection[0]].Id,
                                colValue: currentResultDetails[refColumnCollection[0]].CaseNumber
                            }
                            break;
                        case 'CONTRACTNUMBER':
                            objColData = {
                                colId: currentResultDetails[refColumnCollection[0]].Id,
                                colValue: currentResultDetails[refColumnCollection[0]].ContractNumber
                            }
                            break;
                        default:
                            break;
                    }
                }

                reAssignedColumnValues.push(objColData);
            });

            var currentValueSet = {
                id: currentResultId,
                values: reAssignedColumnValues
            }

            columnValueSet.push(currentValueSet);

        });

        cmp.set('v.resultValues', columnValueSet);
    },

    redirectToRecordView: function(cmp, event, helper){
        var selectedRecord = event.currentTarget;
        var navigateEvent = $A.get("e.force:navigateToSObject");
        navigateEvent.setParams({
            "recordId": selectedRecord.getAttribute('data-element')
        });

        navigateEvent.fire();

        event.stopPropagation();
        return false;
    },

    handleTableHeaderClick: function(cmp, event, helper){
        var currentFieldName = event.currentTarget.dataset.fieldName;
        var currentObjectName = cmp.get('v.responseDetails').objectName;

        var isSortable = event.currentTarget.dataset.isSortable;
        if (isSortable === 'true') {

            var filteringDetailsReq = cmp.get('v.filteringDetails') ? cmp.get('v.filteringDetails') : {};

            var sortDirection = '';
            var sortByFieldName = '';
            if(filteringDetailsReq != null && filteringDetailsReq.sortBy != null){
                sortDirection = filteringDetailsReq.sortBy.direction;
                sortByFieldName = filteringDetailsReq.sortBy.fieldName;
            }

            if (sortByFieldName === currentFieldName)
                sortDirection = (sortDirection === 'ASC'? 'DESC' : 'ASC');
            else
                sortDirection = 'DESC';

            filteringDetailsReq = {
                objectName: currentObjectName,
                sortBy: {
                    fieldName : currentFieldName,
                    direction: sortDirection
                }
            };

            cmp.set('v.filteringDetails', filteringDetailsReq);

            var filterEvent = cmp.getEvent('customSearchFilterEvent');
            if(filterEvent){
                filterEvent.setParams({
                    filterDetails: cmp.get('v.filteringDetails')
                }).fire();
            }
        }
    },

    toggleVisibility: function(cmp, event, helper){
        cmp.set('v.collapsed', !cmp.get('v.collapsed'));

        var accordionInfo = {
            objectName: cmp.get('v.responseDetails').objectName,
            collapsed: cmp.get('v.collapsed')
        }

        cmp.set('v.accordionInfo', accordionInfo);

        var filterEvent = cmp.getEvent('customSearchFilterEvent');
        if(filterEvent){
            filterEvent.setParams({
                expandCollapse: cmp.get('v.accordionInfo')
            }).fire();
        }
    }
})