/**
 * Created by mcallison on 6/29/2018.
 */
({
    getTitle: function(cmp,place,title) {
        console.log('OstkPageLayoutHelper:getTitle - enter');

        var action = cmp.get("c.getConfig");
        action.setParams({conf:title});
        action.setCallback(this, function(res) {
            var title = res.getReturnValue();
            var state = res.getState();
            if(state==="SUCCESS") {
                cmp.set(place, title[0].config_text__c);
            }
            else {
                state==="FAILURE";
            }
        });

        $A.enqueueAction(action);

        console.log('OstkPageLayoutHelper:getTitle - exit');

    },

})