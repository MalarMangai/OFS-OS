({
    doInit: function(component,event,helper) {
        // console.log("OstkPageLayoutInnerController:doInit - enter");
        //
        // helper.getTitle(component,'v.title','EKB Main Page Title');
        // helper.getTitle(component,'v.intro','EKB Main Page Intro');
        //
        // console.log("OstkPageLayoutInnerController:doInit - exit");
    },

	goHome : function(component,event,helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "/"
		});
		urlEvent.fire();
	},

	goAllFAQ: function(component,event,helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "/topiccatalog"
		});
		urlEvent.fire();
	},

	goText: function(component,event,helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "/article/Send-Us-a-Text-Message"
		});
		urlEvent.fire();
	},

	goCall: function(component,event,helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "/article/Customer-Care-Contact-Information"
		});
		urlEvent.fire();
	},

	goShop: function(component,event,helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "https://www.overstock.com"
		});
		urlEvent.fire();
	}
})