/**
 * Created by mcallison on 8/8/2018.
 */
({
    doInit: function(component,event,helper){
    	console.log("OstkEkbBreadcrumbsController.doInit - enter");
        var url = window.location.href;
        url = url.split("/");
        console.log(url);
        switch (url[5]) {
            case "topiccatalog":
            	helper.updateCrumb(component,"t1","Topic Catalog");
                break;
            case "topic":
	            switch (url[7]) {
		            case "orders":
			            helper.updateCrumb(component,"t1","Orders");
			            break;
		            case "shipping-and-returns":
			            helper.updateCrumb(component,"t1","Shipping and Returns");
			            break;
		            case "product-information":
			            helper.updateCrumb(component,"t1","Product Information");
			            break;
		            case "my-account":
			            helper.updateCrumb(component,"t1","My Account");
			            break;
		            case "rewards-services":
			            helper.updateCrumb(component,"t1","Overstock Services");
			            break;
		            case "about-overstock":
			            helper.updateCrumb(component,"t1","About Overstock");
			            break;
		            default:
			            break;
	            }
                break;
            case "article":
	            helper.updateCrumb(component,"t2",url[6]);
                break;
	        case "global-search":
	        	helper.updateCrumb(component,"t1","Search Results");
	        	break;
            default:
                break;
        }
	    console.log("OstkEkbBreadcrumbsController.doInit - exit");
    },

	goCrumb : function(component,event,helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		var url = sessionStorage.getItem("breadcrumb--tier1url");
		urlEvent.setParams({
			"url": url
		});
		urlEvent.fire();
	},



})