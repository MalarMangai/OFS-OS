/**
 * Created by mcallison on 8/8/2018.
 */
({
	updateCrumb: function(cmp,tier,crumb) {
		console.log("OstkEkbBreadcrumbsHelper.updateCrumb - enter");

		if(tier=="t1") {
			sessionStorage.setItem("breadcrumb--tier1", crumb);
			sessionStorage.setItem("breadcrumb--tier1url",window.location.href);
			sessionStorage.removeItem("breadcrumb--tier2");
			cmp.set("v.tier1",crumb);
			cmp.set("v.tier2enabled",false);
		}
		else {
			var t1 = sessionStorage.getItem("breadcrumb--tier1");
			var t1url = sessionStorage.getItem("breadcrumb--tier1url");
			cmp.set("v.tier1", t1);
			cmp.set("v.tier1url",t1url);
			cmp.set("v.tier2enabled",true);
			cmp.set("v.tier2", crumb);
		}

		console.log(crumb);

		console.log("OstkEkbBreadcrumbsHelper.updateCrumb - exit");
	}
})