/**
 * Created by mcallison on 6/7/18.
 */
({
    goContactUs: function(component, event, helper) {
        console.log("OstkEkbButtonContactUs:goContactUs: enter");
        var modalHeader;
        var modalBody;
        var modalFooter;

        $A.createComponents([
            ["c:OstkEkbButtonContactUsModalHeader",{}],
            ["c:OstkEkbButtonContactUsModal",{}],
            ["c:OstkEkbButtonContactusModalFooter",{}]
        ],
            function(components,status) {
                if(status==="SUCCESS") {
                    modalHeader = components[0];
                    modalBody = components[1];
                    modalFooter = components[2];
                    component.find('overlayLib').showCustomModal({
                        header: modalHeader,
                        body: modalBody,
                        footer: modalFooter,
                        showCloseButton: false,
                        cssClass: "contactusModal slds-modal_medium",
                        closeCallback: function() {
                            console.log("Modal closed");
                        }
                    })
                }
            }
        );

        console.log("OstkEkbButtonContactUs:goContactUs: exit");
    }
})