/**
 * Created by mcallison on 6/8/18.
 */
({
    doInit: function(component,event,helper) {

        console.log('OstkEkbButtonContactUsModal:doInit - enter');

        // helper.getContactUsArticle(component);
        helper.checkMobile(component);
        helper.getTextNumber(component);
        helper.getContactUsModalBodyTitle(component,'v.ModalIntro','Contact Us Modal Body Intro');
        helper.getContactTileToggle(component,'v.usHoursToggle','Contact Us Modal Body US Hours Toggle');
        helper.getContactTileToggle(component,'v.intlHoursToggle','Contact Us Modal Body INTL Hours Toggle');
        helper.getContactTileToggle(component,'v.chatHoursToggle','Contact Us Modal Body Chat Toggle');
        helper.getContactTileToggle(component,'v.phoneHoursToggle','Contact Us Modal Body Phone Toggle');
        helper.getContactTileToggle(component,'v.textHoursToggle','Contact Us Modal Body Text Toggle');
        helper.getContactTileToggle(component,'v.intlContactToggle','Contact Us Modal Body INTL Contact Toggl');
        helper.getContactTileToggle(component,'v.requestHelpToggle','Contact Us Modal Body Request Help Toggl');
        helper.getContactTileToggle(component,'v.socialToggle','Contact Us Modal Body Social Toggle');
        helper.getContactUsModalBodyTitle(component,'v.ModalUSHoursTitle','Contact Us Modal Body US Hours Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalINTLHoursTitle','Contact Us Modal Body INTL Hours Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalPhoneTitle','Contact Us Modal Body Phone Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalChatTitle','Contact Us Modal Body Chat Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalTextTitle','Contact Us Modal Body Text Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalINTLContactTitle','Contact Us Modal Body INTL Contact Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalReqHelpTitle','Contact Us Modal Body Request Help Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalSocialTitle','Contact Us Modal Body Social Title');
        helper.getContactUsModalBodyTitle(component,'v.ModalUSHoursBody','Contact Us Modal Body US Hours Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalINTLHoursBody','Contact Us Modal Body INTL Hours Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalChatBody','Contact Us Modal Body Chat Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalPhoneBody','Contact Us Modal Body Phone Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalTextBody','Contact Us Modal Body Text Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalINTLContactBody','Contact Us Modal Body INTL Contact Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalReqHelpBody','Contact Us Modal Body Request Help Body');
        helper.getContactUsModalBodyTitle(component,'v.ModalSocialBody','Contact Us Modal Body Social Body');

        console.log('OstkEkbButtonContactUsModal:doInit - exit');

    },

	afterJSLoaded: function (component, event, helper) {
    var i = setInterval(function() {
      if (!!document.getElementsByClassName("abc-contact-us")[0]) {
          console.log('Start abc-contact-us')
        window.clearInterval(i);
        var AppleBusinessChat=function(e){"use strict";const t="1.2.0",n=[10,13,4],r=[11,3];var i=/\((Macintosh|iPhone|iPad|(?:iPod(?:\x20touch)?));.*\x20((?:\d[_.]{0,1})+)[^)]*\)\x20/i;function o(){var e=window.navigator&&window.navigator.userAgent||"";return function(e,t){var n=u(e);if(!n.type)return!1;if("MACINTOSH"!==n.type.toUpperCase())return!1;if(!a(n.version,t))return!1;return!0}(e,n)||function(e,t){var n=u(e);if(!n.type)return!1;if(!["IPHONE","IPAD","IPOD","IPOD TOUCH"].includes(n.type.toUpperCase()))return!1;if(!a(n.version,t))return!1;return!0}(e,r)}function u(e){var t=i.exec(e);return t?{type:t[1],version:function(e){var t=[],n=/(\d+)/g,r=null;do{if(r=n.exec(e)){var i=parseInt(r[0],10);if("number"!=typeof i)return null;t.push(i)}}while(r);return t}(t[2])}:null}function a(e,t){if(void 0===e)return!1;for(var n=0,r=t.length;n<r;n++){var i=t[n],o=parseInt(e[n],10);if(isNaN(o)&&(o=0),o>i)return!0;if(o<i)return!1}return!0}const s=["en-us","it-it","de-de","fr-fr","ja-jp","es-es","ko-kr"],c={en:["us"],it:["it"],de:["de"],fr:["fr"],ja:["jp"],es:["es"],ko:["kr"]},l="en-us",d=["ButtonTitle"],f={"en-us":["Chat with Messages"],"it-it":["Chat con Messaggi"],"de-de":["Chat mit â€žNachrichtenâ€œ"],"fr-fr":["Discuter avec Messages"],"ja-jp":["â€œãƒ¡ãƒƒã‚»ãƒ¼ã‚¸â€ã§ãƒãƒ£ãƒƒãƒˆ"],"es-es":["Chatear con Mensajes"],"ko-kr":["ë©”ì‹œì§€ì—ì„œ ëŒ€í™”í•˜ê¸°"]},p={"en-us":[163,52,6],"it-it":[156,52,6],"de-de":[163,52,6],"fr-fr":[163,52,6],"ja-jp":[149,52,6],"es-es":[156,52,6],"ko-kr":[111,52,6]};var v={"zh-hk":"zh-tw","nb-no":"no-no","nn-no":"no-no",nb:"no-no",nn:"no-no",he:"iw-il","he-il":"iw-il",pt:"pt-pt","vi-vn":"vi-vi","es-419":"es-mx","es-xl":"es-mx",nl:"nl-nl"},h=[163,52,6];function m(){return l}function g(e){if("string"==typeof e){var t=e.toLowerCase().replace(/_/g,"-"),n=v[t];void 0!==n&&(t=n);var r=t.split("-"),i=r[0],o=r[1],u=c[i];if(u&&u.indexOf(o)>=0)return t;if(u&&0!==u.length)return i+"-"+u[0]}}function w(e){return s.indexOf(g(e))>-1}function b(){var e,t=g((e=window.navigator)&&void 0!==e.languages?e.languages[0]:e&&e.language);return w(t)?t:l}function I(e,t){var n=d.indexOf(t);if(n<0)return t;e=g(e);var r=f[e];return void 0===r?t:r[n]||t}function x(e,n,r){if(!y(e))throw new Error('Unsupported theme "'+e+'"');var i=function(e,t){var n="@"+t+"x",r=e.lastIndexOf(".");return e.slice(0,r)+n+e.slice(r)}("business-chat-button-"+e+".png",n);return function(e){var t=e.url,n=e.themeName,r=e.locale,i=(e.version,e.pixelRatio),o=function(e){return e=g(e),p[e]||h}(r),u=o[0],a=o[1],s=o[2];return{theme:n,locale:r,pixelRatio:i,url:t,width:u,height:a,spriteLocations:{normal:[0,0],hover:[0,a+s],press:[0,2*a+2*s]}}}({url:"https://static.cdn-apple.com"+function(){var e=[],t=arguments.length;for(;t--;)e[t]=arguments[t];return("/"+e.join("/")).replace(/\/+/g,"/")}("businesschat","start-chat-button",t,r,"images",i),themeName:e,pixelRatio:n,locale:r,PKG_VERSION:t})}function y(e){return"light"===e||"dark"===e}function j(e,t,n){void 0===n&&(n={});var r=function(e,t,n){var r=function(e){return"string"==typeof e&&e.length>0};if(!P(e))throw new Error('Not a valid business id: "'+e+'"');var i="https://bcrw.apple.com/urn:biz:"+e,o=[];r(t)&&o.push("biz-intent-id="+t);r(n)&&o.push("biz-group-id="+n);o.length>0&&(i+="?"+o.join("&"));return encodeURI(i)}(t,(n=function(e,t){var n=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r=function(e){return void 0===e};for(var i in t){var o=n(t,i)&&!r(t[i]),u=!n(e,i)||r(e[i]);o&&u&&(e[i]=t[i])}return e}(n,{theme:"light",locale:m(),businessIntentId:"",businessGroupId:""})).businessIntentId,n.businessGroupId);if(e.childElementCount>0){var i='a[href="'+r+'"]';if(e.querySelectorAll(i).length>0)return}var o,u=function(e,t){var n=e.url,r=e.width,i=e.height,o=e.spriteLocations,u=document.createElement("img");u.src=n,u.alt=I(t,"ButtonTitle"),u.width=r,u.height=i,u.draggable=!1,u.ondragstart=function(){return!1};var a=function(e){var t=e[0],n=e[1];return u.style.objectPosition=t+"px -"+n+"px"};return u.style.objectFit="cover",u.style.objectPosition=a(o.normal),u.onmouseleave=u.onmouseup=function(){return a(o.normal)},u.onmouseenter=function(){return a(o.hover)},u.onmousedown=function(){return a(o.press)},u}(x(n.theme,((o=Math.floor(window.devicePixelRatio||1))<1&&(o=1),o>3&&(o=3),o),n.locale),n.locale),a=function(e,t){var n=document.createElement("a");return n.href=e,n.title=I(t,"ButtonTitle"),n}(r,n.locale);a.appendChild(u),e.appendChild(a)}function C(e){var t=e.dataset.appleBusinessId;if(P(t)){var n=(e.dataset.appleButtonTheme||"").toLowerCase();y(n)||(n=void 0);var r=g(e.dataset.appleButtonLocale||b());w(r)||(r=m()),j(e,t,{theme:n,locale:r,businessIntentId:e.dataset.appleBusinessIntentId,businessGroupId:e.dataset.appleBusinessGroupId})}}function P(e){return"string"==typeof e&&e.trim().length>0}e.isSupported=function(){return!1},e.setUpButtons=function(){};var B,O,N=t,E={buildNumber:"1818ProjectDev17",masteringNumber:"M1818ProjectDev17"};return o()&&((O=function(e){return void 0!==e})(document.querySelectorAll)&&O(document.childElementCount)&&O(document.readyState)&&O(window.addEventListener)&&O(Promise))&&(e.isSupported=function(){return o()},e.setUpButtons=function(){return function(e){for(var t=document.querySelectorAll(e),n=0,r=t.length;n<r;n++)C(t[n])}("div.apple-business-chat-button-container")},B=function(){return e.setUpButtons()},"complete"!==document.readyState?window.addEventListener("load",function e(){B(),window.removeEventListener("load",e)}):B()),e.version=N,e.__BUILD_INFO=E,e}({});
          console.log('Done abc-contact-us')
      }
    }, 100);
                              
	}
})