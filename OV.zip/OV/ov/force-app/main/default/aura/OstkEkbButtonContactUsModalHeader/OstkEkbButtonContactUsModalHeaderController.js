/**
 * Created by mcallison on 6/8/18.
 */
({
    doInit: function(component,event,helper) {
        console.log('OstkEkbButtonContactUsModalHeader:doInit - enter');

        helper.populateHeader(component);

        console.log('OstkEkbButtonContactUsModalHeader:doInit - exit');
    },

    closeModal: function(component,event,helper) {

        console.log('OstkEkbButtonContactUsModalHeader:closeModal - enter');

        // Closes the modal window
        component.find("overlayLib").notifyClose();

        console.log('OstkEkbButtonContactUsModalHeader:closeModal - exit');
    },

})