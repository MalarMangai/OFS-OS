/**
 * Created by mcallison on 6/25/18.
 */
({
    populateHeader: function(cmp) {
        console.log("OstkEkbButtonContactUsModalHeaderHelper.populateHeader: enter");

        var action = cmp.get("c.getModalHeader");
        action.setCallback(this, function(res) {
           var header = res.getReturnValue();
           var state = res.getState();
           if(state==="SUCCESS") {
               cmp.set("v.headerText", header);
           }
           else {
               state==="FAILURE";
           }
        });

        $A.enqueueAction(action);

        console.log("OstkEkbButtonContactUsModalHeaderHelper.populateHeader: exit");
    },

})