/**
 * Created by mcallison on 6/8/18.
 */
({
    closeModal: function(component,event,helper) {

        console.log('OstkEkbButtonContactusModalFooter:closeModal - enter');

        // Closes the modal window
        component.find("overlayLib").notifyClose();

        console.log('OstkEkbButtonContactusModalFooter:closeModal - exit');
    }
})