/**
 * Created by mcallison on 6/6/18.
 */
({
    goShopNow: function(component,event,helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "https://www.overstock.com"
        });
        urlEvent.fire();
    },

})