/**
 * Created by mcallison on 6/6/18.
 */
({
    goShowAllArticles: function(component,event,helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/topiccatalog"
        });
        urlEvent.fire();
    },

})