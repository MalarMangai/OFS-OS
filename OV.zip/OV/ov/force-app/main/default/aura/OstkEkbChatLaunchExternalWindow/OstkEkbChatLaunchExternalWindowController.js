/**
 * Created by mcallison on 6/12/18.
 */
({
    doInit: function(component, event, helper) {
        console.log("OstkEkbChatLaunchExternalWindowController.doInit: enter");

        helper.checkMobile(component);

        helper.getChatButtonLabel(component);

        helper.getTextButtonLabel(component);

        helper.getTextNumber(component);

        console.log("OstkEkbChatLaunchExternalWindowController.doInit: exit");
    },

    goChat: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowController:goChat - enter');

        helper.logClientInfo(component,'CHAT');

        window.open('/help/apex/liveagent','chatnew','width=555,height=620,scrollbars=1');

        console.log('OstkEkbChatLaunchExternalWindowController:goChat - exit');
    },

    goText: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowController:goText - enter');
        helper.logClientInfo(component,'TEXT');
        console.log('OstkEkbChatLaunchExternalWindowController:goText - exit');
    }
})