/**
 * Created by mcallison on 7/16/2018.
 */
({
    doInit: function(component, event, helper) {

        console.log("OstkEkbChatLaunchExternalWindowBSVController.doInit: enter");

        helper.checkMobile(component);
        helper.getConfigs(component,"v.textNumber","SMS Main Number");
        helper.getConfigs(component,"v.chatLabel","EKB Chat Button Label");
        helper.getConfigs(component,"v.textLabel","EKB Text Button Label");

        console.log("OstkEkbChatLaunchExternalWindowBSVController.doInit: exit");
    },

    goChat: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowBSVController:goChat - enter');

        helper.logClientInfo(component,'CHAT');

        window.open('/help/apex/liveagent','chatnew','width=555,height=620,scrollbars=1');

        console.log('OstkEkbChatLaunchExternalWindowBSVController:goChat - exit');
    },

    goText: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowBSVController:goText - enter');

        var modalHeader;
        var modalBody;
        var modalFooter;

        $A.createComponents([
            ["c:OstkEkbChatLaunchExternalWindowBSVHeader",{}],
            ["c:OstkEkbChatLaunchExternalWindowBSVFooter",{}],
            ["c:OstkEkbChatLaunchExternalWindowBSVBody",{}]
            ],
            function(components,status) {
                if(status==="SUCCESS") {
                    modalHeader = components[0];
                    modalFooter = components[1];
                    modalBody = components[2];
                    component.find('overlayLib').showCustomModal({
                        header: modalHeader,
                        footer: modalFooter,
                        body: modalBody,
                        cssClass: "bsvModal",
                        showCloseButton: false,
                        closeCallback: function() {
                            console.log("Modal closed");
                        }
                    })
                }
            }
        );
        console.log('OstkEkbChatLaunchExternalWindowBSVController:goText - exit');
    },

})