/**
 * Created by mcallison on 7/17/2018.
 */
({
    doInit: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowBSVBodyController:doInit - enter');

        helper.getConfigs(component,"v.introText","BSV Modal Body Intro");
        helper.getConfigs(component,"v.textNumber","SMS Main Number");

        console.log('OstkEkbChatLaunchExternalWindowBSVBodyController:doInit - exit');
    },
    goChat: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowBSVBodyController:goChat - enter');

        helper.logClientInfo(component,'CHAT');
        window.open('/help/apex/liveagent','chatnew','width=555,height=620,scrollbars=1');
        component.find("overlayLib").notifyClose();

        console.log('OstkEkbChatLaunchExternalWindowBSVBodyController:goChat - exit');
    },

    goText: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowBSVBodyController:goText - enter');

        helper.logClientInfo(component,'TEXT');
        component.find("overlayLib").notifyClose();

        console.log('OstkEkbChatLaunchExternalWindowBSVBodyController:goText - exit');
    },

})