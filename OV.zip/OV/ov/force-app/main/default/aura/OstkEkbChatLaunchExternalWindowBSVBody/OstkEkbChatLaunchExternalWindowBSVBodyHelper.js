/**
 * Created by mcallison on 7/17/2018.
 */
({
    getConfigs: function(cmp,place,title) {
        console.log("OstkEkbChatLaunchExternalWindowBSVBodyController.getConfigs: enter");

        var action = cmp.get("c.getModalConfig");
        action.setParams({titleString:title});
        action.setCallback(this, function(res) {
            var header = res.getReturnValue();
            var state = res.getState();
            if(state==="SUCCESS") {
                cmp.set(place, header);
            }
            else {
                console.log("NO");
                state==="FAILURE";
            }
        });

        $A.enqueueAction(action);

        console.log("OstkEkbChatLaunchExternalWindowBSVBodyController.getConfigs: exit");
    },

    logClientInfo: function(cmp,iType) {

        console.log("OstkEkbChatLaunchExternalWindowBSVBodyController.logClientInfo: enter");

        var interaction = iType;
        var platform = $A.get("$Browser.formFactor");
        var platformSubType = "";

        if($A.get("$Browser.isPhone")){
            platformSubType = "Generic";
        }
        if($A.get("$Browser.isTablet")){
            platformSubType = "Tablet";
        }
        if($A.get("$Browser.isAndroid")){
            platformSubType = "Android";
        }
        if($A.get("$Browser.isIOS")){
            platformSubType = "iOS";
        }
        if($A.get("$Browser.isIPad")){
            platformSubType = "IPad";
        }
        if($A.get("$Browser.isIPhone")){
            platformSubType = "IPhone";
        }
        if($A.get("$Browser.isWindowsPhone")){
            platformSubType = "WindowsPhone";
        }

        var action = cmp.get("c.logClientInfo");
        action.setParams({
            interactionType:interaction,
            platformType:platform,
            subType:platformSubType});
        action.setCallback(this, function(response) {
            var heads = response.getReturnValue();
            var state = response.getState();
            if(state==="SUCCESS") {
                console.log(heads);
            }
            else {
                console.log("NO");
                state === "FAILURE";
            }
        });
        $A.enqueueAction(action);

        console.log("OstkEkbChatLaunchExternalWindowBSVBodyController.logClientInfo: exit");

    },
})