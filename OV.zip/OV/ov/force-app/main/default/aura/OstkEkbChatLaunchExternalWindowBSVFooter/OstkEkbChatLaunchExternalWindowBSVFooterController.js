/**
 * Created by mcallison on 7/17/2018.
 */
({
    closeModal: function(component,event,helper) {

        console.log('OstkEkbChatLaunchExternalWindowBSVFooterController:closeModal - enter');

        // Closes the modal window
        component.find("overlayLib").notifyClose();

        console.log('OstkEkbChatLaunchExternalWindowBSVFooterController:closeModal - exit');
    }
})