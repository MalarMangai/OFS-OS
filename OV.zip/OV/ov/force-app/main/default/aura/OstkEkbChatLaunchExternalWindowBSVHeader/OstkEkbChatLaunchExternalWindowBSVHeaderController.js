/**
 * Created by mcallison on 7/17/2018.
 */
({
    doInit: function(component,event,helper) {
        console.log('OstkEkbChatLaunchExternalWindowBSVHeaderController:doInit - enter');

        helper.populateHeader(component);

        console.log('OstkEkbChatLaunchExternalWindowBSVHeaderController:doInit - exit');
    },

    closeModal: function(component,event,helper) {

        console.log('OstkEkbChatLaunchExternalWindowBSVHeaderController:closeModal - enter');

        // Closes the modal window
        component.find("overlayLib").notifyClose();

        console.log('OstkEkbChatLaunchExternalWindowBSVHeaderController:closeModal - exit');
    }
})