/**
 * Created by mcallison on 7/17/2018.
 */
({
    populateHeader: function(cmp) {
        console.log("OstkEkbChatLaunchExternalWindowBSVHeaderHelper.populateHeader: enter");

        var action = cmp.get("c.getModalConfig");
        action.setParams({titleString:"BSV Modal Header Text"});
        action.setCallback(this, function(res) {
            var header = res.getReturnValue();
            var state = res.getState();
            if(state==="SUCCESS") {
                cmp.set("v.headerText", header);
            }
            else {
                console.log("NO");
                state==="FAILURE";
            }
        });

        $A.enqueueAction(action);

        console.log("OstkEkbChatLaunchExternalWindowBSVHeaderHelper.populateHeader: exit");
    }
})