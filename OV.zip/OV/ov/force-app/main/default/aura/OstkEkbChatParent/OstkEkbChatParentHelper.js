/**
 * Created by mcallison on 5/29/18.
 */
({
    setIframeURL: function(component) {
        var action = component.get("c.getIframeURL");

        action.setCallback(this, function(response){
            if(component.isValid() && response !== null && response.getState() == 'SUCCESS'){
                component.set("v.chatURL", response.getReturnValue());
            }
        });

        $A.enqueueAction(action);
    }
})