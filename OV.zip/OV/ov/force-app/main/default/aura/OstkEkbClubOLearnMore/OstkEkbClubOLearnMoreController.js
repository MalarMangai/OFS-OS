/**
 * Created by mcallison on 8/16/2018.
 */
({
	handleClick: function(component,event,helper) {
		console.log("OstkEkbClubOLearnMoreController.handleClick - enter");

		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "https://www.overstock.com/club-o-rewards-program"
		});
		urlEvent.fire();

		console.log("OstkEkbClubOLearnMoreController.handleClick - exit");
	}
})