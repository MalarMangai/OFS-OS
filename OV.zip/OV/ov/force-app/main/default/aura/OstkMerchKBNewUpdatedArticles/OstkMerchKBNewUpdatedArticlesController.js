({
    getArts: function(cmp){
        var action = cmp.get("c.getArticlesList");
        action.setCallback(this, function(response){
        	var arts = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
            	console.log(arts);
                cmp.set("v.articles", arts);
            }
            else {
            	state === "FAILURE";
            }
        });
     $A.enqueueAction(action);
    }
})