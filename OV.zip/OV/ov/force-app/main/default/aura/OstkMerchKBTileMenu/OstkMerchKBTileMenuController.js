({
	goSO : function(component, event, helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "https://www.supplieroasis.com"
		});
		urlEvent.fire();
	},
	requestArt : function(component, event, helper) {
		var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
			"url": "https://overstk.sharepoint.com/sites/Communities/training/trainingdevelopment/SitePages/Training Requests.aspx"
		});
		urlEvent.fire();
	}
})