/**
 * Created by mcallison on 4/3/18.
 */
({
    handleShowModal: function(component, event, helper) {
        console.log("OstkOrderTrackingFormController:handleShowModal: enter");

        var modalHeader;
        var modalBody;

        $A.createComponents([
                ["c:OstkOrderTrackingFormModalHeader",{}],
                ["c:OstkOrderTrackingFormModal",{}]
            ],
            function(components,status) {
                if(status==="SUCCESS") {
                    modalHeader = components[0];
                    modalBody = components[1];
                    component.find('overlayLib').showCustomModal({
                        header: modalHeader,
                        body: modalBody,
                        showCloseButton: false,
                        cssClass: "orderTrackingFormModal",
                        closeCallback: function() {
                            console.log("Modal closed");
                        }
                    })
                }
            }
        );

        console.log("OstkOrderTrackingFormController:handleShowModal: exit");
    },

})