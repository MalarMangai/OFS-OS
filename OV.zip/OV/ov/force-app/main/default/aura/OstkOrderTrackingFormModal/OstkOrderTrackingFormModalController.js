/**
 * Created by mcallison on 4/9/18.
 */
({
    doInit : function(component, event, helper) {
        var vfOrigin = "https://overstock.force.com";
        window.addEventListener("message", function(event) {
            if(event.origin !== vfOrigin) {
                return;
            }
            if(event.data.action =='alohaCallingCAPTCHA' && event.data.alohaResponseCAPTCHA == 'NOK') {
                alert("Please complete the captcha before submitting");
            }
            else if(event.data.action =='alohaCallingCAPTCHA' && event.data.alohaResponseCAPTCHA == 'OK') {
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams ({
                    "url": "https://www.overstock.com/myaccount/orders/trackpackage?orderId=" + component.get("v.ordernum") + "&trackingNumber=" + component.get("v.tracknum")
                });
                urlEvent.fire();
            }
        }, false);
    },

    trackOrder : function(component,event,helper) {
        var message = 'alohaCallingCAPTCHA';
        var vfOrigin = "https://overstock.force.com";
        var vfWindow = component.find("vfFrame").getElement().contentWindow;
        vfWindow.postMessage({action: "alohaCallingCAPTCHA"}, vfOrigin);
    }
})