/**
 * Created by mcallison on 7/3/2018.
 */
({
    trackOrder: function(component,event,helper) {
        var myEvent = $A.get("e.c:OstkOrderTrackingFormEvent");
        myEvent.setParams({"data":"Test"});
        myEvent.fire();
    },

    closeModal: function(component,event,helper) {

        console.log('OstkOrderTrackingFormModalFooter:closeModal - enter');

        // Closes the modal window
        component.find("overlayLib").notifyClose();

        console.log('OstkOrderTrackingFormModalFooter:closeModal - exit');
    }
})