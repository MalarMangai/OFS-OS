/**
 * Created by mcallison on 7/3/2018.
 */
({
    doInit: function(component,event,helper) {
        console.log('OstkOrderTrackingFormModalHeaderController:doInit - enter');

        helper.populateHeader(component);

        console.log('OstkOrderTrackingFormModalHeaderController:doInit - exit');
    },

    closeModal: function(component,event,helper) {

        console.log('OstkOrderTrackingFormModalHeaderController:closeModal - enter');

        // Closes the modal window
        component.find("overlayLib").notifyClose();

        console.log('OstkOrderTrackingFormModalHeaderController:closeModal - exit');
    }
})