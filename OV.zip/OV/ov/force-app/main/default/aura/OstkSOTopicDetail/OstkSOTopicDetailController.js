/**
 * Created by mcallison on 9/4/2018.
 */
({
	doInit: function(component,event,helper) {
		console.log("OstkSOTopicDetailController.doInit - enter");

		helper.setCommunityName(component);

		component.set("v.sortField","Hits");
		component.set("v.sortDir","DESC");

		helper.getTopicArticles(component,component.get("v.sortField"),component.get("v.sortDir"));

		console.log("OstkSOTopicDetailController.doInit - exit");
	},

	listReSort: function (component,event,helper) {
		console.log("OstkSOTopicDetailController.listReSort - enter");

		var sortField = component.get("v.sortField");
		var sortDir = component.get("v.sortDir");
		var sortValue = component.find('sortDropdown').get('v.value');
		console.log(sortValue);

		switch (sortValue) {
			case "alpha":
				component.set("v.sortField","Name");
				component.set("v.sortDir","ASC");
				break;
			case "hits":
				component.set("v.sortField","Hits");
				component.set("v.sortDir","DESC");
			default:
				break;
		}

		helper.getTopicArticles(component,component.get("v.sortField"),component.get("v.sortDir"));

		console.log("OstkSOTopicDetailController.listReSort - exit");
	}
})