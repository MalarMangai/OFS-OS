/**
 * Created by mcallison on 9/4/2018.
 */
({
	setCommunityName: function(cmp) {
		var communityName = window.location.href.split('/')[3];
		cmp.set('v.communityName',communityName);
	},

	getTopicArticles: function(cmp,sortField,sortDir) {
		console.log("OstkSOTopicDetailHelper.getTopicName - enter");

		var currentTopicId = window.location.href.split('/')[6];

		var action = cmp.get("c.getArticlesList");
		action.setParams({
			topicId: currentTopicId,
			sortField : sortField,
			sortDir : sortDir
		});

		action.setCallback(this, function(res) {
			var state = res.getState();
			var articles = res.getReturnValue();
			if(state === "SUCCESS") {
				cmp.set('v.articles',articles);
			}
			else {
				console.log('STATE - ' + state);
				var errors = res.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						console.log("Error message: " +
						errors[0].message);
					}
				} else {
					console.log("Unknown error");
				}
			}
		});

		$A.enqueueAction(action);

		console.log("OstkSOTopicDetailHelper.getTopicName - exit");
	}
})