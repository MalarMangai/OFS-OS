({
  handleRecordUpdated: function(component, event, helper) {
    var eventParams = event.getParams();
    if (
      eventParams.changeType === "LOADED" ||
      eventParams.changeType === "CHANGED"
    ) {
      var record = component.get("v.recordData");
      var phoneNumber = (record.Account && (record.Account.PersonMobilePhone ||record.Account.Phone))

      var appEvent = $A.get("e.goquiq:QuiqData");
      appEvent.setParams({ quiqData: { phoneNumber: phoneNumber } });
      appEvent.fire();
    }
  }
});