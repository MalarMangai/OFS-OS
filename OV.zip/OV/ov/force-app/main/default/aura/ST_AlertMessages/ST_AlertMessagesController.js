({
  handleNewEvent: function(cmp, event, helper) {
    if (helper.shouldEventBeHandled(cmp, event)) {
      helper.handleNewEvent(cmp, event);
    }
  },

  removeMessage: function(cmp, event, helper) {
    var index = event.target.dataset.msgIndex;
    helper.removeMessage(cmp, index);
  },

  handleClearMessagesEvent: function(cmp, event, helper) {
    if (helper.shouldEventBeHandled(cmp, event)) {
      helper.clearMessages(cmp);
    }
  },

  //helper method for extracting errors from Aura Action error object, to be used by parent component
  getExtractedErrors: function(cmp, event, helper) {
    var params = event.getParam('arguments');
    if (params) {
      return helper.getExtractedMessagesFromError(params.errorObject);
    }
    return [];
  }
})