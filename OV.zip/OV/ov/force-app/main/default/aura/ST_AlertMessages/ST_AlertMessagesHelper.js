({

  handleNewEvent: function(cmp, event) {
    var newMessageList = [];
    if ($A.util.isEmpty(event.getParam('message'))) {
      var extractedMessageList = this.getExtractedMessagesFromError(event.getParam('errorObject'));
      Array.prototype.push.apply(newMessageList, extractedMessageList);
    } else {
      newMessageList.push(event.getParam('message'));
    }

    var variant = event.getParam('variant') || 'ALERT';
    this.handleNewMessages(cmp, newMessageList, variant);
  },

  handleNewMessages: function(cmp, messageList, variant) {
    if (variant === 'ALERT') {
      var currentMessageList =  cmp.get('v.messageList');
      Array.prototype.push.apply(currentMessageList, messageList);
      cmp.set('v.messageList', currentMessageList);
    } else if (variant === 'TOAST') {
      messageList.forEach(function(msg) {
        $A.get('e.force:showToast').setParams({
          type: 'error',
          message: msg
        }).fire();
      });
    }
  },

  removeMessage: function(cmp, index) {
    var messageList = cmp.get('v.messageList');
    messageList.splice(index, 1);
    cmp.set('v.messageList', messageList);
  },

  clearMessages: function(cmp) {
    cmp.set('v.messageList', []);
  },

  shouldEventBeHandled: function(cmp, event) {
    var cmpIdentifier = cmp.get('v.cmpIdentifier');
    var evtCmpIdentifier = event.getParam('cmpIdentifier');

    return ($A.util.isEmpty(cmpIdentifier) && $A.util.isEmpty(evtCmpIdentifier)
            || cmpIdentifier === evtCmpIdentifier);
  },

  getExtractedMessagesFromError: function(error) {
    var messageList = [];

    (function parseObjectMessages(obj) {
      var result = null;
      if ($A.util.isArray(obj)) {
        for (var i = 0; i < obj.length; i++) {
          parseObjectMessages(obj[i]);
        }
      }
      else {
        for (var prop in obj) {
          if (prop === 'message') {
            messageList.push(obj[prop]);
          }
          if ($A.util.isObject(obj[prop]) || $A.util.isArray(obj[prop])) {
            parseObjectMessages(obj[prop]);
          }
        }
      }
    })(error);

    return messageList;
  }

})