({
  doInit: function(cmp, event, helper) {
    helper.getCaseDetailsAndSetupIframeUrl(cmp);
    //helper.refreshDetailTab(cmp);
  },

  handleIframeReload: function(cmp, event, helper) {
    var params = event.getParam('arguments');
    if (params) {
      helper.getCaseDetailsAndSetupIframeUrl(cmp, params.callback);
    }
  }

})