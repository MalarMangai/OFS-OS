({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getCaseDetailsAndSetupIframeUrl: function(cmp, callback) {
    var helper = this;

    var action = cmp.get("c.getCaseRecordInitialSetup");
    action.setParams({
      caseId: cmp.get('v.recordId')
    });
    action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          var initialSetup = response.getReturnValue();
          cmp.set('v.caseRecord', initialSetup.caseObj);
          if ($A.util.isEmpty(cmp.get('v.csAppBaseUrl'))) {
            cmp.set('v.csAppBaseUrl', initialSetup.csAppUrl);
          }

          helper.setupIframeUrl(cmp);
          if (callback) {
            callback();
          }
        }
    });
    $A.enqueueAction(action);
  },

    refreshDetailTab: function(cmp) {
        console.log('ST_CSappCaseRecordHelper.refreshDetailTab - enter');
        cmp._postMessageHandler = $A.getCallback(function(event) {
          console.log('ST_CSappCaseRecordHelper.refreshDetailTab - refreshing view');
          $A.get('e.force:refreshView').fire();
        });
        window.addEventListener("message", cmp._postMessageHandler, false);
        console.log('ST_CSappCaseRecordHelper.refreshDetailTab - exit');
    },

  //================================================================================
  // IFRAME SETUP
  //================================================================================

  setupIframeUrl: function(cmp) {
    var caseDetails = cmp.get('v.caseRecord');
    var customerId = ($A.util.isEmpty(caseDetails.Contact) || $A.util.isEmpty(caseDetails.Contact.Account)?
                     null : caseDetails.Contact.Account.CustomerId__c);

    var paramList = [];
    if (!$A.util.isEmpty(customerId)) {
      paramList.push({ name: 'cst_id', value: customerId })
    }
    if (!$A.util.isEmpty(caseDetails.InvoiceId__c)) {
      paramList.push({ name: 'inv_id', value: caseDetails.InvoiceId__c })
    }
    if (!$A.util.isEmpty(caseDetails.Id)) {
      paramList.push({ name: 'caseId', value: caseDetails.Id })
    }

    paramList.push({ name: 'timestamp', value: Date.now() })

    var url = _ltngUtil.url.buildURLWithParams(cmp.get('v.csAppBaseUrl'), paramList);
    cmp.set('v.iframeUrl', url);
  }

})