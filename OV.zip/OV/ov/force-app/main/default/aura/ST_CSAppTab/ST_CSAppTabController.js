({
  handleInit: function(cmp, event, helper) {
    helper.initIFrameUrl(cmp);
    helper.createWindowMessageListener(cmp);
  },

  handleDestroy: function(cmp, event, helper) {
    helper.removeWindowEventListener(cmp);
  }
})