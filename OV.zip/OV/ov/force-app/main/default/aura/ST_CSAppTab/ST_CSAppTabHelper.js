({

  //================================================================================
  // COMPONENT INITIALIZATION
  //================================================================================

  initIFrameUrl: function(cmp) {
    var helper = this;
    if ($A.util.isEmpty(cmp.get('v.csAppBaseUrl'))) {
      var action = cmp.get("c.getTabCSAppUrl");
      action.setCallback(this, function(response) {
          var state = response.getState();
          if (state === "SUCCESS") {
            var csAppUrl = response.getReturnValue();
            cmp.set('v.csAppBaseUrl', csAppUrl);
            helper.setupIFrameUrl(cmp);
          }
      });
      $A.enqueueAction(action);
    } else {
      helper.setupIFrameUrl(cmp);
    }
  },

  setupIFrameUrl: function(cmp) {
    var phoneNumberUrlParam = _ltngUtil.url.getURLParameterByName('phone');
    var iframeUrl = cmp.get('v.csAppBaseUrl') + (phoneNumberUrlParam !== null? '?phone=' + phoneNumberUrlParam : '');
    cmp.set('v.iframeUrl', iframeUrl);
  },

  createWindowMessageListener: function(cmp) {
    var helper = this;

    cmp._postMessageHandler = $A.getCallback(function(event) {

      //discard messages from different origin
      /*if (!$A.util.isEmpty(cmp.get('v.iframeUrl'))
          && cmp.get('v.iframeUrl').indexOf(event.origin) !== -1) {
              console.log('XXX ' + event.data);
        helper.handleMessage(cmp, event.data);
      }*/
        helper.handleMessage(cmp, event.data); //TODO: URL whitelisting
    });
    window.addEventListener("message", cmp._postMessageHandler, false);
  },


  //================================================================================
  // IFRAME EVENT HANDLING
  //================================================================================

  handleMessage: function(cmp, data) {
      console.log(data);
    switch(data.messageType) {

      case 'OPEN_TAB':
        this.findRecordAndDisplay(cmp, data.value);
        break;
      case 'FOCUS_TAB':
        this.focusTab(cmp, data.value);
        break;
      case 'REFRESH_CASE_ACTIONS':
        console.log('Calling REFRESH_CASE_ACTIONS');
        this.refreshCaseActions();
        break;
      case 'REFRESH_PAGE':
        console.log('Calling REFRESH_PAGE');
        this.refreshPage();
        break;

    }
  },

  findRecordAndDisplay: function(cmp, extRecordId) {
    var helper = this;

    var action = cmp.get("c.getContactIdByExternalId");
    action.setParams({
      extId: extRecordId
    });
    action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          var recordId = response.getReturnValue();

          if (recordId !== null) {
            helper.openRecordInNewTab(cmp, recordId);
          } else {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: $A.get('$Label.c.ST_CSApp_ContactNotFound'),
                message: $A.get('$Label.c.ST_CSApp_NoMatchingRecord')
            });
            toastEvent.fire();
          }
        } else {
          var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: $A.get('$Label.c.ST_GenericErrorTitle'),
                message: $A.get('$Label.c.ST_GenericErrorMessage')
            });
            toastEvent.fire();
        }
    });
    $A.enqueueAction(action);
  },

  openRecordInNewTab: function(cmp, recordId) {
    var workspaceAPI = cmp.find("workspace");
    workspaceAPI.openTab({
        recordId: recordId,
        focus: true
    }).then(function(response) {
        workspaceAPI.focusTab({
            tabId: response
        });
    });
  },

  focusTab: function(cmp, tabType) {
    switch(tabType) {
      case 'Search':
        this.focusSearchTab(cmp,'CSApp Search');
        break;
      case 'Search20':
        this.focusSearchTab(cmp,'CSApp Search 2.0');
        break;
      default:
        break;
    }
  },

  focusSearchTab: function(cmp,title) {
    var workspaceAPI = cmp.find("workspace");

    workspaceAPI.getAllTabInfo().then(function(response) {
      for (var i = 0; i < response.length; i++) {
        var tab = response[i];
        if(tab.title == title){
          workspaceAPI.focusTab({tabId : tab.tabId});
        }
      }
    })
    .catch(function(error) {
      console.log(error);
    });
  },

  refreshCaseActions: function() {
    var appEvent = $A.get("e.c:ST_RefreshCaseActions");
    appEvent.fire();
  },

  refreshPage: function() {
      console.log('Invoking REFRESH_PAGE');
      $A.get('e.force:refreshView').fire();
      console.log('Finished REFRESH_PAGE');
  },


  //================================================================================
  // COMPONENT DESTROY
  //================================================================================

  removeWindowEventListener: function(cmp) {
    window.removeEventListener('message', cmp._postMessageHandler, false);
  }

})