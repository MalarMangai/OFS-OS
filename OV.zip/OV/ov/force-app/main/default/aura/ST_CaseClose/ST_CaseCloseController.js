({

  //================================================================================
  // COMPONENT STARTUP
  //================================================================================

  initialize: function(cmp, event, helper) {
    helper.getCase(cmp);
    helper.initNewCaseActionObj(cmp);
    helper.getCaseActions(cmp);
  },



  //================================================================================
  // UI ACTION HANDLERS
  //================================================================================

  handleAddActionBtnClick: function(cmp, event, helper) {
    helper.createCaseAction(cmp);
  },

  handleRemoveActionBtnClick: function(cmp, event, helper) {
    var caseActionId = event.getSource().get("v.value");
    helper.removeCaseAction(cmp, caseActionId);
  },

  handleCloseCaseBtnClick: function(cmp, event, helper) {
    helper.closeCase(cmp);
  },

  handleCaseActionsRefresh: function(cmp, event, helper) {
    helper.getCaseActions(cmp);
  },


  //================================================================================
  // OUTER RECORD CHANGES HANDLING
  //================================================================================

  handleRecordUpdate: function(cmp, event, helper) {
    var eventParams = event.getParams();
    if (eventParams.changeType === 'CHANGED') {
      helper.getCase(cmp);
    }
  }

})