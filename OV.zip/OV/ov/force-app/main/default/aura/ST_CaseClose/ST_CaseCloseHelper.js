({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getCase: function(cmp) {
    var helper = this;
    helper.clearErrors();

    cmp.set('v.isFetchingCase', true);
    var action = cmp.get('c.getCase');
    action.setParams({
        'caseId': cmp.get('v.recordId')
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        cmp.set('v.case', data);
        cmp.set('v.isCaseClosed', data.Status === 'Closed');
      });
      cmp.set('v.isFetchingCase', false);
    });
    $A.enqueueAction(action);
  },

  getCaseActions: function(cmp) {
    var helper = this;
    helper.clearErrors();

    cmp.set('v.isFetchingActions', true);
    var action = cmp.get('c.getCaseActionsForCaseId');
    action.setParams({
        'caseId': cmp.get('v.recordId')
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        cmp.set('v.caseActions', data);
      });
      cmp.set('v.isFetchingActions', false);
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // DATA MODIFICATION
  //================================================================================

  createCaseAction: function(cmp) {
    var helper = this;
    helper.clearErrors();

    cmp.set('v.isCreatingAction', true);
    var action = cmp.get('c.createCaseAction');
    action.setParams({
        caseAction: cmp.get('v.newCaseAction')
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        helper.initNewCaseActionObj(cmp);
        helper.getCaseActions(cmp);
      });
      cmp.set('v.isCreatingAction', false);
    });
    $A.enqueueAction(action);
  },

  removeCaseAction: function(cmp, caseActionId) {
    var helper = this;
    helper.clearErrors();

    cmp.set('v.isUpdatingActions', true);
    var action = cmp.get('c.removeCaseAction');
    action.setParams({
        caseActionId: caseActionId
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        helper.getCaseActions(cmp);
      });
      cmp.set('v.isUpdatingActions', false);
    });
    $A.enqueueAction(action);
  },

  closeCase: function(cmp) {
    var helper = this;
    helper.clearErrors();
    cmp.set('v.isUpdatingCase', true);

    var newCaseAction = cmp.get('v.newCaseAction');

    var action = cmp.get('c.closeCase');
    action.setParams({
        caseObj: cmp.get('v.case'),
        caseAction: ($A.util.isEmpty(newCaseAction.Category__c)? null : newCaseAction)
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        cmp.find('chatterFeedPoster').post(function() {
          cmp.set('v.isCaseClosed', true);
          $A.get('e.force:showToast').setParams({
            type: 'success',
            duration: 3000,
            message: $A.get('$Label.c.ST_CCCaseClosed')
          }).fire();
          helper.closeTabIfPossible(cmp);
          cmp.set('v.isUpdatingCase', false);
        });
      }, function() {
        cmp.set('v.isUpdatingCase', false);
      });
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  initNewCaseActionObj: function(cmp) {
    cmp.set('v.newCaseAction', {
      sObjectType: 'CaseAction__c',
      Case__c: cmp.get('v.recordId')
    });
  },

  closeTabIfPossible: function(cmp) {
    var workspaceAPI = cmp.find('workspace');
    workspaceAPI.getFocusedTabInfo().then(function(response) {
      var focusedTabId = response.tabId;
      workspaceAPI.closeTab({
        tabId: focusedTabId
      });
    })
    .catch(function(error) {
      $A.get('e.force:refreshView').fire();
    });
  },

  handleActionResponse: function(cmp, response, successCallback, errorCallback) {
    var state = response.getState();
    if (cmp.isValid() && state === 'SUCCESS') {
        successCallback(response.getReturnValue());
    } else {
      this.displayError(response.getError());
      if (errorCallback) {
        errorCallback();
      }
    }
  },

  displayError: function(errorObject) {
    $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
      errorObject: errorObject,
      cmpIdentifier: 'CASE_CLOSE_ALERTS',
    }).fire();
  },

  clearErrors: function() {
    $A.get('e.c:ST_AlertMessages_EVTClear').setParams({
      cmpIdentifier: 'CASE_CLOSE_ALERTS'
    }).fire();
  }

})