({

  //================================================================================
  // COMPONENT STARTUP
  //================================================================================

  initialize: function(cmp, event, helper) {
    helper.getCase(cmp);
  },

  //================================================================================
  // UI ACTION HANDLERS
  //================================================================================

  handleEscalationTypeChange: function(cmp, event, helper) {
    if (event.getParam('oldValue') === 'Other') {
      cmp.set('v.case.OwnerId', cmp.get('v.originalCaseOwner'));
    }
  },

  handleEscalateBtnClick: function(cmp, event, helper) {
    helper.handleEscalateBtnClick(cmp);
  },


  //================================================================================
  // OUTER RECORD CHANGES HANDLING
  //================================================================================

  handleRecordUpdate: function(cmp, event, helper) {
    var eventParams = event.getParams();
    if (eventParams.changeType === 'CHANGED') {
      helper.getCase(cmp);
    }
  }

})