({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getCase: function(cmp) {
    var helper = this;

    cmp.set('v.isFetchingCase', true);
    var action = cmp.get('c.getCase');
    action.setParams({
        'caseId': cmp.get('v.recordId')
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        cmp.set('v.case', data);
        cmp.set('v.isCaseClosed', data.Status === 'Closed');
        cmp.set('v.originalCaseOwner', data.OwnerId)
      });
      cmp.set('v.isFetchingCase', false);
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // DATA MODIFICATION
  //================================================================================

  handleEscalateBtnClick: function(cmp) {
    var caseObj = cmp.get('v.case');
    if (caseObj.EscalationType__c !== 'Other'
        && ($A.util.isEmpty(caseObj.Contact) ||
            $A.util.isEmpty(caseObj.Contact.Account) ||
            $A.util.isEmpty(caseObj.Contact.Account.CustomerId__c)))
    {
      $A.get('e.c:ST_Modal_EVTDisplay').setParams({
        cmpIdentifier: 'CASE_ESCALATE_MODAL',
        header: $A.get('$Label.c.ST_ECEscalationIssue'),
        message: $A.get('$Label.c.ST_ECMissingCustomerId'),
        showCloseButton: true
      }).fire();
    } else {
      this.escalateCase(cmp);
    }
  },

  escalateCase: function(cmp) {
    var helper = this;
    helper.clearErrors();
    cmp.set('v.isUpdatingCase', true);

    var caseObj = cmp.get('v.case');
    var action = cmp.get('c.escalateCase');
    action.setParams({
        caseObj: caseObj
    });
    action.setCallback(this, function(response) {
      helper.handleActionResponse(cmp, response, function(data) {
        cmp.find('chatterFeedPoster').post(function() {
          if (caseObj.EscalationType__c === 'Other') {
            $A.get('e.force:showToast').setParams({
              type: 'success',
              duration: 3000,
              message: $A.get('$Label.c.ST_ECCaseEscalated')
            }).fire();
            helper.closeTabIfPossible(cmp);
          } else {
            helper.startGuidedFlow(cmp, caseObj.EscalationType__c);
          }
          cmp.set('v.isUpdatingCase', false);
        });
      }, function() {
        cmp.set('v.isUpdatingCase', false);
      });
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  closeTabIfPossible: function(cmp) {
    var workspaceAPI = cmp.find('workspace');
    workspaceAPI.getFocusedTabInfo().then(function(response) {
      var focusedTabId = response.tabId;
      workspaceAPI.closeTab({
        tabId: focusedTabId
      });
    })
    .catch(function(error) {
      // fail gracefully
    });
  },

  startGuidedFlow: function(cmp, escalationType) {
    // if (cmp.find('user-info').get('v.userDetails').Profile.Name !== 'Customer Care (Pilot)') {
    //   this.startOldFlow(cmp, escalationType);
    // } else {
      this.startNewFlow(cmp, escalationType);
    // }
  },

  startOldFlow: function(cmp, escalationType) {
    var flowName;
    switch (escalationType) {
      case 'Shipping Address Change':
      case 'Cancellation':
        flowName = 'Cancellation_Request';
        break;
      case 'Parts Request':
      case 'Documentation Request':
        flowName = 'PartsRequest';
        break;
      case 'Invalid Tracking':
        flowName = 'InvalidTracking';
        break;
    }

    cmp.set('v.isRedirecting', true);
    $A.get("e.force:navigateToComponent").setParams({
      componentDef : "c:ST_TWFlowContainer",
      isredirect: true,
      componentAttributes: {
        flowName: flowName,
        caseId: cmp.get('v.recordId'),
        recordIdToRedirectOnFinish: cmp.get('v.recordId')
      }
    }).fire();
  },

  startNewFlow: function(cmp, escalationType) {
    var flowComponentName;
    switch (escalationType) {
      case 'Cancellation':
        flowComponentName = 'c:ST_GFCancelationRequest';
        break;
      case 'Invalid Tracking':
        flowComponentName = 'c:ST_GFInvalidTracking';
        break;
      case 'Shipping Address Change':
        flowComponentName = 'c:ST_GFShipAddrCorrection';
        break;
      case 'Parts Request':
      case 'Documentation Request':
        flowComponentName = 'c:ST_GFPartsRequest';
        break;
    }
    var flowStarter = cmp.find('flow-starter');
    flowStarter.startGuidedFlow(
      flowComponentName,
      [
        { attrName: 'caseId', attrValue: cmp.get('v.recordId') }
      ]
    );
  },


  handleActionResponse: function(cmp, response, successCallback, errorCallback) {
    var state = response.getState();
    if (cmp.isValid() && state === 'SUCCESS') {
        successCallback(response.getReturnValue());
    } else {
      this.displayError(response.getError());
      if (errorCallback) {
        errorCallback();
      }
    }
  },

  displayError: function(errorObject) {
    $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
      errorObject: errorObject,
      cmpIdentifier: 'CASE_ESCALATE_ALERTS',
    }).fire();
  },

  clearErrors: function() {
    $A.get('e.c:ST_AlertMessages_EVTClear').setParams({
      cmpIdentifier: 'CASE_ESCALATE_ALERTS'
    }).fire();
  }

})