({
  doInit: function(cmp, event, helper) {
    helper.replaceRecordId(cmp);
  }
})