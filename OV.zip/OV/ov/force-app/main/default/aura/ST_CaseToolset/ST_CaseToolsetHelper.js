({
  replaceRecordId: function(component) {
    var recordId = component.get("v.recordId");
    if (recordId.substring(0, 3) == '570') {
      var action = component.get("c.getCaseIdFromChat");
      action.setParams({
        chatId: recordId
      });

      action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          component.set("v.caseRecordId", response.getReturnValue());
        }
      });

      $A.enqueueAction(action);
    } else {
      component.set("v.caseRecordId", recordId);
    }
  }
})