({
    doInit: function(component, event, helper) {
        helper.setIframeURL(component);
    }
})