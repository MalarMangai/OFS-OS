({

  //================================================================================
  // COMPONENT LIFECYCLE
  //================================================================================

  handleLibraryLoad: function(cmp, event, helper) {
    cmp.set('v.isReady', true);
    helper.setupAutoResize(cmp);
    helper.toggleDisabledAttr(cmp);
  },

  handleDestroy: function(cmp, event, helper) {
    helper.handleDestroy(cmp);
  },


  //================================================================================
  // UI EVENTS
  //================================================================================

  handleClick: function(cmp, event, helper) {
    helper.updateCaretPosition(cmp);
    helper.performMentionCheck(cmp);
  },

  handleScroll: function(cmp, event, helper) {
    helper.updateCaretPosition(cmp);
  },

  handleInput: function(cmp, event, helper) {
    helper.updateCaretPosition(cmp);
    helper.performMentionCheck(cmp);
  },

  handleInputKeyPress: function(cmp, event, helper) {
    if (cmp.get('v.isOpen')) {
      helper.handleInputKeyPress(cmp, event);
    }
  },

  handleBlur: function(cmp, event, helper) {
    helper.handleFocusLost(cmp);
  },

  handleEntrySelection: function(cmp, event, helper) {
    var entryIndex = event.currentTarget.dataset.entryIndex;
    helper.handleEntrySelection(cmp, entryIndex);
  },

  preventDefault: function(cmp, event) {
    event.preventDefault();
  },

  handleDisabledChange: function(cmp, event, helper) {
    helper.toggleDisabledAttr(cmp);
  },


  //================================================================================
  // API EVENTS
  //================================================================================

  handlePost: function(cmp, event, helper) {
    var params = event.getParam('arguments');
    if (params) {
      helper.postFeedUpdate(cmp, params.callback);
    }
  }
})