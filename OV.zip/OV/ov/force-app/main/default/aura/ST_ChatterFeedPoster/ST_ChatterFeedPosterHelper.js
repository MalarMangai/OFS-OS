({

  //================================================================================
  // INIT SETUP
  //================================================================================

  setupAutoResize: function(cmp) {
    var textarea = cmp.find('textarea').getElement();

    cmp._autoResizeHandler = function() {
        textarea.style.height = '0px';
        textarea.style.height = (textarea.scrollHeight + 10) + 'px';
    }
    var eventList = ['change', 'keyup', 'keydown', 'paste', 'cut'];
    eventList.forEach(function(eventName) {
      textarea.addEventListener(eventName, cmp._autoResizeHandler, false);
    });
  },


  //================================================================================
  // INPUT CONTROLS
  //================================================================================

  updateCaretPosition: function(cmp) {
    var textarea = cmp.find('textarea').getElement();
    var coordinates = getCaretCoordinatesInPx(textarea, textarea.selectionEnd);
    var pxFromTop = coordinates.top - textarea.scrollTop;
    var pxFromLeft = coordinates.left - textarea.scrollLeft;

    cmp.set('v.caretPosition', {
      top: pxFromTop + coordinates.height,
      left: pxFromLeft,
      height: coordinates.height
    });
  },

  performMentionCheck: function(cmp) {
    var textarea = cmp.find('textarea').getElement();
    var value = textarea.value;
    var inputSelection = getInputSelection(textarea);

    var isMentionPhraseCorrect = false;

    if (inputSelection.start === inputSelection.end) {
      var substringBefore = value.substring(0, inputSelection.start);
      var lastMentionCharacterIndex = substringBefore.lastIndexOf('@');
      var substringAfter = value.substring(inputSelection.start);
      var nextParenthesesCharIndex  = substringAfter.search(/[\[\]]/g);

      if (lastMentionCharacterIndex !== -1
          && (nextParenthesesCharIndex === -1 || substringAfter.charAt(nextParenthesesCharIndex) === '[')) {
        var phrase = substringBefore.substring(lastMentionCharacterIndex + 1);

        var invalidCharacters = ['@', '[', ']', '\n'];
        var containsInvalidCharacters = invalidCharacters.some(function(e) {
          return phrase.indexOf(e) > -1;
        });
        if (!$A.util.isEmpty(phrase) && !containsInvalidCharacters && phrase.split(' ').length < 4) {
          isMentionPhraseCorrect = true;
          cmp.set('v.replacementIndexes', {
            start: lastMentionCharacterIndex + (substringBefore.charAt(lastMentionCharacterIndex - 1) === '['? -1 : 0),
            end: inputSelection.start
          });
          this.getMentionEntries(cmp, phrase);
        }
      }
    }

    if (!isMentionPhraseCorrect) {
      this.closeDropdown(cmp);
    }
  },

  setSelection: function(cmp, selectedEntry) {
    var textarea = cmp.find('textarea').getElement();
    var replacementIndexes = cmp.get('v.replacementIndexes');
    var value = textarea.value;
    var valuePartsToJoin = [
      value.slice(0, replacementIndexes.start),
      '[@' + selectedEntry.label + ']',
      value.slice(replacementIndexes.end)
    ];

    textarea.value = valuePartsToJoin.join('');
  },


  //================================================================================
  // AUTOCOMPLETE DATA LOAD
  //================================================================================

  getMentionEntries: function(cmp, searchTerm) {
    var helper = this;

    cmp.set('v.isLoadingEntries', true);
    this.openDropdown(cmp);
    helper.clearSuggestions(cmp);

    var thisActionTimestamp = Date.now();
    cmp._lastGetEntriesTimestamp = thisActionTimestamp;

    var action = cmp.get('c.getMentionLookupEntries');
    action.setAbortable();
    action.setParams({
      searchTerm: searchTerm
    });
    action.setCallback(this, function(response) {
      if (cmp._lastGetEntriesTimestamp === null || cmp._lastGetEntriesTimestamp !== thisActionTimestamp) {
        //discard action
        return;
      }
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseList = response.getReturnValue();
        helper.setEntryList(cmp, responseList);
      } else {
        console.warn('ERROR:', response.getError());
      }
      cmp.set('v.isLoadingEntries', false);
    });
    $A.enqueueAction(action);
  },

  setEntryList: function(cmp, entryList) {
    var helper = this;

    cmp.set('v.objEntryList', entryList);
    cmp.set('v.currentHighlightIndex', entryList.length == 1? 0 : -1);

    setTimeout($A.getCallback(function() {
      helper.verifyOpeningDirection(cmp);
    }));
  },


  //================================================================================
  // POST ACTION
  //================================================================================

  postFeedUpdate: function(cmp, callback) {
    var helper = this;

    var postBody = cmp.find('textarea').getElement().value;
    if (!$A.util.isEmpty(postBody)) {
      cmp.set('v.disabled', true);

      var action = cmp.get('c.postFeedUpdate');
      action.setParams({
        recordId: cmp.get('v.recordId'),
        postBody: cmp.find('textarea').getElement().value
      });
      action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === 'SUCCESS') {
          if (callback) {
            callback(true);
          }
          helper.clearTextareaValue(cmp);
       } else {
         console.warn('ERROR:', response.getError());
         if (callback) {
           callback(false);
         }
       }
       cmp.set('v.disabled', false);
      });
      $A.enqueueAction(action);
    } else {
      if (callback) {
        callback(true);
      }
    }
  },


  //================================================================================
  // UI MANAGEMENT
  //================================================================================

  handleFocusLost: function(cmp) {
    this.closeDropdown(cmp);
  },

  handleEntrySelection: function(cmp, entryIndex) {
    var objEntryList = cmp.get('v.objEntryList');
    var selectedEntry = objEntryList[entryIndex];

    this.closeDropdown(cmp);
    this.setSelection(cmp, selectedEntry);
    cmp.set('v.objEntryList', null);
  },

  handleInputKeyPress: function(cmp, event) {
    var helper = this;
    switch (event.keyCode) {
      case 38: //up arrow
        if (this.hasEntries(cmp)) {
          setTimeout($A.getCallback(function() {
            helper.highlightPrevEntry(cmp);
          }));
        }
        event.preventDefault();
        break;
      case 40: //down arrow
        if (this.hasEntries(cmp)) {
          setTimeout($A.getCallback(function() {
            helper.highlightNextEntry(cmp);
          }));
        }
        event.preventDefault();
        break;
      case 13: //enter
        if (this.hasEntries(cmp)) {
          this.selectHighlightedOption(cmp);
          event.preventDefault();
        }
        break;
      case 27: //escape
        this.closeDropdown(cmp);
        break;
    }
  },

  highlightNextEntry: function(cmp) {
    var currentHighlightIndex = cmp.get('v.currentHighlightIndex');
    var nextHighlightIndex = currentHighlightIndex + 1;

    var numOfOptions = cmp.get('v.objEntryList').length;
    if (nextHighlightIndex >= numOfOptions) {
      nextHighlightIndex = 0;
    }

    cmp.set('v.currentHighlightIndex', nextHighlightIndex);

    this.scrollToEntryIfOutOfView(cmp, nextHighlightIndex);
  },

  highlightPrevEntry: function(cmp) {
    var currentHighlightIndex = cmp.get('v.currentHighlightIndex');
    var nextHighlightIndex = currentHighlightIndex - 1;

    var numOfOptions = cmp.get('v.objEntryList').length;
    if (nextHighlightIndex < 0) {
      nextHighlightIndex = numOfOptions - 1;
    }

    cmp.set('v.currentHighlightIndex', nextHighlightIndex);

    this.scrollToEntryIfOutOfView(cmp, nextHighlightIndex);
  },

  selectHighlightedOption: function(cmp, event) {
    var currentHighlightIndex = cmp.get('v.currentHighlightIndex');
    if (currentHighlightIndex !== -1) {
      this.handleEntrySelection(cmp, currentHighlightIndex);
    }
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  openDropdown: function(cmp) {
    var helper = this;

    setTimeout($A.getCallback(function() {
      helper.verifyOpeningDirection(cmp);
      cmp.set('v.isOpen', true);
    }));
  },

  closeDropdown: function(cmp) {
    cmp.set('v.isOpen', false);
    cmp.set('v.isOpenAbove', true);
    cmp.set('v.isOpenLeft', true);
  },

  clearSuggestions: function(cmp) {
    cmp.set('v.objEntryList', null);
  },

  hasEntries: function(cmp) {
    return !$A.util.isEmpty(cmp.get('v.objEntryList'));
  },

  verifyOpeningDirection: function(cmp) {
    var container = cmp.find('lookup-dropdown').getElement();
    var anchor = cmp.find('lookup-dropdown-anchor').getElement();
    var cHeight = container.clientHeight;
    var cWidth = container.clientWidth;
    var clientRect = anchor.getBoundingClientRect();
    var aOffsetTop = clientRect.top;
    var aOffsetLeft = clientRect.left;
    cmp.set('v.isOpenAbove', cHeight + aOffsetTop + 40 > window.innerHeight);
    cmp.set('v.isOpenLeft', cWidth + aOffsetLeft > document.documentElement.clientWidth);
  },

  scrollToEntryIfOutOfView: function(cmp, entryIndex) {
      var container = cmp.find('lookup-dropdown').getElement();
      var entryList = cmp.find('lookup-entry');
      if (entryList.filter) {
        var entry = entryList.filter(function(item) {
          return parseInt(item.getElement().dataset.entryIndex) === entryIndex;
        })[0].getElement();

        var cTop = container.scrollTop;
        var cBottom = cTop + container.clientHeight;

        var eTop = entry.offsetTop;
        var eBottom = eTop + entry.clientHeight;

        if (eTop < cTop) {
          container.scrollTop -= (cTop - eTop);
        }
        else if (eBottom > cBottom) {
          container.scrollTop += (eBottom - cBottom);
        }
      }
  },

  toggleDisabledAttr: function(cmp) {
    var textarea = cmp.find('textarea').getElement();
    if (cmp.get('v.disabled')) {
      textarea.setAttribute('disabled', 'true');
    } else {
      textarea.removeAttribute('disabled');
    }
  },


  //================================================================================
  // CLEANUP
  //================================================================================

  handleDestroy: function(cmp) {
    var textarea = cmp.find('textarea').getElement();

    if (textarea) {
      //cleanup auto resize
      var autoResizeEventList = ['change', 'keyup', 'keydown', 'paste', 'cut'];
      autoResizeEventList.forEach(function(eventName) {
        textarea.removeEventListener(eventName, cmp._autoResizeHandler, false);
      });
    }
  },

  clearTextareaValue: function(cmp) {
      var textarea = cmp.find('textarea').getElement();

      if (cmp.isValid() && textarea) {
        textarea.value = '';
      }
  }


})