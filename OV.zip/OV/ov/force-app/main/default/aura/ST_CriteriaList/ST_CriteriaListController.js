({
  initialize: function (cmp, event, helper) {
    helper.getFieldsDetails(cmp)
  },


  //================================================================================
  // CRITERIA MANAGEMENT
  //================================================================================

  handleAddCriteriaRowClick: function (cmp, event, helper) {
    helper.addCriteriaRow(cmp);
  },

  handleRemoveCriteriaRowClick: function (cmp, event, helper) {
    var index = parseInt(event.getSource().get('v.name'));
    helper.removeCriteriaRow(cmp, index);
  }
})