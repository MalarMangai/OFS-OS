({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getFieldsDetails: function(cmp) {
    var action = cmp.get('c.getFieldsDetails');
    action.setParams({
      objectName: cmp.get('v.objectName'),
      filterableFields: cmp.get('v.filterableFields')
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseList = response.getReturnValue();
        cmp.set('v.fieldDetails', responseList);
      } else {
         console.error('Field details retrieval failed!', response.getError());
       }
       cmp.set('v.isLoaded', true);
    });
    $A.enqueueAction(action);
  },

  //================================================================================
  // CRITERIA LIST MANAGEMENT
  //================================================================================

  addCriteriaRow: function(cmp) {
    var criteriaList = cmp.get('v.criteriaList');
    criteriaList.push({});
    cmp.set('v.criteriaList', criteriaList);
  },

  removeCriteriaRow: function(cmp, index) {
    var criteriaList = cmp.get('v.criteriaList');
    criteriaList.splice(index, 1);
    cmp.set('v.criteriaList', criteriaList);
  }

})