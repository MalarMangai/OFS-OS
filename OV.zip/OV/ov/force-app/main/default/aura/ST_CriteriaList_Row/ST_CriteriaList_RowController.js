({

  initialize: function(cmp, event, helper) {
    helper.buildFieldDetailsMap(cmp);
    helper.setupFieldPicklist(cmp);

    var criteria = cmp.get('v.criteria');
    if (!$A.util.isEmpty(criteria.fieldName)) {
      helper.updateOperatorList(cmp, criteria.fieldName, false);
      helper.setSelectedFieldDetail(cmp, criteria.fieldName);
    }
  },

  handleFieldPicklistValueChange: function(cmp, event, helper) {
    helper.updateOperatorList(cmp, event.getParam('value'), true);
    helper.setSelectedFieldDetail(cmp, event.getParam('value'));
    helper.clearValue(cmp);
  }

})