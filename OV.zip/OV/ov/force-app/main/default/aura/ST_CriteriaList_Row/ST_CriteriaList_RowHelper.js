({

  //================================================================================
  // INITIAL SETUP
  //================================================================================

  buildFieldDetailsMap: function(cmp) {
    var fieldDetailsMap = {};
    cmp.get('v.fieldDetails').forEach(function(item) {
      fieldDetailsMap[item.fieldName] = item;
    });
    cmp.set('v.fieldDetailsMap', fieldDetailsMap);
  },

  setupFieldPicklist: function(cmp) {
    var fieldDetails = cmp.get('v.fieldDetails');

    var fieldList = fieldDetails.map(function(fieldDetail) {
      return {
        value: fieldDetail.fieldName,
        label: fieldDetail.fieldLabel
      };
    });
    cmp.set('v.fieldList', fieldList);
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  updateOperatorList: function(cmp, fieldName, preselectFirstOperator) {
    var fieldDetailsMap = cmp.get('v.fieldDetailsMap');
    var criteriaOperators = fieldDetailsMap[fieldName].criteriaOperators;
    var operatorList = criteriaOperators.map(function(operator) {
      return {
        value: operator.type,
        label: operator.label
      }
    });

    if (preselectFirstOperator) {
      cmp.set('v.criteria.operator', null);
      operatorList[0].isSelected = true;
    }
    cmp.set('v.operatorList', operatorList);
  },

  setSelectedFieldDetail: function(cmp, fieldName) {
    cmp.set('v.selectedFieldDetail', cmp.get('v.fieldDetailsMap')[fieldName]);
  },

  clearValue: function(cmp, fieldName) {
    cmp.set('v.criteria.value', null);
    cmp.set('v.criteria.valueList', null);
  }

})