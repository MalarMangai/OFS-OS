({
  doInit: function(cmp, event, helper) {
    helper.retrieveToken(cmp);
  },

  backToHome: function(cmp, event, helper) {
    var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
      "url": "/lightning/page/home"
    });
    urlEvent.fire();
  }
})