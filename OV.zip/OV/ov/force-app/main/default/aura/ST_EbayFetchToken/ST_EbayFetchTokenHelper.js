({
  retrieveToken: function(cmp) {
    var helper = this;
    cmp.set('v.isFetching', true);

    var trials = 0;
    var maxTrials = 3;

    function nextTrial(errorMessage) {
      trials++;
      if (trials <= maxTrials) {
        setTimeout($A.getCallback(function() {
          cmp.set('v.trialNumber', trials);
          helper.retrieveTokenTrial(cmp, nextTrial);
        }), trials > 1? 5000 : 0);
      } else {
        cmp.set('v.isFetching', false);
        cmp.set('v.isSuccess', false);
        cmp.set('v.errorMessage', errorMessage);
      }
    }

    nextTrial();
  },

  retrieveTokenTrial: function(cmp, onTrialFailure) {
    var action = cmp.get('c.fetchAuthToken');
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        cmp.set('v.isSuccess', true);
        cmp.set('v.isFetching', false);
      } else {
        var errors = response.getError();
        var errorMessage = cmp.find('alertMessagesHelper').getExtractedErrors(errors)[0];
        onTrialFailure(errorMessage);
      }
    });
    $A.enqueueAction(action);
  }
})