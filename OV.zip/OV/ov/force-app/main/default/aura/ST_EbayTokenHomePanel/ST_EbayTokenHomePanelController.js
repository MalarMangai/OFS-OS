({
  doInit: function(cmp, event, helper) {
    helper.getAuthTokenDetails(cmp);
  },

  startFetchTokenFlow: function(cmp, event, helper) {
    helper.getEbayRedirectionURL(cmp, function(url) {
      window.location.replace(url);
    })
  }
})