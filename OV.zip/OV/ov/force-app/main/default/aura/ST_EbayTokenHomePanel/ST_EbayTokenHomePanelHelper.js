({
  getAuthTokenDetails: function(cmp) {
    var helper = this;

    var action = cmp.get('c.getTokenDetails');
    action.setCallback(this, function(response) {
      var state = response.getState();

      if (state === 'SUCCESS') {
        cmp.set('v.tokenDetails', response.getReturnValue());
      }
      else {
        var errors = response.getError();
        helper.toastError(errors);
        cmp.set('v.isGettingURL', false);
      }
    });
    $A.enqueueAction(action);
  }, 

  getEbayRedirectionURL: function(cmp, callback) {
    var helper = this;
    
    cmp.set('v.isGettingURL', true);
    var action = cmp.get('c.getEbayRedirectionURL');
    action.setCallback(this, function(response) {
      var state = response.getState();

      if (state === 'SUCCESS') {
        // flag for getting url is not set to false, because of redirection
        callback(response.getReturnValue());
      }
      else {
        var errors = response.getError();
        helper.toastError(errors);
        cmp.set('v.isGettingURL', false);
      }
    });
    $A.enqueueAction(action);
  },

  toastError: function(errorObject) {
    $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
      errorObject: errorObject,
      cmpIdentifier: 'EBAY_TOKEN_HOME_PANEL_ALERTS',
      variant: 'TOAST'
    }).fire();
  }

})