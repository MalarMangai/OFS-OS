({

  //================================================================================
  // UI EVENTS
  //================================================================================

  handleAnchorClick: function(cmp, event, helper) {
    if (cmp.get('v.popoverMode') === 'CLICK' && cmp.get('v.isOpen') === false && cmp.isValid()) {
      helper.openPopover(cmp);
    }
  },

  handleMouseEnter: function(cmp, event, helper) {
    if (cmp.get('v.popoverMode') === 'HOVER') {
      helper.handleMouseEnter(cmp);
    }
  },

  handleMouseLeave: function(cmp, event, helper) {
    if (cmp.get('v.popoverMode') === 'HOVER') {
      helper.handleMouseLeave(cmp);
    }
  },

  handleCloseBtnClick: function(cmp, event, helper) {
    event.stopPropagation();
    helper.closePopover(cmp);
  },

  handleClosePopover: function(cmp, event, helper) {
    helper.closePopover(cmp);
  }

})