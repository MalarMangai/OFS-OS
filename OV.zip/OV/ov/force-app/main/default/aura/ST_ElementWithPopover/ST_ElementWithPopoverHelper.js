({

  //================================================================================
  // UI EVENTS
  //================================================================================

  handleMouseEnter: function(cmp) {
    var helper = this;

    cmp._lastMouseEvent = 'ON_MOUSE_ENTER';
    if (!cmp.get('v.isOpen') && !cmp._isAboutToBeOpened) {
      cmp._isAboutToBeOpened = true;
      setTimeout($A.getCallback(function() {
        if (cmp._lastMouseEvent === 'ON_MOUSE_ENTER') {
          helper.openPopover(cmp);
        }
        cmp._isAboutToBeOpened = false;
      }), 150);
    }
  },

  handleMouseLeave: function(cmp) {
    var helper = this;

    cmp._lastMouseEvent = 'ON_MOUSE_LEAVE';
    setTimeout($A.getCallback(function() {
      if (cmp._lastMouseEvent === 'ON_MOUSE_LEAVE') {
        helper.closePopover(cmp);
      }
    }), 250);
  },


  //================================================================================
  // UI MANAGEMENT
  //================================================================================

  openPopover: function(cmp) {
    var helper = this;

    var nubbinPosition = cmp.get('v.nubbinPosition');

    if ($A.util.isEmpty(nubbinPosition)) {
      var vectorToCenter = this.getVectorToCenter(cmp);
      var vectorAngle = this.getVectorAngle(vectorToCenter);
      nubbinPosition = this.getNubbinPosition(vectorAngle);
    }

    cmp.set('v.nubbinCSSClass', 'slds-nubbin_' + nubbinPosition);
    cmp.set('v.isOpen', true);

    if (cmp.get('v.popoverMode') === 'CLICK') {
      var container = cmp.find('container').getElement();
      cmp._outsideClickEventHandler = $A.getCallback(function(event) {
        if (!container.contains(event.target)) {
          helper.closePopover(cmp);
        }
      });
      document.addEventListener('click', cmp._outsideClickEventHandler, true);
    }

    cmp.get('e.onPopoverOpen').fire();
  },

  closePopover: function(cmp) {
    setTimeout($A.getCallback(function() {
      cmp.set('v.isOpen', false);
    }));

    if (cmp.get('v.popoverMode') === 'CLICK') {
      document.removeEventListener('click', cmp._outsideClickEventHandler, true);
    }
  },


  //================================================================================
  // STYLING MATH
  //================================================================================

  getVectorToCenter: function(cmp) {
    var containerEl = cmp.find('container').getElement();
    var contElBounds = containerEl.getBoundingClientRect();

    var centerX = (contElBounds.left + contElBounds.right) / 2;
    var centerY = (contElBounds.top + contElBounds.bottom) / 2;

    var windowCenterX = window.innerWidth / 2;
    var windowCenterY = window.innerHeight / 2;

    var vectorX = windowCenterX - centerX;
    var vectorY = windowCenterY - centerY;

    return { x: vectorX, y: -vectorY };
  },

  getVectorAngle: function(vector) {
    return Math.atan2(vector.y, vector.x) * 180 / Math.PI;
  },

  getNubbinPosition: function(vectorAngle) {
    var nubbinPosition;

    //popover to the right
    if (vectorAngle <= 45 && vectorAngle >= -45) {
      nubbinPosition = 'left';
      if (vectorAngle > 15) {
        nubbinPosition += '-bottom';
      } else
      if (vectorAngle < -15) {
        nubbinPosition += '-top';
      }
    }
    //popover to the left
    if (vectorAngle >= 135 || vectorAngle <= -135) {
      nubbinPosition = 'right';
      if (vectorAngle < 165 && vectorAngle >= 135) {
        nubbinPosition += '-bottom';
      } else
      if (vectorAngle > -165 && vectorAngle <= -135) {
        nubbinPosition += '-top';
      }
    }
    //popover to top
    if (vectorAngle < -45 && vectorAngle > -135) {
      nubbinPosition = 'top';
      if (vectorAngle > -75) {
        nubbinPosition += '-left';
      } else
      if (vectorAngle < -105) {
        nubbinPosition += '-right';
      }
    }
    //popover to bottom
    if (vectorAngle > 45 && vectorAngle < 135) {
      nubbinPosition = 'bottom';
      if (vectorAngle < 75) {
        nubbinPosition += '-left';
      } else
      if (vectorAngle > 105) {
        nubbinPosition += '-right';
      }
    }
    return nubbinPosition;
  }

})