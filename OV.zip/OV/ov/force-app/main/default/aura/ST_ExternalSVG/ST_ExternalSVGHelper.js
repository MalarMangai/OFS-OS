({
  buildSVG: function(cmp) {
    var anchor = cmp.find('anchor').getElement();

    var svgElement = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svgElement.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    svgElement.setAttribute('viewBox', '0 0 64 64');

    var useElement = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    useElement.setAttribute('href', cmp.get('v.src'));
    svgElement.appendChild(useElement);

    anchor.appendChild(svgElement);
  }
})