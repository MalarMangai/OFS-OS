({
  afterRender: function(cmp, helper) {
    this.superAfterRender();
    helper.buildSVG(cmp);
  }
})