({
  handleFeedbackButtonClick: function(cmp, event, helper) {
    cmp.find('modal').openModal({
      header: $A.get('$Label.c.ST_FeedbackTitle'),
      showCloseButton: true
    });

    setTimeout($A.getCallback(function() {
      cmp.find('feedback-input').focus();
    }));
  },

  handleSendClick: function(cmp, event, helper) {
    helper.postFeedback(cmp);
  }
})