({
  postFeedback: function(cmp) {
    cmp.set('v.isProcessing', true);
    var input = cmp.find('feedback-input');

    var action = cmp.get('c.postFeedback');
    action.setParams({
      content: input.get('v.value')
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        input.set('v.value', '');
        $A.get('e.force:showToast').setParams({
          type: 'success',
          title: $A.get('$Label.c.ST_FeedbackThankYou'),
          message: $A.get('$Label.c.ST_FeedbackThankYouMessage')
        }).fire();
        cmp.find('modal').closeModal();
      } else {
        $A.get('e.force:showToast').setParams({
          type: 'error',
          title: $A.get('$Label.c.ST_GenericErrorTitle'),
          message: $A.get('$Label.c.ST_GenericErrorMessage')
        }).fire();
      }
      cmp.set('v.isProcessing', false);
    });
    $A.enqueueAction(action);
  }
})