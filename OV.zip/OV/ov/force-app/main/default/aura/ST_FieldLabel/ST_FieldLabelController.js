({
  initialize: function(cmp, event, helper) {
    var action = cmp.get('c.getLabel');

    action.setParams({
      sObjectField: cmp.get('v.sObjectField')
    });
    action.setStorable();
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (cmp.isValid() && state === 'SUCCESS') {
        cmp.set('v.label', response.getReturnValue());
        cmp.set('v.isLoaded', true);

        if (cmp.get('v.isRendered')) {
          helper.renderLabel(cmp, response.getReturnValue());
        }
      }
    });

    $A.enqueueAction(action);
  }
})