({
  renderLabel: function(cmp, label) {
    if (cmp.get('v.variant') === 'PROVIDER') {
      var inputComponent = cmp.get('v.body')[0];
      if (inputComponent) {
        inputComponent.set('v.label', label);
        $A.util.addClass(inputComponent, 'loaded');
      }
    }
  }
})