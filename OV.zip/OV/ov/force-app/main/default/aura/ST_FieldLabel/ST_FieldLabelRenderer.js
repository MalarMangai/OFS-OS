({
  afterRender: function (cmp, helper) {
    this.superAfterRender();

    cmp.set('v.isRendered', true);
    var label = cmp.get('v.label');
    if (!$A.util.isEmpty(label)) {
      helper.renderLabel(cmp, label);
    }
  }
})