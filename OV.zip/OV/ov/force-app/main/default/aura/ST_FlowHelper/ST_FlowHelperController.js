({
  handleGUIDBroadcast: function(cmp, event) {
    if ($A.util.isEmpty(cmp.get('v.flowGUID'))) {
      cmp.set('v.flowGUID', event.getParam('guid'));
    }
  },

  getFlowGUID: function(cmp) {
    return cmp.get('v.flowGUID');
  }
})