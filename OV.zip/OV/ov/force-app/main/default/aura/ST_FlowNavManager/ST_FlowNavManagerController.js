({
  initialize: function(cmp, event, helper) {
    helper.fireAllowNextEvent(cmp);
  },

  callAllowNextEvent: function(cmp, event, helper) {
    helper.fireAllowNextEvent(cmp);
  }
})