({
  fireAllowNextEvent: function(cmp) {
    setTimeout($A.getCallback(function() {
      var event = $A.get('e.c:ST_FlowNavbar_EVTAllowNext');

      if (event) {
        event.setParams({
          allow: !cmp.get('v.isBtnNextDisabled'),
          flowGUID: cmp.find('flowHelper').getFlowGUID()
        }).fire();
      }
    }));
  }
})