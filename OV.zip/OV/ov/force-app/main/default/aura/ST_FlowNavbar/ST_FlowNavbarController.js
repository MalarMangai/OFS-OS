({
  initialize: function(cmp, event, helper) {
    cmp.set('v.allowNextManagerMap', {});

    //figure out which buttons to display
    var availableActions = cmp.get('v.availableActions');
    for (var i = 0; i < availableActions.length; i++) {
       if (availableActions[i] == 'PAUSE') {
          cmp.set('v.canPause', true);
       } else if (availableActions[i] == 'BACK') {
          cmp.set('v.canBack', true);
       } else if (availableActions[i] == 'NEXT') {
          cmp.set('v.canNext', true);
       } else if (availableActions[i] == 'FINISH') {
          cmp.set('v.canFinish', true);
       }
    }
  },

  handleButtonPressed: function(cmp, event, helper) {
    var actionClicked = event.getSource().getLocalId();
    if (actionClicked === 'CANCEL') {
      $A.get('e.force:navigateToSObject').setParams({
        recordId: cmp.get('v.in_recordIdToNavigateOnCancel'),
        isredirect: true,
      }).fire();
    } else {
      var navigate = cmp.get('v.navigateFlow');
      navigate(actionClicked);
    }
  },

  handleAllowNextEvent: function(cmp, event, helper) {
    var flowGUID = cmp.find('flowHelper').getFlowGUID();
    var eventFlowGUID = event.getParam('flowGUID');
    if (flowGUID !== eventFlowGUID) {
      return;
    }

    var allowNext = event.getParam('allow');
    var allowNextManagerMap = cmp.get('v.allowNextManagerMap');
    allowNextManagerMap[event.getSource().getGlobalId()] = allowNext;

    var eachManagerAllows = true;
    for (var managerId in allowNextManagerMap) {
      if (allowNextManagerMap.hasOwnProperty(managerId)) {
        if (allowNextManagerMap[managerId] === false) {
          eachManagerAllows = false;
        }
      }
    }

    cmp.set('v.areForwardActionsDisabled', !eachManagerAllows);
  }
})