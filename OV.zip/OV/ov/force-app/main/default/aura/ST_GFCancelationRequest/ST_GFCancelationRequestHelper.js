({

  //================================================================================
  // OVERRIDE METHODS
  //================================================================================

  handlePrevStep: function(cmp, currentStep) {
    var canGoBack = true;

    // check if step 3 is at the start or trigger prev subStep
    if (currentStep === 3) {
      canGoBack = cmp.find('step-three').prevStep();
    }

    return canGoBack;
  },

  handleNextStep: function(cmp, currentStep) {
    var canGoFurther = true;

    // check if step 3 is finished or trigger next subStep
    if (currentStep === 3) {
      canGoFurther = cmp.find('step-three').nextStep();
    }

    return canGoFurther;
  },

  onStepLeave: function(cmp, step, forward) {
    if (forward) {
      // check if step 2 should be unSkipped
      if (step === 1) {
        if (cmp.get('v.lineList').length > 1) {
          this.unSkipSteps(cmp, [2]);
        }
      }
    }
  },

  onStepEnter: function(cmp, prevStep, step, forward) {
    if (forward) {
      // prepare for step 4
      if (step === 4){
          //get line cancel status to persist to field, then prepare the cases
        this.getInvoiceCancelationInfo(cmp);
      }

      // submit flow
      if (step === 5) {
        this.submit(cmp);
      }
    } else {
      // clear isUniformReason selection on first screen
      if (step === 1) {
        cmp.set('v.isUniformReason', null);
        this.skipSteps(cmp, [2]);
      }
    }
  },

  onFinish: function(cmp) {
    cmp.getEvent('onDone').fire();
  },

  getInvoiceCancelationInfo: function(cmp) {

      var action = cmp.get('c.getInvoiceCancelationInformation');
      action.setParams({
          invoiceId: cmp.get('v.invoice').invoiceId
      });

      action.setCallback(this, function(response) {
          var state = response.getState();
          if (state === 'SUCCESS') {
              var actionResponse = response.getReturnValue();
              this.handleInvoiceCancelationInfo(cmp, actionResponse);
          } else {
              var errors = response.getError();
              this.displayError(cmp, errors);
          }
      });
      $A.enqueueAction(action);
  },

  handleInvoiceCancelationInfo: function(cmp, cancelationInfo) {
      var lineList = cmp.get('v.lineList');
      var lineCancelStatusList = [];
      console.log('handleInvoiceCancelationInfo: ', cancelationInfo.lines);
      console.log('handleInvoiceCancelationInfo: ', lineList);
      cancelationInfo.lines.forEach(function(cancelLine) {
          lineList.forEach(function (line) {
              if (line.lineId == cancelLine.LineId) {
                  lineCancelStatusList.push({
                      Id: cancelLine.lineId,
                      lineCancelStatus: cancelLine.cancelable
                  });
              }
          });
      });
      cmp.set('v.lineCancelStatusList', lineCancelStatusList);
      console.log('handleInvoiceCancelationInfo: LineCancelStatus', cmp.get('v.lineCancelStatusList'));
      cmp.set('v.invCancelStatus', cancelationInfo.invoiceCancelable);

      //We can finally start preparing the cases
      this.prepareCases(cmp);
  },


  //================================================================================
  // STEPS LOGIC
  //================================================================================

  prepareCases: function(cmp) {
    var helper = this;

    var invoice = cmp.get('v.invoice');
    var lineList = cmp.get('v.lineList');
    var parentCase = cmp.get('v.caseRecord');
    var accRecord = cmp.get('v.accRecord');
    var lineCancelStatusList =   cmp.get('v.lineCancelStatusList');

    var caseList = [];
    lineList.forEach(function(line) {
      var lineCancelStatus = '';
        lineCancelStatusList.forEach(function(lineStatus) {
        if (lineStatus.Id == line.details.invoiceLineId){
          lineCancelStatus = lineStatus.lineCancelStatus;
        }
      });
      var newCase = {
        sobjectType: 'Case',
        Status: 'New',
        Reason: line.cancelationReason,
        Subject: 'Cancellation Request',
        Origin: 'Agent Console',
        AlertType__c: 'Cancellation',
        Queue__c: 'Cancellations Requests',
        Category__c: 'Existing Order(s)',
        SubCategory1__c: 'Line Cancellation',
        SubCategory2__c: (line.cancelationReason === 'Fraud Cancelled'?
                          'Fraudulent Order or Item(s)' : 'Customer Requested Cancellation'),
        AccountId: ($A.util.isEmpty(line.accountId)? ($A.util.isEmpty(parentCase)? accRecord.Id : parentCase.AccountId) : line.accountId),
        ContactId: ($A.util.isEmpty(parentCase)? accRecord.PersonContactId : parentCase.ContactId),
        InvoiceId__c: cmp.get('v.invoice').invoiceId,
        LineId__c: line.details.invoiceLineId,
        LineCancelStatus__c: lineCancelStatus,
        OstkInteractionId__c: line.details.invoiceLineId,
        ProductName__c: line.details.fullProductName,
        ProductId__c: line.details.productId,
        CatalogNumber__c: line.details.fullSku,
        OriginalVendorId__c: line.details.vendorId,
        OriginalAddressLine1__c: invoice.shippingAddress.address1,
        OriginalAddressLine2__c: invoice.shippingAddress.address2,
        OriginalCity__c: invoice.shippingAddress.city,
        OriginalCountry__c: invoice.shippingAddress.country,
        OriginalZipCode__c: invoice.shippingAddress.postalCode,
        OriginalState__c: invoice.shippingAddress.state,
        Description:
          'Reason: ' + line.cancelationReason + '\n' +
          'Invoice: ' + cmp.get('v.invoice').invoiceId + '\n' +
          'Ostk SKU: ' + line.details.fullSku + '\n' +
          'Product Name: ' + line.details.fullProductName + '\n' +
          'Customer Name: ' + ($A.util.isEmpty(parentCase)? accRecord.Name : parentCase.Contact.Name) + '\n' +
          'Original Shipping Address: '
              + helper.addrPart(invoice.shippingAddress.address1)
              + helper.addrPart(invoice.shippingAddress.address2)
              + helper.addrPart(invoice.shippingAddress.city)
              + helper.addrPart(invoice.shippingAddress.state)
              + helper.addrPart(invoice.shippingAddress.postalCode)
              + helper.addrPart(invoice.shippingAddress.country)
      };

      caseList.push(newCase);
    });

    cmp.set('v.caseList', caseList);
  },

  submit: function(cmp) {
    cmp.set('v.isCreatingCases', true);
    var caseRecord = cmp.get('v.caseRecord');
    var accRecord = cmp.get('v.accRecord');

    var action = cmp.get('c.submitFlow');
    action.setParams({
      caseList: cmp.get('v.caseList'),
      parentCaseId: ($A.util.isEmpty(caseRecord)? null : caseRecord.Id),
      accountId: ($A.util.isEmpty(accRecord)? null : accRecord.Id)
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseObj = response.getReturnValue();
        cmp.set('v.createdCaseList', responseObj.childCaseList);
        cmp.set('v.createdParentCaseId', responseObj.createdParentCaseId);
      } else {
        $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
          errorObject: response.getError(),
          cmpIdentifier: cmp.getGlobalId() + '_STEP5_ALERTS',
        }).fire();
      }
      cmp.set('v.isCreatingCases', false);
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // HELPERS
  //================================================================================

  addrPart: function(part) {
    if (!$A.util.isEmpty(part)) {
      return ' ' + part;
    }

    return '';
  }



})