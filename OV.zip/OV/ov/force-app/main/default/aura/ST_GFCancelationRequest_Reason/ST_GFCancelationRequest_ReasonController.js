({

  initialize: function(cmp) {
    cmp.set('v.reasonOptions', [
      { label: 'Fraud Cancelled', value: 'Fraud Cancelled' },
      { label: 'Better Price Elsewhere', value: 'Better Price Elsewhere' },
      { label: 'Changed My Mind', value: 'Changed My Mind' },
      { label: 'Duplicate Order', value: 'Duplicate Order' },
      { label: 'Ordered Wrong Item/Size', value: 'Ordered Wrong Item/Size' },
      { label: 'Used Wrong Payment Method', value: 'Used Wrong Payment Method' }
    ]);
  },


  //================================================================================
  // UI EVENT HANDLERS
  //================================================================================

  handleUniformReasonPicklistValueChange: function(cmp, event, helper) {
    helper.goToNextGlobalStep(cmp);
  },

  handleReasonPicklistValueChange: function(cmp, event, helper) {
    var step = cmp.get('v.step');
    if (step < cmp.get('v.stepsCount')) {
      setTimeout($A.getCallback(function() {
        cmp.set('v.step', step + 1);
      }), 60);
    } else {
      helper.goToNextGlobalStep(cmp);
    }
  }


})