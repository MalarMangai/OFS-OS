({
  handleNextStep: function(cmp, currentStep) {
    var canGoFurther = true;

    if (cmp.get('v.isUniformReason')) {
      if ($A.util.isEmpty(cmp.get('v.uniformReason'))) {
        canGoFurther = false;
      }
      cmp.set('v.isUniformReasonNotProvided', $A.util.isEmpty(cmp.get('v.uniformReason')));
    } else {
      var lineList = cmp.get('v.lineList');
      var currentLine = lineList[currentStep - 1];

      if ($A.util.isEmpty(currentLine.cancelationReason)) {
        canGoFurther = false;
        cmp.set('v.invalidStepNumber', currentStep);
      } else {
        cmp.set('v.invalidStepNumber', -1);
      }
    }

    return canGoFurther;
  },

  onFinish: function(cmp) {
    if (cmp.get('v.isUniformReason')) {
      this.setupLinesWithUniformReason(cmp);
    }
  },

  goToNextGlobalStep: function(cmp) {
    setTimeout($A.getCallback(function() {
      cmp.getEvent('onNextStep').fire();
    }), 60);
  },

  setupLinesWithUniformReason: function(cmp) {
    var uniformReason = cmp.get('v.uniformReason');
    var lineList = cmp.get('v.lineList');

    lineList.forEach(function(lineItem) {
      lineItem.cancelationReason = uniformReason;
    });

    cmp.set('v.lineList', lineList);
  }
})