({
  initialize: function(cmp) {
    if (!$A.util.isEmpty(cmp.get('v.isUniformReason'))) {
      cmp.set('v.isUniformReasonString', cmp.get('v.isUniformReason')? 'true' : 'false');
    }
    cmp.set('v.radioOptions', [
      { label: $A.get('$Label.c.ST_YesBtn'), value: 'true' },
      { label: $A.get('$Label.c.ST_NoBtn'), value: 'false' }
    ]);
  },

  handleRadioValueChange: function(cmp) {
    cmp.set('v.isUniformReason', cmp.get('v.isUniformReasonString') === 'true');
    setTimeout($A.getCallback(function() {
      cmp.getEvent('onNextStep').fire();
    }), 60);
  }
})