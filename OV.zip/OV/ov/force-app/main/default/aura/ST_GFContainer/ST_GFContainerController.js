({

  handleCancelButtonClick: function(cmp, event, helper) {
    if (cmp.get('v.isNavDisabled')) {
      return;
    }

    if (cmp.get('v.step') === cmp.get('v.stepsCount')) {
      cmp.getEvent('onNextStep').fire();
    } else {
      cmp.getEvent('onCancel').fire();
    }

    cmp.set('v.isModalOpen', false);
  },

  handlePrevButtonClick: function(cmp, event, helper) {
    cmp.getEvent('onPrevStep').fire();
  },

  handleNextButtonClick: function(cmp, event, helper) {
    cmp.getEvent('onNextStep').fire();
  },

  handleCloseModal: function(cmp) {
    cmp.set('v.isModalOpen', false);
  },


  //================================================================================
  // TRAP FOCUS MECHANISM
  //================================================================================

  handleFirstElementKeyup: function(cmp, event, helper) {
    if (event.which === 9 && event.shiftKey) { // TAB key with SHIFT
      event.preventDefault();
      cmp.find('last-element').getElement().focus();
    }
  },

  handleLastElementKeyup: function(cmp, event, helper) {
    if (event.which === 9 && !event.shiftKey) { // TAB key
      event.preventDefault();
      cmp.find('first-element').getElement().focus();
    }
  }

})