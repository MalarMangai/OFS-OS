({
  afterRender: function (cmp, helper) {
    this.superAfterRender();

    setTimeout($A.getCallback(function() {
      cmp.set('v.isModalOpen', true);
    }), 50);
  }
})