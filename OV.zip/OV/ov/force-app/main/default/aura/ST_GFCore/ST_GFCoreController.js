({

  initializeCore: function(cmp, event, helper) {
    var step = cmp.get('v.step') || 1;
    var skippedSteps = cmp.get('v.skippedSteps');
    if (skippedSteps.indexOf(step) !== -1) {
      step = helper.getNextStep(cmp);
    }
    cmp.set('v.step', step);
    cmp.set('v.delayedStep', step);
  },

  handleStepChange: function(cmp, event, helper) {
    cmp.set('v.isDuringTransition', true);

    setTimeout($A.getCallback(function() {
      cmp.set('v.delayedStep', cmp.get('v.step'));
      cmp.set('v.isDuringTransition', false);
    }), 250);
  },

  //returns true if master flow can go forward
  _handleNextStep: function(cmp, event, helper) {
    var step = cmp.get('v.step');
    if (!cmp.get('v.isDuringTransition') && helper.isCurrentStepDone(cmp, step)) {
      helper.onStepLeave(cmp, step, true);
      var nextStep = helper.getNextStep(cmp);
      if (nextStep === null) {
        helper.onFinish(cmp);
        return true;
      } else {
        helper.onStepEnter(cmp, step, nextStep, true);
        cmp.set('v.step', nextStep);
      }
    }

    return false;
  },

  //returns true if master flow can go back
  _handlePrevStep: function(cmp, event, helper) {
    var step = cmp.get('v.step');
    if (!cmp.get('v.isDuringTransition') && helper.isCurrentStepBackable(cmp, step)) {
      helper.onStepLeave(cmp, step, false);
      var prevStep = helper.getPrevStep(cmp);
      if (prevStep === null) {
        return true;
      } else {
        helper.onStepEnter(cmp, step, prevStep, false);
        cmp.set('v.step', prevStep);
      }
    }

    return false;
  }

})