({

  //================================================================================
  // METHOD TO BE OVERRIDE
  //================================================================================

  handlePrevStep: function(cmp, currentStep) { return true; },
  handleNextStep: function(cmp, currentStep) { return true; },
  onStepLeave: function(cmp, step, forward) {},
  onStepEnter: function(cmp, prevStep, step, forward) {},
  onFinish: function(cmp) {},


  //================================================================================
  // STEP MANAGEMENT
  //================================================================================

  isCurrentStepDone: function(cmp, currentStep) {
    return this.handleNextStep(cmp, currentStep);
  },

  isCurrentStepBackable: function(cmp, currentStep) {
    return this.handlePrevStep(cmp, currentStep);
  },

  getNextStep: function(cmp) {
    var step = cmp.get('v.step') || 1;
    var skippedSteps = cmp.get('v.skippedSteps');

    var nextStep = step + 1;
    while (skippedSteps.indexOf(nextStep) !== -1) {
      nextStep++;
    }

    if (nextStep <= cmp.get('v.stepsCount')) {
      return nextStep;
    }

    return null;
  },

  getPrevStep: function(cmp) {
    var step = cmp.get('v.step') || cmp.get('v.stepsCount');
    var skippedSteps = cmp.get('v.skippedSteps');

    var prevStep = step - 1;
    while (skippedSteps.indexOf(prevStep) !== -1) {
      prevStep--;
    }

    if (prevStep >= 1) {
      return prevStep;
    }

    return null;
  },


  //================================================================================
  // STEP SKIPPING
  //================================================================================

  skipSteps: function(cmp, stepsToSkip, permanentSkip) {
    var skippedSteps = cmp.get('v.skippedSteps');
    var permanentSkippedSteps = cmp.get('v.permanentSkippedSteps');
    stepsToSkip.forEach(function(stepToSkip) {
      if (skippedSteps.indexOf(stepToSkip) === -1) {
        skippedSteps.push(stepToSkip);
      }
      if (permanentSkip) {
        if (permanentSkippedSteps.indexOf(stepToSkip) === -1) {
          permanentSkippedSteps.push(stepToSkip);
        }
      }
    });
    cmp.set('v.skippedSteps', skippedSteps);
    cmp.set('v.permanentSkippedSteps', permanentSkippedSteps);
  },

  unSkipSteps: function(cmp, stepsToUnSkip) {
    var skippedSteps = cmp.get('v.skippedSteps');
    var permanentSkippedSteps = cmp.get('v.permanentSkippedSteps');
    for (var i = skippedSteps.length; i > 0; i--) {
      stepsToUnSkip.forEach(function(stepToUnSkip) {
        var index = skippedSteps.indexOf(stepToUnSkip);
        if (index !== -1 && permanentSkippedSteps.indexOf(stepToUnSkip) === -1) {
          skippedSteps.splice(index, 1);
        }
      })
    }
    cmp.set('v.skippedSteps' ,skippedSteps);
  }

})