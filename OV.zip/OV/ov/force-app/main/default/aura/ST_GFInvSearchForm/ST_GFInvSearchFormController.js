({

  initialize: function (cmp, event, helper) {
    cmp.set('v.isNavBlocked', true);
    cmp.set('v.selectedInvoice', null);
    cmp.set('v.selectedLineList', []);
    if (cmp.get('v.caseRecord') != null) {
      helper.checkForDuplicateCases(cmp);
    }
  },

  handleInvoiceSelection: function(cmp, event, helper) {
    var invoiceId = event.getParam('invoiceId');
    var invoice = event.getParam('invoice');

    cmp.set('v.selectedInvoice', invoice);

    if (cmp.get('v.processType') === 'CANCELATION_REQUEST' && !$A.util.isEmpty(invoiceId)) {
      cmp.set('v.allowLineSelection', false);
      helper.getInvoiceCancelationInfo(cmp, invoiceId, function() {
        cmp.find('lineListSearch').loadInvoiceLines(invoiceId);
      });
    } else {
      cmp.find('lineListSearch').loadInvoiceLines(invoiceId);
    }
  },

  handleSelectedLinesChanges: function(cmp, event, helper) {
    var lineList = event.getParam('lineList');
    cmp.set('v.selectedLineList', lineList);

    if (!$A.util.isEmpty(lineList)) {
      if (cmp.get('v.processType') === 'INVALID_TRACKING') {
        helper.getTrackingInfoForLines(cmp, lineList);
      } else {
        cmp.set('v.isNavBlocked', false);
      }
    } else {
      cmp.set('v.isNavBlocked', true);
    }
  }

})