({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getInvoiceCancelationInfo: function(cmp, invoiceId, callback) {
    cmp.set('v.isProcessing', true);

    var action = cmp.get('c.getInvoiceCancelationInfo');
    action.setParams({
      invoiceId: invoiceId
    });

    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var actionResponse = response.getReturnValue();
          this.handleInvoiceCancelationInfo(cmp, actionResponse);

          if (callback) {
            callback();
          }
      } else {
        var errors = response.getError();
        this.displayError(cmp, errors);
      }
      cmp.set('v.isProcessing', false);
    });
    $A.enqueueAction(action);
  },

  getTrackingInfoForLines: function(cmp, lineList) {
    cmp.set('v.isNavBlocked', true);
    cmp.set('v.isProcessing', true);

    var thisActionTimestamp = Date.now();
    cmp._lastGetTrackingInfoTimestamp = thisActionTimestamp;

    var lineIdList = lineList.map(function(line) {
      return line.details.invoiceLineId;
    });

    var action = cmp.get('c.getTrackingInfoForLines');
    action.setParams({
      lineIdList: lineIdList
    });

    action.setCallback(this, function(response) {
      if (cmp._lastGetTrackingInfoTimestamp !== thisActionTimestamp) {
        //discard action
        return;
      }
      var state = response.getState();
      if (state === 'SUCCESS') {
        var actionResponse = response.getReturnValue();
        this.handleGetTrackingInfoForLines(cmp, actionResponse);
        cmp.set('v.isNavBlocked', false);
      } else {
        var errors = response.getError();
        this.displayError(cmp, errors);
      }
      cmp.set('v.isProcessing', false);
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // INTEGRATION CALLS HANDLERS
  //================================================================================

  handleInvoiceCancelationInfo: function(cmp, cancelationInfo) {
    cmp.set('v.cancelationInfo', cancelationInfo);

    var lineSearchComponent = cmp.find('lineListSearch');
    if(lineSearchComponent != null)
        lineSearchComponent.handleCancelationInfo(cancelationInfo);

    if (cancelationInfo.invoiceCancelable === 'NO') {
      cmp.set('v.allowLineSelection', true);
    } else {
      $A.get('e.c:ST_Modal_EVTDisplay').setParams({
        cmpIdentifier: cmp.getGlobalId(),
        header: $A.get('$Label.c.ST_TWInvoiceIssues'),
        message: (
          cancelationInfo.invoiceCancelable === 'YES' ?
          $A.get('$Label.c.ST_TWInvoiceNonCancelableGoRMA') :
          $A.get('$Label.c.ST_TWInvoiceNonCancelableGoCSApp')
        ),
        buttonsVariant: 'CONFIRM_CANCEL',
        showCloseButton: true
      }).fire();
    }
  },

  handleGetTrackingInfoForLines: function(cmp, trackingInfoMap) {
    var lineList = cmp.get('v.selectedLineList');

    lineList.forEach(function(line) {
      line.trackingInfo = trackingInfoMap[line.details.invoiceLineId];
    });

    cmp.set('v.selectedLineList', lineList);
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  displayError: function(cmp, errorObject) {
    $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
      cmpIdentifier: cmp.getGlobalId(),
      errorObject: errorObject
    }).fire();
  },

  checkForDuplicateCases: function(cmp) {
      var processType = cmp.get('v.processType');
      var alertTypes;
      if (processType == 'PARTS_REQUEST') {
          alertTypes =  ['Parts Request', 'Documentation Request'];
      }
      else if (processType == 'CANCELATION_REQUEST') {
          alertTypes = ['Cancellation', 'Address Correction'];
      }
      else if (processType == 'INVALID_TRACKING') {
          alertTypes = ['Invalid Tracking'];
      }
      var action = cmp.get('c.caseHasChildCases');
      action.setParams({
          caseId: cmp.get('v.caseRecord').Id,
          alertType: alertTypes
      });

      action.setCallback(this, function(response) {
          var state = response.getState();
          if (state === 'SUCCESS') {
              var actionResponse = response.getReturnValue();
              if (actionResponse) {
                this.displayDupPopup(cmp);
              }
          }
          cmp.set('v.isProcessing', false);
      });
      $A.enqueueAction(action);
  },

  displayDupPopup: function(cmp) {
      var processType = cmp.get('v.processType');
      var labelText;
      if (processType == 'PARTS_REQUEST') {
          labelText = $A.get('$Label.c.ST_GFInvSearchDuplicateText').replace('<process>',  'Parts Request(s)');
      }
      else if (processType == 'CANCELATION_REQUEST') {
          labelText = $A.get('$Label.c.ST_GFInvSearchDuplicateText').replace('<process>',  'Cancellation Request(s)');
      }
      else if (processType == 'INVALID_TRACKING') {
          labelText = $A.get('$Label.c.ST_GFInvSearchDuplicateText').replace('<process>',  'Invalid Tracking Request(s)');
      }


      $A.get('e.c:ST_Modal_EVTDisplay').setParams({
          cmpIdentifier: cmp.get('v.flowGUID'),
          header: $A.get('$Label.c.ST_GFInvSearchDuplicate'),
          messageLines: [
              '<p align:"center">' + labelText + '</p> '
          ],
          buttonsVariant: 'CONFIRM',
          cancelCallback: $A.getCallback(function() {
          })
      }).fire();
  }

})