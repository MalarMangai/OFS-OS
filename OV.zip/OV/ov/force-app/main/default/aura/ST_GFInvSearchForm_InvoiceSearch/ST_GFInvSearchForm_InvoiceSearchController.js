({

  initialize: function(cmp, event, helper) {
    cmp.set('v.inputInvoiceNumber', cmp.get('v.preselectedInvoiceId'));

    helper.getInvoices(cmp, 1, function() {
      helper.handleNewInvoiceListLoad(cmp);
    });
  },


  //================================================================================
  // UI ACTION HANDLERS
  //================================================================================

  handleSearchButtonClick: function(cmp, event, helper) {
    helper.getInvoices(cmp, 1, function() {
      cmp.find('pagination').resetSelectedPage();
      helper.handleNewInvoiceListLoad(cmp);
    });
  },

  handleResetCriteria: function(cmp, event, helper) {
    cmp.set('v.inputInvoiceNumber', null),
    cmp.set('v.inputShortSku', null),
    cmp.set('v.inputProductName', null)

    helper.getInvoices(cmp, 1, function() {
      cmp.find('pagination').resetSelectedPage();
      helper.handleNewInvoiceListLoad(cmp);
    });
  },

  onInvoiceTablePageSelected: function(cmp, event, helper) {
    var selectedPage = event.getParam('pageNumber');
    helper.getInvoices(cmp, selectedPage, function() {
      helper.selectInvoice(cmp, cmp.get('v.selectedInvoiceId'), false);
    });
  },

  handleInvoiceSelection: function(cmp, event, helper) {
    var selectedInvoiceId = event.target.value;
    cmp.set('v.selectedInvoiceId', selectedInvoiceId);
    helper.fireInvoiceSelectionEvent(cmp, selectedInvoiceId);
  },

})