({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getInvoices: function(cmp, pageNumber, successCallback) {
    var helper = this;
    cmp.set('v.isLoading', true);

    var action = cmp.get('c.getInvoices');

    var paramsJSON = JSON.stringify({
      pageSize: cmp.get('v.tableItemsPerPage'),
      currentPage: pageNumber - 1,
      customerId: cmp.get('v.customerId'),
      invoiceId: cmp.get('v.inputInvoiceNumber'),
      shortSku: cmp.get('v.inputShortSku'),
      productName: cmp.get('v.inputProductName')
    });
    action.setParams({
      paramsJSON: paramsJSON
    });

    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var actionResponse = response.getReturnValue();
        helper.setInvoices(cmp, actionResponse.invoices);
        cmp.set('v.invoiceListPageCount', actionResponse.pages);
        cmp.set('v.isLoading', false);

        if (successCallback) {
          successCallback();
        }
      } else {
        helper.setInvoices(cmp, []);
        var errors = response.getError();
        helper.displayError(cmp, errors);
      }
      cmp.set('v.isLoading', false);
    });
    $A.enqueueAction(action);
  },

  handleNewInvoiceListLoad: function(cmp) {
    var invoiceList = cmp.get('v.invoiceList');
    if (invoiceList.length === 1) {
      var firstInvoice = invoiceList[0];
      this.selectInvoice(cmp, firstInvoice.invoiceId, true);
    } else {
      this.selectInvoice(cmp, null, true);
    }
  },


  //================================================================================
  // LIST SETUP
  //================================================================================

  setInvoices: function(cmp, invoiceList) {
    cmp.set('v.invoiceList', invoiceList);

    var invoiceMap = {};
    invoiceList.forEach(function(invoice) {
      invoiceMap[invoice.invoiceId] = invoice;
    });
    cmp.set('v.invoiceMap', invoiceMap);
  },


  //================================================================================
  // SELECTION MANAGEMENT
  //================================================================================

  selectInvoice: function(cmp, invoiceId, notifyByEvent) {
    cmp.set('v.selectedInvoiceId', invoiceId);

    if (!$A.util.isEmpty(invoiceId)) {
      setTimeout($A.getCallback(function() {
        var radio = document.getElementById('radio-' + cmp.getGlobalId() + '-' + invoiceId);
        if (radio) {
          radio.checked = true;
        }
      }));
    }

    if (notifyByEvent) {
      this.fireInvoiceSelectionEvent(cmp, invoiceId);
    }
  },

  fireInvoiceSelectionEvent: function(cmp, invoiceId) {
    var invoice = cmp.get('v.invoiceMap')[invoiceId];
    cmp.getEvent('invoiceSelected').setParams({
      invoiceId: invoiceId,
      invoice: invoice
    }).fire();
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  displayError: function(cmp, errorObject) {
    $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
      cmpIdentifier: cmp.get('v.flowGUID'),
      errorObject: errorObject
    }).fire();
  }

})