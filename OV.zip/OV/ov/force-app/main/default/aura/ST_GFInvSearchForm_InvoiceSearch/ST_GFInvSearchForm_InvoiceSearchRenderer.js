({
  afterRender: function (cmp, helper) {
    this.superAfterRender();
    setTimeout($A.getCallback(function() {
      cmp.find('invoice-number-input').focus();
    }), 200);
  }
})