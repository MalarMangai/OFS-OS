({

  initialize: function(cmp, event, helper) {
  },


  //================================================================================
  // UI ACTION HANDLERS
  //================================================================================

  onLineTablePageSelected: function(cmp, event, helper) {
    var selectedPageNumber = event.getParam('pageNumber');
    helper.displayLinesForPage(cmp, selectedPageNumber);
  },

  handleLineToggle: function(cmp, event, helper) {
    var lineId = event.currentTarget.dataset.lineId;

    setTimeout($A.getCallback(function() {
      helper.updateSelectAllCheckbox(cmp);
      helper.handleSelectionChange(cmp);

      if (cmp.get('v.processType') === 'PARTS_REQUEST') {
        helper.verifyLTLShipmentDateAndNotifyNextTick(cmp, lineId);
      }
    }));
  },

  handleSelectAllCbxToggle: function(cmp, event, helper) {
    var isChecked = event.target.checked;
    helper.toggleAllOnPage(cmp, isChecked);
  },

  handleSelectAllPagesClick: function(cmp, event, helper) {
    helper.toggleAllPages(cmp, true);
    helper.updateSelectAllCheckbox(cmp);
  },

  handleDeselectAllPagesClick: function(cmp, event, helper) {
    helper.toggleAllPages(cmp, false);
    helper.updateSelectAllCheckbox(cmp);
  },


  //================================================================================
  // PUBLIC METHODS
  //================================================================================

  loadInvoiceLines: function(cmp, event, helper) {
    var params = event.getParam('arguments');
    if (params) {
      var invoiceId = params.invoiceId;
      if (!$A.util.isEmpty(invoiceId)) {
        helper.getInvoiceLines(cmp, invoiceId);
      } else {
        helper.setLineList(cmp, []);
      }
    }
  },

  handleCancelationInfo : function(component,event) {

    console.log("ST_GFInvSearchForm_LineSearch.handleCancelationInfo: enter");
    var params = event.getParam('arguments');
    if (params) {
        var cancelationInfo = params[0];
        component.set("v.cancelationInfo", cancelationInfo);
        console.log("cancelationInfo: ", component.get('v.cancelationInfo'));
    }

    console.log("ST_GFInvSearchForm_LineSearch.handleCancelationInfo: exit");
  }

})