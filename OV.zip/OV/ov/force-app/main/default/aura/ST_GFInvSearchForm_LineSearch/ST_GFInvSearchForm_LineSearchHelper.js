({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getInvoiceLines: function(cmp, invoiceId) {
    var helper = this;
    cmp.set('v.isLoading', true);

    var action = cmp.get('c.getInvoiceLines');

    action.setParams({
      invoiceId: invoiceId
    });

    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var actionResponse = response.getReturnValue();

        var trySetPreselectedItem = (!cmp.get('v.hasTriedPreSelectingOnce') && !$A.util.isEmpty(cmp.get('v.preselectedLineId')));
        helper.setLineList(cmp, actionResponse, trySetPreselectedItem);
        cmp.set('v.isLoading', false);
      } else {
        helper.setLineList(cmp, []);
        var errors = response.getError();
        helper.displayError(cmp, errors);
      }
      cmp.set('v.isLoading', false);
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // TABLE MANAGEMENT
  //================================================================================

  setLineList: function(cmp, lineList, trySetPreselectedItem) {
    this.processInitiallyLineList(cmp, lineList);
    cmp.set('v.lineList', lineList);

    var itemsPerPage = cmp.get('v.tableItemsPerPage');
    var pageCount = Math.ceil(lineList.length / itemsPerPage);
    cmp.set('v.lineListPageCount', pageCount);

    if (!trySetPreselectedItem) {
      cmp.find('pagination').resetSelectedPage();
      this.displayLinesForPage(cmp, 1);
    } else {
      cmp.set('v.hasTriedPreSelectingOnce', true);
      var preselectedLineId = cmp.get('v.preselectedLineId');
      this.handlePreselectItem(cmp, preselectedLineId);
    }

    this.handleSelectionChange(cmp);
  },

  processInitiallyLineList: function(cmp, lineList) {
    var processType = cmp.get('v.processType');
    var cancelInfo = cmp.get('v.cancelationInfo');
    lineList.forEach(function(line) {
      line.canBeSelected = true;
        var lineCancelStatus = '';
        if (processType === 'CANCELATION_REQUEST') {
          cancelInfo.lines.forEach(function (lineCancel) {
              if (lineCancel.lineId == line.details.invoiceLineId) {
                  lineCancelStatus = lineCancel.cancelable;
              }
          });
          if (line.details.shipped || !line.vendorAllowsCancelationRequests || lineCancelStatus == 'NO') {
              line.canBeSelected = false;
          }
      }
      if (processType === 'PARTS_REQUEST'
          && (!line.details.shipped || !line.vendorAllowsPartsRequests)) {
        line.canBeSelected = false;
      }
      if (processType === 'INVALID_TRACKING'
          && !line.details.shipped) {
        line.canBeSelected = false;
      }
    });
  },

  displayLinesForPage: function(cmp, pageNumber) {
    var lineList = cmp.get('v.lineList');
    var itemsPerPage = cmp.get('v.tableItemsPerPage');

    var sliceFrom = itemsPerPage * (pageNumber - 1);
    var sliceTo = itemsPerPage * (pageNumber - 1) + itemsPerPage;
    sliceTo = sliceTo > lineList.length? lineList.length : sliceTo;

    var displayedLineList = lineList.slice(sliceFrom, sliceTo);

    this.refreshCurrentPageView(cmp, displayedLineList);
  },

  refreshCurrentPageView: function(cmp, displayedLineList) {
    var helper = this;

    var _displayedLineList = displayedLineList || cmp.get('v.displayedLineList');
    cmp.set('v.displayedLineList', _displayedLineList);

    var pageHasLinesVendorNonCancelable = false;
    var pageHasLinesVendorPartsReqDisallowed = false;
    var pageHasSelectableLines = false;
    _displayedLineList.forEach(function(line) {
      if (!line.vendorAllowsCancelationRequests) {
        pageHasLinesVendorNonCancelable = true;
      }
      if (!line.vendorAllowsPartsRequests) {
        pageHasLinesVendorPartsReqDisallowed = true;
      }
      if (line.canBeSelected) {
        pageHasSelectableLines = true;
      }
    });
    cmp.set('v.pageHasLinesVendorNonCancelable', pageHasLinesVendorNonCancelable);
    cmp.set('v.pageHasLinesVendorPartsReqDisallowed', pageHasLinesVendorPartsReqDisallowed);
    cmp.set('v.pageHasSelectableLines', pageHasSelectableLines);

    if (!$A.util.isEmpty(_displayedLineList)) {
      setTimeout($A.getCallback(function() {
        helper.updateSelectAllCheckbox(cmp);
      }));
    }
  },

  handlePreselectItem: function(cmp, preselectedLineId) {
    var lineList = cmp.get('v.lineList');
    var filteredLineList = lineList.filter(function(line) {
      return line.details.invoiceLineId === preselectedLineId;
    });

    var pageToSelect = 1;
    if (!$A.util.isEmpty(filteredLineList)) {
      var lineToPreselect = filteredLineList[0];
      var index = lineList.indexOf(lineToPreselect);

      if (lineToPreselect.canBeSelected) {
        lineToPreselect.checked = true;
        cmp.set('v.lineList', lineList);
      }

      var itemsPerPage = cmp.get('v.tableItemsPerPage');
      pageToSelect = Math.floor(index / itemsPerPage) + 1;
    }

    cmp.find('pagination').selectPage(pageToSelect);
    this.displayLinesForPage(cmp, pageToSelect);
  },


  //================================================================================
  // SELECTION MANAGEMENT
  //================================================================================

  updateSelectAllCheckbox: function(cmp) {
    var anyChecked = false;
    var allChecked = true;

    var displayedLineList = cmp.get('v.displayedLineList');
    if (!$A.util.isEmpty(displayedLineList)) {
      displayedLineList.forEach(function(item) {
        // shipped items are not selectable
        if (!item.canBeSelected) { return; }

        if (item.checked) {
          anyChecked = true;
        } else {
          allChecked = false;
        }
      });
    }

    var cbx = cmp.find('selectAllCbx');
    if (cbx !== undefined) {
      var cbxElem = cbx.getElement();
      cbxElem.checked = allChecked;
      cbxElem.indeterminate = anyChecked && !allChecked;
    }
  },

  toggleAllOnPage: function(cmp, areSelected) {
    var helper = this;

    var displayedLineList = cmp.get('v.displayedLineList');
    displayedLineList.forEach(function(item) {
      // shipped items are not selectable
      if (item.canBeSelected) {
        if (item.checked != areSelected && cmp.get('v.processType') === 'PARTS_REQUEST') {
          helper.verifyLTLShipmentDateAndNotifyNextTick(cmp, item.details.invoiceLineId);
        }
        item.checked = areSelected;
      }
    });
    cmp.set('v.displayedLineList', displayedLineList);
    this.handleSelectionChange(cmp);
  },

  toggleAllPages: function(cmp, areSelected) {
    var helper = this;

    var lineList = cmp.get('v.lineList');
    lineList.forEach(function(item) {
      // shipped items are not selectable
      if (item.canBeSelected) {
        if (item.checked != areSelected && cmp.get('v.processType') === 'PARTS_REQUEST') {
          helper.verifyLTLShipmentDateAndNotifyNextTick(cmp, item.details.invoiceLineId);
        }
        item.checked = areSelected;
      }
    });
    cmp.set('v.lineList', lineList);
    this.refreshCurrentPageView(cmp);
    this.handleSelectionChange(cmp);
  },

  handleSelectionChange: function(cmp) {
    var selectedItemList = cmp.get('v.lineList').filter(function(item) {
      return item.checked;
    });

    cmp.set('v.selectedLineList', selectedItemList);
    this.fireSelectionChangeEvent(cmp, selectedItemList);
  },

  fireSelectionChangeEvent: function(cmp, selectedItems) {
    var checkedIdList = [];

    selectedItems.map(function(item) {
      return item.invoiceLineId;
    });

    cmp.getEvent('onSelectedLinesChange').setParams({
      lineIds: checkedIdList,
      lineList: selectedItems
    }).fire();
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  // this method is only called for PARTS_REQUEST process, and only when line checked changes
  verifyLTLShipmentDateAndNotifyNextTick: function(cmp, lineId) {
    var helper = this;

    setTimeout($A.getCallback(function() {
      var lineList = cmp.get('v.lineList');
      var line = lineList.find(function(line) { return line.details.invoiceLineId === lineId });

      if (line.checked
          && (
            (line.details.ltl && line.daysSinceShipment > 60)
            || (!line.details.ltl && line.daysSinceShipment > 45)
          ))
      {
        $A.get('e.c:ST_Modal_EVTDisplay').setParams({
          cmpIdentifier: cmp.get('v.flowGUID'),
          header: $A.get('$Label.c.ST_TWInvoiceIssues'),
          messageLines: [
            '<b>' + $A.get('$Label.c.ST_TWLineDetails') + ':</b> ' + line.details.fullSku + ' - ' + line.details.fullProductName,
            (line.details.ltl?
              $A.get('$Label.c.ST_TWItemShipped60DaysAgoWarn') :
              $A.get('$Label.c.ST_TWItemShipped45DaysAgoWarn'))
          ],
          buttonsVariant: 'CONFIRM_CANCEL',
          cancelCallback: $A.getCallback(function() {
            line.canBeSelected = false;
            line.checked = false;

            cmp.set('v.lineList', lineList);
            helper.updateSelectAllCheckbox(cmp);
            helper.handleSelectionChange(cmp);

            helper.refreshCurrentPageView(cmp);
          })
        }).fire();
      }
    }));
  },

  displayError: function(cmp, errorObject) {
    $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
      cmpIdentifier: cmp.get('v.flowGUID'),
      errorObject: errorObject
    }).fire();
  }

})