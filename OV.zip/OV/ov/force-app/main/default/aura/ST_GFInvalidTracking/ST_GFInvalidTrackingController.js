({

  //================================================================================
  // INIT SETUP & DATA LOAD
  //================================================================================

  initialize: function(cmp, event, helper) {
    cmp.set('v.stepsCount', 4);
  },


  //================================================================================
  // CONTAINER EVENTS
  //================================================================================

  handlePrevStep: function(cmp, event, helper) {
    helper.handlePrevStep(cmp);
  },

  handleNextStep: function(cmp, event, helper) {
    helper.handleNextStep(cmp);
  },

  handleCancel: function(cmp, event, helper) {
    cmp.getEvent('onDone').setParams({
      passed: false
    }).fire();
  },

  goToParentCase: function(cmp, event, helper) {
    $A.get('e.force:navigateToSObject').setParams({
      recordId: cmp.get('v.createdParentCaseId')
    }).fire();
  }

})