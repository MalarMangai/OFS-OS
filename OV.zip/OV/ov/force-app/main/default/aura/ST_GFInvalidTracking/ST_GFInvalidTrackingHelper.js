({

  //================================================================================
  // OVERRIDE METHODS
  //================================================================================

  handlePrevStep: function(cmp, currentStep) {
    var canGoBack = true;

    // check if step 2 is at the start or trigger prev subStep
    if (currentStep === 2) {
      canGoBack = cmp.find('step-two').prevStep();
    }

    return canGoBack;
  },

  handleNextStep: function(cmp, currentStep) {
    var canGoFurther = true;

    // check if step 2 is finished or trigger next subStep
    if (currentStep === 2) {
      canGoFurther = cmp.find('step-two').nextStep();
    }

    return canGoFurther;
  },

  onStepEnter: function(cmp, prevStep, step, forward) {
    if (forward) {
      // prepare for step 3
      if (step === 3) {
        this.prepareCases(cmp);
      }

      // submit flow
      if (step === 4) {
        this.submit(cmp);
      }
    }
  },

  onFinish: function(cmp) {
    cmp.getEvent('onDone').fire();
  },


  //================================================================================
  // STEPS LOGIC
  //================================================================================

  prepareCases: function(cmp) {
    var invoice = cmp.get('v.invoice');
    var lineList = cmp.get('v.lineList');
    var parentCase = cmp.get('v.caseRecord');
    var accRecord = cmp.get('v.accRecord');

    var caseList = [];
    lineList.forEach(function(line) {
      var newCase = {
        sobjectType: 'Case',
        Status: 'New',
        Subject: 'Invalid Tracking',
        Origin: 'Agent Console',
        AlertType__c: 'Invalid Tracking',
        Queue__c: 'Invalid Tracking',
        Category__c: 'Existing Order(s)',
        SubCategory1__c: 'Invalid Tracking',
        AccountId: ($A.util.isEmpty(line.accountId)? ($A.util.isEmpty(parentCase)? accRecord.Id : parentCase.AccountId) : line.accountId),
        ContactId: ($A.util.isEmpty(parentCase)? accRecord.PersonContactId : parentCase.ContactId),
        InvoiceId__c: cmp.get('v.invoice').invoiceId,
        ProductId__c: line.details.productId,
        ProductName__c: line.details.fullProductName,
        LineId__c: line.invoiceLineId,
        OriginalAddressLine1__c: invoice.shippingAddress.address1,
        OriginalAddressLine2__c: invoice.shippingAddress.address2,
        OriginalCity__c: invoice.shippingAddress.city,
        OriginalCountry__c: invoice.shippingAddress.country,
        OriginalZipCode__c: invoice.shippingAddress.postalCode,
        OriginalState__c: invoice.shippingAddress.state,
        Description:
          'Product Name: ' + line.details.fullProductName + '\n' +
          'Ship Confirm Date: ' + line.details.shipDate + '\n' +
          'Invalid Tracking #: ' + line.trackingInfo.trackingNumber + '\n' +
          'Carrier: ' + line.trackingInfo.carrier + '\n' +
          'Comments: ' + ($A.util.isEmpty(line.comments)? '' : line.comments)
      };

      caseList.push(newCase);
    });

    cmp.set('v.caseList', caseList);
  },

  submit: function(cmp) {
    cmp.set('v.isCreatingCases', true);
    var caseRecord = cmp.get('v.caseRecord');
    var accRecord = cmp.get('v.accRecord');

    var action = cmp.get('c.submitFlow');
    action.setParams({
      caseList: cmp.get('v.caseList'),
      parentCaseId: ($A.util.isEmpty(caseRecord)? null : caseRecord.Id),
      accountId: ($A.util.isEmpty(accRecord)? null : accRecord.Id)
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseObj = response.getReturnValue();
        cmp.set('v.createdCaseList', responseObj.childCaseList);
        cmp.set('v.createdParentCaseId', responseObj.createdParentCaseId);
      } else {
        $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
          errorObject: response.getError(),
          cmpIdentifier: cmp.getGlobalId() + '_STEP5_ALERTS',
        }).fire();
      }
      cmp.set('v.isCreatingCases', false);
    });
    $A.enqueueAction(action);
  }

})