({

  //================================================================================
  // OVERRIDE METHODS
  //================================================================================

  handlePrevStep: function(cmp, currentStep) {
    var canGoBack = true;

    // check if step 5 is finished or fire next substep
    if (currentStep === 5) {
      canGoBack = cmp.find('step-five').prevStep();
    }

    return canGoBack;
  },

  handleNextStep: function(cmp, currentStep) {
    var canGoFurther = true;

    // check if step 5 is finished or fire next substep
    if (currentStep === 5) {
      canGoFurther = cmp.find('step-five').nextStep();
    }

    return canGoFurther;
  },

  onStepLeave: function(cmp, step, forward) {
    if (forward) {
      // check if step 2, 3 and 4 should be unSkipped
      if (step === 1) {
        if (cmp.get('v.lineList').length > 1) {
          this.unSkipSteps(cmp, [2, 3, 4]);
        }
        this.setupLineListForInputs(cmp);
      }

      // check if step 3 and 4 should be skipped
      if (step === 2) {
        if (!cmp.get('v.isUniformReason')) {
          this.skipSteps(cmp, [3, 4]);
        }
      }

      // check if step 4 should be skipped
      if (step === 3) {
        if (cmp.get('v.isDocOnly')) {
          this.skipSteps(cmp, [4]);
        }
      }
    }
  },

  onStepEnter: function(cmp, prevStep, step, forward) {
    if (forward) {
      // prepare for step 5
      if (step === 5) {
        this.prepareForStepFive(cmp);
      }

      // prepare for step 6
      if (step === 6) {
        this.prepareCases(cmp);
      }

      // submit flow
      if (step === 7) {
        this.submit(cmp);
      }
    } else {
      // clear attrs at step 1
      if (step === 1) {
        cmp.set('v.isUniformReason', null);
        cmp.set('v.uniformReason', null);
        cmp.set('v.isDocOnly', null);
        this.skipSteps(cmp, [2, 3, 4]);
      }

      // clear attrs at step 2
      if (step === 2) {
        cmp.set('v.isDocOnly', null);
        cmp.set('v.uniformReason', null);
        this.unSkipSteps(cmp, [3, 4]);
      }

      // clear attrs at step 3
      if (step === 3) {
        cmp.set('v.uniformReason', null);
        this.unSkipSteps(cmp, [4]);
      }

      // reset subForms in case selection at step 2 / 3 changed
      if (step === 2 || step === 3) {
        var lineList = cmp.get('v.lineList');
        lineList.forEach(function(line) {
          line.subFormsStep = null;
        });
        cmp.set('v.lineList', lineList);
      }
    }
  },

  onFinish: function(cmp) {
    cmp.getEvent('onDone').fire();
  },


  //================================================================================
  // STEPS PREPARATION
  //================================================================================

  setupLineListForInputs: function(cmp) {
    var invoice = cmp.get('v.invoice');
    var originalAddress = invoice.shippingAddress;
    var originalShipToFirstName = invoice.shipToFirstName;
    var originalShipToLastName = invoice.shipToLastName;

    var lineList = cmp.get('v.lineList');
    lineList.forEach(function(line) {
      line.inputs = {
        ltl: line.details.ltl,
        address: Object.assign({}, originalAddress),
        shipToFirstName: originalShipToFirstName,
        shipToLastName: originalShipToLastName
      };
    });
    cmp.set('v.lineList', lineList);
  },

  prepareForStepFive: function(cmp) {
    var isUniformReason = cmp.get('v.isUniformReason');
    var isDocOnly = cmp.get('v.isDocOnly');
    var uniformReason = cmp.get('v.uniformReason');

    var lineList = cmp.get('v.lineList');
    lineList.forEach(function(line) {
      line.inputs.isUniformReason = isUniformReason;
      if (isUniformReason) {
        line.inputs.isDocOnly = isDocOnly;
        if (isDocOnly) {
          line.inputs.partsRequestReason = 'Instruction Manual Needed';
        } else {
          line.inputs.partsRequestReason = uniformReason;
        }
      } else {
        line.inputs.isDocOnly = null;
        line.inputs.partsRequestReason = null;
      }
    });
    cmp.set('v.lineList', lineList);
  },

  prepareCases: function(cmp) {
    var helper = this;
    var lineList = cmp.get('v.lineList');

    var caseWrapperList = [];
    lineList.forEach(function(line) {
      var baseCaseRecord = helper.getBaseCaseRecord(cmp, line);

      // default case
      if (!line.inputs.isDocOnly) {
        var defaultCaseWrapper = {
          uploadedFileList: line.inputs.uploadedFileList,
          caseRecord: Object.assign({}, baseCaseRecord)
        };
        defaultCaseWrapper.caseRecord.Subject = 'Parts Request';
        defaultCaseWrapper.caseRecord.AlertType__c = 'Parts Request';
        defaultCaseWrapper.caseRecord.PartsDocumentationOnly__c = 'No';
        defaultCaseWrapper.caseRecord.LtlItemFlag__c = (line.inputs.ltl? 'Yes' : 'No');
        defaultCaseWrapper.caseRecord.LtlItemFlagChanged__c = line.inputs.ltl;
        defaultCaseWrapper.caseRecord.PartsCustomDetails__c = line.inputs.partsCustomDetailsCombined;
        defaultCaseWrapper.caseRecord.TaskDetails__c = line.inputs.detailedInfo;
        line.inputs.partsCustomDetailsCombined = line.inputs.partsCustomDetailsCombined ? line.inputs.partsCustomDetailsCombined : '';
        defaultCaseWrapper.caseRecord.Description =
          'Reason: ' + defaultCaseWrapper.caseRecord.Reason + '\n' +
          defaultCaseWrapper.caseRecord.Description + '\n' +
          'Custom Details: ' + line.inputs.partsCustomDetailsCombined + '\n' +
          'Request Details: ' + line.inputs.detailedInfo;
        caseWrapperList.push(defaultCaseWrapper);
      }

      // documentation case
      if (line.inputs.isDocOnly || line.inputs.isDocNeededInAdditionToParts) {
        var docCaseWrapper = {
          uploadedFileList: [],
          caseRecord: Object.assign({}, baseCaseRecord)
        };
        docCaseWrapper.caseRecord.Reason = 'Instruction Manual Needed';
        docCaseWrapper.caseRecord.Subject = 'Documentation Request';
        docCaseWrapper.caseRecord.AlertType__c = 'Documentation Request';
        docCaseWrapper.caseRecord.PartsDocumentationOnly__c = 'Yes';
        docCaseWrapper.caseRecord.Description =
          'Reason: ' + docCaseWrapper.caseRecord.Reason + '\n' +
          docCaseWrapper.caseRecord.Description + '\n' +
          'Custom Details:' + '\n' +
          'Request Details:';

        caseWrapperList.push(docCaseWrapper);
      }
    });

    cmp.set('v.caseWrapperList', caseWrapperList);
  },

  getBaseCaseRecord: function(cmp, line) {
    var invoice = cmp.get('v.invoice');
    var parentCase = cmp.get('v.caseRecord');
    var accRecord = cmp.get('v.accRecord');

    return {
      sobjectType: 'Case',
      Status: 'New',
      Reason: line.inputs.partsRequestReason,
      Origin: 'Agent Console',
      Queue__c: 'Parts Request',
      Category__c: 'Existing Order(s)',
      SubCategory1__c: 'Parts Request',
      AccountId: ($A.util.isEmpty(line.accountId)? ($A.util.isEmpty(parentCase)? accRecord.Id : parentCase.AccountId) : line.accountId),
      ContactId: ($A.util.isEmpty(parentCase)? accRecord.PersonContactId : parentCase.ContactId),
      InvoiceId__c: invoice.invoiceId,
      LineId__c: line.details.invoiceLineId,
      OstkInteractionId__c: line.details.invoiceLineId,
      ProductName__c: line.details.fullProductName,
      ProductId__c: line.details.productId,
      CatalogNumber__c: line.details.fullSku,
      ShipDate__c: line.details.shipDate,
      OriginalVendorId__c: line.details.vendorId,
      OriginalAddressLine1__c: invoice.shippingAddress.address1,
      OriginalAddressLine2__c: invoice.shippingAddress.address2,
      OriginalCity__c: invoice.shippingAddress.city,
      OriginalCountry__c: invoice.shippingAddress.country,
      OriginalZipCode__c: invoice.shippingAddress.postalCode,
      OriginalState__c: invoice.shippingAddress.state,
      AlternateAddressLine1__c: line.inputs.address.address1,
      AlternateAddressLine2__c: line.inputs.address.address2,
      AlternateCity__c: line.inputs.address.city,
      AlternateCountry__c: line.inputs.address.country,
      AlternateZipCode__c: line.inputs.address.postalCode,
      AlternateState__c: line.inputs.address.state,
      Description:
        'Invoice: ' + invoice.invoiceId + '\n' +
        'Ostk SKU: ' + line.details.fullSku + '\n' +
        'Product Name: ' + line.details.fullProductName + '\n' +
        'Customer Name: ' + ($A.util.isEmpty(parentCase)? accRecord.Name : parentCase.Contact.Name) + '\n' +
        'Original Shipping Address: '
            + this.addrPart(invoice.shippingAddress.address1)
            + this.addrPart(invoice.shippingAddress.address2)
            + this.addrPart(invoice.shippingAddress.city)
            + this.addrPart(invoice.shippingAddress.state)
            + this.addrPart(invoice.shippingAddress.postalCode)
            + this.addrPart(invoice.shippingAddress.country) + '\n' +
        'Ship To Address: '
            + this.addrPart(line.inputs.shipToFirstName)
            + this.addrPart(line.inputs.shipToLastName)
            + this.addrPart(line.inputs.address.address1)
            + this.addrPart(line.inputs.address.address2)
            + this.addrPart(line.inputs.address.city)
            + this.addrPart(line.inputs.address.state)
            + this.addrPart(line.inputs.address.postalCode)
            + this.addrPart(line.inputs.address.country)
    };
  },

  //================================================================================
  // SERVER ACTIONS
  //================================================================================

  submit: function(cmp) {
    cmp.set('v.isCreatingCases', true);
    var caseRecord = cmp.get('v.caseRecord');
    var accRecord = cmp.get('v.accRecord');

    var action = cmp.get('c.submitFlow');
    action.setParams({
      caseWrapperListJSON: JSON.stringify(cmp.get('v.caseWrapperList')),
      parentCaseId: ($A.util.isEmpty(caseRecord)? null : caseRecord.Id),
      accountId: ($A.util.isEmpty(accRecord)? null : accRecord.Id)
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseObj = response.getReturnValue();
        cmp.set('v.createdCaseList', responseObj.childCaseList);
        cmp.set('v.createdParentCaseId', responseObj.createdParentCaseId);
        this.createPartsForCases(cmp);
      } else {
        $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
          errorObject: response.getError(),
          cmpIdentifier: cmp.getGlobalId() + '_STEP7_ALERTS',
        }).fire();
      }
      cmp.set('v.isCreatingCases', false);
    });
    $A.enqueueAction(action);
  },

  removeNotReattachedFiles: function(cmp, callback) {
    var action = cmp.get('c.removeNotReattachedFiles');
    action.setParams({
        parentRecordId: cmp.get('v.caseId') || cmp.get('v.accountId')
    });
    action.setCallback(this, function(response) {
      if (callback) {
        callback();
      }
    });
    $A.enqueueAction(action);
  },


  //================================================================================
  // PARTS REQUEST WEBSERVICE
  //================================================================================

  createPartsForCases: function(cmp) {
    cmp.set('v.isProcessingPartsRequest', true);
    var action = cmp.get('c.createPartForCases');

    var caseIdList = cmp.get('v.createdCaseList').map(function(caseObj) {
      return caseObj.Id;
    });
    var createPartParams = {
      invoiceNumber: cmp.get('v.invoice').invoiceId,
      caseIdList: caseIdList
    };
    action.setParams({
      createPartParamsJSON: JSON.stringify(createPartParams)
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var successfulCaseIdList = response.getReturnValue();
        this.handleCreatePartsForCasesResponse(cmp, successfulCaseIdList);
      } else {
        $A.get('e.c:ST_AlertMessages_EVTNew').setParams({
          errorObject: response.getError(),
          cmpIdentifier: cmp.getGlobalId() + '_STEP7_ALERTS',
        }).fire();
      }
      cmp.set('v.isProcessingPartsRequest', false);
    });
    $A.enqueueAction(action);
  },

  handleCreatePartsForCasesResponse: function(cmp, successfulCaseIdList) {
    // get unsuccessful cases and display deletion notifications
    var caseList = cmp.get('v.createdCaseList');
    var deletedCases = caseList.filter(function(caseObj) {
      return successfulCaseIdList.indexOf(caseObj.Id) === -1;
    });
    if (!$A.util.isEmpty(deletedCases)) {
      this.displayPartsErrorModal(cmp, deletedCases);
    }

    // get successful cases and display them
    var successfulCases = caseList.filter(function(caseObj) {
      return successfulCaseIdList.indexOf(caseObj.Id) !== -1;
    });
    cmp.set('v.createdCaseListToDisplay', successfulCases);
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  addrPart: function(part) {
    if (!$A.util.isEmpty(part)) {
      return ' ' + part;
    }

    return '';
  },

  displayPartsErrorModal: function(cmp, deletedCases) {
    var msgLines = [
      '<b>' + $A.get('$Label.c.ST_TWPartCreationFailure') + '<b/>'
    ];

    var listLine = '<ol class="slds-list_ordered">';
    deletedCases.forEach(function(caseObj) {
      listLine += '<li>' + caseObj.CatalogNumber__c + ' - ' + caseObj.ProductName__c + '</li>';
    });
    listLine += '</ol>';
    msgLines.push(listLine);

    $A.get('e.c:ST_Modal_EVTDisplay').setParams({
      cmpIdentifier: cmp.getGlobalId(),
      header: $A.get('$Label.c.ST_TWInvoiceIssues'),
      messageLines: msgLines,
    }).fire();
  }

})