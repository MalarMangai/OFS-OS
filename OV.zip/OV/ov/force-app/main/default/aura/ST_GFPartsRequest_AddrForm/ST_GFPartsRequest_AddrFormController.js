({
  handleCheckValidity: function(cmp) {
    var cbx = cmp.find('address-confirmation-cbx');
    cbx.showHelpMessageIfInvalid();
    return cbx.get('v.validity').valid;
  }
})