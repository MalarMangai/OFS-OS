({
  initialize: function(cmp, event, helper) {
    cmp.set('v.picklistOptions', [
      { value: 'Requested', label: 'Requested' },
      { value: 'Unavailable', label: 'Unavailable' },
      { value: 'Available', label: 'Available' }
    ]);
  },

  handlePartsAvailabilityChange: function(cmp, event, helper) {
    if (cmp.get('v.picklistValue') !== 'Available') {
      cmp.set('v.comment', null);
    }
    helper.fireValuesChangeNotificationEvent(cmp);
  },

  handleCommentChange: function(cmp, event, helper) {
    helper.fireValuesChangeNotificationEvent(cmp);
  },

  handleCheckValidity: function(cmp) {
    var picklistValue = cmp.get('v.picklistValue');
    if (!$A.util.isEmpty(picklistValue)) {
      if (picklistValue === 'Available' && $A.util.isEmpty(cmp.get('v.comment'))) {
        cmp.find('inputComment').showHelpMessageIfInvalid();
        return false;
      }
    } else {
      cmp.set('v.displayPicklistError', true);
      return false;
    }
    return true;
  }
})