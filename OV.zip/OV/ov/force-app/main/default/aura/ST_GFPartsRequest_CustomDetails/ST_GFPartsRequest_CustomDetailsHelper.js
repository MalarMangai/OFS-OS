({
  fireValuesChangeNotificationEvent: function(cmp) {
    cmp.get('e.onValuesChange').fire();
  }
})