({
  initialize: function(cmp) {
    if ($A.util.isEmpty(cmp.get('v.partsCustomDetailsWrappers'))) {
      var partsCustomDetailsDefinition = cmp.get('v.invoiceLine.partsCustomDetailsText');
      var splitDef;
      if (partsCustomDetailsDefinition.indexOf(';') !== -1) {
        splitDef = partsCustomDetailsDefinition.split(';');
      } else {
        splitDef = [partsCustomDetailsDefinition];
      }
      var trimDefList = splitDef.map(function(item) { return item.trim(); });
      var finalList = trimDefList.filter(function(item) { return !$A.util.isEmpty(item); });

      var partsCustomDetailsWrappers = finalList.map(function(item) {
        return {
          label: item,
          value: null,
          comment: null
        };
      });

      cmp.set('v.partsCustomDetailsWrappers', partsCustomDetailsWrappers);
    }
  },

  handleWrapperChange: function(cmp) {
    var partsCustomDetailsWrappers = cmp.get('v.partsCustomDetailsWrappers');

    var output = '';
    partsCustomDetailsWrappers.forEach(function(item, index) {
      output += (index > 0? ' - ' : '');
      output += item.label + ' ' + item.value + ($A.util.isEmpty(item.comment)? '' : ' ' + item.comment);
    });

    cmp.set('v.partsCustomDetailsCombined', output);
  },

  handleCheckValidity: function(cmp) {
    var customDetailsList = cmp.find('custom-details');
    var isValid;

    if(Array.isArray(customDetailsList)) {
      isValid = customDetailsList.reduce(function(acc, childCmp) {
        return childCmp.checkValidity() === false? false : acc;
      }, true);
    } else {
      isValid = customDetailsList.checkValidity();
    }

    return isValid;
  }
})