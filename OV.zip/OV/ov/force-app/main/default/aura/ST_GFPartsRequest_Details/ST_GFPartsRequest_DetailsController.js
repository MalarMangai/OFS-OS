({
  handleCheckValidity: function(cmp) {
    var textarea = cmp.find('textarea-input');
    textarea.showHelpMessageIfInvalid();
    return textarea.get('v.validity').valid;
  }
})