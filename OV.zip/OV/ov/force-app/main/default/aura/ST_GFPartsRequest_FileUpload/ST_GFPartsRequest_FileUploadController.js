({
  initialize: function(cmp, event, helper) {
    var line = cmp.get('v.invoiceLine');
    if (line.partsPicturesRequired && line.inputs.partsRequestReason === 'Damaged or Defective Parts') {
      helper.setPicklistOptions(cmp);
      cmp.set('v.isPicklistEnabled', true);
    }
    helper.getUploadedFiles(cmp);
  },

  handleUploadFinished: function(cmp, event, helper) {
    var uploadedFileList = cmp.get('v.uploadedFileList');
    var newUploadedFileList = event.getParam('files');
	console.log('uploadedFileList ' + cmp.get('v.uploadedFileList'));
   	console.log('newUploadedFileList ' + event.getParam('files'));

    Array.prototype.push.apply(uploadedFileList, newUploadedFileList);

    cmp.set('v.uploadedFileList', uploadedFileList);

    var newCDIds = newUploadedFileList.map(function(file) {
      return file.documentId;
    })
    helper.updateCDsDescription(cmp, newCDIds);
  },

  handleCheckValidity: function(cmp, event, helper) {
    if (cmp.get('v.isPicklistEnabled')) {
      if ($A.util.isEmpty(cmp.get('v.picklistSelection'))) {
        cmp.set('v.displayPicklistError', true);
        return false;
      } else if (cmp.get('v.picklistSelection') === 'Available' && $A.util.isEmpty(cmp.get('v.uploadedFileList'))) {
        cmp.set('v.displayFileUploadError', true);
        return false;
      } else if (cmp.get('v.isProcessing')) {
        return false;
      }
    }
    return true;
  }
})