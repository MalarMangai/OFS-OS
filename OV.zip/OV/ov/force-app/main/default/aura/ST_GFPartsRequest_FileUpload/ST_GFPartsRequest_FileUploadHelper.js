({
  getUploadedFiles: function(cmp) {
    cmp.set('v.isProcessing', true);
    var action = cmp.get('c.getUploadedFiles');

    action.setParams({
      parentRecordId: cmp.get('v.containerRecordId'),
      invoiceLineId: cmp.get('v.invoiceLine.details.invoiceLineId')
    });

    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var actionResponse = response.getReturnValue();
        cmp.set('v.uploadedFileList', actionResponse);
      }
      cmp.set('v.isProcessing', false);
    });
    $A.enqueueAction(action);
  },

  updateCDsDescription: function(cmp, cdIdList) {
    cmp.set('v.isProcessing', true);
    var action = cmp.get('c.updateCDsDescription');

    console.log('Container record id : ' + cmp.get('v.containerRecordId'));
    console.log('invoiceLineId : ' + cmp.get('v.invoiceLine.details.invoiceLineId'));

    action.setParams({
      cdIdList: cdIdList,
      parentRecordId: cmp.get('v.containerRecordId'),
      invoiceLineId: cmp.get('v.invoiceLine.details.invoiceLineId')
    });

    action.setCallback(this, function(response) {
      cmp.set('v.isProcessing', false);
    });
    $A.enqueueAction(action);
  },

  setPicklistOptions: function(cmp) {
    cmp.set('v.picklistOptions', [
      { value: 'Requested', label: 'Requested' },
      { value: 'Unavailable', label: 'Unavailable' },
      { value: 'Available', label: 'Available' }
    ]);
  }
})