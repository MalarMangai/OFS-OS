({
  initialize: function(cmp, event, helper) {
    cmp.set('v.isInitialized', true);
  }
})