({
  getSubFormsComponent: function(cmp) {
    var subForms = cmp.find('sub-forms');
    return $A.util.isArray(subForms)? subForms[0] : subForms;
  },

  handleNextStep: function(cmp) {
    var subForms = this.getSubFormsComponent(cmp);
    return subForms.nextStep();
  },

  handlePrevStep: function(cmp) {
    var subForms = this.getSubFormsComponent(cmp);
    return subForms.prevStep();
  }
})