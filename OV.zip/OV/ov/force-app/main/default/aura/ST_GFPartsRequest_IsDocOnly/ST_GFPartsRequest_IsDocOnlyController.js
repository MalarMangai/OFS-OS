({
  initialize: function(cmp, event, helper) {
    var isDocOnly = cmp.get('v.isDocOnly');
    if (!$A.util.isEmpty(isDocOnly)) {
      cmp.set('v.isDocOnlyString', cmp.get('v.isDocOnly')? 'true' : 'false');
    }

    cmp.set('v.docOnlyRadioOptions', [
      { label: $A.get('$Label.c.ST_YesBtn'), value: 'true' },
      { label: $A.get('$Label.c.ST_NoBtn'), value: 'false' }
    ]);
  },

  handleDocOnlyRadioValueChange: function(cmp, event, helper) {
    cmp.set('v.isDocOnly', cmp.get('v.isDocOnlyString') === 'true');
    setTimeout($A.getCallback(function() {
      cmp.getEvent('onNextStep').fire();
    }), 60);
  }
})