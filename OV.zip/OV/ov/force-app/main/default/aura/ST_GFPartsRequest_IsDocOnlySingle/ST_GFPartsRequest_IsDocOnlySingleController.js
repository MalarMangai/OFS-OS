({
  initialize: function(cmp, event, helper) {
    var isDocOnly = cmp.get('v.isDocOnly');
    if (!$A.util.isEmpty(isDocOnly)) {
      cmp.set('v.isDocOnlyString', cmp.get('v.isDocOnly')? 'true' : 'false');
    }
    cmp.set('v.isNavBlocked', $A.util.isEmpty(isDocOnly));

    cmp.set('v.docOnlyRadioOptions', [
      { label: $A.get('$Label.c.ST_YesBtn'), value: 'true' },
      { label: $A.get('$Label.c.ST_NoBtn'), value: 'false' }
    ]);
  },

  handleDocOnlyRadioValueChange: function(cmp, event, helper) {
    cmp.set('v.isDocOnly', cmp.get('v.isDocOnlyString') === 'true');
    setTimeout($A.getCallback(function() {
      cmp.set('v.isNavBlocked', false);
      cmp.getEvent('onNextStep').fire();
    }), 60);
  },

  handleCheckValidity: function(cmp) {
    var hasError = $A.util.isEmpty(cmp.get('v.isDocOnly'));
    cmp.set('v.displayRadioError', hasError);
    cmp.find('radio-input').showHelpMessageIfInvalid();
    return !hasError;
  }
})