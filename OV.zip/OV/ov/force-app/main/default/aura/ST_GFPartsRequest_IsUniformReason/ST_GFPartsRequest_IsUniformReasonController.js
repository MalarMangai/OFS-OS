({
  initialize: function(cmp, event, helper) {
    if (!$A.util.isEmpty(cmp.get('v.isUniformReason'))) {
      cmp.set('v.isUniformReasonString', cmp.get('v.isUniformReason')? 'true' : 'false');
    } else {
      cmp.set('v.isNavBlocked', true);
    }
    cmp.set('v.uniformReasonRadioOptions', [
      { label: $A.get('$Label.c.ST_YesBtn'), value: 'true' },
      { label: $A.get('$Label.c.ST_NoBtn'), value: 'false' }
    ]);
  },

  handleUniformReasonRadioValueChange: function(cmp, event, helper) {
    cmp.set('v.isUniformReason', cmp.get('v.isUniformReasonString') === 'true');
    setTimeout($A.getCallback(function() {
      cmp.set('v.isNavBlocked', false);
      cmp.getEvent('onNextStep').fire();
    }), 60);
  }
})