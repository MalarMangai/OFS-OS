({
  initialize: function(cmp, event, helper) {
    cmp.set('v.stepsCount', 6);
    var line = cmp.get('v.line');

    if (!line.partsCustomDetails || $A.util.isEmpty(line.partsCustomDetailsText)) {
      helper.skipSteps(cmp, [4], true);
    }

    if (line.inputs.isDocOnly && line.inputs.isUniformReason) {
      helper.skipSteps(cmp, [1, 2, 3, 4, 5]);
    } else if (line.inputs.isUniformReason) {
      helper.skipSteps(cmp, [1, 2]);
    } else if (line.inputs.isDocOnly) {
      helper.skipSteps(cmp, [2, 3, 4, 5]);
    }

    setTimeout($A.getCallback(function() {
      cmp.set('v.isInitialized', true);
    }));
  }
})