({

  //================================================================================
  // SUBSTEP MANAGEMENT
  //================================================================================

  handleNextStep: function(cmp, currentStep) {
    return cmp.find('step-' + currentStep).checkValidity();
  },

  onStepLeave: function(cmp, step, forward) {
    if (forward) {
      if (step === 1) {
        var line = cmp.get('v.line');
        if (line.inputs.isDocOnly) {
          this.skipSteps(cmp, [2, 3, 4, 5]);
          line.inputs.partsRequestReason = 'Instruction Manual Needed';
          line.inputs.picturesAvailability = null;
          line.inputs.partsCustomDetailsCombined = null;
          line.inputs.partsCustomDetailsWrappers = null;
          line.inputs.detailedInfo = null;
          line.inputs.ltl = line.details.ltl;
          line.inputs.isDocNeededInAdditionToParts = false;
        } else {
          this.unSkipSteps(cmp, [2, 3, 4, 5]);
          if (line.inputs.partsRequestReason === 'Instruction Manual Needed') {
            line.inputs.partsRequestReason = null;
          }
        }
        line.inputs.isAddressConfirmed = false;
        cmp.set('v.line', line);
      }
    }
  },

})