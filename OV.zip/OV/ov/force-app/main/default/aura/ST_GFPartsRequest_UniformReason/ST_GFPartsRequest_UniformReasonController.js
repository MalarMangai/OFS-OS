({

  initialize: function(cmp) {
    cmp.set('v.isNavBlocked', $A.util.isEmpty(cmp.get('v.uniformReason')));

    cmp.set('v.reasonOptions', [
      { label: 'Incorrect Parts', value: 'Incorrect Parts' },
      { label: 'Damaged or Defective Parts', value: 'Damaged or Defective Parts' },
      { label: 'Request Exception', value: 'Request Exception' },
      { label: 'Missing Parts', value: 'Missing Parts' }
    ]);
  },

  handleUniformReasonPicklistValueChange: function(cmp) {
    setTimeout($A.getCallback(function() {
      cmp.getEvent('onNextStep').fire();
    }), 60);
  }

})