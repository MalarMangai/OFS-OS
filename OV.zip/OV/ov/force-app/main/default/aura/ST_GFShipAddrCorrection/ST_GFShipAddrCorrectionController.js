({

  //================================================================================
  // INIT SETUP & DATA LOAD
  //================================================================================

  initialize: function(cmp, event, helper) {
    cmp.set('v.stepsCount', 5);
    helper.skipSteps(cmp, [2]);
  },


  //================================================================================
  // CONTAINER EVENTS
  //================================================================================

  handleCancel: function(cmp, event, helper) {
    cmp.getEvent('onDone').setParams({
      passed: false
    }).fire();
  },

  goToParentCase: function(cmp, event, helper) {
    $A.get('e.force:navigateToSObject').setParams({
      recordId: cmp.get('v.createdParentCaseId')
    }).fire();
  }

})