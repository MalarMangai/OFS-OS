({
  onFinish: function(cmp) {
    if (cmp.get('v.isUniformCorrection')) {
      this.setupLinesWithUniformAddressCorrection(cmp); 
    }
  },

  setupLinesWithUniformAddressCorrection: function(cmp) {
    var lineList = cmp.get('v.lineList');
    lineList.forEach(function(lineItem) {
      lineItem.correctedShipToFirstName = cmp.get('v.correctedShipToFirstName');
      lineItem.correctedShipToLastName = cmp.get('v.correctedShipToLastName');
      lineItem.correctedAddress = cmp.get('v.correctedAddress');
    });

    cmp.set('v.lineList', lineList);
  }
})