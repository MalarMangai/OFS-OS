({
  initialize: function(cmp) {
    if (!$A.util.isEmpty(cmp.get('v.isUniformCorrection'))) {
      cmp.set('v.isUniformCorrectionString', cmp.get('v.isUniformCorrection')? 'true' : 'false');
    }
    cmp.set('v.radioOptions', [
      { label: $A.get('$Label.c.ST_YesBtn'), value: 'true' },
      { label: $A.get('$Label.c.ST_NoBtn'), value: 'false' }
    ]);
  },

  handleRadioValueChange: function(cmp) {
    cmp.set('v.isUniformCorrection', cmp.get('v.isUniformCorrectionString') === 'true');
    setTimeout($A.getCallback(function() {
      cmp.getEvent('onNextStep').fire();
    }), 60);
  }
})