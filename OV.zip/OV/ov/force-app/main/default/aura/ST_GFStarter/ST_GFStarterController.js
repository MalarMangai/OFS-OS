({

  handleStartGuidedFlow: function(cmp, event, helper) {
    if (cmp.get('v.hasActiveFlow')) {
      return;
    }
    cmp.set('v.hasActiveFlow', true);
    cmp.set('v.isLoadingFlow', true);

    var params = event.getParam('arguments');
    var attributes = {
      'aura:id': 'guided-flow-component',
      onDone: cmp.getReference('c.destroyGuidedFlowComponent')
    };
    if (!$A.util.isEmpty(params.flowAttrs)) {
      params.flowAttrs.forEach(function(flowAttr) {
        attributes[flowAttr.attrName] = flowAttr.attrValue;
      });
    }

    $A.createComponent(
      params.componentName,
      attributes,
      function(flowCmp, status, errorMessage) {
        if (status === 'SUCCESS') {
          var body = cmp.get('v.body');
          body.push(flowCmp);
          cmp.set('v.body', body);
        }
        else {
          console.warn('Error: ' + errorMessage);
        }
        cmp.set('v.isLoadingFlow', false);
      }
    );
  },

  destroyGuidedFlowComponent: function(cmp, event, helper) {
    cmp.find('guided-flow-component').destroy();
    cmp.set('v.hasActiveFlow', false);
  }

})