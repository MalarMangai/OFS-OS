({

  initialize: function(cmp, event, helper) {
    var currentStep = cmp.get('v.currentStep');
    if (cmp.get('v.thisStep') === currentStep) {
      cmp.set('v.isVisible', true);
    }
    cmp.set('v.prevStep', currentStep);
  },

  handleCurrentStepChange: function(cmp, event, helper) {
    var thisStep = cmp.get('v.thisStep');
    var prevStep = cmp.get('v.prevStep');
    var currentStep = cmp.get('v.currentStep');

    if (prevStep === currentStep || $A.util.isEmpty(currentStep)) {
      return;
    }

    var willBeVisible = (currentStep === thisStep);
    var willBeHidden = (prevStep === thisStep);

    if (willBeVisible || willBeHidden) {
      var animationFromClass = ''
      var animationDirectionClass = '';
      var animationPostfix = (prevStep > currentStep? 'right' : 'left');
      if (willBeVisible) {
        animationFromClass = 'slide-in-' + animationPostfix;
      } else {
        animationFromClass = 'slide-out-' + animationPostfix;
      }
      animationDirectionClass = 'animate-' + animationPostfix;

      cmp.set('v.animationFromClass', animationFromClass);
      cmp.set('v.animationClass', '');

      if (willBeHidden) {
        setTimeout($A.getCallback(function() {
          cmp.set('v.animationClass', animationDirectionClass);
        }));
        setTimeout($A.getCallback(function() {
          cmp.set('v.isVisible', false);
        }), 250);
      }

      if (willBeVisible) {
        setTimeout($A.getCallback(function() {
          cmp.set('v.isVisible', true);
          setTimeout($A.getCallback(function() {
            cmp.set('v.animationClass', animationDirectionClass);
          }));
        }), 251);
      }
    }

    cmp.set('v.prevStep', currentStep);
  }

})