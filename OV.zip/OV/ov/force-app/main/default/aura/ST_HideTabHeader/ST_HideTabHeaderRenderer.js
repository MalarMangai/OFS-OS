({
  afterRender: function (cmp, helper) {
    this.superAfterRender();
    setTimeout($A.getCallback(function() {
      cmp.set('v.hideHeader', true);
    }), cmp.get('v.delay'));
  }
})