({
  handleReloadIframeClick: function(cmp, event, helper) {
    helper.handleReloadIframeClick(cmp);
  },

  handleIframeLoad: function(cmp) {
    cmp.set('v.isReloadingIframe', false);
  }
})