({

  //================================================================================
  // RELOADING
  //================================================================================

  handleReloadIframeClick: function(cmp) {
    var helper = this;
    cmp.set('v.isReloadingIframe', true);

    var cmpInst = cmp.getConcreteComponent();
    if (cmpInst.onIframeReload) {
      cmpInst.onIframeReload(function() {
        helper.resetIframeSource(cmp);
      });
    } else {
      helper.resetIframeSource(cmp);
    }
  },

  resetIframeSource: function(cmp) {
    var iframe = cmp.find('iframe').getElement();
    iframe.src = iframe.src;

    setTimeout($A.getCallback(function() {
      cmp.set('v.isReloadingIframe', false);
    }), 5000);
  },

  //================================================================================
  // UI STYLING
  //================================================================================

  calcIFrameOffsetAttr: function(cmp) {
    var iframe = cmp.find('iframe').getElement();
    var offsetTop = iframe.getBoundingClientRect().top;

    cmp.set('v.iframeOffsetTop', offsetTop);
  }

})