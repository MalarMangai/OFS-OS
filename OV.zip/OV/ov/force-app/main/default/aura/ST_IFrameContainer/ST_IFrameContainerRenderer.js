({
  afterRender: function (cmp, helper) {
    this.superAfterRender();

    helper.calcIFrameOffsetAttr(cmp);
  }
})