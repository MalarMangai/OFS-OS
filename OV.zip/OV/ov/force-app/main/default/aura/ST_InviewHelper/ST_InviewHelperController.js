({

  initialize: function(cmp, event, helper) {
    cmp._checkIfInViewHandler = helper.debounce($A.getCallback(function() {
      if (cmp.isValid() && cmp.get('v.isRendered')) {
        helper.checkIfInView(cmp);
      }
    }));

    window.addEventListener('scroll', cmp._checkIfInViewHandler);
    window.addEventListener('resize', cmp._checkIfInViewHandler);
  },


  destroy: function(cmp, event, helper) {
    helper.cleanup(cmp);
  }

})