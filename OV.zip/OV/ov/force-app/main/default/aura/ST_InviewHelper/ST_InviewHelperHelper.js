({

  checkIfInView: function(cmp) {
    var elem = cmp.find('anchor').getElement();
    var elemBoundingRect = elem.getBoundingClientRect()
    if (elemBoundingRect.top < window.innerHeight + cmp.get('v.distanceThreshold')) {
      this.fireInViewEvent(cmp);
      this.cleanup(cmp);
    }
  },

  fireInViewEvent: function(cmp) {
    cmp.get('e.onInView').fire();
  },

  debounce: function(func) {
    var timeout;

    return function() {
     clearTimeout(timeout);
     timeout = setTimeout($A.getCallback(function() {
       timeout = null
       func.call();
     }), 100);
    };
  },

  cleanup: function(cmp) {
    window.removeEventListener('scroll', cmp._checkIfInViewHandler);
    window.removeEventListener('resize', cmp._checkIfInViewHandler);
  }

})