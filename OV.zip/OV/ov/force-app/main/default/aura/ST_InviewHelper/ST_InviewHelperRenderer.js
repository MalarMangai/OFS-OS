({
  afterRender: function(cmp, helper) {
    this.superAfterRender();

    cmp.set('v.isRendered', true);
    helper.checkIfInView(cmp);
  }
})