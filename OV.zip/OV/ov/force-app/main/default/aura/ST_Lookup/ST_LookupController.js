({

  //================================================================================
  // COMPONENT STARTUP
  //================================================================================

  initialize: function(cmp, event, helper) {
    cmp.set('v.objEntryList', null);

    var preselectedRecordId = cmp.get('v.value');
    if (!$A.util.isEmpty(preselectedRecordId)) {
      helper.getSelectedRecord(cmp, preselectedRecordId);
    }
  },


  //================================================================================
  // PARENT COMPONENT MANIPULATION
  //================================================================================

  handleValueChange: function(cmp, event, helper) {
    if (!cmp._isSelfValueChange) {
      //handle change of value forced by parent component
      try {
        var value = cmp.get('v.value');
        if ($A.util.isEmpty(value)) {
          helper.setSelection(cmp, null, false);
        } else {
          helper.getSelectedRecord(cmp, value);
        }
      } catch(e) {} //fail gracefully - exception might be caused by handlers being accessed before component is unrendered
    }

    setTimeout($A.getCallback(function() {
      cmp._isSelfValueChange = false;
    }));
  },


  //================================================================================
  // UI ACTION HANDLERS
  //================================================================================

  handleInputEvent: function(cmp, event, helper) {
    var searchTerm = event.target.value;

    helper.clearSuggestions(cmp);
    if (!$A.util.isEmpty(searchTerm)) {
      helper.getEntries(cmp, searchTerm);
    } else {
      helper.discardCurrentAction(cmp);
    }
  },

  handleInputFocus: function(cmp, event, helper) {
    cmp.set('v.isFocused', true);
    if (!$A.util.isEmpty(cmp.get('v.objEntryList'))) {
      helper.openDropdown(cmp);
    }
  },

  handleInputBlur: function(cmp, event, helper) {
    cmp.set('v.isFocused', false);
    helper.closeDropdown(cmp);
  },

  handleInputKeyPress: function(cmp, event, helper) {
    helper.handleInputKeyPress(cmp, event);
  },

  handleEntrySelection: function(cmp, event, helper) {
    var entryIndex = event.currentTarget.dataset.entryIndex;
    helper.handleEntrySelection(cmp, entryIndex);
  },

  handleEntryDeselection: function(cmp, event, helper) {
    helper.handleEntryDeselection(cmp);
  },

  preventDefault: function(cmp, event) {
    event.preventDefault();
  },


  //================================================================================
  // COMPONENT ATTRS MANIPULATION
  //================================================================================

  handleDisabledChange: function(cmp, event, helper) {
    helper.updateInputAttrs(cmp);
  }


})