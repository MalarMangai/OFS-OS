({

  //================================================================================
  // DATA LOAD
  //================================================================================

  getEntries: function(cmp, searchTerm) {
    var helper = this;

    cmp.set('v.isLoadingEntries', true);
    var thisActionTimestamp = Date.now();
    cmp._lastGetEntriesTimestamp = thisActionTimestamp;

    var action = cmp.get('c.getLookupEntries');
    action.setAbortable();
    var params = this.getParamsObject(cmp);
    action.setParams({
      paramsJSON: JSON.stringify(params),
      searchTerm: searchTerm
    });
    action.setCallback(this, function(response) {
      if (cmp._lastGetEntriesTimestamp === null || cmp._lastGetEntriesTimestamp !== thisActionTimestamp) {
        //discard action
        return;
      }
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseList = response.getReturnValue();
        helper.setEntryList(cmp, responseList);
        helper.openDropdown(cmp);
      } else {
        console.warn('ERROR:', response.getError());
      }
      cmp.set('v.isLoadingEntries', false);
    });
    $A.enqueueAction(action);
  },

  getSelectedRecord: function(cmp, recordId) {
    var helper = this;
    cmp.set('v.isLoadingPreselectedRecord', true);

    var action = cmp.get('c.getSelectedRecord');
    var params = this.getParamsObject(cmp);
    action.setParams({
      paramsJSON: JSON.stringify(params),
      recordId: recordId
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var preselectedRecord = response.getReturnValue();
        this.setSelection(cmp, preselectedRecord, false);
      } else {
        console.warn('ERROR:', response.getError());
      }
      cmp.set('v.isLoadingPreselectedRecord', false);
    });
    $A.enqueueAction(action);
  },

  getParamsObject: function(cmp) {
    var objectNames = $A.util.isEmpty(cmp.get('v.objectNames_mult'))?
      $A.util.isEmpty(cmp.get('v.objectName'))? null : [cmp.get('v.objectName')] : cmp.get('v.objectNames_mult');
    var searchByFields = $A.util.isEmpty(cmp.get('v.searchByFields_mult'))?
      $A.util.isEmpty(cmp.get('v.searchByFields'))?  null : [cmp.get('v.searchByFields')] : cmp.get('v.searchByFields_mult');
    var whereConditions = $A.util.isEmpty(cmp.get('v.whereConditions_mult'))?
        $A.util.isEmpty(cmp.get('v.whereConditions'))?  null : [cmp.get('v.whereConditions')] : cmp.get('v.whereConditions_mult');
    var displayObjectNames = $A.util.isEmpty(cmp.get('v.displayObjectName_mult'))?
        $A.util.isEmpty(cmp.get('v.displayObjectName'))?  null : [cmp.get('v.displayObjectName')] : cmp.get('v.displayObjectName_mult');
    var displayFields = $A.util.isEmpty(cmp.get('v.displayFields_mult'))?
        $A.util.isEmpty(cmp.get('v.displayFields'))?  null : [cmp.get('v.displayFields')] : cmp.get('v.displayFields_mult');
    return {
      objectNames: objectNames,
      searchByFields: searchByFields,
      whereConditions: whereConditions,
      displayObjectNames: displayObjectNames,
      displayFields: displayFields,
      maxEntriesPerObj: cmp.get('v.maxEntries')
    };
  },

  setEntryList: function(cmp, entryList) {
    var objectIcons_mult = cmp.get('v.objectIcons_mult');
    if (!$A.util.isEmpty(objectIcons_mult)) {
      var objNames = cmp.get('v.objectNames_mult');
      var objNameToIconMap = {};
      for (var i = 0; i < objectIcons_mult.length; i++) {
        objNameToIconMap[objNames[i]] = objectIcons_mult[i];
      }

      entryList.forEach(function(entry) {
        entry.ltngIconName = objNameToIconMap[entry.objectType];
      });
    }

    cmp.set('v.objEntryList', entryList);
    cmp.set('v.currentHighlightIndex', entryList.length == 1? 0 : -1);
  },


  //================================================================================
  // ENTRY SELECTION METHODS
  //================================================================================

  handleEntrySelection: function(cmp, entryIndex) {
    var objEntryList = cmp.get('v.objEntryList');
    var selectedEntry = objEntryList[entryIndex];

    this.closeDropdown(cmp);
    this.setSelection(cmp, selectedEntry, true);
    this.clearSuggestions(cmp);
    this.focusDeselectionBtn(cmp);
  },

  handleEntryDeselection: function(cmp) {
    this.setSelection(cmp, null, true);
    this.focusInput(cmp);
  },

  setSelection: function(cmp, selectedEntry, fireValueChangeEvent) {
    this.setValue(cmp, (!$A.util.isEmpty(selectedEntry)? selectedEntry.value : null), fireValueChangeEvent);
    cmp.set('v.displayValue', (!$A.util.isEmpty(selectedEntry)? selectedEntry.label : null));
    cmp.set('v.selectedRecord', selectedEntry);

    this.updateInputAttrs(cmp);
  },

  setValue: function(cmp, value, fireValueChangeEvent) {
    var oldValue = cmp.get('v.value');
    if (oldValue !== value) {
      cmp._isSelfValueChange = true;
      cmp.set('v.value', value);

      //events
      if (fireValueChangeEvent) {
        cmp.get('e.valueChange').setParams({
          value: value,
          oldValue: oldValue
        }).fire();
      }
      cmp.get('e.valueChange_anySource').setParams({
        value: value,
        oldValue: oldValue
      }).fire();
    }
  },


  //================================================================================
  // KEYBOARD HELPER METHODS
  //================================================================================

  handleInputKeyPress: function(cmp, event) {
    var helper = this;
    switch (event.keyCode) {
      case 38: //up arrow
        if (this.hasEntries(cmp)) {
          setTimeout($A.getCallback(function() {
            helper.highlightPrevEntry(cmp);
          }));
        }
        event.preventDefault();
        break;
      case 40: //down arrow
        if (this.hasEntries(cmp)) {
          setTimeout($A.getCallback(function() {
            helper.highlightNextEntry(cmp);
          }));
        }
        event.preventDefault();
        break;
      case 13: //enter
        if (this.hasEntries(cmp)) {
          this.selectHighlightedOption(cmp);
        }
        break;
      case 27: //escape
        this.closeDropdown(cmp);
        break;
    }
  },

  highlightNextEntry: function(cmp) {
    var currentHighlightIndex = cmp.get('v.currentHighlightIndex');
    var nextHighlightIndex = currentHighlightIndex + 1;

    var numOfOptions = cmp.get('v.objEntryList').length;
    if (nextHighlightIndex >= numOfOptions) {
      nextHighlightIndex = 0;
    }

    cmp.set('v.currentHighlightIndex', nextHighlightIndex);

    this.scrollToEntryIfOutOfView(cmp, nextHighlightIndex);
  },

  highlightPrevEntry: function(cmp) {
    var currentHighlightIndex = cmp.get('v.currentHighlightIndex');
    var nextHighlightIndex = currentHighlightIndex - 1;

    var numOfOptions = cmp.get('v.objEntryList').length;
    if (nextHighlightIndex < 0) {
      nextHighlightIndex = numOfOptions - 1;
    }

    cmp.set('v.currentHighlightIndex', nextHighlightIndex);

    this.scrollToEntryIfOutOfView(cmp, nextHighlightIndex);
  },

  selectHighlightedOption: function(cmp, event) {
    var currentHighlightIndex = cmp.get('v.currentHighlightIndex');
    if (currentHighlightIndex !== -1) {
      this.handleEntrySelection(cmp, currentHighlightIndex);
    }
  },


  //================================================================================
  // UI HELPER METHODS
  //================================================================================

  openDropdown: function(cmp) {
    //check if dropDOWN should be actually a dropUP
    setTimeout($A.getCallback(function() {
      if (!cmp.get('v.isOpen')) {
        var container = cmp.find('lookup-dropdown').getElement();
        var anchor = cmp.find('lookup-dropdown-anchor').getElement();
        var cHeight = container.clientHeight;
        var aOffsetTop = anchor.getBoundingClientRect().top;
        cmp.set('v.isOpenAbove', cHeight + aOffsetTop > window.innerHeight)
        cmp.set('v.isOpen', true);
      }
    }));
  },

  closeDropdown: function(cmp) {
    cmp.set('v.isOpen', false);
    cmp.set('v.isOpenAbove', true);
  },

  focusInput: function(cmp) {
    cmp.set('v.isFocused', false);
    setTimeout($A.getCallback(function() {
      var input = cmp.find('input').getElement();
      input.focus();
    }));
  },

  updateInputAttrs: function(cmp) {
    var helper = this;

    setTimeout($A.getCallback(function() {
      if ($A.util.isEmpty(cmp.get('v.selectedRecord'))) {
        helper.setAttrsOnInput(cmp);
        helper.applyDisabledAttr(cmp, 'input');
      } else {
        cmp.set('v.isFocused', false);
        helper.setDisplayValueOnReadonlyInput(cmp);
        helper.applyDisabledAttr(cmp, 'readonly-input');
      }
    }));
  },

  setDisplayValueOnReadonlyInput: function(cmp) {
    var input = this.getInput(cmp, 'readonly-input');
    if (input) {
      input.setAttribute('value', cmp.get('v.displayValue'));
    }
  },

  setAttrsOnInput: function(cmp) {
    var input = this.getInput(cmp, 'input');
    if (input) {
      input.setAttribute('autocomplete', 'off');
    }
  },

  applyDisabledAttr: function(cmp, inputName) {
    var input = this.getInput(cmp, inputName);
    if (input) {
      if (cmp.get('v.disabled')) {
        input.setAttribute('disabled', 'true');
      } else {
        input.removeAttribute('disabled');
      }
    }
  },

  focusDeselectionBtn: function(cmp) {
    setTimeout($A.getCallback(function() {
      var btn = cmp.find('deselection-btn').getElement();
      btn.focus();
    }));
  },

  scrollToEntryIfOutOfView: function(cmp, entryIndex) {
      var container = cmp.find('lookup-dropdown').getElement();
      var entryList = cmp.find('lookup-entry');
      if (entryList.filter) {
        var entry = entryList.filter(function(item) {
          return parseInt(item.getElement().dataset.entryIndex) === entryIndex;
        })[0].getElement();

        var cTop = container.scrollTop;
        var cBottom = cTop + container.clientHeight;

        var eTop = entry.offsetTop;
        var eBottom = eTop + entry.clientHeight;

        if (eTop < cTop) {
          container.scrollTop -= (cTop - eTop);
        }
        else if (eBottom > cBottom) {
          container.scrollTop += (eBottom - cBottom);
        }
      }
  },


  //================================================================================
  // HELPER METHODS
  //================================================================================

  clearSuggestions: function(cmp) {
    cmp.set('v.objEntryList', null);
  },

  getInput: function(cmp, inputName) {
    var input = cmp.find(inputName);
    if (input) {
      return input.getElement();
    }
    return null;
  },

  hasEntries: function(cmp) {
    return !$A.util.isEmpty(cmp.get('v.objEntryList'));
  },

  discardCurrentAction: function(cmp) {
    cmp._lastGetEntriesTimestamp = null;
    cmp.set('v.isLoadingEntries', false);
  }

})