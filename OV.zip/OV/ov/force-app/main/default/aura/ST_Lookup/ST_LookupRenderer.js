({
  afterRender: function(cmp, helper) {
    this.superAfterRender();

    helper.updateInputAttrs(cmp);

    //icon load is postponed due to bug, which caused it not to load at component init
    setTimeout($A.getCallback(function() {
      cmp.set('v.loadSearchIcon', true);
    }));
  }
})