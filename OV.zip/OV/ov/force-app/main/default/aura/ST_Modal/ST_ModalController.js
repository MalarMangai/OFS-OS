({

  //================================================================================
  // MODAL EVENTS
  //================================================================================

  enqueueNewEvent: function(cmp, event, helper) {
    var cmpIdentifier = cmp.get('v.cmpIdentifier');
    if (($A.util.isEmpty(cmpIdentifier) && $A.util.isEmpty(event.getParam('cmpIdentifier')))
        || cmpIdentifier === event.getParam('cmpIdentifier')) {
      helper.enqueueNewEvent(cmp, event);
    }
  },

  handleOpenModal: function(cmp, event, helper) {
    var params = event.getParam('arguments').params;
    var eventObj = {
      getParam: function(paramName) {
        return params[paramName];
      }
    };
    helper.enqueueNewEvent(cmp, eventObj);
  },

  handleCloseModal: function(cmp, event, helper) {
    helper.finalizeCurrentEvent(cmp)
  },


  //================================================================================
  // UI EVENTS
  //================================================================================

  handleConfirmClick: function(cmp, event, helper) {
    var callback = cmp.get('v.confirmCallback');

    var shouldFinalize = true;
    if (callback) {
      shouldFinalize = callback();
    }

    if (shouldFinalize !== false) {
      helper.finalizeCurrentEvent(cmp)
    }
  },

  handleCancelClick: function(cmp, event, helper) {
    var callback = cmp.get('v.cancelCallback');
    if (callback) {
      callback();
    }

    helper.finalizeCurrentEvent(cmp)
  },

  handleOutsideModalClick: function(cmp, event, helper) {
    if (cmp.get('v.showCloseButton')) {
      var callback = cmp.get('v.cancelCallback');
      if (callback) {
        callback();
      }

      helper.finalizeCurrentEvent(cmp)
    }
  },

  stopPropagation: function(component, event, helper) {
    event.stopPropagation();
  },

  //================================================================================
  // COMPONENT LIFECYCLE
  //================================================================================

  destroy: function(cmp, event, helper) {
    helper.cleanupFocusMechanism(cmp);
  }

})