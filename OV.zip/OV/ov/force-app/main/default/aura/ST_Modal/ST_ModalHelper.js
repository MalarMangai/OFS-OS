({

  //================================================================================
  // MODAL EVENT QUEUE
  //================================================================================

  enqueueNewEvent: function(cmp, event) {
    var eventQueue = cmp.get('v.eventQueue');
    eventQueue.push(event);
    cmp.set('v.eventQueue', eventQueue);

    if (eventQueue.length === 1) {
      this.handleNextEvent(cmp, event);
    }
  },

  handleNextEvent: function(cmp, event) {
    var helper = this;

    cmp.set('v.messageLines', event.getParam('messageLines')
                              || ($A.util.isEmpty(event.getParam('message'))? null : [event.getParam('message')]));
    cmp.set('v.html', event.getParam('html'));
    cmp.set('v.header', event.getParam('header'));
    cmp.set('v.showCloseButton', event.getParam('showCloseButton') || false);
    cmp.set('v.confirmCallback', event.getParam('confirmCallback'));
    cmp.set('v.cancelCallback', event.getParam('cancelCallback'));
    cmp.set('v.buttonsVariant', event.getParam('buttonsVariant') || 'CONFIRM');
    cmp.set('v.confirmButtonLabel', event.getParam('confirmButtonLabel'));
    cmp.set('v.noContentPadding', event.getParam('noContentPadding') || false);
    if(!$A.util.isEmpty(event.getParam('size'))) {
      cmp.set('v.size', event.getParam('size'));
    }

    cmp.set('v.isOpen', true);
    cmp.set('v.isBackdropVisible', true);

    setTimeout($A.getCallback(function() {
       helper.setupFocusMechanism(cmp);
    }));
  },

  finalizeCurrentEvent: function(cmp) {
    var helper = this;

    var eventQueue = cmp.get('v.eventQueue');
    eventQueue.shift();
    cmp.set('v.eventQueue', eventQueue);

    cmp.set('v.isOpen', false);
    if (!this.hasMoreEvents(cmp)) {
      cmp.set('v.isBackdropVisible', false);
    }
    this.cleanupFocusMechanism(cmp);

    if (this.hasMoreEvents(cmp)) {
      setTimeout($A.getCallback(function() {
        helper.handleNextEvent(cmp, eventQueue[0]);
      }), 200);
    }
  },

  hasMoreEvents: function(cmp) {
    return cmp.get('v.eventQueue').length !== 0;
  },


  //================================================================================
  // UI HELPERS
  //================================================================================

  setupFocusMechanism: function(cmp) {
    var helper = this;

    var modal = cmp.find('modal-container').getElement();
    var focusableElements = modal.querySelectorAll('button, a, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');

    cmp._firstFocusable = focusableElements[0];
    cmp._lastFocusable = focusableElements[focusableElements.length - 1];

    cmp._lastFocusableHandler = function (e) {
      if (e.which === 9 && !e.shiftKey) { // TAB key
        e.preventDefault();
        cmp._firstFocusable.focus();
      }
    };
    cmp._lastFocusable.addEventListener('keydown', cmp._lastFocusableHandler);

    cmp._firstFocusableHandler = function (e) {
      if (e.which === 9 && e.shiftKey) { // TAB key
        e.preventDefault();
        cmp._lastFocusable.focus();
      }
    };
    cmp._firstFocusable.addEventListener('keydown', cmp._firstFocusableHandler);

    cmp._escapeKeyHandler = $A.getCallback(function(e) {
      if (e.keyCode === 27) { // ESCAPE key
        helper.finalizeCurrentEvent(cmp);
      };
    });
    modal.addEventListener('keyup', cmp._escapeKeyHandler);

    var cancelBtn = cmp.find('cancel-btn');
    var confirmBtn = cmp.find('cancel-btn');
    if (!$A.util.isEmpty(cancelBtn)) {
      cancelBtn.getElement().focus();
    } if (!$A.util.isEmpty(confirmBtn)) {
      confirmBtn.getElement().focus();
    }
  },

  cleanupFocusMechanism: function(cmp) {
    if (cmp.isValid()) {
      if (!$A.util.isEmpty(cmp._lastFocusable)) {
        cmp._lastFocusable.removeEventListener('keydown', cmp._lastFocusableHandler);
      }
      if (!$A.util.isEmpty(cmp._firstFocusable)) {
        cmp._firstFocusable.removeEventListener('keydown', cmp._firstFocusableHandler);
      }
    }
  }

})