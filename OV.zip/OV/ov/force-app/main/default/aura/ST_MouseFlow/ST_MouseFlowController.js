({
  afterJSLoaded: function(component, event, helper) {
    helper.loadMouseFlowScript(component);
  }
})