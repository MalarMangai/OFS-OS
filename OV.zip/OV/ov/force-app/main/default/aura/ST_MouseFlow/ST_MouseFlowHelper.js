({
  putUserData: function(component) {
    var action = component.get("c.fetchCurrentUser");
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        window._mfq.push(["setVariable", "Username", response.getReturnValue().Username]);
          console.log(response.getReturnValue().Username);
      }
    });

    $A.enqueueAction(action);
  },

  loadMouseFlowScript: function(component) {
    window._mfq = window._mfq || [];
    (function() {
      var mf = document.createElement("script");
      mf.type = "text/javascript";
      mf.async = true;
      mf.src = $A.get('$Resource.OstkMouseFlowBase');
      document.getElementsByTagName("head")[0].appendChild(mf);
    })();

    window._mfq.push(["newPageView", component.get("v.pageName")]);
    this.putUserData(component);
  }
})