({

    doInit: function(component,event,helper) {
    },

  saveRecord: function(component, event, helper) {
    helper.saveRecord(component);
  },
})