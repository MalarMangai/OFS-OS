({
  fireSavedEvent: function(component) {
    var appEvent = $A.get("e.c:ST_PAAccountUpdate_EVTSaved");
    appEvent.setParams({"account" : component.get("v.simpleRecord")});
    appEvent.fire();
  },

  saveRecord: function(component) {
		console.log('ST_PAAccountUpdateHelper.saveRecord - enter');
	  var action = component.get('c.createUpdateCase');
	  var tempCaseId = 'NONE';
	  var newCase = new Boolean();
	  if(component.get('v.tempCaseId')) {
		newCase = false;
		tempCaseId = component.get('v.tempCaseId');
	  }
	  else {
	  	newCase = true;
	  }
	  console.log('ST_PAAccountUpdateHelper.saveRecord - New Case = ' + newCase);
	  action.setParams({
		  a:component.get('v.simpleRecord'),
		  newCase: newCase,
		  caseId: tempCaseId
	  });
	  action.setCallback(this, function(response) {
		  var caseId = response.getReturnValue();
		  var state = response.getState();
		  console.log('ST_PAAccountUpdateHelper.saveRecord - Case ID = ' + caseId);
		  if(state === "SUCCESS") {
			  component.set('v.tempCaseId',caseId);
			  var action1 = component.get('c.pushToCSApp');
			  action1.setParams({
				  cid:caseId,
				  a:component.get('v.account'),
				  s:component.get('v.simpleRecord')
			  });
			  action1.setCallback(this, function(res) {
			  	var csAppResponse = res.getReturnValue();
			  	var state1 = res.getState();
				  console.log('ST_PAAccountUpdateHelper.saveRecord - CSApp Response = ' + csAppResponse);
			  	if(state1 === 'SUCCESS') {
			  		if(csAppResponse === 'SUCCESS') {
			  			this.successUpdatingCSApp(component,caseId);
				    }
				    else {
					    var errMsg = JSON.parse(csAppResponse);
					    var message = new String();
					    for (var i = 0; i < errMsg['fields'].length; i++) {
					    	switch (errMsg['fields'][i]['field']) {
							    case 'workPhone':
								    message += 'Account Phone - ';
							    	break;
							    case 'homePhone':
								    message += 'Home Phone - ';
							    	break;
							    case 'mobilePhone':
								    message += 'Mobile Phone - ';
						            break;
							    case 'email':
								    message += 'Email - ';
							    	break;
					    		default:
							    	break;
						    }
						    message += errMsg['fields'][i]['message'] + '\n';
					    }
					    this.errorUpdatingCSApp(component,message,caseId);
				    }
			    }
			    else {
			    	console.log('CSAPP UPDATE FAILURE');
			    }
			  });
			  $A.enqueueAction(action1);
		  }
		  else {
			  console.log('CASE CREATE FAILURE');
		  }
	  });
	  $A.enqueueAction(action);
	  console.log('ST_PAAccountUpdateHelper.saveRecord - exit');
  },

	successUpdatingCSApp: function(component,caseId) {
		console.log('ST_PAAccountUpdateHelper.successUpdatingCSApp - enter');
  	    var action = component.get('c.csAppSuccess');
  	    action.setParams({
	        cid: caseId
        });
  	    action.setCallback(this,function(response) {
  	    	var status = response.getReturnValue();
  	    	var state = response.getState();
	        console.log('ST_PAAccountUpdateHelper.successUpdatingCSApp - Update Response = ' + status);
  	    	if(state === 'SUCCESS') {
		        console.log('ST_PAAccountUpdateHelper.successUpdatingCSApp - Updating Person Account');
		        this.fireSavedEvent(component);
		        this.updateSalesforce(component);
		        this.closeModal(component);
	        }
	        else {
	        	console.log('ST_PAAccountUpdateHelper.successUpdatingCSApp - Error updating Salesforce - ' + status);
	        }
        });
		$A.enqueueAction(action);
		console.log('ST_PAAccountUpdateHelper.successUpdatingCSApp - exit');
	},

	errorUpdatingCSApp: function(component,errMsg,caseId) {
		console.log('ST_PAAccountUpdateHelper.errorUpdatingCSApp - enter');
		var action = component.get('c.csAppFailure');
		action.setParams({
			cid: caseId,
			errMsg: errMsg
		});
		action.setCallback(this, function(response) {
			var status = response.getReturnValue();
			var state = response.getState();
			if (state === "SUCCESS") {
				console.log(status);
			}
			else {
				console.log('Setting Case to In Process failed');
			}
		});
		$A.enqueueAction(action);

		var toastEvent = $A.get('e.force:showToast');
		toastEvent.setParams({
			type: 'error',
			title: $A.get('$Label.c.ST_PAAccountUpdateFormatFaliure'),
			message: errMsg,
			duration: '5000',
			mode: 'dismissible'
		});
		toastEvent.fire();
		console.log('ST_PAAccountUpdateHelper.errorUpdatingCSApp - exit');
	},

	updateSalesforce: function(component) {
		console.log('ST_PAAccountUpdateHelper.updateSalesforce - enter');
		component.find('recordHandler').saveRecord($A.getCallback(function(saveResult) {
			var message;
			var type;
			if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
				message = $A.get('$Label.c.ST_PASaveCompleted');
				type = 'success';
			} else if (saveResult.state === "INCOMPLETE") {
				message = $A.get('$Label.c.ST_PAUserOffline');
				type = 'warning';
			} else if (saveResult.state === "ERROR") {
				message = $A.get('$Label.c.ST_PARecordCouldntBeSaved');
				type = 'error';
			} else {
				message = $A.get('$Label.ST_PAUnknownProblem');
				type = 'info';
			}

			var toastEvent = $A.get("e.force:showToast");
			toastEvent.setParams({
				"message": message,
				"type": type
			});
			toastEvent.fire();
		}));
		console.log('ST_PAAccountUpdateHelper.updateSalesforce - exit');
	},

	closeModal: function(component) {
		console.log('ST_PAAccountUpdateHelper.closeModal - enter');
		var appEvent = $A.get("e.c:ST_Modal_EVTClose").fire();
		console.log('ST_PAAccountUpdateHelper.closeModal - exit');
	}
})