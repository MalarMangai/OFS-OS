({
  onAccountValueChange: function(component, event, helper) {
    helper.splitAuthorizedUsers(component);
  },

  handleAccountInfoChange: function(component, event, helper) {
    helper.updateHoverFields(component, event);
    helper.splitAuthorizedUsers(component);
  }
})