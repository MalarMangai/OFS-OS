({
  splitAuthorizedUsers: function(component) {
    if(component.get("v.account.AuthorizedUsers__c") != null) {
      component.set("v.authorizedUsers", component.get("v.account.AuthorizedUsers__c").split(','));
    } else {
      component.set("v.authorizedUsers", null);
    }
  },

  updateHoverFields: function(component, event) {
    component.set("v.account.Phone", event.getParam("account").Phone);
    component.set("v.account.PersonHomePhone", event.getParam("account").PersonHomePhone);
    component.set("v.account.PersonMobilePhone", event.getParam("account").PersonMobilePhone);
    component.set("v.account.PersonEmail", event.getParam("account").PersonEmail);
    component.set("v.account.AuthorizedUsers__c", event.getParam("account").AuthorizedUsers__c);
  }
})