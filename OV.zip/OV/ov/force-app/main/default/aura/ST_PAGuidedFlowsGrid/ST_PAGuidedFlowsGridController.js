({
  doInit: function(component, event, helper) {
    helper.buildFlowList(component);
  },

  handleFlowClick: function(component, event, helper) {
    helper.handleFlowClick(component, event);
  },

  handleCreateCaseClick: function(component, event, helper) {
    helper.handleCreateCaseClick(component, event);
  },

  handleCancelationRequestClick: function(component, event, helper) {
    helper.startGuidedFlow(component, 'c:ST_GFCancelationRequest');
  },

  handlePartsRequestClick: function(component, event, helper) {
    helper.startGuidedFlow(component, 'c:ST_GFPartsRequest');
  },

  handleOrderSelectionEvent: function(component, event, helper) {
    helper.setOrderTableSelections(component, event);
  },

  handleShippingAddressCorrectionClick: function(component, event, helper) {
    helper.startGuidedFlow(component, 'c:ST_GFShipAddrCorrection');
  },

  handleInvalidTrackingNumberClick: function(component, event, helper) {
    helper.startGuidedFlow(component, 'c:ST_GFInvalidTracking');
  },

  handleUpdateAccountInformation: function(component, event, helper) {
    helper.openUpdateAccountModal(component);
  }
})