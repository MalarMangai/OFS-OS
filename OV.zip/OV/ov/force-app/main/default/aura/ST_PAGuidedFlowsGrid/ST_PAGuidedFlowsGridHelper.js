({

  //================================================================================
  // INIT SETUP
  //================================================================================

  buildFlowList: function(component) {
    var flowDetails = [
      {
        name: 'Exchange_or_Replace_Item',
        label: $A.get('$Label.c.ST_PATileExchangeReplaceItem'),
        icon: 'box-2',
        isComingSoon: true
      },
      {
        name: 'Join_or_Update_Club_O',
        label: $A.get('$Label.c.ST_PATileJoinUpdateClubO'),
        icon: 'award',
        isComingSoon: true
        }
    ];

    component.set('v.flows', flowDetails);
  },


  //================================================================================
  // ORDER/LINE SELECTIOn
  //================================================================================

  setOrderTableSelections: function(component, event) {
    if (event.getParam('paRecordId') === component.get('v.recordId')) {
      component.set('v.selectedOrder', event.getParam('order'));
      component.set('v.selectedOrderLine', event.getParam('orderLine'));
    }
  },


  //================================================================================
  // FLOW HANDLERS
  //================================================================================

  handleFlowClick: function(component, event) {
    var flowName = event.getSource().get('v.name');
    switch(flowName) {
      case 'TODO':
        break;
    }
  },

  handleCreateCaseClick: function(component, event) {
    component.set("v.isProcessing", true);
    var action = component.get("c.createQuickCaseWithInvoiceDetails");
    var invoiceId = component.get("v.selectedOrder.id") != null ? component.get("v.selectedOrder.id").toString() : null;
    var invoiceLineId = component.get("v.selectedOrderLine.details.id") != null ? component.get("v.selectedOrderLine.details.id").toString() : null;

    action.setParams({accountId: component.get("v.recordId"), invoiceId: invoiceId, invoiceLineId: invoiceLineId});
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
          "recordId": response.getReturnValue(),
        });
        navEvt.fire();

        component.set("v.isProcessing", false);
      }
    });

    $A.enqueueAction(action);
  },

  startGuidedFlow: function(component, flowComponentName) {
    var preselectedInvoiceId = ($A.util.isEmpty(component.get('v.selectedOrder'))?
                                null : component.get('v.selectedOrder.id').toString());
    var preselectedInvoiceLineId = ($A.util.isEmpty(component.get('v.selectedOrderLine'))?
                                    null : component.get('v.selectedOrderLine.details.id').toString());

    var flowStarter = component.find('flow-starter');
    flowStarter.startGuidedFlow(
      flowComponentName,
      [
        { attrName: 'accountId', attrValue: component.get('v.recordId') },
        { attrName: 'preselectedInvoiceId', attrValue: preselectedInvoiceId },
        { attrName: 'preselectedInvoiceLineId', attrValue: preselectedInvoiceLineId }
      ]
    );
  },

  openUpdateAccountModal: function(component) {
    var helper = this;
    $A.get('e.c:ST_Modal_EVTDisplay').setParams({
      cmpIdentifier: 'updateAccount' + component.get('v.recordId'),
      showCloseButton: true,
      buttonsVariant: 'NONE',
      noContentPadding: true
    }).fire();
  },
})