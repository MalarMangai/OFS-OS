({
  onInit: function(component, event, helper) {
    helper.initializeAccount(component);
    helper.getCustomerClubODetails(component);
  },

  onUpdateAccountClick: function(component, event, helper) {
    helper.openModal(component, 'updateAccount');
  },

  handleAccountInfoChange: function(component, event, helper) {
    helper.initializeAccount(component);
  },
})