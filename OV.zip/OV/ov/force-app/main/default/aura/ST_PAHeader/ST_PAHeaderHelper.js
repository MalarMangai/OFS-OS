({
  initializeAccount: function(component) {
    var action = component.get("c.getAccount");
    action.setParams({ recordId : component.get("v.recordId")});
      action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          component.set("v.account", response.getReturnValue());
        }
      });

    $A.enqueueAction(action);
  },

  getCustomerClubODetails: function (component) {
    var action = component.get('c.getCustomerClubODetails');
    action.setParams({
      recordId: component.get('v.recordId')
    });
    action.setCallback(this, function (response) {
      var state = response.getState();
      var details = response.getReturnValue();
      if (state === 'SUCCESS') {
        if (details !== null) {
            this.setClubOHeaderAndLabel(details);
            if (details.type) {
                details.shortType = details.type.replace(/^[^\/]*\/ /, '');
            }
            console.log('Details: ' + JSON.stringify(details));
            component.set('v.clubODetails', details);
            var detailsComponent = component.find('customer-club-o-info');
            detailsComponent.set('v.isActive',
                component.get('v.inactiveClubOTypes').indexOf(details.clubType) === -1);
        }
      } else {
        component.set('v.customerClubOInfoError', response.getError()[0].message);
      }
      component.set('v.isClubOInfoLoadingFinished', true);
    });
    $A.enqueueAction(action);
  },

  setClubOHeaderAndLabel: function (details) {
    var types = {
      'Club O Gift': 'NA',
      'CLUBO': 'Club O',
      'CLUBO_FREE_TRIAL': 'Free Trial',
      'CLUBO_BRONZE': 'NA',
      'CLUBO_FNBO': 'FNBO',
      'CLUBO_EMPLOYEE': 'Employee',
      'CS_INCIDENT': 'Incident',
      'CS_FREE': 'Free',
      'CLUBO_TEACHER': 'Teacher',
      'CLUBO_FRST_RESPONDER': 'First Responder',
      'CLUBO_MILITARY': 'Military',
      'CLUBO_STUDENT': 'Student',
      'NA': 'Not A Member'
    };

    var translatedType = types[details.clubType] ?  types[details.clubType] : details.clubType;
    var typeToDisplay = 'Active ' + '/ ' + translatedType;
    var rewardsHeader = 'Available Rewards';
    var timeDiff = Math.abs(new Date(Date.now()).getTime() - new Date(details.endDate).getTime());

    if(!details.membershipStatus.includes('ACTIVE')) {
      if(details.membershipStatus.includes('WITHIN_GRACE_PERIOD')) {
        details.withinGracePeriod = true;
      }

      typeToDisplay = 'Expired ' + '/ ' + translatedType;
    } else {
      if(details.membershipStatus.includes('WITHIN_GRACE_PERIOD')){
        details.expiresIn = Math.ceil(timeDiff / (1000 * 3600 * 24));
      }

      if(details.membershipStatus.includes('CLUBO_BRONZE')) {
        typeToDisplay = 'Inactive';
        details.isNotClubOGoldMember = true;
      }
    }

    if(new Date(details.endDate) < new Date( Date.now())) {
      rewardsHeader = details.hasMembershipEndedWithin90Days && !details.membershipStatus.includes('CLUBO_BRONZE') ? 'Available Upon Renewal' : 'Locked Rewards';
    }

    details.type = typeToDisplay;
    details.rewardsHeader = rewardsHeader;
  },

  openModal: function(component, type) {
    var helper = this;
    $A.get('e.c:ST_Modal_EVTDisplay').setParams({
          cmpIdentifier: type + component.get('v.recordId'),
          showCloseButton: true,
          buttonsVariant: 'NONE',
          noContentPadding: true,
          confirmCallback: function() { helper.saveRecord(component, type); }
    }).fire();
  },

  saveRecord: function(component, type) {
    component.find(type).saveRecord();
  }
})