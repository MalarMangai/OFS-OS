/**
 * Created by shellierobertson on 9/18/2018.
 */
({
    doInit: function(component, event, helper) {
        helper.getAccountLifetimeValueInfo(component);
    }
})