/**
 * Created by shellierobertson on 9/18/2018.
 */
({
    getAccountLifetimeValueInfo: function(component) {
        var action = component.get('c.getLifetimeValueInfo');
        action.setParams({
            recordId: component.get('v.accountId').toString()
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === 'SUCCESS') {
                component.set('v.AccountInformation', response.getReturnValue());
            }
        });

        $A.enqueueAction(action);
    }
})