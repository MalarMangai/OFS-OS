({
  handleActionMenuSelection: function(component, event, helper) {
    var selectedMenuItemValue = event.getParam('value');
    helper.handleMenuSelection(component, selectedMenuItemValue);
  },

  handleOnKeyUp: function(component, event, helper) {
    helper.checkInputValidity(component, event);
    helper.fireSearchOnEnter(component, event);
    helper.setShowClearIcon(component, !$A.util.isEmpty(event.currentTarget.value));
  },

  handleClearClick: function(component, event, helper) {
    helper.setShowClearIcon(component, false);
    helper.clearOrderNumber(component);
    helper.refreshPage(component);
  },

  handleRefreshClick: function(component, event, helper) {
    helper.clearOrderNumber(component);
    helper.refreshPage(component);
  },

  handleOrderSelectionEvent: function(component, event, helper) {
    if (event.getParam('paRecordId') === component.get('v.recordId')) {
      component.set('v.selectedOrder', event.getParam('order'));
      component.set('v.selectedOrderLine', event.getParam('orderLine'));
    }
  },

  setTabMarker: function(component, event, helper) {
    component.set("v.isOrdersTabSelected", !component.get("v.isOrdersTabSelected"));
    helper.clearOrderNumber(component);
  },

  handleSendLinkModalEvent : function(component,event) {

      console.log("ST_PAMainContentController.handleSendLinkModalEvent: enter");
      console.log("Event Name: " + event.getName());

      var params = event.getParams();
      var accountInfo = params.AccountInfo;
      var actions = params.sendLinkActions;
      var details = params.sendLinkDetails;
      component.set("v.AccountInformation", accountInfo);
      component.set("v.sendLinkActions", actions);
      component.set("v.sendLinkDetails", details);
      console.log("Account Info: " + component.get('v.AccountInformation').PersonEmail);
      console.log("sendLinkActions: " + component.get('v.sendLinkActions'));
      console.log("sendLinkDetails: " + component.get('v.sendLinkDetails'));

      console.log("ST_PAMainContentController.handleSendLinkModalEvent: exit");
  },

  handleSendLinkModalCheckboxEvent : function(component,event) {

    console.log("ST_PAMainContentController.handleSendLinkModalCheckboxEvent: enter");
    console.log("Event Name: " + event.getName());

    var params = event.getParams();
    var actions = params.sendLinkActions;
    var details = params.sendLinkDetails;
    component.set("v.sendLinkActions", actions);
    component.set("v.sendLinkDetails", details);
    console.log("sendLinkActions: " + component.get('v.sendLinkActions'));
    console.log("sendLinkDetails: " + component.get('v.sendLinkDetails'));

    console.log("ST_PAMainContentController.handleSendLinkModalCheckboxEvent: exit");
  },

  handleSendClick: function(cmp, event, helper) {
      helper.handleSendInformationActions(cmp);
  }

})