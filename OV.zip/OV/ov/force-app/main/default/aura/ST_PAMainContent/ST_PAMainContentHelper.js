({
clearOrderNumber: function(component) {
    component.find('searchInput').getElement().value = null;
},

refreshPage: function(component) {
    var childCmp;
    if(component.get('v.isOrdersTabSelected')) {
      childCmp = component.find('ordersTable');
    } else {
      childCmp = component.find('returnsTable');
    }
    childCmp.refreshPage();
},

setShowClearIcon: function(component, isTrue) {
    component.set('v.showClearIcon', isTrue);
},

checkInputValidity: function(component, event) {

    var searchString = event.currentTarget.value.trim();
    // if(component.get('v.isOrdersTabSelected')) {
    //   if(isNaN(searchString)) {
    //     event.currentTarget.value = null;
    //   }
    // } else {
    //   if(!searchString.match(/^[0-9a-zA-Z]+$/)) {
    //     event.currentTarget.value = null;
    //   }
    // }
    //event.currentTarget.value = event.currentTarget.value != null ? event.currentTarget.value.trim() : null;
},

fireSearchOnEnter: function(component, event) {
    if(event.code == 'Enter' || event.code == 'NumpadEnter') {
      this.fireSearch(component, event.currentTarget.value);
    }
},

fireSearch: function(component, value) {
    var childCmp;
    if(component.get('v.isOrdersTabSelected')) {
      childCmp = component.find('ordersTable');
    } else {
      childCmp = component.find('returnsTable');
    }
    childCmp.fireSearch(value);
},


//================================================================================
// ACTION MENU SELECTIONS
//================================================================================

handleMenuSelection: function(component, menuItemName) {
    if (['Cancel_Order',
         'Request_Parts_Accessories',
        'Shipping_Address_Correction',
         'Invalid_Tracking_Number'].indexOf(menuItemName) !== -1)
    {
      this.startGuidedFlow(component, menuItemName);
    } else if(menuItemName == 'Return') {
      this.createReturnCase(component);
    } else if(menuItemName == 'Send Information'){
      console.log('Opening send information modal');
      this.openSendInformationModal(component);
    }
},

createReturnCase: function(component) {
    component.set('v.isLoadingGuidedFlow', true);
    var action = component.get('c.buildReturnCase');
        var invoiceId = component.get('v.selectedOrder.id') != null ? component.get('v.selectedOrder.id').toString() : null;
        var invoiceLineId = component.get('v.selectedOrderLine.details.id') != null ? component.get('v.selectedOrderLine.details.id').toString() : null;

        action.setParams({accountId: component.get('v.recordId'), invoiceId: invoiceId, invoiceLineId: invoiceLineId});
        action.setCallback(this, function(response) {
          var state = response.getState();
          if (state === 'SUCCESS') {
            var navEvt = $A.get('e.force:navigateToSObject');
            navEvt.setParams({
              'recordId': response.getReturnValue(),
            });
            navEvt.fire();

            component.set('v.isLoadingGuidedFlow', false);
          }
        });

        $A.enqueueAction(action);
},

startGuidedFlow: function(component, menuItemName) {
    var actionToCMPMap = {
      'Cancel_Order': 'c:ST_GFCancelationRequest',
      'Request_Parts_Accessories': 'c:ST_GFPartsRequest',
      'Shipping_Address_Correction': 'c:ST_GFShipAddrCorrection',
      'Invalid_Tracking_Number': 'c:ST_GFInvalidTracking'
    };

    var preselectedInvoiceId = ($A.util.isEmpty(component.get('v.selectedOrder'))?
                                null : component.get('v.selectedOrder.id').toString());
    var preselectedInvoiceLineId = ($A.util.isEmpty(component.get('v.selectedOrderLine'))?
                                    null : component.get('v.selectedOrderLine.details.id').toString());

    var flowStarter = component.find('flow-starter');
    flowStarter.startGuidedFlow(
      actionToCMPMap[menuItemName],
      [
        { attrName: 'accountId', attrValue: component.get('v.recordId') },
        { attrName: 'preselectedInvoiceId', attrValue: preselectedInvoiceId },
        { attrName: 'preselectedInvoiceLineId', attrValue: preselectedInvoiceLineId }
      ]
    );
},

openSendInformationModal: function(component) {

    var helper = this;
    var sendLinkModal = component.find('sendLinkModalContent');
    sendLinkModal.getAccountInfo(component);
    component.set("v.trackingLink", null);
    var lineId = component.get('v.selectedOrderLine');
    if (lineId != null){
        lineId = lineId.details.id.toString();
        this.getTrackingLink(component, lineId);
    }
    $A.get('e.c:ST_Modal_EVTDisplay').setParams({
      cmpIdentifier: 'sendInformation' + component.get('v.recordId'),
      confirmButtonLabel: $A.get('$Label.c.ST_SendBtn'),
      showCloseButton: true,
      header: 'Send Information to Customer',
      confirmCallback: function() { helper.handleSendInformationActions(component); }
    }).fire();
},

getTrackingLink : function(component, lineId) {
      var action = component.get('c.getTrackingDetail');
      console.log('LINE ID: ', lineId);
      action.setParams({
          'lineId': lineId
      });

      action.setCallback(this, function(response) {
          var state = response.getState();
          if (state === "SUCCESS") {
          if(response.getReturnValue() != null) {
                  component.set("v.trackingLink", response.getReturnValue());
                  console.log('Tracking Link', component.get('v.trackingLink'));
          }
          } else {
              component.set("v.errorMessage", response.getError()[0].message);
          }
      });
      $A.enqueueAction(action);
},

handleSendInformationActions: function(component) {

    var sendLinkModal = component.find('sendLinkModalContent');
    var actions = component.get('v.sendLinkActions');
    var details = component.get('v.sendLinkDetails');
    component.find('sendLinkModalContent').set('v.isProcessing', true);
    component.set('v.smsComplete', false);
    component.set('v.emailComplete', false);

    console.log(actions, details);


    var success = false;
    var trackingLink = component.get('v.trackingLink');
    var lineId = component.get('v.selectedOrderLine');
    var invoiceId = component.get('v.selectedOrder.id');
    if (invoiceId != null)
        invoiceId = invoiceId.toString();
    var accountInfo = component.get('v.AccountInformation');

    console.log('Product Link Information:' + component.get('v.selectedOrderLine.details.product.productHref'));

    if (actions.includes('Text Message (SMS)')) {
        var smsAction = component.get('c.sendSMSInformation');
        smsAction.setParams({
            'phoneNumber': accountInfo.PersonMobilePhone,
            'infoLinks': details,
            'trackingLink': trackingLink,
            'accountId': component.get('v.recordId'),
            'productLink': component.get('v.selectedOrderLine.details.product.productHref')
        });
        smsAction.setCallback(this, function (response) {
            var state = response.getState();
            console.log(state);

            if (state === "SUCCESS") {
                console.log('RETURN VALUE: ' + response.getReturnValue());
                //Create cases for SMS AFTER successful send.  Email cases are created before.
                if (response.getReturnValue() == true) {
                    var action = component.get('c.insertCases');
                    action.setParams({
                        'accountId': component.get('v.recordId'),
                        'actions': actions,
                        'details': details,
                        'invoiceId': invoiceId,
                        'currentAction': 'Text Message (SMS)'
                    });
                    action.setCallback(this, function (response) {
                        var state = response.getState();
                        console.log('CASE CREATE' + state);
                        if (state === "SUCCESS") {
                            var returnValue = response.getReturnValue();
                            //refreshes Case Related List
                            $A.get('e.c:ST_RelatedList_EVTRefresh').setParams({
                                recordId: component.get('v.recordId'),
                                objectName: 'Case'
                            }).fire();
                        }
                        component.find('sendLinkModalContent').set('v.isProcessing', false);
                    });
                    $A.enqueueAction(action);

                    $A.get('e.force:showToast').setParams({
                        type: 'success',
                        duration: 3000,
                        message: $A.get('$Label.c.ST_PASendLinkSMSSuccess')
                    }).fire();
                    success = true;
                }
                else {
                    $A.get('e.force:showToast').setParams({
                        type: 'error',
                        duration: 30000000,
                        message: $A.get('$Label.c.ST_PASendLinkSMSFail')
                    }).fire();
                    success = false;

                    return;
                }
            }
            component.set('v.smsComplete', true);

            console.log('ST_PAMainContentController:SMS ' + component.get('v.smsComplete') + component.get('v.emailComplete'))
            if (component.get('v.smsComplete') && component.get('v.emailComplete')) {
                component.find('sendLinkModalContent').set('v.isProcessing', false);
                component.find('sendInformationModal').closeModal();
            }

        });
        $A.enqueueAction(smsAction);
    }
    else {
        component.set('v.smsComplete', true);
    }

    if (actions.includes('Email')) {
        //Insert cases for email sends here.  SMS cases are created after send
        var action = component.get('c.insertCases');
        action.setParams({
            'accountId': component.get('v.recordId'),
            'actions': actions,
            'details': details,
            'invoiceId': invoiceId,
            'currentAction': 'Email'
        });
        action.setCallback(this, function (response) {
            var state = response.getState();
            console.log('CASE CREATE' + state);
            if (state === "SUCCESS") {
                console.log('Account Email ' + accountInfo.PersonEmail);
                var returnValue = response.getReturnValue();
                var emailAction = component.get('c.sendEmailInformation');
                emailAction.setParams({
                    'personemail': accountInfo.PersonEmail,
                    'infoLinks': details,
                    'trackingLink': trackingLink,
                    'accountId': component.get('v.recordId'),
                    'invoiceId': invoiceId,
                    'caseId': returnValue,
                    'productLink': component.get('v.selectedOrderLine.details.product.productHref')
                });
                emailAction.setCallback(this, function (response) {
                    var state = response.getState();
                    console.log(state);

                    if (state === "SUCCESS") {
                        console.log('RETURN VALUE: ' + response.getReturnValue());
                        if (response.getReturnValue() == true) {
                            component.find('sendLinkModalContent').set('v.isProcessing', false);
                            $A.get('e.force:showToast').setParams({
                                type: 'success',
                                duration: 3000,
                                message: $A.get('$Label.c.ST_PASendLinkEmailSuccess')
                            }).fire();
                            success = true;
                        }
                        else {
                            $A.get('e.force:showToast').setParams({
                                type: 'error',
                                duration: 30000000,
                                message: $A.get('$Label.c.ST_PASendLinkEmailFail')
                            }).fire();
                            success = false;

                            return;
                        }
                        component.set('v.emailComplete', true);
                        console.log('ST_PAMainContentControllerEmail: ' + component.get('v.smsComplete') + component.get('v.emailComplete'))
                        if (component.get('v.smsComplete') && component.get('v.emailComplete')) {
                            component.find('sendLinkModalContent').set('v.isProcessing', false);
                            component.find('sendInformationModal').closeModal();
                        }
                    }
                });
                $A.enqueueAction(emailAction);
                //refreshes Case Related List
                $A.get('e.c:ST_RelatedList_EVTRefresh').setParams({
                    recordId: component.get('v.recordId'),
                    objectName: 'Case'
                }).fire();
            }
        });
        $A.enqueueAction(action);
    }
    else {
        component.set('v.emailComplete', true);
    }
}
})