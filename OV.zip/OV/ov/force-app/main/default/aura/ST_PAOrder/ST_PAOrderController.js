({
  onOrderClick: function(component, event, helper) {
    if(!component.get("v.isExpanded")) {
      helper.getOrderLines(component, true);
    }
    helper.toggleOrder(component);
  },

  onLineTablePageSelected: function(component, event, helper) {
    helper.changePageNumber(component, event);
  },

  handleRadioChange: function(component, event, helper) {
    helper.getOrderCancelationInfo(component);
    helper.fireSelectionEvent(component);
  },

  stopPropagation: function(component, event, helper) {
    event.stopPropagation();
  },

  handleInvoiceClick: function(component, event, helper){
      $A.get('e.c:ST_PAInvoice_EVTDetails').setParams({
          currentOrder: component.get('v.order')
      }).fire();

       var orderIdHover = component.find('orderIdHover');
       if(orderIdHover){
           orderIdHover.close();
       }

       var orderTotalHover = component.find('orderTotalHover');
       if(orderTotalHover){
           orderTotalHover.close();
       }
  }
})