({
  toggleOrder: function(component) {
    var detailedContent = component.find('detailed-content').getElement();
    $(detailedContent).slideToggle();
    component.set('v.isExpanded', !component.get('v.isExpanded'));
  },

  getOrderLines: function(component, isInitialLoad) {
    component.set('v.isOrderLinesLoadingFinished', false);
    var action = component.get('c.getOrderLines');
    action.setParams({
      orderId: component.get('v.order.id'),
      pageNumber: component.get('v.pageNumber') - 1
    });
    action.setBackground();
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        var responseObj = response.getReturnValue();
        component.set('v.orderLinesResponse', responseObj);
        if (isInitialLoad) {
          component.set('v.totalPages', responseObj.originalResponse.totalPages);
        }
      } else {
        component.set("v.errorMessage", response.getError()[0].message);
      }
      component.set('v.isOrderLinesLoadingFinished', true);
    });

    $A.enqueueAction(action);
  },

  getOrderCancelationInfo: function(component) {
    var helper = this;

    if (component.get('v.order.orderCancelable') === undefined) {
      var action = component.get('c.getOrderCancelationInfo');
      action.setParams({
        orderId: component.get('v.order.id')
      });

      action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === 'SUCCESS') {
          var actionResponse = response.getReturnValue();

          var order = component.get('v.order');
          order.orderCancelable = actionResponse.invoiceCancelable === 'NO';
          component.set('v.order', order);

          if (component.get('v.isSelected')) {
            helper.fireSelectionEvent(component);
          }
        }
      });
      $A.enqueueAction(action);
    }
  },

  changePageNumber: function(component, event) {
    component.set('v.pageNumber', event.getParam('pageNumber'));
    this.getOrderLines(component, false);

    if (component.get('v.isSelected') && component.get('v.hasLineSelected')) {
      this.fireSelectionEvent(component, true);
    }
  },

  fireSelectionEvent: function(component, deselect) {
    $A.get('e.c:ST_PAOrdersTable_EVTSelection').setParams({
      paRecordId: component.get('v.recordId'),
      order: (deselect? null : component.get('v.order'))
    }).fire();
  }

})