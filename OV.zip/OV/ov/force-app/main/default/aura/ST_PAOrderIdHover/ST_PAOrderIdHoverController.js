({
  handleOnArticleClick: function(component, event, helper) {
    event.stopPropagation();
  }
})