({
  doInit: function(component, event, helper) {
    helper.getReturnableInfo(component);
    helper.getReviewInfo(component);
    helper.getClubOInfo(component);
  },

  handleProductLinkClick: function(component, event, helper) { 
    helper.showProductModal(component);
  },

  handleTrackingButtonClick: function(component, event, helper) {
    if(component.get("v.orderLine.details.trackings.length") == 1) {
      helper.openTrackingUrl(component.get("v.orderLine.details.trackings[0].href"));
    }
  },

  handleTrackingMenuSelect: function(component, event, helper) {
    helper.openTrackingURLFromMenu(component, event);
  },

  handleRadioChange: function(component, event, helper) {
    helper.getOrderCancelationInfo(component);
    helper.fireSelectionEvent(component);
  }
})