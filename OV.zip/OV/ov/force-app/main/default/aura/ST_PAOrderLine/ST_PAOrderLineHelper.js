({
  getReturnableInfo: function(cmp) {
    if (this._debounceCount <= 2000) {
      this._debounceCount+= 200;
    } else {
      this._debounceCount = 0;
    }

    var helper = this;
    var action = cmp.get("c.getReturnableInfo");
    action.setParams({ invoiceId: cmp.get("v.invoiceId"), lineItemId: cmp.get("v.orderLine.details.id") });
    action.setBackground();
    action.setCallback(this, function(response) {
      var state = response.getState();

      if (state === "SUCCESS") {
        cmp.set("v.returnableInfo", response.getReturnValue());

        var orderLine = cmp.get("v.orderLine");
        orderLine.returnable = response.getReturnValue().returnable;
        cmp.set("v.orderLine", orderLine);
        console.log(JSON.stringify(response.getReturnValue()));

        if(response.getReturnValue().restrictions != null) {
          var restrictions = response.getReturnValue().restrictions;
          for(var i = 0; i < restrictions.length; i++) {
            response.getReturnValue().restrictions[i] = this.formatRestrictions(restrictions[i]);
          }
        }

        if (cmp.get('v.isSelected')) {
          helper.fireSelectionEvent(cmp);
        }
      } else {
        cmp.set("v.returnableInfoError", response.getError()[0].message);
      }
      cmp.set("v.isReturnableInfoLoadingFinished", true);
    });

    setTimeout($A.getCallback(function() {
      if (cmp.isValid()) {
        $A.enqueueAction(action);
      }
    }), this._debounceCount); 
  },

  getReviewInfo: function(cmp) {
    var action = cmp.get("c.getReviewInfo");
    action.setParams({ recordId: cmp.get("v.recordId"), productId: cmp.get("v.orderLine.details.product.id") });
    action.setBackground();
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        console.log(response.getReturnValue());
        cmp.set("v.reviewInfo", response.getReturnValue());
      } else {
        cmp.set("v.reviewInfoError", response.getError()[0].message);
      }
      cmp.set("v.isReviewInfoLoadingFinished", true);
    });

    setTimeout($A.getCallback(function() {
      if (cmp.isValid()) {
        $A.enqueueAction(action);
      }
    }), this._debounceCount);
  },

  getClubOInfo: function(cmp) {
    var action = cmp.get("c.getClubOInfo");
    action.setParams({ lineId: cmp.get("v.orderLine.details.id")});
    action.setBackground();
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        cmp.set("v.clubOInfo", response.getReturnValue());
      } else {
        cmp.set("v.clubOInfoError", response.getError()[0].message);
      }
      cmp.set("v.isClubOInfoLoadingFinished", true);
    });

    setTimeout($A.getCallback(function() {
      if (cmp.isValid()) {
        $A.enqueueAction(action);
      }
    }), this._debounceCount);
  },

  getOrderCancelationInfo: function(cmp) {
    var helper = this;

    if (cmp.get('v.order.orderCancelable') === undefined) {
      var action = cmp.get('c.getOrderCancelationInfo');
      action.setParams({
        orderId: cmp.get('v.order.id')
      });

      action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === 'SUCCESS') {
          var actionResponse = response.getReturnValue();

          var order = cmp.get('v.order');
          order.orderCancelable = actionResponse.invoiceCancelable === 'NO';
          cmp.set('v.order', order);

          if (cmp.get('v.isSelected')) {
            helper.fireSelectionEvent(cmp);
          }
        }
      });
      $A.enqueueAction(action);
    }
  },

  showProductModal: function(component) {
    $A.get('e.c:ST_Modal_EVTDisplay').setParams({
      cmpIdentifier: component.get("v.recordId"),
      html: "<iframe src='" + component.get("v.orderLine.details.product.href") + "' style='width: 100%;height: calc(100vh - 160px);border: none;' />",
      noContentPadding: true,
      showCloseButton: true,
      size: 'large',
      confirmButtonLabel: 'Back to Order'
    }).fire();
  },

  openTrackingUrl: function(url) {
    window.open(url);
  },

  openTrackingURLFromMenu: function(component, event) {
    var selectedMenuItemValue = event.getParam("value");
    this.openTrackingUrl(selectedMenuItemValue);
  },

  fireSelectionEvent: function(component) {
    $A.get('e.c:ST_PAOrdersTable_EVTSelection').setParams({
      paRecordId: component.get('v.recordId'),
      order: component.get('v.order'),
      orderLine: component.get('v.orderLine')
    }).fire();
  },

  formatRestrictions: function(restriction) {
    var formattedRestriction = restriction;
    if(restriction.match(/\d+/g) != null) {
      for(var i = 0; i < restriction.match(/\d+/g).length; i++) {
            formattedRestriction = formattedRestriction.replace(restriction.match(/\d+/g)[i], restriction.match(/\d+/g)[i].replace(/\B(?=(\d{3})+(?!\d))/g, ","));
      }
    }
    return formattedRestriction;
  }
})