({
  doInit: function(component, event, helper) {
    helper.getClubOInvoiceInfo(component);
  },

  handleOnArticleClick: function(component, event, helper) {
    event.stopPropagation();
  }
})