({
  getClubOInvoiceInfo: function(component) {
    var action = component.get('c.getClubOInvoiceInfo');
    action.setParams({
      invoiceId: component.get("v.order.id").toString()
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        component.set('v.clubOInfo', response.getReturnValue());
      } else {
        component.set("v.errorMessage", response.getError()[0].message);
      }
      component.set('v.isLoadingFinished', true);
    });

    $A.enqueueAction(action);
  }
})