({
  doInit: function(component, event, helper) {
    helper.setOrders(component, true);
  },

  onColumnHeaderClick: function(component, event, helper) {
    helper.setSortParameters(component, event);
    helper.setOrders(component, false);
    helper.fireClearSelectionEvent(component);
  },

  doSearch: function(component, event, helper) {
    helper.setOrdersForGivenId(component, event);
    helper.fireClearSelectionEvent(component);
    helper.clearErrors(component);
  },

  onLineTablePageSelected: function(component, event, helper) {
    helper.changePageNumber(component, event);
    helper.fireClearSelectionEvent(component);
  },

  refreshPage: function(component, event, helper) {
    helper.setOrders(component, true);
    helper.fireClearSelectionEvent(component);
    helper.clearErrors(component);
  },

  handleInvoiceEvent: function(component, event, helper){
     component.set('v.currentOrderDetails', null);
     var currentOrderDetails = event.getParam('currentOrder');
     if(currentOrderDetails){
         component.set('v.currentOrderDetails', currentOrderDetails);
         component.find('invoiceDetailsModal').openModal({
             header: 'Order Details',
             showCloseButton: true,
             buttonsVariant: 'CONFIRM_CANCEL',
             confirmButtonLabel: 'Email to Customer'
         });

         var invoicePaymentCmp = component.find('invoiceDetails').find('invoicePayment');
         if(invoicePaymentCmp){
             invoicePaymentCmp.loadClubO();
         }

         var invoiceLineDetailsTableCmp = component.find('invoiceDetails').find('invoiceLineDetailsTable');
         if(invoiceLineDetailsTableCmp){
             invoiceLineDetailsTableCmp.loadInvoiceLineDetails();
         }
     }
  }
})