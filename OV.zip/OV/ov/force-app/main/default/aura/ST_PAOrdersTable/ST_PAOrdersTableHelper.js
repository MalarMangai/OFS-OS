({
  setOrders: function(component, isInitialLoad) {
    component.set("v.isLoadingFinished", false);
    var action = component.get("c.getOrdersList");
    action.setParams({ recordId : component.get("v.recordId"), pageNumber: component.get("v.pageNumber")-1,
                      ordersSort: component.get("v.sortParameters.columnName") + ',' + component.get("v.sortParameters.sortDirection")});
    action.setBackground();
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === "SUCCESS") {
        if(response.getReturnValue() != null) {
          component.set("v.orders", this.processOrders(component, response.getReturnValue()));
          if(isInitialLoad) {
            component.set("v.totalPages", response.getReturnValue().totalPages);
          }
        }
      } else {
        component.set("v.errorMessage", response.getError()[0].message);
      }
      component.set("v.isLoadingFinished", true);
    });
    $A.enqueueAction(action);
  },

  setOrdersForGivenId: function(component, event) {
    if(!$A.util.isEmpty(event.getParam('arguments').searchValue)) {
      component.set("v.isLoadingFinished", false);
      var action = component.get("c.getOrdersList");
      action.setParams({ recordId : component.get("v.recordId"), searchString: event.getParam('arguments').searchValue, pageNumber: component.get("v.pageNumber")-1,
                           ordersSort: component.get("v.sortParameters.columnName") + ',' + component.get("v.sortParameters.sortDirection")});
      action.setBackground();
      action.setCallback(this, function(response) {
        var state = response.getState();
        if (state === "SUCCESS") {
          if(response.getReturnValue() != null) {
            component.set("v.orders", this.processOrders(component, response.getReturnValue()));
            component.set("v.totalPages", response.getReturnValue().totalPages);
          }
        } else {
          component.set("v.errorMessage", response.getError()[0].message);
        }
        component.set("v.isLoadingFinished", true);
      });
      $A.enqueueAction(action);
    }
  },

  processOrders: function (component, orders) {
      var missingIcons = component.get('v.missingIcons');
      orders.content.forEach(function (order) {
          if (order.icon && missingIcons.indexOf(order.icon) === -1) {
              // all icons in Logos folder must be in lower case
              order.iconPath = '/Logos/' + order.icon.toLowerCase() + '-16x16.png';
          }
      });
      return orders;
  },

  setSortParameters: function(component, event) {
    component.set("v.sortParameters.columnName", event.currentTarget.dataset.columnName);
    if(component.get("v.sortParameters.sortDirection") == 'asc' || component.get("v.sortParameters.sortDirection") == '') {
      component.set("v.sortParameters.sortDirection", "desc");
    } else {
      component.set("v.sortParameters.sortDirection", "asc");
    }
  },

  changePageNumber: function(component, event) {
    component.set("v.isLoadingFinished", false);
    component.set("v.pageNumber", event.getParam('pageNumber'));
    this.setOrders(component, false);
  },

  fireClearSelectionEvent: function(component) {
    $A.get('e.c:ST_PAOrdersTable_EVTSelection').setParams({
      paRecordId: component.get('v.recordId'),
      order: null
    }).fire();
  },

  clearErrors: function(component) {
    component.set("v.errorMessage", null);
  }
})