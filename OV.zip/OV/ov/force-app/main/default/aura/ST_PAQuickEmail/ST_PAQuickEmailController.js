({
  handleEmailClick: function(cmp, event, helper) {
    $A.get('e.c:ST_PAQuickEmailModal_EVTOpen').setParams({
      accountId: cmp.get('v.accountId')
    }).fire();
  }
})