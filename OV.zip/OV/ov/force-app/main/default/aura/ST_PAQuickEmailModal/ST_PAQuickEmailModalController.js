({
  handleOpenModalEvent: function(cmp, event, helper) {
    if (event.getParam('accountId') === cmp.get('v.accountId')) {
      cmp.find('modal').openModal({
        header: $A.get('$Label.c.ST_PAQuickEmailTitle'),
        showCloseButton: true
      });
    }

    setTimeout($A.getCallback(function() {
      cmp.find('content-input').focus();
    }));
  },

  handleSendClick: function(cmp, event, helper) {
    helper.sendEmail(cmp);
  }
})