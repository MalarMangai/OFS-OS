({
  sendEmail: function(cmp) {
    cmp.set('v.isProcessing', true);

    var action = cmp.get('c.sendEmail');
    action.setParams({
      accId: cmp.get('v.accountId'),
      subject: cmp.get('v.subjectInputValue'),
      content: cmp.get('v.contentInputValue')
    });
    action.setCallback(this, function(response) {
      var state = response.getState();
      if (state === 'SUCCESS') {
        cmp.set('v.subjectInputValue', 'Requested Information - Overstock.com');
        cmp.set('v.contentInputValue', '');

        $A.get('e.force:showToast').setParams({
          type: 'success',
          title: $A.get('$Label.c.ST_PAQuickEmailNotifTitle'),
          message: $A.get('$Label.c.ST_PAQuickEmailNotifMessage')
        }).fire();

        //refreshes Case Related List
        $A.get('e.c:ST_RelatedList_EVTRefresh').setParams({
          recordId: cmp.get('v.accountId'),
          objectName: 'Case'
        }).fire();

        cmp.find('modal').closeModal();
      } else {
        $A.get('e.force:showToast').setParams({
          type: 'error',
          title: $A.get('$Label.c.ST_GenericErrorTitle'),
          message: $A.get('$Label.c.ST_GenericErrorMessage')
        }).fire();
      }
      cmp.set('v.isProcessing', false);
    });
    $A.enqueueAction(action);
  }
})