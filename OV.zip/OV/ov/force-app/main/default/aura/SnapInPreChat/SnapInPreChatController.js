({
  initialize: function(cmp, event, helper) {
    helper.initInputs(cmp);
  },

  handleStartButtonClick: function(cmp, event, helper) {
    helper.onStartButtonClick(cmp);
  }
});