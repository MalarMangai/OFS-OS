({
  initInputs: function(cmp) {
    var prechatFields = cmp.find('prechatAPI').getPrechatFields();
    cmp.set('v.radioOptions', prechatFields[3].picklistOptions);

    var fieldNameToLabelMap = {};
    var fieldNameList = [];
    prechatFields.forEach(function(prechatField) {
      fieldNameToLabelMap[prechatField.name] = prechatField.label;
      fieldNameList.push(prechatField.name);
    });
    cmp.set('v.fieldNameToLabelMap', fieldNameToLabelMap);
    cmp.set('v.fieldNameList', fieldNameList);
  },

  onStartButtonClick: function(cmp) {
    var formValues = this.getFormValuesForChatStartup(cmp);

    if(cmp.find('prechatAPI').validateFields(formValues).valid) {
      cmp.find('prechatAPI').startChat(formValues);
    } else {
      cmp.find('prechatAPI').startChat(formValues);
    }
  },

  getFormValuesForChatStartup: function(cmp) {
    var fieldNameToLabelMap = cmp.get('v.fieldNameToLabelMap');
    var fieldNameList = cmp.get('v.fieldNameList');

    var formValueList = [];
    fieldNameList.forEach(function(fieldName) {
      formValueList.push({
        name: fieldName,
        label: fieldNameToLabelMap[fieldName],
        value: cmp.get('v.input_' + fieldName)
      })
    });

    return formValueList;
  },

})