function showRecipientDetails(request){
          
        
        var ApprovedRecCount = 0;
        var RejectedRecCount = 0;
        var PendingRecCount = 0;
        var ThresholdValue = 150;
        var ApprovedDetailVar = '';
        var RejectedDetailVar = '';
        var PendingDetailVar = '';
        var ScoreBar = '';
        var BothScorevar = '';
        var PendingEventDetailVar = '';
        var pmtAttachments = new Array();
        
       
        if(request.Is_Event_Request__c == true){
                var Attachmentdetails = '';
                GH_OrderApprovers.createDummyRecord(function(result, event){
                     if(event.status){
                        if(result != null){
                        var SBG = '';
                                    if(sbgSelectionPMT == true){
                                      SBG = 'PMT';
                                    }
                                    if(sbgSelectionACS == true){
                                      SBG = 'ACS';
                                    }
                                    if(sbgSelectionTS == true){
                                      SBG = 'TS';
                                    }
                        
                            GH_OrderApprovers.GetAttachments(request.Id, SBG, result, function(result,event) {                      
                                    var allAttachments = '';                                                         
                                    if(result != null){
                                       
                                        $.each(result, function(index,value){                                       
                                            allAttachments += '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-event-attach">'
                                                           +  '<a href="/servlet/servlet.FileDownload?file='+ value.Id +'" target="_blank">' + value.Name +'</a><br/>'
                                                           +  '</div>';
                                        });
                                    }
                                    
                              if(allAttachments!=''){
                                  Attachmentdetails      +=         allAttachments;             
                               }
                              if(allAttachments ==''){
                                 Attachmentdetails       +=  '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-event-attach" style ="font-weight: normal;border-bottom: white;">'
                                                         +   'No Documents found'                        
                                                         +   '</div>';
                               }
                             
                                 $('#EventPendingDocstest').html(Attachmentdetails);
                                
                            });
                        
                        }
                    }
                });
       
     
                 
                 $('#EventRequestNumber').html(request.GH_Req_Number__c);
                 
                var PendingRecDate = normalizeDateExtended(request.CreatedDate);
                var PendingRecmonth = PendingRecDate[0];
                var PendingRecdate = PendingRecDate[1];
                var PendingRecyear = PendingRecDate[2];
                var PendingRecCreatedDate = PendingRecmonth+' '+PendingRecdate+','+PendingRecyear;
                
                var EventSchDate = normalizeDateExtended(request.Event_Date__c);
                var EventSchmonth = EventSchDate[0];
                var EventSchdate = EventSchDate[1];
                var EventSchyear = EventSchDate[2];
                var EventScheduledDate = EventSchmonth+' '+EventSchdate+','+EventSchyear;
                
                //$('#Eventscheduledate').html('Event Scheduled - '+EventScheduledDate);
                 
                var EventRequestorName = request.CreatedByName;
                var EventRequestedOn = PendingRecCreatedDate;
                $('#Eventscheduledate').html(' '+EventScheduledDate);
                $('#EventRequestorName').html(' '+EventRequestorName);
                $('#EventRequestedOn').html(' '+EventRequestedOn);


                  
                  var Eventinvitedgovtoffcial = 'No';
                    if(request.Event_invited_to_government_official__c == true){
                        Eventinvitedgovtoffcial = 'Yes'
                    }
                    var SpouseinvitedtoEvent = 'No';
                    if(request.Spouse_invited_to_Event__c == true){
                        SpouseinvitedtoEvent = 'Yes'
                    }
                    var EventwithinSEAguidelines = 'No';
                    if(request.Is_Event_within_SEA_guidelines__c == true){
                        EventwithinSEAguidelines = 'Yes'
                    }
                   
                    var EventConductedCountry  = request.Event_Conducted_Country__c;
                    var NumberofPeople  = request.Number_of_people_for_event__c;
                    var Totalcostincurrency  = request.Event_Total_cost_covered_in_currency__c;
                    var AdditionalComments = request.Event_Additional_Comments__c;   

                    if(EventConductedCountry == null || EventConductedCountry ==''){    
                        EventConductedCountry = 'N/A';
                    }
                    if(NumberofPeople == null || NumberofPeople ==''){  
                        NumberofPeople = 'N/A';
                    }
                    if(Totalcostincurrency == null || Totalcostincurrency ==''){    
                        Totalcostincurrency = 'N/A';
                    }
                    else{
                      Totalcostincurrency  = '$'+request.Event_Total_cost_covered_in_currency__c;
                    }
                    if(AdditionalComments == null || AdditionalComments ==''){  
                        AdditionalComments = 'N/A';
                    }
                    var CostParameters = '';
                   if(request.Flights_Cost__c == true){
                      CostParameters+='Flights'+',';
                    }
                     if(request.Meals_Cost__c == true){
                      CostParameters+='Meals'+',';
                    }                       
                     if(request.Gifts_Cost__c == true){
                      CostParameters+='Gifts'+',';
                    }   
                    if(request.Visa_Cost__c == true){
                      CostParameters+='Visa'+',';
                    }
                     if(request.Accommodation_Cost__c == true){
                      CostParameters+='Accommodation'+',';
                    }
                     if(request.Local_Transportation_Cost__c == true){
                      CostParameters+='LocalTransportation'+',';
                    }
                     if(request.Entertainment_Cost__c == true){
                      CostParameters+='Entertainment'+',';
                    }
                     if(request.Other_Costs__c == true){
                      CostParameters+= request.Other_Cost_Type__c+',';
                    }
                    CostParameters = CostParameters.substring(0, CostParameters.lastIndexOf(","));
                    if(CostParameters == null || CostParameters ==''){  
                        CostParameters = 'N/A';
                    }
                    
                    
                PendingEventDetailVar  +=  '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-recipient-border" style="padding-bottom: 30px;">' 
                    +       '<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9 gh-recipient gh-approver-rec">'; 
                    if(request.Event_Type__c == 'Other'){
                    PendingEventDetailVar   +=  '<div>'+ request.Event_Type__c + ' (' +request.Other_Event_Type__c +')</div>';
                    }
                    else{
                    PendingEventDetailVar   +=  '<div>'+request.Event_Type__c +'</div>';
                    }
                    PendingEventDetailVar   +=  '<small>'+PendingRecCreatedDate+' </small>'
                    +           '<div><span>Event</span></div>'
                    +           '<div class="gh-recipient-expand"><img id="PendingEventExpandUrl'+request.Id+'" src="{!URLFOR($Resource.GEResource,"images/icon-expand.png")}" onclick="ShowEventPendingDetails("'+request.Id+'")"/></div>'
                    +       '</div>'                
                    +       '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="PendingEventAddInfo'+request.Id+'" style="padding-top:10px;padding-bottom:10px;display:none">'
                    +          '<div class="gh-event-details">'
                    +          '<table class="table table-striped">'
                    +             '<tr><td>'
                    +                'Country where Event is conducted:'
                    +             '</td><td>' 
                    +                 EventConductedCountry 
                    +             '</td></tr>'
                    +             '<tr><td>'
                    +                'Is the recipient/invitee a government official or a person affiliated with the public sector (including employee of a state-owned or state-controlled business)?'
                    +             '</td><td>'
                    +                Eventinvitedgovtoffcial 
                    +              '</td></tr>'
                    +              '<tr><td>'
                    +                'How many people are being invited to this event?'
                    +              '</td><td>'
                    +                 NumberofPeople 
                    +               '</td></tr>'
                    +              '<tr><td>'
                    +                 'Are spouses, life partners or relatives invited to the event?'
                    +              '</td><td>'
                    +                  SpouseinvitedtoEvent
                    +              '</td></tr>'
                    +              '<tr><td>'
                    +                 'Total costs covered by Honeywell (per recipient)'
                    +               '</td><td>'
                    +                  Totalcostincurrency 
                    +               '</td></tr>'
                    +               '<tr><td>'
                    +                 'Is the event within your SEA guidelines?'
                    +               '</td><td>'
                    +                 EventwithinSEAguidelines 
                    +               '</td></tr>'                        
                    +               '<tr><td>'
                    +                  'Costs incurred by Honeywell'
                    +               '</td><td>'
                    +                 CostParameters
                    +              '</td></tr>'                         
                    +              '<tr><td colspan="2" style="padding-bottom: 0px;">'
                    +                'Additional Comment:' 
                    +              '</td></tr>'
                    +              '<tr><td colspan="2">'
                    +                 AdditionalComments                        
                    +              '</td></tr>'
                    +         '</table>'
                    +         '</div>'
                    +   '<div class="gh-event-attachmaindiv">'
                    + '<b>Documents related to Event</b><br/>'                      
                    +   '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-event-attach" id="EventPendingDocstest">'
                    +           'Loading...'                     
                    +       '</div>'
                    +   '</div>'                    
                    //+                Attachmentdetails                             
                    +          '<div id="approvalRejectPanel'+request.Id+'" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding-top: 10px;margin-bottom:10px;padding-left: 0px;text-align: center;">'
                    +               '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">'
                    +                   '<a class="btn gh-grey-btn gh-reject-icon" onclick="rejectEventConfirm("'+request.Id+'");"><img src="{!URLFOR($Resource.GEResource,'images/icon-reject.png')}" /><span style="padding-left: 5px">Reject</span></a>'
                    +               '</div>'
                    +               '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">'
                    +                   '<a class="btn gh-red-btn gh-approve-icon" onclick="approveEventConfirm("'+request.Id+'");"><img src="{!URLFOR($Resource.GEResource,'images/icon-approval.png')}" /><span style="padding-left: 5px">Approve</span></a>'
                    +               '</div>'
                    +           '</div>'
                    +       '</div>'
                    +       '</div>'; 
                    
                    $('#EventPendingReviewDiv').html(PendingEventDetailVar);
                
                    $('#requestPage').addClass('hidden');
                    $('#requestEventDetailPage').removeClass('hidden');
                    
                            
        }  
        else if(request.Is_Event_Request__c == false) { 
            $('#DetailRequestNumber').html(request.GH_Req_Number__c);
            
            var RequestType = 'Recipients';
            var RequestTypeLabel = 'Offering a Gift/Meals & Entertainment ';
            var BenefitType = '';
            
            var RequestorName = request.CreatedByName;  
            $('#RequestorName').html('Requestor Name: <span style="font-weight: 100;">' + RequestorName + '</span>');
            
            var RecDate = normalizeDateExtended(request.CreatedDate);
            var Recmonth = RecDate[0];
            var Recdate = RecDate[1];
            var Recyear = RecDate[2];
            var RecCreatedDate = Recmonth+' '+Recdate+','+Recyear;
            $('#RequestedDate').html('Requested On: <span style="font-weight: 100;">' + RecCreatedDate + '</span>');

    
                           
            
            
            
            
            
            //$('#Numberofrecipients').html('Number of Recipients: '+request.NumberOfRecipients);
        
                $.each(request.listRecipients, function(key,val) {
                
                if(val.Gift_Recipient__c == true){
                    RequestType = 'Providers';
                    RequestTypeLabel = 'Receiving a Gift/Meals & Entertainment ';
                }
                if(val.Gifts__c == true){
                  var Attachmentdetails = '';
                      GH_OrderApprovers.createDummyRecord(function(result, event){
                         if(event.status){
                            if(result != null){
                            var SBG = '';
                                        if(sbgSelectionPMT == true){
                                          SBG = 'PMT';
                                        }
                                        if(sbgSelectionACS == true){
                                          SBG = 'ACS';
                                        }
                                        if(sbgSelectionTS == true){
                                          SBG = 'TS';
                                        }
                            
                                GH_OrderApprovers.GetAttachments(val.Id, SBG, result, function(result,event) {                      
                                        var allAttachments = '';                                                         
                                        if(result != null){
                                           
                                            $.each(result, function(index,value){                                       
                                                allAttachments += '<div id="GiftPendingDoc'+val.Id+'">'
                                                               +  '<a href="/servlet/servlet.FileDownload?file='+ value.Id +'" target="_blank">' + value.Name +'</a><br/>'
                                                               +  '</div>';
                                            });
                                        }
                                        
                                  if(allAttachments!=''){
                                      Attachmentdetails      +=         allAttachments;             
                                   }
                                  if(allAttachments ==''){
                                     Attachmentdetails       +=  '<div id="GiftPendingDoc'+val.Id+'">'
                                                             +   'No Documents found'                        
                                                             +   '</div>';
                                   }
                                 
                                     $('#GiftPendingDoc'+val.Id).html(Attachmentdetails);
                                    
                                });
                            
                            }
                        }
                    });
                        
                 } 


                  /* -------------------------------------------------------Prepare information string to be displayed ------------------------------------------*/
                            var GiftOccasionBusinessMeeting = 'No';
                            if(val.Gift_Occasion_Business_Meeting__c == true){
                                GiftOccasionBusinessMeeting = 'Yes'
                            }
                            var GiftOccasionAwardPlacement = 'No';
                            if(val.Gift_Occasion_Award_Placement__c == true){
                                GiftOccasionAwardPlacement = 'Yes'
                            }
                            var GiftFrequency = 'No';
                            if(val.Gift_Frequency__c == true){
                                GiftFrequency = 'Yes'
                            }
                            var GiftGiventoGovernmentOfficial = 'No';
                            if(val.Gift_Gift_given_to_government_official__c == true){
                                GiftGiventoGovernmentOfficial = 'Yes'
                            }
                            var GiftOfferedtoSpouse = 'No';
                            if(val.Gift_Gift_offered_to_spouse__c == true){
                                GiftOfferedtoSpouse = 'Yes'
                            }
                            var GiftLineManagerInformed = 'No';
                            if(val.Gift_Line_Manager_Informed__c == true){
                                GiftLineManagerInformed = 'Yes'
                            }
                                         
                            QuestionsAndDetailsOfGift =       
                                                '<b> Recipient Details - Gift </b>'
                                    +           '<table class="table">'                     
                                    +               '<tr><td>'
                                    +                       'Will the gift occasion be before/during/after a business meeting?'
                                    +                   '</td><td>'
                                    +                       GiftOccasionBusinessMeeting
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the gift occasion be impending order award/placement?'
                                    +                   '</td><td>'
                                    +                       GiftOccasionAwardPlacement
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the gift be given to a government official or person affiliated with the public sector (including employee of a state owned or state controlled business)?'
                                    +                   '</td><td>'
                                    +                       GiftGiventoGovernmentOfficial
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will total value of gifts provided to this recipient exceed $300 / year?'
                                    +                   '</td><td>'
                                    +                       GiftFrequency
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the gift be offered to spouse, life partner, relatives, or guests?'
                                    +                   '</td><td>'
                                    +                       GiftOfferedtoSpouse
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Is the value of this gift within your SEA guidelines?'
                                    +                   '</td><td>'
                                    +                       GiftLineManagerInformed
                                    +               '</td></tr>' 
                                    +           '</table>';
                                   
                                   
                                            
                            var MEOccasionBusinessMeeting = 'No';
                            if(val.ME_Occasion_Business_Meeting__c == true){
                                MEOccasionBusinessMeeting = 'Yes'
                            }
                            var MEOccasionAwardPlacement = 'No';
                            if(val.ME_Occasion_Award_Placement__c  == true){
                                MEOccasionAwardPlacement = 'Yes'
                            }
                            var MEFrequency = 'No';
                            if(val.ME_Frequency__c == true){
                                MEFrequency = 'Yes'
                            }
                            var METravelProvidedToGovernmentOfficial = 'No';
                            if(val.ME_Travel_provided_to_government_officia__c == true){
                                METravelProvidedToGovernmentOfficial = 'Yes'
                            }
                            var METravelOfferedToSpouse = 'No';
                            if(val.ME_Travel_offered_to_spouse__c == true){
                                METravelOfferedToSpouse = 'Yes'
                            }
                            var MELineManagerInformed = 'No';
                            if(val.ME_Line_Manager_Informed__c == true){
                                MELineManagerInformed = 'Yes'
                            }
                                           
                            QuestionsAndDetailsOfMeal =       
                                                '<b> Recipient Details - Meals/Entertainment</b>'
                                    +           '<table class="table">'                     
                                    +               '<tr><td>'
                                    +                       'Will the meal/entertainment occasion be before/during/after a business meeting?'
                                    +                   '</td><td>'
                                    +                       MEOccasionBusinessMeeting
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the meal/entertainment occasion be impending order award/placement?'
                                    +                   '</td><td>'
                                    +                       MEOccasionAwardPlacement 
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the Meal / entertainment / travel be provided to a government official or person affiliated with the public sector (including employee of a state owned or state controlled business)?'
                                    +                   '</td><td>'
                                    +                       METravelProvidedToGovernmentOfficial
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will total value of Meals/Entertainment provided to this recipient exceed $600 / year?'
                                    +                   '</td><td>'
                                    +                       MEFrequency
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the Meal / entertainment / travel be offered to spouse, life partner, relatives, or guests?'
                                    +                   '</td><td>'
                                    +                       METravelOfferedToSpouse 
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Is the value of this gift within your SEA guidelines?'
                                    +                   '</td><td>'
                                    +                       MELineManagerInformed 
                                    +               '</td></tr>' 
                                    +           '</table>';
                                  
                                   
                                    
                            var ProGiftOccasionBusinessMeeting = 'No';
                            if(val.Pro_Gift_Occasion_Business_Meeting__c == true){
                                ProGiftOccasionBusinessMeeting = 'Yes'
                            }
                            var ProGiftOccasionAwardPlacement = 'No';
                            if(val.Pro_Gift_Occasion_Award_Placement__c == true){
                                ProGiftOccasionAwardPlacement = 'Yes'
                            }
                            var ProGiftSolicitedByYou = 'No';
                            if(val.Pro_Gift_Solicited_By_You__c == true){
                                ProGiftSolicitedByYou = 'Yes'
                            }
                            var ProGiftEmbarrassingIfPublic = 'No';
                            if(val.Pro_Gift_Embarrassing_If_Public__c == true){
                                ProGiftEmbarrassingIfPublic = 'Yes'
                            }
                            var ProGiftOfferedToSpouse = 'No';
                            if(val.Pro_Gift_Offered_To_Spouse__c == true){
                                ProGiftOfferedToSpouse = 'Yes'
                            }
                            var ProGiftManagerApprovedGift = 'No';
                            if(val.Pro_Gift_Manager_Approved_Gift__c == true){
                                ProGiftManagerApprovedGift = 'Yes'
                            }
                            
                                            
                            QuestionsAndDetailsOfGiftPro =       
                                               '<b> Provider Details - Gifts </b>'
                                    +           '<table class="table">'                     
                                    +               '<tr><td>'
                                    +                       'Will the gift occasion be before/during/after a business meeting?'
                                    +                   '</td><td>'
                                    +                       ProGiftOccasionBusinessMeeting
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the gift occasion be impending order award/placement?'
                                    +                   '</td><td>'
                                    +                       ProGiftOccasionAwardPlacement
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Was this gift solicited by you?'
                                    +                   '</td><td>'
                                    +                       ProGiftSolicitedByYou
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Would accepting this gift be embarrasing to the company if it were made public?'
                                    +                   '</td><td>'
                                    +                       ProGiftEmbarrassingIfPublic
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Gift offered to your spouse, life partner, relatives, or guests?'
                                    +                   '</td><td>'
                                    +                       ProGiftOfferedToSpouse
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Has your manager approved the gift receipt (note: manager\'s approval is required only for gifts exceeding USD 150)?'
                                    +                   '</td><td>'
                                    +                       ProGiftManagerApprovedGift
                                    +               '</td></tr>' 
                                    +           '</table>';
                                   
                                   
                                            
                             var ProMealOccasionBusinessMeeting = 'No';
                            if(val.Pro_ME_Occasion_Award_Placement__c == true){
                                ProMealOccasionBusinessMeeting = 'Yes'
                            }
                            var ProMealOccasionAwardPlacement = 'No';
                            if(val.Pro_ME_Occasion_Business_Meeting__c == true){
                                ProMealOccasionAwardPlacement = 'Yes'
                            }
                            var ProMealSolicitedByYou = 'No';
                            if(val.Pro_ME_Solicited_By_You__c == true){
                                ProMealSolicitedByYou = 'Yes'
                            }
                            var ProMealEmbarrassingIfPublic = 'No';
                            if(val.Pro_ME_Embarrassing_If_Public__c == true){
                                ProMealEmbarrassingIfPublic = 'Yes'
                            }
                            var ProMealOfferedToSpouse = 'No';
                            if(val.Pro_ME_Offered_To_Spouse__c == true){
                                ProMealOfferedToSpouse = 'Yes'
                            }
                            var ProMealManagerApproved = 'No';
                            if(val.Pro_ME_Manager_Approved__c == true){
                                ProMealManagerApproved = 'Yes'
                            }
                            
                                            
                            QuestionsAndDetailsOfMealPro =       
                                               '<b> Provider Details - Meals/Entertainment </b>'
                                    +           '<table class="table">'                     
                                    +               '<tr><td>'
                                    +                       'Will the meal/entertainment occasion be before/during/after a business meeting?'
                                    +                   '</td><td>'
                                    +                       ProMealOccasionBusinessMeeting
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Will the meal/entertainment occasion be impending order award/placement?'
                                    +                   '</td><td>'
                                    +                       ProMealOccasionAwardPlacement
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Was this meal/entertainment solicited by you?'
                                    +                   '</td><td>'
                                    +                       ProMealSolicitedByYou
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Would accepting this meal/entertainment be embarrasing to the company if it were made public?'
                                    +                   '</td><td>'
                                    +                       ProMealEmbarrassingIfPublic
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Meal/Entertainment offered to your spouse, life partner, relatives, or guests?'
                                    +                   '</td><td>'
                                    +                       ProMealOfferedToSpouse
                                    +               '</td></tr>' 
                                    +               '<tr><td>'
                                    +                       'Has your manager approved the meal receipt (note: manager\'s approval is required only for Meals exceeding USD 150)?'
                                    +                   '</td><td>'
                                    +                       ProMealManagerApproved
                                    +               '</td></tr>' 
                                    +           '</table>';
                                   
                                   
                                                
                            /* -------------------------------------------------------Prepare information string to be displayed ------------------------------------------*/
                            
                                var giftDescription  = val.Gift_Description__c;
                                var giftBusinessPurpose  = val.Gift_Business_Purpose__c;
                                var giftAdditionalComments  = val.Gift_Additional_Comments__c; 
                                var valueOfProviderGift = val.Pro_Gift_Value_of_Gift__c;
                                
                                var CountrywhereGiftisprovided = val.Country_where_Gift_is_provided__c;
                                var proGiftDescription  = val.Pro_Gift_Description__c;
                                if(CountrywhereGiftisprovided ==null || CountrywhereGiftisprovided ==''){
                                CountrywhereGiftisprovided = 'N/A';
                                }
                                var ApproverRejectorName=val.Approver_Name__c;
                                if(ApproverRejectorName ==null || ApproverRejectorName ==''){
                                ApproverRejectorName = 'N/A';
                                }
                                var dt=val.Approval_Rejection_Date__c;
                                if(dt ==null || dt ==''){
                                ApproverRejectorDate= 'N/A';
                                }
                                else{
                                var ApprovedRejDateFull = normalizeDateExtended(val.Approval_Rejection_Date__c);
                                var ApprovedRejmonth = ApprovedRejDateFull[0];
                                var ApprovedRejdate = ApprovedRejDateFull[1];
                                var ApprovedRejyear = ApprovedRejDateFull[2];
                                var ApproverRejectorDate = ApprovedRejmonth+' '+ApprovedRejdate+','+ApprovedRejyear;}
                                
                                var ValueOfGift = val.Gift_Value_of_gift__c;
                                
                                var mealDescription  = val.ME_Description__c;
                                var mealBusinessPurpose  = val.ME_Business_Purpose__c;
                                var mealAdditionalComments  = val.ME_Additional_Comments__c;
                                var CountrywhereMealisprovided = val.Country_where_ME_is_provided__c;
                                var valueOfProviderMeal = val.Pro_ME_Value_of_Meal_Entertainment__c;
                                var proMealDescription  = val.Pro_Meal_Description__c;
                                var ValueOfMeal = val.ME_Value_of_Meals_Entertainment__c;
                                if(CountrywhereMealisprovided ==null || CountrywhereMealisprovided ==''){
                                CountrywhereMealisprovided = 'N/A';
                                }
                               
                            if(val.Status__c == 'Pending') {
                                var typevar = '';
                                var ElectedRepresentative = '';
                                var ValueOfGiftMeal = '';
                                var AvgExpGiftMeal = '';
                                var BarStyle = '';
                                var PercentStyle ='';
                                var ThresholdText = '';
                                var GiftMealScore = '';
                                var DetailAnalysis = '';
                                if(val.Gifts__c == true  && val.Meals_Entertainment__c == false) {
                                    var GiftScore = val.Gift_Score__c;  
                                    BothScorevar = '<div id="status1'+val.Id+'" class="gh-approver-status review"><span class="review">'+GiftScore+'</span> <div class="review">(Review)</div></div>';                  
                                    typevar = 'Gifts';
                                    ValueOfGiftMeal = val.Gift_Value_of_gift__c;
                                    if(val.Gift_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGiftMeal = val.Gift_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGiftMeal = 0;
                                    }
                                    if(val.Gift_Value_of_gift__c >= ThresholdValue) {
                                        BarStyle = 'width: 100%';
                                        ThresholdText = 'Above Threshold';
                                        ScoreBar = '<div style="'+BarStyle+'">'+ThresholdText+'</div>';
                                    }
                                    if(val.Gift_Value_of_gift__c < ThresholdValue) {
                                        var BarWidth = ((val.Gift_Value_of_gift__c/ThresholdValue)*100).toFixed(0);
                                        BarStyle = 'width: '+BarWidth+'%';
                                        var PercentWidth = 100 - BarWidth;
                                        PercentStyle = 'width: '+PercentWidth+'%';
                                        ThresholdText = 'Below Threshold';
                                        ScoreBar = '<div style="'+BarStyle+'">Below Threshold</div><div style="'+PercentStyle+'">'+PercentWidth+'%</div>'
                                    }

                                    //var QuestionsAndDetailsOfGift = '';
                                    if(val.Gift_Recipient__c == false) {
                                        //alert(GiftMealScore);
                                        DetailAnalysis  += QuestionsAndDetailsOfGift
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpGiftMeal        
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfGiftMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Gift is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereGiftisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(giftDescription!=null && giftDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(giftBusinessPurpose!=null && giftBusinessPurpose!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                       
                                                            DetailAnalysis   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>'
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>';   
                                       
                                        
                                       
                                    }else{
                                        
                                        
                                        DetailAnalysis  +=       QuestionsAndDetailsOfGiftPro
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                                                                             
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+valueOfProviderGift
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(proGiftDescription!=null && proGiftDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ proGiftDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>'
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>';   
                                       
                                        
                                       
                                                        
                                    }
                                    
                                    
                                        
                                    
                                } 
                                if(val.Gifts__c == false && val.Meals_Entertainment__c == true) {
                                    typevar = 'Meals/Entertainment';
                                    var MealScore = val.Meal_Score__c;
                                    ValueOfGiftMeal = val.ME_Value_of_Meals_Entertainment__c;
                                    BothScorevar = '<div id="status1'+val.Id+'" class="gh-approver-status review"><span class="review">'+MealScore+'</span> <div class="review">(Review)</div></div>';
                                    
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGiftMeal = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGiftMeal = 0;
                                    }
                                    if(val.ME_Value_of_Meals_Entertainment__c >= ThresholdValue) {
                                        BarStyle = 'width: 100%';
                                        ThresholdText = 'Above Threshold';
                                        ScoreBar = '<div style="'+BarStyle+'">'+ThresholdText+'</div>';
                                    }
                                    if(val.ME_Value_of_Meals_Entertainment__c < ThresholdValue) {
                                        var BarWidth = ((val.ME_Value_of_Meals_Entertainment__c/ThresholdValue)*100).toFixed(0);
                                        BarStyle = 'width: '+BarWidth+'%';
                                        var PercentWidth = 100 - BarWidth;
                                        console.log('################ '+BarWidth);
                                        PercentStyle = 'width: '+PercentWidth+'%';
                                        ThresholdText = 'Below Threshold';
                                        ScoreBar = '<div style="'+BarStyle+'">Below Threshold</div><div style="'+PercentStyle+'">'+PercentWidth+'%</div>'
                                    }
                                    GiftMealScore = val.Meal_Score__c;
                                    
                                    
                                    if(val.Gift_Recipient__c == false){ 
                                    
                                        DetailAnalysis  += QuestionsAndDetailsOfMeal
                                                        +         '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpGiftMeal        
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfGiftMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Meal is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereMealisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description: </b>';
                                                        if(mealDescription!=null && mealDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ mealDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(mealBusinessPurpose!=null && mealBusinessPurpose!=''){
                                                            DetailAnalysis   +=           '<div>'+ mealBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                   
                                                            DetailAnalysis   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(mealAdditionalComments!=null && mealAdditionalComments!=''){
                                                            DetailAnalysis   +=           '<div>'+ mealAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>';
                                      
                                                        
                                                    
                                    }else{
                                        
                                        
                                        
                                        DetailAnalysis  +=   QuestionsAndDetailsOfMealPro
                                                        +          '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                        
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ valueOfProviderMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description </b>';
                                                        if(proMealDescription!=null && proMealDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ proMealDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>';
                                                        
                                        
                                    }
                                } 
                                
                                var AvgExpMealScore = '';
                                var ValueOfMealVar = 0;
                                var GiftScoreBar = '';
                                var MealScoreBar = '';
                                var PercentStyleGift ='';
                                var PercentStyleMeal ='';
                                var GiftBarStyle = '';
                                var MealBarStyle = '';
                                var AvgExpGift = '';
                                var AvgExpMeal = '';
                                if(val.Gifts__c == true && val.Meals_Entertainment__c == true) {
                                    if(val.Gift_Needs_Approval__c == true && val.ME_Needs_Approval__c == false) {
                
                                        BothScorevar = '<div id="status1'+val.Id+'" class="gh-approver-status review"><span class="review">'+val.Gift_Score__c+'</span><div id="Review" class="review">(Review)</div></div>'
                                                     +  '<div id="status111" style="margin-right: 5px;" class="gh-approver-status go"><span id="GME" class="hidden"></span><span id="Score" class="go">'+val.Meal_Score__c+'</span> <div id="Review" class="go">(GO)</div></div>';
                                    }
                                    if(val.ME_Needs_Approval__c == true && val.Gift_Needs_Approval__c == false) {
                                        BothScorevar = '<div id="status111" class="gh-approver-status go"><span id="GME" class="hidden"></span><span id="Score" class="go">'+val.Meal_Score__c+'</span> <div id="Review" class="go">(GO)</div></div>' 
                                                     +  '<div id="status1'+val.Id+'" style="margin-right: 5px;" class="gh-approver-status review"><span class="review">'+val.Gift_Score__c+'</span><div id="Review" class="review">(Review)</div></div>'; 
                
                                    }
                                    if(val.ME_Needs_Approval__c == true && val.Gift_Needs_Approval__c == true) {
                                        BothScorevar = '<div id="status1'+val.Id+'"  class="gh-approver-status review"><span class="review">'+val.Gift_Score__c+'</span><div id="Review" class="review">(Review)</div></div>'
                                                     +  '<div id="status111'+val.Id+'" style="margin-right: 5px;" class="gh-approver-status review"><span class="review">'+val.Meal_Score__c+'</span><div id="Review" class="review">(Review)</div></div>';
                                                     //+  '<div id="status111" style="margin-right: 5px;" class="gh-approver-status review"><span id="GME" class="hidden"></span><span id="Score" class="go">'+val.Meal_Score__c+'</span> <div id="Review" class="go">(Review)</div></div>';   
                
                                    }
                                    if (val.ME_Needs_Approval__c == false && val.Gift_Needs_Approval__c == false) {
                                        BothScorevar = '<div id="status11" style="margin-right: 5px;" class="gh-approver-status go"><span id="GME" class="hidden"></span><span id="Score" class="go">'+val.Gift_Score__c+'</span> <div id="Review" class="go">(Go)</div></div>'
                                                     +  '<div id="status111" style="margin-right: 5px;" class="gh-approver-status go"><span id="GME" class="hidden"></span><span id="Score" class="go">'+val.Meal_Score__c+'</span> <div id="Review" class="go">(Go)</div></div>';
                                    } 
                                    
                                    typevar = 'Gifts, Meals/Entertainment';
                                    ValueOfGiftMeal = val.Gift_Value_of_gift__c;
                                    ValueOfMealVar = val.Meal_Score__c;
                                    if(val.Gift_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGift = val.Gift_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGift = 0;
                                    }
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpMeal = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpMeal = 0;
                                    }
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpMealScore = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpMealScore = 0;
                                    }
                                    if(val.Gift_Value_of_gift__c >= ThresholdValue) {
                                        
                                        GiftBarStyle = 'width: 100%';
                                        ThresholdText = 'Above Threshold';
                                        GiftScoreBar = '<div style="'+GiftBarStyle+'">'+ThresholdText+'</div>';
                                    }
                                    
                                    if(val.Gift_Value_of_gift__c < ThresholdValue) {
                                        var BarWidth = ((val.Gift_Value_of_gift__c/ThresholdValue)*100).toFixed(0);
                                        GiftBarStyle = 'width: '+BarWidth+'%';
                                        var PercentWidthGift = 100 - BarWidth;
                                        PercentStyleGift = 'width: '+PercentWidthGift+'%';
                                        ThresholdText = 'Below Threshold';
                                        GiftScoreBar = '<div style="'+GiftBarStyle+'">Below Threshold</div><div style="'+PercentStyleGift+'">'+PercentWidthGift+'%</div>'
                                    }
                                    if(val.ME_Value_of_Meals_Entertainment__c >= ThresholdValue) {
                                        BarStyle = 'width: 100%';
                                        ThresholdText = 'Above Threshold';
                                        MealScoreBar = '<div style="'+BarStyle+'">'+ThresholdText+'</div>';
                                    }
                                    
                                    if(val.ME_Value_of_Meals_Entertainment__c < ThresholdValue) {
                                        var BarWidth = ((val.ME_Value_of_Meals_Entertainment__c/ThresholdValue)*100).toFixed(0);
                                        MealBarStyle = 'width: '+BarWidth+'%';
                                        var PercentWidthMeal = 100 - BarWidth;
                                        PercentStyleMeal = 'width: '+PercentWidthMeal+'%';
                                        ThresholdText = 'Below Threshold';
                                        MealScoreBar = '<div style="'+MealBarStyle+'">Below Threshold</div><div style="'+PercentStyleMeal+'">'+PercentWidthMeal+'%</div>'
                                    }
                                    GiftMealScore = val.Gift_Score__c;
                                    if(val.Gift_Recipient__c == false){ 
                                       
                                        
                                        
                                        DetailAnalysis  +=   QuestionsAndDetailsOfGift
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpGift        
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfGiftMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Gift is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereGiftisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(giftDescription!=null && giftDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(giftBusinessPurpose!=null && giftBusinessPurpose!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                       
                                                            DetailAnalysis   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>'                                                                                                                                                                                                                   
                                                       // +           '<div>'
                                                       // +               '<b>Current Expenditure</b><br/>'
                                                       // +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                       // +                     GiftScoreBar       
                                                       // +              '</div>'                        
                                                       // +           '</div>';
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>'
                                                        +               QuestionsAndDetailsOfMeal                                                                
                                                        +         '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpMeal        
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Meal is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereMealisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description: </b>';
                                                        if(mealDescription!=null && mealDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ mealDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(mealBusinessPurpose!=null && mealBusinessPurpose!=''){
                                                            DetailAnalysis   +=           '<div>'+ mealBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                   
                                                            DetailAnalysis   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(mealAdditionalComments!=null && mealAdditionalComments!=''){
                                                            DetailAnalysis   +=           '<div>'+ mealAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>';
                                                        //+           '<div>'
                                                        //+               '<b>Current Expenditure</b><br/>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                        //+                     MealScoreBar        
                                                        //+              '</div>'                        
                                                        //+           '</div>'; 
                                        
                                        
                                                          
                                     }else{
                                     
                                         
                                     
                                       //var valueOfProviderGift = val.Pro_Gift_Value_of_Gift__c;
                                        //var valueOfProviderMeal = val.Pro_ME_Value_of_Meal_Entertainment__c;
                                         
                                        DetailAnalysis  += QuestionsAndDetailsOfGiftPro
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                                                                             
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+valueOfProviderGift
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(proGiftDescription!=null && proGiftDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ proGiftDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            DetailAnalysis   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>'
                                                        //+           '<div>'
                                                        //+               '<b>Current Expenditure</b><br/>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                        //+                     GiftScoreBar       
                                                        //+              '</div>'                        
                                                        //+           '</div>';
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>'
                                                        +      QuestionsAndDetailsOfMealPro
                                                        +          '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                        
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ valueOfProviderMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description </b>';
                                                        if(proMealDescription!=null && proMealDescription!=''){
                                                            DetailAnalysis   +=           '<div>'+ proMealDescription + '</div>';
                                                        }
                                                        else {
                                                            DetailAnalysis   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            DetailAnalysis   +=        '</div>';
                                                        //+           '<div>'
                                                        //+               '<b>Current Expenditure</b><br/>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                        //+                     MealScoreBar        
                                                        //+              '</div>'                        
                                                        //+           '</div>'; 
                                                        
                                                                                               
                                    }                           
                                }
                                
                                ClickedRecId = val.Id;
                                var QuestionsAndDetails = '';
                                var QuestionsAndDetailsBoth = '';
                                if(val.Gifts__c == true  && val.Meals_Entertainment__c == false){
                                    QuestionsAndDetails = QuestionsAndDetailsOfGift;
                                }else if(val.Meals_Entertainment__c == true && val.Gifts__c == false){
                                    QuestionsAndDetails = QuestionsAndDetailsOfMeal;
                                }else if(val.Gifts__c == true  && val.Meals_Entertainment__c == true){
                                    QuestionsAndDetails = QuestionsAndDetailsOfGift;
                                }
                                
                                
                                PendingDetailVar +=  '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-recipient-border">' 
                                                +       '<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9 gh-recipient gh-approver-rec">' 
                                                +           '<div>'+val.Name_of_Recipient__c+'</div>'
                                                +           '<small>'+val.Company__c+' ,'+val.Country__c+'</small>'
                                                +           '<div><span>'+typevar+'</span></div>'
                                                +           '<div class="gh-recipient-expand"><img id="PendingExpandUrl'+val.Id+'" src="{!URLFOR($Resource.GEResource,"images/icon-expand.png")}" onclick="ShowPendingDetails("'+val.Id+'")"/></div>'
                                                +       '</div>'
                                                +       '<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 gh-transation-status review">' 
                                                +            BothScorevar
                                                +       '</div>' 
                                                +   '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="AddInfo'+val.Id+'" style="padding-top:10px;padding-bottom:10px;display:none">'
                                                +     DetailAnalysis                                                                     
                                                +           '<div id="approvalRejectPanel'+val.Id+'" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding-top: 10px;margin-bottom:10px;padding-left: 0px;text-align: center;">'
                                                +               '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">'
                                                +                   '<a class="btn gh-grey-btn gh-reject-icon" onclick="rejectRecipientConfirm("'+val.Id+'","'+val.GH_Request__c+'");"><img src="{!URLFOR($Resource.GEResource,'images/icon-reject.png')}" /><span style="padding-left: 5px">Reject</span></a>'
                                                +               '</div>'
                                                +               '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">'
                                                +                   '<a class="btn gh-red-btn gh-approve-icon" onclick="approveRecipientConfirm("'+val.Id+'","'+val.GH_Request__c+'");"><img src="{!URLFOR($Resource.GEResource,'images/icon-approval.png')}" /><span style="padding-left: 5px">Approve</span></a>'
                                                +               '</div>'
                                                +           '</div>'
                                                +       '</div>'
                                                +       '</div>'; 
                                    //alert(+PendingDetailVar);         
                                                
                                PendingRecCount++;   
                            }
                            
                            else if(val.Status__c == 'Approved' ) {
                                var GiftMealScore = '';
                                var BothScorevar = '';
                                var AvgExpGiftMeal = '';
                                var ValueOfGiftMeal = '';
                                 var scoreInfo = '';
                                
                                var typevar;
                                if(val.Gifts__c == true && val.Meals_Entertainment__c == false) {
                                    typevar = 'Gifts';
                                    ValueOfGiftMeal = val.Gift_Value_of_gift__c;
                                    if(val.Gift_Score__c < 10) {
                                        GiftMealScore = '0'+val.Gift_Score__c;
                                    }
                                    else {
                                        GiftMealScore = val.Gift_Score__c;
                                    }
                                    if(val.Gift_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGiftMeal = val.Gift_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGiftMeal = 0;
                                    }
                                    BothScorevar = '<div class="gh-approver-status"><span class="go">'+GiftMealScore+'</span> <div class="go">(GO)</div></div>';
                                    if(val.Gift_Recipient__c == false){
                                        scoreInfo   += QuestionsAndDetailsOfGift
                                                    +           '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$'+ ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Total Expenditure in past 12 months'       
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                    +                      '$'+AvgExpGiftMeal        
                                                    +                   '</div>'
                                                    +               '</div>'                           
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Gift'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+ValueOfGiftMeal
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Country where Gift is provided'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       CountrywhereGiftisprovided
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Gift Description </b>';
                                                    if(giftDescription!=null && giftDescription!=''){
                                                        scoreInfo   +=           '<div>'+ giftDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>' 
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Business Purpose: </b>';
                                                    if(giftBusinessPurpose!=null && giftBusinessPurpose!=''){
                                                        scoreInfo   +=           '<div>'+ giftBusinessPurpose + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                                                   
                                                        scoreInfo   +=        '</div>'
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Additional Comments: </b>';
                                                    if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                        scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>'
                                                    +   '<div class="gh-approval-detail">'
                                                    + '<b>Documents related to Gift</b><br/>'                      
                                                    +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                    +           'Loading...'                     
                                                    +       '</div>'
                                                    +   '</div>';   
                                    }else{
                                        scoreInfo   += QuestionsAndDetailsOfGiftPro
                                                    +           '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$'+ ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'                                                                             
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Gift'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+valueOfProviderGift
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    //+                       'Country where Gift is provided'
                                                    //+                   '</div>'
                                                    //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    //+                       CountrywhereGiftisprovided
                                                    //+                   '</div>'
                                                    //+               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Gift Description </b>';
                                                    if(proGiftDescription!=null && proGiftDescription!=''){
                                                        scoreInfo   +=           '<div>'+ proGiftDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Additional Comments: </b>';
                                                    if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                        scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>';
                                                    +   '<div class="gh-approval-detail">'
                                                    + '<b>Documents related to Gift</b><br/>'                      
                                                    +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                    +           'Loading...'                     
                                                    +       '</div>'
                                                    +   '</div>'; 
                                                   
                                    }
                                }
                                if(val.Meals_Entertainment__c == true && val.Gifts__c == false) {
                                    typevar = 'Meals/Entertainment';                                
                                    ValueOfGiftMeal = val.ME_Value_of_Meals_Entertainment__c;
                                   
                                    
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGiftMeal = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGiftMeal = 0;
                                    }
                                    if(val.Meal_Score__c < 10) {
                                        GiftMealScore = '0'+val.Meal_Score__c;
                                    }
                                    else {
                                        GiftMealScore = val.Meal_Score__c;
                                    }
                                    BothScorevar = '<div class="gh-approver-status"><span class="go">'+GiftMealScore+'</span> <div class="go">(GO)</div></div>';
                                    
                                    if(val.Gift_Recipient__c == false){
                                        scoreInfo   += QuestionsAndDetailsOfMeal
                                                    +         '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$' + ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Total Expenditure in past 12 months'       
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                    +                      '$'+AvgExpGiftMeal        
                                                    +                   '</div>'
                                                    +               '</div>'                           
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Meal'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+ValueOfGiftMeal
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Country where Meal is provided'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       CountrywhereMealisprovided
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Meal/Entertainment Description: </b>';
                                                    if(mealDescription!=null && mealDescription!=''){
                                                        scoreInfo   +=           '<div>'+ mealDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>' 
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Business Purpose: </b>';
                                                    if(mealBusinessPurpose!=null && mealBusinessPurpose!=''){
                                                        scoreInfo   +=           '<div>'+ mealBusinessPurpose + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                                               
                                                        scoreInfo   +=        '</div>'
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Additional Comments: </b>';
                                                    if(mealAdditionalComments!=null && mealAdditionalComments!=''){
                                                        scoreInfo   +=           '<div>'+ mealAdditionalComments + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>';
                                                  
                                    }else{
                                        scoreInfo   += QuestionsAndDetailsOfMealPro
                                                    +          '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$' + ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'                        
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Gift'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+ valueOfProviderMeal
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Approved Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    //+                       'Country where Gift is provided'
                                                    //+                   '</div>'
                                                    //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    //+                       CountrywhereGiftisprovided
                                                    //+                   '</div>'
                                                    //+               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Meal/Entertainment Description </b>';
                                                    if(proMealDescription!=null && proMealDescription!=''){
                                                        scoreInfo   +=           '<div>'+ proMealDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>';
                                                  
                                    }
                                }
                                var AvgExpGift = '';
                                var AvgExpMeal = '';
                                if(val.Meals_Entertainment__c == true && val.Gifts__c == true) {
                                    var MealScore = 0;
                                    var GiftScore = 0;
                                    typevar = 'Gifts, Meals/Entertainment';
                                    ValueOfGiftMeal = val.Gift_Value_of_gift__c;
                                    
                                    ValueOfMealVar = val.Meal_Score__c;
                                    
                                    if(val.Gift_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGift = val.Gift_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGift = 0;
                                    }
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpMeal = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpMeal = 0;
                                    }
                                    
                                    if(val.Meal_Score__c < 10) {
                                        MealScore = '0'+val.Meal_Score__c;
                                    }
                                    else {
                                        MealScore = val.Meal_Score__c;
                                    }
                                    if(val.Gift_Score__c < 10) {
                                        GiftScore = '0'+val.Gift_Score__c;
                                    }
                                    else {
                                        GiftScore = val.Gift_Score__c;
                                    }
                                    BothScorevar = '<div class="gh-approver-status"><span class="go">'+GiftScore+'</span> <div class="go">(GO)</div></div>'
                                                 + '<div class="gh-approver-status" style="margin-right: 5px;"><span class="go">'+MealScore+'</span> <div class="go">(GO)</div></div>';
                                                 
                                    if(val.Gift_Recipient__c == false){
                                        scoreInfo       += QuestionsAndDetailsOfGift 
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpGift       
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfGift
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Gift is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereGiftisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(giftDescription!=null && giftDescription!=''){
                                                            scoreInfo   +=           '<div>'+ giftDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(giftBusinessPurpose!=null && giftBusinessPurpose!=''){
                                                            scoreInfo   +=           '<div>'+ giftBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                       
                                                            scoreInfo   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>'                                                                                                                                                                                                                    
                                                       // +           '<div>'
                                                       // +               '<b>Current Expenditure</b><br/>'
                                                       // +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                       // +                     GiftScoreBar       
                                                       // +              '</div>'                        
                                                       // +           '</div>';
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>'
                                                        +               QuestionsAndDetailsOfMeal                                                                
                                                        +         '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpMeal        
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Meal is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereMealisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description: </b>';
                                                        if(mealDescription!=null && mealDescription!=''){
                                                            scoreInfo   +=           '<div>'+ mealDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(mealBusinessPurpose!=null && mealBusinessPurpose!=''){
                                                            scoreInfo   +=           '<div>'+ mealBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                   
                                                            scoreInfo   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(mealAdditionalComments!=null && mealAdditionalComments!=''){
                                                            scoreInfo   +=           '<div>'+ mealAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>';
                                    }else{
                                        scoreInfo       += QuestionsAndDetailsOfGiftPro 
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                                                                             
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+valueOfProviderGift
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(proGiftDescription!=null && proGiftDescription!=''){
                                                            scoreInfo   +=           '<div>'+ proGiftDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>'
                                                        //+           '<div>'
                                                        //+               '<b>Current Expenditure</b><br/>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                        //+                     GiftScoreBar       
                                                        //+              '</div>'                        
                                                        //+           '</div>';
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>' 
                                                        +      QuestionsAndDetailsOfMealPro
                                                        +          '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                        
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ valueOfProviderMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Approved Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description </b>';
                                                        if(proMealDescription!=null && proMealDescription!=''){
                                                            scoreInfo   +=           '<div>'+ proMealDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>';
                                    }
                                }
                                ClickedRecId = val.Id;
                                ApprovedDetailVar += '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-recipient-border">' 
                                                 +  '<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9 gh-recipient gh-approver-rec">'
                                                 +      '<div>'+val.Name_of_Recipient__c+'</div>'
                                                 +      '<small>'+val.Company__c+' ,'+val.Country__c+'</small>'
                                                 +      '<div><span>'+typevar+'</span></div>'
                                                 +      '<div class="gh-recipient-expand"><img id="ApprovedExpandUrl'+val.Id+'" src="{!URLFOR($Resource.GEResource,"images/icon-expand.png")}" onclick="ShowApproveDetails("'+val.Id+'")"/></div>'
                                                 +  '</div>'
                                                 +  '<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 gh-transation-status nogo">' 
                                                 +   BothScorevar                                            
                                                 +  '</div>' 
                                                 +  '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="ApprovedeAddInfo'+val.Id+'" style="padding-top:10px;padding-bottom:10px;display:none">'                                           
                                                 +    scoreInfo
                                                 +  '</div>'
                                                 + '</div>';
                                ApprovedRecCount++;
                            }
                            else if(val.Status__c == 'Rejected') {
                                var GiftMealScore = '';
                                var BothScorevar = '';
                                var AvgExpGiftMeal = '';
                                var ValueOfGiftMeal = '';
                                var scoreInfo = '';
                                if(val.Gifts__c == true && val.Meals_Entertainment__c == false) {
                                    typevar = 'Gifts';
                                    
                                    if(val.Gift_Score__c < 10) {
                                        GiftMealScore = '0'+val.Gift_Score__c;
                                    }
                                    else {
                                        GiftMealScore = val.Gift_Score__c;
                                    }
                                    ValueOfGiftMeal = val.Gift_Value_of_gift__c;
                              
                                    if(val.Gift_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGiftMeal = val.Gift_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGiftMeal = 0;
                                    }
                                    BothScorevar = '<div id="status11" class="gh-approver-status nogo"><span class="nogo">'+GiftMealScore+'</span> <div class="nogo">(NO-GO)</div></div>';
                                    
                                    if(val.Gift_Recipient__c == false){
                                        scoreInfo   += QuestionsAndDetailsOfGift
                                                    +           '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$'+ ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Total Expenditure in past 12 months'       
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                    +                      '$'+AvgExpGiftMeal        
                                                    +                   '</div>'
                                                    +               '</div>'                           
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Gift'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+ValueOfGiftMeal
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Country where Gift is provided'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       CountrywhereGiftisprovided
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Gift Description </b>';
                                                    if(giftDescription!=null && giftDescription!=''){
                                                        scoreInfo   +=           '<div>'+ giftDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>' 
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Business Purpose: </b>';
                                                    if(giftBusinessPurpose!=null && giftBusinessPurpose!=''){
                                                        scoreInfo   +=           '<div>'+ giftBusinessPurpose + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                                                   
                                                        scoreInfo   +=        '</div>'
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Additional Comments: </b>';
                                                    if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                        scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>'
                                                    +   '<div class="gh-approval-detail">'
                                                    + '<b>Documents related to Gift</b><br/>'                      
                                                    +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                    +           'Loading...'                     
                                                    +       '</div>'
                                                    +   '</div>'; 
                                                        
                                                  
                                    }else{
                                        scoreInfo   += QuestionsAndDetailsOfGiftPro
                                                    +           '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$'+ ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'                                                                             
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Gift'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+valueOfProviderGift
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    //+                       'Country where Gift is provided'
                                                    //+                   '</div>'
                                                    //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    //+                       CountrywhereGiftisprovided
                                                    //+                   '</div>'
                                                    //+               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Gift Description </b>';
                                                    if(proGiftDescription!=null && proGiftDescription!=''){
                                                        scoreInfo   +=           '<div>'+ proGiftDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Additional Comments: </b>';
                                                    if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                        scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>'
                                                    +   '<div class="gh-approval-detail">'
                                                    + '<b>Documents related to Gift</b><br/>'                      
                                                    +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                    +           'Loading...'                     
                                                    +       '</div>'
                                                    +   '</div>'; 
                                    }
                                }
                                if(val.Meals_Entertainment__c == true && val.Gifts__c == false) {
                                    typevar = 'Meals/Entertainment';
                                     ValueOfGiftMeal = val.ME_Value_of_Meals_Entertainment__c;                                                                     
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGiftMeal = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGiftMeal = 0;
                                    }
                                    if(val.Meal_Score__c < 10) {
                                        GiftMealScore = '0'+val.Meal_Score__c;
                                    }
                                    else {
                                        GiftMealScore = val.Meal_Score__c;
                                    }
                                    BothScorevar = '<div id="status11" class="gh-approver-status nogo"><span class="nogo">'+GiftMealScore+'</span> <div class="nogo">(NO-GO)</div></div>';
                                    
                                    if(val.Gift_Recipient__c == false){
                                        scoreInfo   += QuestionsAndDetailsOfMeal
                                                    +         '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$' + ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Total Expenditure in past 12 months'       
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                    +                      '$'+AvgExpGiftMeal        
                                                    +                   '</div>'
                                                    +               '</div>'                           
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Meal'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+ValueOfGiftMeal
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Country where Meal is provided'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       CountrywhereMealisprovided
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Meal/Entertainment Description: </b>';
                                                    if(mealDescription!=null && mealDescription!=''){
                                                        scoreInfo   +=           '<div>'+ mealDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>' 
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Business Purpose: </b>';
                                                    if(mealBusinessPurpose!=null && mealBusinessPurpose!=''){
                                                        scoreInfo   +=           '<div>'+ mealBusinessPurpose + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                                               
                                                        scoreInfo   +=        '</div>'
                                                                                    +        '<div class="gh-approval-detail">'
                                                                                    +           '<b> Additional Comments: </b>';
                                                    if(mealAdditionalComments!=null && mealAdditionalComments!=''){
                                                        scoreInfo   +=           '<div>'+ mealAdditionalComments + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>';
                                    }else{
                                        scoreInfo   += QuestionsAndDetailsOfMealPro
                                                    +          '<div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Threshold value'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       '$' + ThresholdValue    
                                                    +                   '</div>'
                                                    +               '</div>'                        
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Value of the Meal'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       '$'+ valueOfProviderMeal
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected By'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorName
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    +                       'Rejected Date'
                                                    +                   '</div>'
                                                    +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    +                       ApproverRejectorDate
                                                    +                   '</div>'
                                                    +               '</div>'
                                                    //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                    //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                    //+                       'Country where Gift is provided'
                                                    //+                   '</div>'
                                                    //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                    //+                       CountrywhereGiftisprovided
                                                    //+                   '</div>'
                                                    //+               '</div>'
                                                    +           '</div>'
                                                    +        '<div class="gh-approval-detail">'
                                                    +           '<b> Meal/Entertainment Description </b>';
                                                    if(proMealDescription!=null && proMealDescription!=''){
                                                        scoreInfo   +=           '<div>'+ proMealDescription + '</div>';
                                                    }
                                                    else {
                                                        scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                    }
                                                        scoreInfo   +=        '</div>';
                                    }
                                }
                                var AvgExpGift = '';
                                var AvgExpMeal = '';
                                if(val.Meals_Entertainment__c == true && val.Gifts__c == true) {
                                    typevar = 'Gifts, Meals/Entertainment';
                                    var MealScore = 0;
                                    var GiftScore = 0;
                                     if(val.Gift_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpGift = val.Gift_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpGift = 0;
                                    }
                                    if(val.ME_Twelve_Months_Aggregate_Value__c != null) {
                                        AvgExpMeal = val.ME_Twelve_Months_Aggregate_Value__c;
                                    }
                                    else {
                                        AvgExpMeal = 0;
                                    }
                                    if(val.Meal_Score__c < 10) {
                                        MealScore = '0'+val.Meal_Score__c;
                                    }
                                    else {
                                        MealScore = val.Meal_Score__c;
                                    }
                                    if(val.Gift_Score__c < 10) {
                                        GiftScore = '0'+val.Gift_Score__c;
                                    }
                                    else {
                                        GiftScore = val.Gift_Score__c;
                                    }
                                    BothScorevar += '<div class="gh-approver-status nogo"><span class="nogo">'+GiftScore+'</span><div class="nogo">(NO-GO)</div></div>' 
                                     +  '<div class="gh-approver-status nogo" style="margin-right: 5px;"><span class="nogo">'+MealScore+'</span> <div class="nogo">(NO-GO)</div></div>'; 
                                     
                                     if(val.Gift_Recipient__c == false){
                                        scoreInfo       += QuestionsAndDetailsOfGift 
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpGift       
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfGift
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Gift is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereGiftisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(giftDescription!=null && giftDescription!=''){
                                                            scoreInfo   +=           '<div>'+ giftDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(giftBusinessPurpose!=null && giftBusinessPurpose!=''){
                                                            scoreInfo   +=           '<div>'+ giftBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                       
                                                            scoreInfo   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>'                                                                                                                                                                                                                    
                                                       // +           '<div>'
                                                       // +               '<b>Current Expenditure</b><br/>'
                                                       // +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                       // +                     GiftScoreBar       
                                                       // +              '</div>'                        
                                                       // +           '</div>';
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>' 
                                                        +               QuestionsAndDetailsOfMeal                                                                
                                                        +         '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Total Expenditure in past 12 months'       
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="totalValue">'
                                                        +                      '$'+AvgExpMeal        
                                                        +                   '</div>'
                                                        +               '</div>'                           
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ValueOfMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Country where Meal is provided'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       CountrywhereMealisprovided
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description: </b>';
                                                        if(mealDescription!=null && mealDescription!=''){
                                                            scoreInfo   +=           '<div>'+ mealDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>' 
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Business Purpose: </b>';
                                                        if(mealBusinessPurpose!=null && mealBusinessPurpose!=''){
                                                            scoreInfo   +=           '<div>'+ mealBusinessPurpose + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                                                   
                                                            scoreInfo   +=        '</div>'
                                                                                        +        '<div class="gh-approval-detail">'
                                                                                        +           '<b> Additional Comments: </b>';
                                                        if(mealAdditionalComments!=null && mealAdditionalComments!=''){
                                                            scoreInfo   +=           '<div>'+ mealAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>';
                                    }else{
                                        scoreInfo       += QuestionsAndDetailsOfGiftPro
                                                        +           '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$'+ ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                                                                             
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Gift'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+valueOfProviderGift
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Gift Description </b>';
                                                        if(proGiftDescription!=null && proGiftDescription!=''){
                                                            scoreInfo   +=           '<div>'+ proGiftDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Additional Comments: </b>';
                                                        if(giftAdditionalComments!=null && giftAdditionalComments!=''){
                                                            scoreInfo   +=           '<div>'+ giftAdditionalComments + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>'
                                                        //+           '<div>'
                                                        //+               '<b>Current Expenditure</b><br/>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-score-bar" style="margin-top:10px;">'
                                                        //+                     GiftScoreBar       
                                                        //+              '</div>'                        
                                                        //+           '</div>';
                                                        +   '<div class="gh-approval-detail">'
                                                        + '<b>Documents related to Gift</b><br/>'                      
                                                        +   '<div id="GiftPendingDoc'+val.Id+'">'
                                                        +           'Loading...'                     
                                                        +       '</div>'
                                                        +   '</div>'
                                                        +      QuestionsAndDetailsOfMealPro
                                                        +          '<div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-top:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Threshold value'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       '$' + ThresholdValue    
                                                        +                   '</div>'
                                                        +               '</div>'                        
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Value of the Meal'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       '$'+ valueOfProviderMeal
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected By'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorName
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        +               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        +                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        +                       'Rejected Date'
                                                        +                   '</div>'
                                                        +                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        +                       ApproverRejectorDate
                                                        +                   '</div>'
                                                        +               '</div>'
                                                        //+               '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-scoreTable" style="margin-bottom:10px;">'
                                                        //+                   '<div class="col-xs-10 col-sm-6 col-md-6 col-lg-6">'
                                                        //+                       'Country where Gift is provided'
                                                        //+                   '</div>'
                                                        //+                   '<div class="col-xs-2 col-sm-6 col-md-6 col-lg-6" id="currentValue">'
                                                        //+                       CountrywhereGiftisprovided
                                                        //+                   '</div>'
                                                        //+               '</div>'
                                                        +           '</div>'
                                                        +        '<div class="gh-approval-detail">'
                                                        +           '<b> Meal/Entertainment Description </b>';
                                                        if(proMealDescription!=null && proMealDescription!=''){
                                                            scoreInfo   +=           '<div>'+ proMealDescription + '</div>';
                                                        }
                                                        else {
                                                            scoreInfo   +=           '<div>'+ 'N/A' + '</div>';
                                                        }
                                                            scoreInfo   +=        '</div>';                                     
                                    }
                                }
                                ClickedRecId = val.Id;
                                RejectedDetailVar += '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 gh-recipient-border">' 
                                                 +  '<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9 gh-recipient gh-approver-rec">'
                                                 +      '<div>'+val.Name_of_Recipient__c+'</div>'
                                                 +      '<small>'+val.Company__c+' ,'+val.Country__c+'</small>'
                                                 +      '<div><span>'+typevar+'</span></div>'
                                                 +      '<div class="gh-recipient-expand"><img id="RejectedExpandUrl'+val.Id+'" src="{!URLFOR($Resource.GEResource,"images/icon-expand.png")}" onclick="ShowRejectDetails("'+val.Id+'")"/></div>'
                                                 +  '</div>'
                                                 +  '<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 gh-transation-status">' 
                                                 +   BothScorevar
                                                // +      '<div class="gh-approver-status"><span class="go">'+GiftMealScore+'</span> <div class="go">(GO)</div></div>'
                                                 +  '</div>'                                            
                                                 +  '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="ApprovedeAddInfo'+val.Id+'" style="padding-top:10px;padding-bottom:10px;display:none">'
                                                 +   scoreInfo 
                                                 + '</div>'
                                                 +'</div>';
                                RejectedRecCount++;
                            }
                });
                
                $('#Numberofrecipients').html('Number of ' + RequestType +': <span style="font-weight: 100;">'+request.NumberOfRecipients + '</span>');
                $('#RequestType').html(RequestTypeLabel);
                console.log('PendingRecCount '+PendingRecCount);
                if(PendingRecCount > 0) {
                    $('#PendingReviewDiv').html(PendingDetailVar);
                }
                else {
                    $('#PendingReviewDiv').html('No records found');
                }
                if(ApprovedRecCount > 0) {
                    $('#ApprovedDiv').html(ApprovedDetailVar);
                }
                else {
                    $('#ApprovedDiv').html('No records found');
                }
                 if(RejectedRecCount > 0) {
                    $('#RejectedDiv').html(RejectedDetailVar);
                }
                else {
                    $('#RejectedDiv').html('No records found');
                }
                
                $('#requestPage').addClass('hidden');
                $('#requestEventDetailPage').addClass('hidden');
                $('#requestDetailPage').removeClass('hidden');
                $('#completedRequestDetailPage').addClass('hidden'); 
        }
    }