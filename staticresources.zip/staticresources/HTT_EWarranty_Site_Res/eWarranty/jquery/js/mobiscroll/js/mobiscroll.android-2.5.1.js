(function ($) {

    $.mobiscroll.themes.android = {
        defaults: {
            dateOrder: 'Mddyy',
            mode: 'clickpick',
            height: 50
        }
    }

})(jQuery);

