

var aContactHON = new Object();
	aContactHON = 
	{
		contactId: '',
		contactName: '',
		contactEmail: '',
		functionalTeam: ''
	}
var anActionHistory = new Object();
	anActionHistory = 
	{
		parentId: '',
		oldValue: '',
		newValue: '',
		field: '',
		createdBy: '',
		dateCreated: '',
		dateCompletion: ''
	}
var transferAction = new Object();
	transferAction = 
	{
		id: '',
		type__c: '',
		Action__c: '',
		Due_Date__c: '',
		Functional_Team__c: '',
		Action_Owner__c: '',
		Action_Owner__name: '',
		Status__c: ''
	}
var currentAction, currentActionIndex;
var stringAllActionsSelections;
var listSelectedActions = [];

var listDueDateStatus = ['ALL','On track','Overdued/Escalated','Over 90 days'];
var listFreeSearchActions = ['ALL','Account','Parent Account','Action Owner','Action ID','NPS ID','Action'];

var objSelActionsLOB = newInputRadioOrCheckbox();
var objSelActionsRegion = newInputRadioOrCheckbox();
var objSelActionsDEEPN = newInputRadioOrCheckbox();
var objSelActionsPlant = newInputRadioOrCheckbox();
var objSelActionsType = newInputRadioOrCheckbox();
var objSelActionsStatus = newInputRadioOrCheckbox();
var objSelActionsDueDateStatus = newInputRadioOrCheckbox();
var objSelActionsPhases = newInputRadioOrCheckbox();
var objSelActionsCategories = newInputRadioOrCheckbox();
var objSelActionsFunctionalTeam = newInputRadioOrCheckbox();
var objSelActionsOwnership = newInputRadioOrCheckbox();
var objSelActionsFreeSearch = newInputRadioOrCheckbox();

var objSelActionsTypeB = newInputRadioOrCheckbox();
var objSelActionsStatusB = newInputRadioOrCheckbox();

var objActionContentUpgrd = newTextInputUpgraded();

function initializeActions()
	{
		objActionContentUpgrd.initialize('F21-txtaAction',250,'textarea','');
		contentSelectionsActions();
		
		sortActionsTable('dueDate','desc');
		contentActionsTable();
		

		eventsActionsTable();
		eventsActions();
	}

function contentSelectionsActions()
	{
		var i, content, aTab = [];
		
		content = '<option></option>';
		for(i=0;i<listFunctionalTeam.length;i++) 
			content += '<option value="'+listFunctionalTeam[i]+'">'+listFunctionalTeam[i]+'</option>';
		document.getElementById('F21-listFunctionalTeam').innerHTML = content;
		document.getElementById('F21-listFunctionalTeam').selectedIndex = 0;
		
		aTab.length = 0; for(i=0;i<listLOBall.length;i++) aTab[aTab.length] = listLOBall[i][0];
		objSelActionsLOB.initialize('F1-rLOB','radio',aTab,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		
		aTab.length = 0; for(i=0;i<listRegionsAll.length;i++) aTab[aTab.length] = listRegionsAll[i][0]; 
		objSelActionsRegion.initialize('F1-rRegions','radio',aTab,callbackSelectionsActions,'inputSelected','inputUnselected','0');

		objSelActionsDEEPN.initialize('F1-rDEEPN','radio',listDEEPNall,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsPlant.initialize('F1-rPlant','radio',listPlantsAll,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsType.initialize('F1-rActionType','radio',listActionTypeAll,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsStatus.initialize('F1-rStatus','radio',listActionStatusAll,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsDueDateStatus.initialize('F1-rActionDueDateStatus','radio',listDueDateStatus,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsPhases.initialize('F1-rPhases','radio',listPhases,callbackSelectionsActions,'inputSelected','inputUnselected','0');			
		objSelActionsCategories.initialize('F1-rCategories','radio',listCategories,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsFunctionalTeam.initialize('F1-rFunctionalTeam','radio',listFunctionalTeamAll,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsOwnership.initialize('F1-rOwnership','radio',listOwnership,callbackSelectionsActions,'inputSelected','inputUnselected','0');
		objSelActionsFreeSearch.initialize('F1-rFreeSearch','radio',listFreeSearchActions,callbackSelectionsActions,'inputSelected','inputUnselected','0');

		objSelActionsTypeB.initialize('F21-rActionType','radio',listActionType,callbackNone,'inputSelected','inputUnselected','0');
		objSelActionsStatusB.initialize('F21-rStatus','radio',listActionStatus,callbackNone,'inputSelected','inputUnselected','0');
	}
function contentActionsTable()
	{
		var i, j, ck, index, content = '', someAccounts, someCategories, someSources, aStatus, aTitle, indexSelected = -1;
		
		document.getElementById('F1-txtFilterTitles').innerHTML = stringAllActionsSelections;
		document.getElementById('F2-txtNumberSelectedActions').innerHTML = listSelectedActions.length + ' action(s) selected';
		arrangeCSSclasses('F1-txtFilterTitles','tagAppearance,tagAppearance','0,1');
		
		for(i=0;i<listSelectedActions.length;i++)
		{
			index = listSelectedActions[i];

			someAccounts = allActionResponses[index].accounts;
			ck = true;while(ck){ck = false;if(someAccounts.indexOf(';') != -1){ck = true;someAccounts = someAccounts.replace(';',',<br/>');}}
			
			someCategories = allActionResponses[index].categories;
			ck = true;while(ck){ck = false;if(someCategories.indexOf(';') != -1){ck = true;someCategories = someCategories.replace(';',',<br/>');}}
			
			someSources = allActionResponses[index].sourcesNames;
			ck = true;while(ck){ck = false;if(someSources.indexOf(';') != -1){ck = true;someSources = someSources.replace(';',',<br/>');}}
			
			
			if(today > allActionResponses[index].dueDate)
			{
				aStatus = '<br/>'+'<i class="fa fa-circle colorHONred" aria-hidden="true"></i>' +
						'<span class="colorHONred pushOutLeft05">'+parseInt((today-parseInt(allActionResponses[index].dueDate))/(24*3600*1000)) + ' days</span>';
				aTitle = parseInt((today-parseInt(allActionResponses[index].dueDate))/(24*3600*1000)) + ' days delay ('+allActionResponses[index].status+')';
			}
			else
			{
				if(allActionResponses[index].status.indexOf('On Going') != -1)
				aStatus = '<br/>'+'<i class="fa fa-square colorGreen" aria-hidden="true"></i>' +
						'<span class="colorGreen pushOutLeft05">'+parseInt((parseInt(allActionResponses[index].dueDate)-today)/(24*3600*1000)) + ' days</span>';
					else aStatus = '<br/>'+'<i class="fa fa-square colorGreenRed" aria-hidden="true"></i>' +
						'<span class="colorGreenRed pushOutLeft05">'+parseInt((parseInt(allActionResponses[index].dueDate)-today)/(24*3600*1000)) + ' days</span>';
				aTitle = parseInt((today-parseInt(allActionResponses[index].dueDate))/(24*3600*1000)) + ' days remaining ('+allActionResponses[index].status+')';
			}
			if((allActionResponses[index].status == listActionStatus[listActionStatus.length-1]) || (allActionResponses[index].status == listActionStatus[listActionStatus.length-2]))
			{
				aStatus = '';
				aTitle = 'Completed or Withdawn';
			}
			
			if(idA == allActionResponses[index].actionID) indexSelected = index; //(idA != 'undefined')
			content +='<tr id="F2-row'+index+'" class="cursorPointer">'+
					'<td class="textCenter">'+(i+1)+'</td>'+
					'<td class="noWrap">'+allActionResponses[index].actionName+'</td>'+
					'<td class="preserveLines">'+allActionResponses[index].listFeedback+'</td>'+
					'<td class="preserveLines">'+allActionResponses[index].action+'</td>'+
					'<td>'+allActionResponses[index].actionOwner+'<br/><span class="colorGray40">'+allActionResponses[index].functionalTeam+'</span></td>'+
					//'<td>'+allActionResponses[index].actionType+'</td>'+
					//'<td class="noWrap">'+allActionResponses[index].status+'</td>'+
					'<td class="noWrap" title="'+aTitle+'">'+dateConverted(allActionResponses[index].dueDate)+aStatus+'</td>'+
					
					
					//'<td class="noWrap">'+someCategories+'</td>'+
					'<td class="noWrap">'+someAccounts+'</td>'+
				'</tr>';
		}
		document.getElementById('F2-tbActions').innerHTML = content;
		if(indexSelected != -1) contentActionDetails('F2-row'+indexSelected);
	}
function contentActionDetails(id)
	{
		var i, y, tab = [], aTab = [], tagStyle1, tagStyle2, hDetails, hContainer, index, aContent, contentFT, selectedTeam, oldIdR;
		arrangeCSSclasses('F21-sDetails','tagAppearance,tagAppearance','0,1');
		if(id != -1)
		{
			index = id.replace('F2-row','');
			currentAction = index;
			for(i=0;i<allActionResponses.length;i++)
				if(document.getElementById('F2-row'+i)) arrangeCSSclasses('F2-row'+i,'groundLightOrange','0');				
			arrangeCSSclasses(id,'groundLightOrange','1');
			
			document.getElementById('F21-listFunctionalTeam').style.display = 'block';
			document.getElementById('F21-listActionOwners').style.display = 'block';
			document.getElementById('F21-rActionTypeContainer').style.display = 'block';
			document.getElementById('F21-iDueDate').style.display = 'block';
			document.getElementById('F21-rStatusContainer').style.display = 'block';
			document.getElementById('F21-btnCancel').disabled = false;
			document.getElementById('F21-btnSave').disabled = false;
			idA = allActionResponses[index].actionID;
			// name
			document.getElementById('F21-txtName').innerHTML = allActionResponses[index].actionName;
			// sources
			aContent = ''; 
			tab.length = 0; tab = allActionResponses[index].sourcesNames.split(';');
			aTab.length = 0; aTab = allActionResponses[index].sourcesIDs.split(';');
			oldIdR = idR;
			
			for(i=0;i<tab.length;i++)
			{
				idR = aTab[i];
				aContent += '<p id="F21-txtDetailsSource'+i+'" class="noWrap aLink">&bull;&nbsp;'+tab[i]+'</p>';
			}
			idR = oldIdR;
			document.getElementById('F21-txtSource').innerHTML = aContent;
			// action type
			for(i=0;i<listActionType.length;i++)
				if(allActionResponses[index].actionType == listActionType[i])
					objSelActionsTypeB.forceSelection(i.toString());

			// action
			document.getElementById('F21-txtaActionObject').value = allActionResponses[index].action;
			document.getElementById('F21-txtaActionCounter').innerHTML = document.getElementById('F21-txtaActionObject').value.length;
			// this part should be investigated (when working with Form somehow is altered the content of 'F21-listFunctionalTeam')
			contentFT = '<option></option>';
			for(i=0;i<listFunctionalTeam.length;i++) 
				contentFT += '<option value="'+listFunctionalTeam[i]+'">'+listFunctionalTeam[i]+'</option>';
			document.getElementById('F21-listFunctionalTeam').innerHTML = contentFT;
			// functional team & action owners list
			for(i=0;i<listFunctionalTeam.length;i++)
				if(listFunctionalTeam[i] == allActionResponses[index].functionalTeam) 
				{
					document.getElementById('F21-listFunctionalTeam').selectedIndex = (i+1);
					selectedTeam = allActionResponses[index].functionalTeam;
					fulfillActionOwnersList(selectedTeam,'F21-listActionOwners');
					for(j=0;j<listActionOwner.length;j++)
						if(listActionOwner[j] == allActionResponses[index].actionOwner) 
							{
							
								document.getElementById('F21-listActionOwners').selectedIndex = j;
							}
				}
			// due date
			document.getElementById('F21-iDueDate').value = dateConverted(allActionResponses[index].dueDate);
			// touchpoints
			aContent = ''; tab.length = 0; tab = allActionResponses[index].touchpointsExt.split(';');
			for(i=0;i<tab.length;i++)
				aContent += '<li>'+tab[i]+'</li>';
			document.getElementById('F21-txtTouchpoints').innerHTML = aContent;
			// categories
			aContent = ''; tab.length = 0; tab = allActionResponses[index].categoriesExt.split(';');
			for(i=0;i<tab.length;i++)
				aContent += '<li>'+tab[i]+'</li>';
			document.getElementById('F21-txtCategories').innerHTML = aContent;
			// accounts
			document.getElementById('F21-txtAccounts').innerHTML = allActionResponses[index].accounts;
			// regions
			document.getElementById('F21-txtRegions').innerHTML = allActionResponses[index].listRegions;
			
			// status
			for(i=0;i<listActionStatus.length;i++)
				if(allActionResponses[index].status == listActionStatus[i])
					objSelActionsStatusB.forceSelection(i.toString());
			// action history
			SFDCactionHistory.length = 0;
			readActionHistory(allActionResponses[index].actionID);
			aContent = '';
			for(i=0;i<SFDCactionHistory.length;i++)
				aContent += '<tr>'+
							//'<td class="noWrap textTop">'+dateConverted(SFDCactionHistory[i].dateCreated)+'</td>'+
							'<td class="noWrap textTop">'+dateConverted(SFDCactionHistory[i].dateCreated)+'</td>'+
							'<td class="textTop">'+SFDCactionHistory[i].field+'</td><td>'+SFDCactionHistory[i].oldValue+' -> '+SFDCactionHistory[i].newValue+
							'<br/>('+SFDCactionHistory[i].createdBy+')</td>'+
							'</tr>';
			aContent += '<tr><td>'+dateConverted(allActionResponses[index].dateCreated)+'</td><td colspan="2">Created</td></tr>';
			document.getElementById('F21-tbHistory').innerHTML = aContent;


			hDetails = parseInt(window.getComputedStyle(document.getElementById('F21-sDetails'), null).getPropertyValue('height'));
			hContainer = parseInt(window.getComputedStyle(document.getElementById('F2-sBigContainer'), null).getPropertyValue('height'));
			y = getPosition(document.getElementById(id),'').y - getPosition(document.getElementById('F2-sDetailsContainer'),'').y;
			if((hDetails + y) > hContainer) y = hContainer - hDetails;
			document.getElementById('F21-sDetails').style.top = y+'px';
			//arrangeCSSclasses('F21-sDetails','tagAppearance,tagAppearance','0,1');
		}
		else 
		{
			document.getElementById('F21-txtName').innerHTML = '';
			document.getElementById('F21-txtSource').innerHTML = '';
			document.getElementById('F21-txtaActionObject').value = '';
			document.getElementById('F21-listFunctionalTeam').selectedIndex = 0;
			document.getElementById('F21-listActionOwners').style.display = 'none';
			document.getElementById('F21-rActionTypeContainer').style.display = 'none';
			document.getElementById('F21-iDueDate').style.display = 'none';
			document.getElementById('F21-rStatusContainer').style.display = 'none';
			document.getElementById('F21-txtTouchpoints').innerHTML = '';
			document.getElementById('F21-txtCategories').innerHTML = '';
			document.getElementById('F21-txtAccounts').innerHTML = '';
			document.getElementById('F21-btnCancel').disabled = true;
			document.getElementById('F21-btnSave').disabled = true;
			document.getElementById('F21-tbHistory').innerHTML = '';
			y = getPosition(document.getElementById('F2-sDetailsContainer'),'').y;
			document.getElementById('F21-sDetails').style.top = '32px';
		}
		eventsActionDetails();
	}

function eventsActions()
	{
		var i, selectedTeam;
		document.getElementById('F1-btnSearch').onclick = function(){fillSelectedActions();contentActionsTable();eventsActionsTable();return false;}
		document.getElementById('F1-iSearch').onkeyup = function(event) {if(event.keyCode == 13) {fillSelectedActions();contentActionsTable();eventsActionsTable();}}
		document.getElementById('F1-iSearch').onkeydown = function(event) {if(event.keyCode == 13) {fillSelectedActions();contentActionsTable();eventsActionsTable();}}
		
		document.getElementById('F21-listFunctionalTeam').onchange = function() 
		{
			fulfillActionOwnersList(document.getElementById('F21-listFunctionalTeam').options[document.getElementById('F21-listFunctionalTeam').selectedIndex].value,'F21-listActionOwners');
		}

		document.getElementById('F21-iDueDate').onchange = function() {document.getElementById('F21-iDueDate').value = dateConverted(Date.parse(document.getElementById('F21-iDueDate').value));}
		document.getElementById('F21-btnCancel').onclick = function() {contentActionDetails('F2-row'+currentAction);}
		document.getElementById('F21-btnSave').onclick = function() {saveAction();}
	}
function eventsActionsTable()
	{
		var i;
		
		/*document.getElementById('F2-hcStatus').onclick = function()
			{
				if(document.getElementById('F2-hcStatus').innerHTML.indexOf('fa-sort-asc') != -1) sortActionsTable('plan','desc');
				else sortActionsTable('plan','asc');
			}*/
		document.getElementById('F2-hcOwner').onclick = function()
			{
				if(document.getElementById('F2-hcOwner').innerHTML.indexOf('fa-sort-asc') != -1) sortActionsTable('owner','desc');
				else sortActionsTable('owner','asc');
			}
		document.getElementById('F2-hcDueDate').onclick = function()
			{
				if(document.getElementById('F2-hcDueDate').innerHTML.indexOf('fa-sort-asc') != -1) sortActionsTable('dueDate','desc');
				else sortActionsTable('dueDate','asc');
			}
		for(i=0;i<allActionResponses.length;i++)
			if(document.getElementById('F2-row'+i))
				document.getElementById('F2-row'+i).onclick = function() {contentActionDetails(this.id);};
	}
function eventsActionDetails()
	{
		var i = 0;
		while(document.getElementById('F21-txtDetailsSource'+i))
		{
			document.getElementById('F21-txtDetailsSource'+i).onclick = function(){selectActionSource(this.id);};
			i++;
		}
	}

function callbackSelectionsActions()
	{
		fillSelectedActions();
		contentActionsTable();
		eventsActionsTable();
	}
function sortActionsTable(param,direction)
	{
		var returnAsc, returnDesc;
		//document.getElementById('F2-hcActionType').innerHTML = 'Type&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		//document.getElementById('F2-hcStatus').innerHTML = 'Status&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('F2-hcOwner').innerHTML = 'Action Owner&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('F2-hcDueDate').innerHTML = 'Due Date&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		if(direction == 'asc') {returnAsc = 1; returnDesc = -1;}
		else {returnAsc = -1; returnDesc = 1;}
		switch(param)
		{
			case 'type':
			{
				document.getElementById('F2-hcActionType').innerHTML = 'Type&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allActionResponses.sort(function(a,b)
				{
					var x = a.actionType;
					var y = b.actionType;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.dueDate > b.dueDate) return -1;
						if(a.dueDate < b.dueDate) return 1;
						else return 0;
					}
				});
			};break;
			/*case 'plan':
			{
				document.getElementById('F2-hcStatus').innerHTML = 'Plan&nbsp;Update&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allActionResponses.sort(function(a,b)
				{
					var x = a.status;
					var y = b.status;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.dueDate > b.dueDate) return -1;
						if(a.dueDate < b.dueDate) return 1;
						else return 0;
					}
				});
			};break;*/
			case 'owner':
			{
				document.getElementById('F2-hcOwner').innerHTML = 'Action owner&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allActionResponses.sort(function(a,b)
				{
					var x = a.actionOwner;
					var y = b.actionOwner;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.dueDate > b.dueDate) return -1;
						if(a.dueDate < b.dueDate) return 1;
						else return 0;
					}
				});
			};break;
			case 'dueDate':
			{
				document.getElementById('F2-hcDueDate').innerHTML = 'Due Date&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allActionResponses.sort(function(a,b)
				{
					var x = a.dueDate;
					var y = b.dueDate;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else return 0;
				});
			};break;
			

		}
		fillSelectedActions();
		contentActionsTable();
		eventsActionsTable();
	}
function selectActionSource(id)
	{
		var index, aTab = [];
		index = parseInt(id.replace('F21-txtDetailsSource',''));
		aTab.length = 0; aTab = allActionResponses[currentAction].sourcesIDs.split(';');
		selectedResponse = aTab[index];
		goToFormPage();
	}

function fillSelectedActions()
	{
		var i, j, k;
		var selectedLOB, selectedRegion, selectedDEEPN, selectedPlant, selectedActionType, selectedStatus, selectedDueDateStatus, selectedPhase, selectedCategory, selectedTeam, selectOwnership, searchWord;
		var checkLOB, checkRegion, checkDEEPN, checkPlant, checkActionType, checkStatus, checkDueDateStatus, checkPhase, checkCategory, checkTeam;
		stringAllActionsSelections = '';
		
		// Identify active filters
			i = objSelActionsLOB.indexSelected; //LOB filter
			if(i != 0)
			{
				selectedLOB = listLOBall[i][0];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listLOBall[i][0];
					else stringAllActionsSelections += '; ' + listLOBall[i][0];	
			}
			
			i = objSelActionsRegion.indexSelected;
			if(i != 0)
			{
				selectedRegion = listRegionsAll[i][0];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listRegionsAll[i][0];
				else stringAllActionsSelections += '; ' + listRegionsAll[i][0];
			}	

			i = objSelActionsDEEPN.indexSelected; //DEEPN filter
			if(i != 0)
			{
				selectedDEEPN = listDEEPNall[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listDEEPNall[i];
				else stringAllActionsSelections += '; ' + listDEEPNall[i];
			}

			i = objSelActionsPlant.indexSelected; //Plant filter
			if(i != 0)
			{
				selectedPlant = listPlantsAll[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listPlantsAll[i];
				else stringAllActionsSelections += '; ' + listPlantsAll[i];
			}
			
			i = objSelActionsType.indexSelected;// Action Type filter
			if(i != 0)
			{
				selectedActionType = listActionTypeAll[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listActionTypeAll[i];
					else stringAllActionsSelections += '; ' + listActionTypeAll[i];
			}
			
			i = objSelActionsStatus.indexSelected;// Plan Update filter
			if(i != 0)
			{
				selectedStatus = listActionStatusAll[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listActionStatusAll[i];
					else stringAllActionsSelections += '; ' + listActionStatusAll[i];
			}
			
			i = objSelActionsDueDateStatus.indexSelected;//Action Status filter 
			if(i != 0)
			{
				selectedDueDateStatus = listDueDateStatus[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listDueDateStatus[i];
					else stringAllActionsSelections += '; ' + listDueDateStatus[i];
			}

			i = objSelActionsPhases.indexSelected //Phases filter
			if(i != 0)
			{
				selectedPhase = listPhases[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listPhases[i];
					else stringAllActionsSelections += '; ' + listPhases[i];
			}
			
			i = objSelActionsCategories.indexSelected;//Categories filter
			if(i != 0)
			{
				selectedCategory = listCategories[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listCategories[i];
					else stringAllActionsSelections += '; ' + listCategories[i];
			}
			
			i = objSelActionsFunctionalTeam.indexSelected;//Functional Team filter
			if(i != 0)
			{
				selectedTeam = listFunctionalTeamAll[i];
				if(stringAllActionsSelections == '') stringAllActionsSelections = listFunctionalTeamAll[i];
					else stringAllActionsSelections += '; ' + listFunctionalTeamAll[i];
			}
			
			i = objSelActionsOwnership.indexSelected; // Ownership filter
			if(i != 0)
			{
				selectedOwnership = i;
				if(stringAllActionsSelections == '') stringAllActionsSelections = listOwnership[i];
				else stringAllActionsSelections += '; ' + listOwnership[i];
			}
					
			searchWord = document.getElementById('F1-iSearch').value;// Free search filter
			if(searchWord != '')
			{			
				if(stringAllActionsSelections == '') stringAllActionsSelections = searchWord; 
				else stringAllActionsSelections += '; ' + searchWord;
			}

		listSelectedActions.length = 0;
		for(i=0;i<allActionResponses.length;i++)
		{
			if(document.getElementById('F1-rLOB0').checked) checkLOB = true;
			else
			{
				if(allActionResponses[i].LOBs.indexOf(selectedLOB) != -1) checkLOB = true;
				else checkLOB = false;
			}
			if(document.getElementById('F1-rRegions0').checked) checkRegion = true;
			else
			{
				if(allActionResponses[i].listRegions.indexOf(selectedRegion) != -1) checkRegion = true;
				else checkRegion = false;	
			}
			if(document.getElementById('F1-rDEEPN0').checked) checkDEEPN = true;
			else
			{
				if(allActionResponses[i].listDEEPNs.indexOf(selectedDEEPN) != -1) checkDEEPN = true;
				else checkDEEPN = false;
			}
			if(document.getElementById('F1-rPlant0').checked) checkPlant = true;
			else
			{
				if(allActionResponses[i].categoriesExt.indexOf(selectedPlant) != -1) checkPlant = true;
				else checkPlant = false;
			}
			if(document.getElementById('F1-rActionType0').checked) checkActionType = true;
			else
			{
				if(allActionResponses[i].actionType.indexOf(selectedActionType) != -1) checkActionType = true;
				else checkActionType = false;
			}
			if(document.getElementById('F1-rStatus0').checked) checkStatus = true;
			else
			{
				if(allActionResponses[i].status.indexOf(selectedStatus) != -1) checkStatus = true;
				else 
				{
					if(document.getElementById('F1-rStatus1').checked)
					{
						if((allActionResponses[i].status.indexOf(listActionStatus[listActionStatus.length-1]) == -1) 
							&& (allActionResponses[i].status.indexOf(listActionStatus[listActionStatus.length-2]) == -1))
							checkStatus = true;
						else checkStatus = false;
					}
					else checkStatus = false;
				}
			}
			if(document.getElementById('F1-rActionDueDateStatus0').checked) checkDueDateStatus = true;
			else
			{
				if(allActionResponses[i].dueDateStatus.indexOf(selectedDueDateStatus) != -1) checkDueDateStatus = true;
				else checkDueDateStatus = false;
			}
			if(document.getElementById('F1-rPhases0').checked) checkPhase = true;
			else
			{
				if(allActionResponses[i].touchpoints.indexOf(selectedPhase) != -1) checkPhase = true;
				else checkPhase = false;
			}
			if(document.getElementById('F1-rCategories0').checked) checkCategory = true;
			else
			{
				if(allActionResponses[i].categories.indexOf(selectedCategory) != -1) checkCategory = true;
				else checkCategory = false;
			}
			if(document.getElementById('F1-rFunctionalTeam0').checked) checkTeam = true;
			else
			{
				if((allActionResponses[i].functionalTeam != null) && (allActionResponses[i].functionalTeam.indexOf(selectedTeam) != -1)) checkTeam = true;
				else checkTeam = false;
			}
			if(document.getElementById('F1-rOwnership0').checked) checkOwnership = true;
			else
			{
				switch(selectedOwnership.toString())
					{
						case '1':
						{
							checkOwnership = false;
							for(j=0;j<listUserAccounts.length;j++)
								for(k=0;k<allActionResponses[i].accounts.split(';').length;k++)
									if(listUserAccounts[j] == allActionResponses[i].accounts.split(';')[k]) checkOwnership = true;
						};break;
						case '2':
						{
							checkOwnership = false;
							for(j=0;j<listUserParentAccounts.length;j++)
								for(k=0;k<allActionResponses[i].parentAccounts.split(';').length;k++)
									if(listUserParentAccounts[j] == allActionResponses[i].parentAccounts.split(';')[k]) checkOwnership = true;
						};break;
					}
			}

			if(checkLOB && checkRegion && checkDEEPN && checkPlant && checkActionType && checkStatus && checkDueDateStatus && checkPhase && checkCategory && checkTeam && checkOwnership)
			{
				if(searchWord.length == 0) listSelectedActions[listSelectedActions.length] = i;
				else
				{
					ck = false;
					if(document.getElementById('F1-rFreeSearch0').checked)
					{
						if(allActionResponses[i].accounts.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allActionResponses[i].parentAccounts.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allActionResponses[i].actionOwner.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allActionResponses[i].actionName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allActionResponses[i].sourcesNames.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allActionResponses[i].action.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;	
					}
					else
					{
						if((document.getElementById('F1-rFreeSearch1').checked) && (allActionResponses[i].accounts.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('F1-rFreeSearch2').checked) && (allActionResponses[i].parentAccounts.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('F1-rFreeSearch3').checked) && (allActionResponses[i].actionOwner.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('F1-rFreeSearch4').checked) && (allActionResponses[i].actionName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('F1-rFreeSearch5').checked) && (allActionResponses[i].sourcesNames.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('F1-rFreeSearch6').checked) && (allActionResponses[i].action.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
					}
					if(ck) listSelectedActions[listSelectedActions.length] = i;
				}	
			}
		}
		contentActionDetails(-1);
	}
function saveAction()
	{
		var i, aValue;
		transferAction.id = allActionResponses[currentAction].actionID;
		for(i=0;i<listActionType.length;i++)
			if(document.getElementById('F21-rActionType'+(i)).checked) 
			{
				transferAction.Type__c = listActionType[i];
				allActionResponses[currentAction].actionType = listActionType[i];
			}
		
		transferAction.Action__c = document.getElementById('F21-txtaActionObject').value;
		allActionResponses[currentAction].action = document.getElementById('F21-txtaActionObject').value;
		transferAction.Due_Date__c = new  Date(document.getElementById('F21-iDueDate').value);
		document.getElementById('F21-txtaActionObject').dueDate = Date.parse(transferAction.Due_Date__c);
		transferAction.Functional_Team__c = document.getElementById('F21-listFunctionalTeam').options[document.getElementById('F21-listFunctionalTeam').selectedIndex].value;
		allActionResponses[currentAction].functionalTeam = transferAction.Functional_Team__c;
		aValue = document.getElementById('F21-listActionOwners').options[document.getElementById('F21-listActionOwners').selectedIndex].value;
		
		if(document.getElementById('F21-listActionOwners').selectedIndex < 1) 
		{
			transferAction.Action_Owner__c = null;
			transferAction.Action_Owner__name = '';
			allActionResponses[currentAction].actionOwnerID = null;
			allActionResponses[currentAction].actionOwner = '';
		}
		else
		for(i=0;i<allHONcontacts.length;i++)
		{
			if(allHONcontacts[i].contactName == aValue) 
			{
				transferAction.Action_Owner__c = allHONcontacts[i].contactId;
				transferAction.Action_Owner__name = aValue;
				allActionResponses[currentAction].actionOwner = aValue;
				allActionResponses[currentAction].actionOwnerID = allHONcontacts[i].contactId;
			}
		}
		
		for(i=0;i<listActionStatus.length;i++)
			if(document.getElementById('F21-rStatus'+(i)).checked) 
			{
				transferAction.Status__c = listActionStatus[i];
				allActionResponses[currentAction].status = listActionStatus[i];
			}
			
		updateSFDCaction(transferAction);
	}

