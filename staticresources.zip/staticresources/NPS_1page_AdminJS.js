	
var objectiveOrientedTargets = [[]];//0: objective name; 1:value+':'+date;

function initializeAdmin()
	{
		rearrangeTargetValues();
		contentTargetValues();
		eventsAdmin();
		identifyNPSadmin();
	}

function contentTargetValues()
	{
		var i, j, content = '', anotherContent = '', aList = [];
		for(i=0;i<objectiveOrientedTargets.length;i++)
		{
			aList.length = 0;anotherContent = '';
			aList = objectiveOrientedTargets[i][2].split(';');
			for(j=0;j<aList.length;j++)
				anotherContent += aList[j].split(';')[0]+' ('+dateConverted(aList[j].split(';')[1])+'); ';
			content += '<p class="sArea pushOutBottom1">'+objectiveOrientedTargets[i][0]+'/'+objectiveOrientedTargets[i][1]+' --> '+anotherContent+'</p>';
		}
		
		document.getElementById('T1-sTargetContent').innerHTML = content;
	}
function eventsAdmin()
	{
		;
	}
function identifyNPSadmin()
	{
		if(adminNPS.name.length == 0) identifySFDCadminNPS(adminNPS.contactID);			
	}
function rearrangeTargetValues()
	{
		var i, j, ck, aList = [], aTable = [[]];
		objectiveOrientedTargets.length = 0;
		for(i=0;i<allNPSobjectives.length;i++)
		{
			ck = true;
			for(j=0;j<objectiveOrientedTargets.length;j++)
				if((objectiveOrientedTargets[j][0] == allNPSobjectives[i].type) && (objectiveOrientedTargets[j][1] == allNPSobjectives[i].objName))
				{
					ck = false;
					objectiveOrientedTargets[j][2] += ';'+allNPSobjectives[i].objValue+':'+allNPSobjectives[i].dateStart;
				}
			if(ck)				
				objectiveOrientedTargets[objectiveOrientedTargets.length] = [allNPSobjectives[i].type,
					allNPSobjectives[i].objName, allNPSobjectives[i].objValue+':'+allNPSobjectives[i].dateStart];
		}
		objectiveOrientedTargets.sort();
		for(i=0;i<objectiveOrientedTargets.length;i++)
		{
			aList.length = 0;
			aTable.length = 0;
			aList = objectiveOrientedTargets[i][2].split(';');
			for(j=0;j<aList.length;j++)
				aTable[aTable.length] = [aList[j].split(':')[0],aList[j].split(':')[1]];
			aTable.sort(function(a,b)
				{					
					if(a[2] > b[2]) return -1;
					if(a[2] < b[2]) return 1;
					else return 0;
			});	
			objectiveOrientedTargets[i][2] = '';
			for(j=0;j<aTable.length;j++)
				if(j==0) objectiveOrientedTargets[i][2] = aTable[j][0]+':'+aTable[j][1];
				else objectiveOrientedTargets[i][2] += ';'+aTable[j][0]+':'+aTable[j][1];
		}
	}
