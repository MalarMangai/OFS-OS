
// Created: Dan Dragu, 27.Nov.2017


var thisActionResponses = [];
	
var transferResponse = new Object();
	transferResponse = 
	{
		id: '',
		Customer_team_feedback__c: '',
		Touchpoints_EE__c: '',
		Touchpoints_NI__c: '',
		Categories__c: '',
		Actions_Checkbox__c: '',
		NPS_Closed_Date__c: ''
	}
var transferAction = new Object();
	transferAction = 
	{
		id: '',
		type__c: '',
		Action__c: '',
		Due_Date__c: '',
		Functional_Team__c: '',
		Action_Owner__c: '',
		Status__c: ''
	}
var transferActionResponse = new Object();
	transferActionResponse =
	{
		id: '',
		Action__c: '',
		Net_Promoter_Score__c: ''
	}

 var currentUser = new Object();
			currentUser = {id:'', name:'', email:''};

var listSelectedGoodTouchpoints = '', listSelectedBadTouchpoints = '', listSelectedPoints = '';
var listAssignedActions = '', listUnassignedActions = '';
var listStatusSimplified = ['ALL','Open','Completed'];
var listActionOwner = [];  

var noNewActions = 0, actionFromExisting = -1, actionFromSelected = -1;

var objSelFormActionType = newInputRadioOrCheckbox();
var objSelFormActionStatus = newInputRadioOrCheckbox();
var objSelFormCategories = newInputRadioOrCheckbox();
var objSelFormStatusSimplified = newInputRadioOrCheckbox();

var objFormActionContentUpgrd = newTextInputUpgraded();
		
function initializeForm()
	{
		objFormActionContentUpgrd.initialize('E22-txtaAction',250,'textarea','');
		noNewActions = 0; listAssignedActions = ''; listUnassignedActions = '';
		listSelectedGoodTouchpoints = ''; listSelectedBadTouchpoints = ''; listSelectedPoints = '';
		listActionOwner.length = 0;
		document.getElementById('E3-tHeaderDetails').innerHTML = '';
		document.getElementById('E1-sStatusOverview').style.display = 'block';
		document.getElementById('E1-sTouchpoints').style.display = 'none';
		document.getElementById('E2-sCategories').style.display = 'none';
		document.getElementById('E2-sActions').style.display = 'none';
		document.getElementById('E21-sAllActions').style.display = 'none';
		document.getElementById('E2-sSelectedActions').style.display = 'none';
		document.getElementById('E2-sNewAction').style.display = 'none';			

		contentCurrentResponse();
		contentTouchpoints();
		contentCategories();
		contentSelectionsForm();
		contentFunctionalTeam();
		contentSelectedTouchpoints();
		contentSelectedPointsImprove();
		
		eventsMainFormLeft();
		eventsMainFormRight();
		eventsTouchpoints();
		eventsCategories();
		eventsStepsExpantion();
		eventsFunctionalTeam();
		
		extractAssociatedActions();
		updateCurrentResponse();

		contentAllActions();
		contentSelectedActions();

		eventsAllActions();
		eventsSelectedActions();

		statusUpdate();
		//contentStatusOverview();
		
	}

function contentCurrentResponse()
	{
		// fulfill the static info in the top of the page related to the selected response 
		
		if(aResponse.score != 0)
		{
			document.getElementById('E0-txtScore').innerHTML = 'NPS: '+aResponse.score;
			if(aResponse.score > 8)	arrangeCSSclasses('E0-txtScore','groundWhite,groundHONred,groundLightYellow,groundGreen,colorWhite','0,0,0,1,1');
			else
			{
				if(aResponse.score > 6)	arrangeCSSclasses('E0-txtScore','groundWhite,groundHONred,groundLightYellow,groundGreen,colorWhite','0,0,1,0,0');
				else arrangeCSSclasses('E0-txtScore','groundWhite,groundHONred,groundLightYellow,groundGreen,colorWhite','0,1,0,0,1');
			}
		}
		else 
		{
			document.getElementById('E0-txtScore').innerHTML = 'VOC';
			arrangeCSSclasses('E0-txtScore','groundWhite,groundHONred,groundLightYellow,groundGreen,colorWhite','1,0,0,0,0');
		}
		document.getElementById('E0-txtCreatedDate').innerHTML = dateConverted(aResponse.dateCreated);
		document.getElementById('E0-sContactName').innerHTML = '<a href="https://hon-ts.my.salesforce.com/'+aResponse.contactID+'" target="_blank">'+aResponse.contactName+'</a>';
		document.getElementById('E0-txtContactDetails').innerHTML = aResponse.contactEmail+'; '+aResponse.contactPhone;
		document.getElementById('E0-txtAccountDetails').innerHTML = aResponse.account+'; '+aResponse.accountOwner+' (Account Owner)';
		document.getElementById('E12-txtComments_EE').innerHTML = aResponse.commentsEE;
		document.getElementById('E12-txtComments_NI').innerHTML = aResponse.commentsNI;
	}
function contentTouchpoints()
	{
		// fulfill all touchpoints as they are in SFDC (to allow further selection)
		var i, j, content = '', initialVisibility, initialDisplay, tab = [];
		content = '<table class="width100"><tbody class="diffRows tablePattern">';
		for(i=0;i<tbE2ESteps.length;i++)
		{
			if(tbE2ESteps[i][2] == '1') {initialDisplay = 'displayBlock';initialVisibility = 'visibilityFalse';}
			else {initialDisplay = 'displayNone';initialVisibility = 'visibilityTrue';}
			
			content += '<tr class="">'+
				'<td id="E1-stepName'+i+'" class="textTop textRight fontBold cursorPointer noWrap">'+
				'<span class="">'+tbE2ESteps[i][0]+'&nbsp;</span><span class="groundBlack colorWhite '+initialVisibility+'">&nbsp;+&nbsp;</span></td>'+
				'<td class="pushInTop05 pushInLeft05"><p id="E1-stepContent'+i+'" class="sArea '+initialDisplay+'">';				
			{
				tab.length = 0;
				tab = tbE2ESteps[i][1].split(';');
				for(j=0;j<tab.length;j++)
					content += '<span id="E1-tb'+i+'.'+j+'" class="sAreaSmall cursorPointer pushOutRight1 pushOutBottom05 mOver1 inputUnselected">'+tab[j]+'</span>';
			}				
			content += '</p></td></tr>';
		}
		content += '</tbody></table>';
		document.getElementById('E1-sTouchpoints').innerHTML = content;
	}
function contentCategories()
	{
		// fulfill all points to improve as they are in SFDC (to allow further selection)
		var i, j, content = '', initialVisibility, tab = [];
		content = '<table class="width100"><tbody class="diffRows">';
		for(i=0;i<tbCategories.length;i++)
		{				
			content += '<tr class="">'+
				'<td id="E2-category'+i+'" class="textTop textRight fontBold pushIn05 pushInRight05 pushInLeft05 cursorPointer width20">'+
				'<span class="sAreaSmall floatRight">'+tbCategories[i][0]+'&nbsp;</span></td>'+
				'<td class="pushInLeft05"><p id="E2-stepContent'+i+'" class="sArea displayBlock">';
			
			tab.length = 0;
			tab = tbCategories[i][1].split(';');
			for(j=0;j<tab.length;j++)
				content += '<span id="E2-tb'+i+'.'+j+'" class="sAreaSmall cursorPointer pushOutRight1 pushOutBottom05 mOver1 inputUnselected">'+tab[j]+'</span>';
			
			content += '</p></td></tr>';
		}
		content += '</tbody></table>';
		document.getElementById('E2-sCategories').innerHTML = content;
	}
function contentSelectionsForm()
	{
		// initialize the object associated with the filters included in the "Form" page
		var i, aTab = [];
		
		objSelFormActionType.initialize('E22-rActionType','radio',listActionType,callbackNone,'inputSelected','inputUnselected','0');
		objSelFormActionStatus.initialize('E22-rActionStatus','radio',listActionStatus,callbackNone,'inputSelected','inputUnselected','0');
		
		objSelFormStatusSimplified.initialize('E2-rStatusSimplified','radio',listStatusSimplified,callbackSelForm,'inputSelected','inputUnselected','0');

		aTab.length = 0; for(i=1;i<listCategories.length;i++) aTab[aTab.length] = listCategories[i];
		objSelFormCategories.initialize('E2-ckCategories','checkbox',aTab,callbackSelForm,'inputSelected','inputUnselected','');
	}
function contentFunctionalTeam()
	{
		// fulfill the dropdown component with the values of functionalTeam
		var i, content = '';
		listFunctionalTeam.sort();
		for(i=1;i<listFunctionalTeam.length;i++)
			content += '<option value="'+listFunctionalTeam[i]+'">'+listFunctionalTeam[i]+'</option>';
		if(document.getElementById('E22-listFunctionalTeam')) document.getElementById('E22-listFunctionalTeam').innerHTML = content; // "if()" due SFDC initial rendering
		for(i=0;i<listFunctionalTeam.length;i++)
			if(listFunctionalTeam[i] == 'Sales') document.getElementById('E22-listFunctionalTeam').options[i].selected = true;
		fulfillActionOwnersList('Sales','E22-listActionOwners');
	}
function contentSelectedTouchpoints()
	{
		// apply css classes to those touchpoints selected for the current response;
		// display the name of the phases and touchpoints in the left side of the desktop;

		var i, j, tab = [], touchpoint, contentGood = '', contentBad = '', ck;
		
		listSelectedGoodTouchpoints = '';
		listSelectedBadTouchpoints = '';

		for(i=0;i<tbE2ESteps.length;i++)
		{
			j = 0; ck = false;
			while(document.getElementById('E1-tb'+i+'.'+j))
			{
				if(document.getElementById('E1-tb'+i+'.'+j).classList.contains('goodFeedback'))
				{
					tab = tbE2ESteps[i][1].split(';');
					touchpoint = tbE2ESteps[i][0]+' / ' + tab[j];
					contentGood += '<li>'+touchpoint+'</li>';
					if(listSelectedGoodTouchpoints == '') listSelectedGoodTouchpoints = i+','+j; else listSelectedGoodTouchpoints += ';'+i+','+j;
					ck = true;
				}
				if(document.getElementById('E1-tb'+i+'.'+j).classList.contains('badFeedback'))
				{
					tab = tbE2ESteps[i][1].split(';');
					touchpoint = tbE2ESteps[i][0]+' / ' + tab[j];
					contentBad += '<li>'+touchpoint+'</li>';
					if(listSelectedBadTouchpoints == '') listSelectedBadTouchpoints = i+','+j; else listSelectedBadTouchpoints += ';'+i+','+j;
					ck = true;
				}
				j++;	
			}
			if(ck || (tbE2ESteps[i][0] == 'Design')) 
			{
				arrangeCSSclasses('E1-stepContent'+i,'displayBlock,displayNone','1,0');
				document.getElementById('E1-stepName'+i).innerHTML = '<span class="">'+tbE2ESteps[i][0]+'&nbsp;</span><span class="groundBlack colorWhite visibilityFalse">&nbsp;+&nbsp;</span>';
			}
			else
			{
				arrangeCSSclasses('E1-stepContent'+i,'displayBlock,displayNone','0,1');
				document.getElementById('E1-stepName'+i).innerHTML = '<span class="">'+tbE2ESteps[i][0]+'&nbsp;</span><span class="groundBlack colorWhite visibilityTrue">&nbsp;+&nbsp;</span>';
			}	
		}
		document.getElementById('E12-sGoodTouchpoints').innerHTML = contentGood;
		document.getElementById('E12-sBadTouchpoints').innerHTML = contentBad;

		statusUpdate();
	}
function contentSelectedPointsImprove()
	{
		// apply css classes to those points to improve selected for the current response;
		// display the name of the categories and points to improve s in the left side of the desktop;
		var i, j, tab = [], pointImprove, content = '', aStar = '&nbsp;<i class="fa fa-star" aria-hidden="true"></i>';
		
		listSelectedPoints = '';
		for(i=0;i<tbCategories.length;i++)
		{
			j = 0;
			while(document.getElementById('E2-tb'+i+'.'+j))
			{					
				if(document.getElementById('E2-tb'+i+'.'+j).classList.contains('inputSelected'))
				{
					tab = tbCategories[i][1].split(';');
					pointImprove = tbCategories[i][0]+' / ' + tab[j];
					content += '<li>'+pointImprove+'</li>';	
					if(listSelectedPoints == '') listSelectedPoints = i+','+j; else listSelectedPoints += ';'+i+','+j;
				}
				j++;
			}
		}
		document.getElementById('E12-sCategoriesSelected').innerHTML = content;
		statusUpdate();
	}

function contentSelectedActions()
	{
		// build the table with the all actions assigned to the current response, as they are stored in thisActionResponses ;
		var i, j, contentTable = '', content = '', contentCategories = '', tabCategories = [], tab1 = [], tab2 = [];

		for(i=0;i<thisActionResponses.length;i++)
		{
			contentCategories = thisActionResponses[i].categoriesExt;
			contentTable += '<tr>'+
				'<td>'+(i+1)+'</td>'+
				'<td class="preserveLines">'+thisActionResponses[i].action+'</td>'+
				'<td>'+dateConverted(thisActionResponses[i].dueDate) +'</td>'+
				'<td>'+thisActionResponses[i].functionalTeam+'</td>'+
				'<td>'+contentCategories+'</td>'+
				'<td id="E3-tb'+i+'" class="aLink">'+thisActionResponses[i].actionName+'</td>'+
				'<td>'+thisActionResponses[i].status+'</td>'+
			'</tr>';
			content += '<li>'+thisActionResponses[i].action+
				'<br/><span class="fontSmall fontBold">'+thisActionResponses[i].actionOwner+', Due: '+dateConverted(thisActionResponses[i].dueDate)+'</span>'+
				'</li>';
		}
		
		document.getElementById('E23-tblSelectedActions').innerHTML = contentTable;
		document.getElementById('E12-sActionsSelected').innerHTML = content;
		switch(thisActionResponses.length)
		{
			case '0': document.getElementById('E23-txtNoActionsAssigned').innerHTML = 'NO'; break;
			default: document.getElementById('E23-txtNoActionsAssigned').innerHTML = thisActionResponses.length;
		}
		document.getElementById('E23-txtNoActionsAssigned').innerHTML = thisActionResponses.length;
		statusUpdate();
	}
function contentAllActions()
	{
		var i, j, k, content = '' , status, contentCategories, tabCategoriesSelected = [];
		var statusSelected, aTab = [], ckCategories, ckStatusSimplified, counter = 1, alreadySelected;
		
		i = 0;
		while(document.getElementById('E2-rStatusSimplified'+i))
		{
			if(document.getElementById('E2-rStatusSimplified'+i).checked) statusSelected = i.toString();				
			i++;
		}
		tabCategoriesSelected.length = 0;
		i = 0;
		while(document.getElementById('E2-ckCategories'+i))
		{
			if(document.getElementById('E2-ckCategories'+i).checked) tabCategoriesSelected[tabCategoriesSelected.length] = listCategories[i+1];				
			i++;
		}
		
		for(i=0;i<allActionResponses.length;i++)
		{
			ckStatusSimplified = false;
			switch(statusSelected)
			{
				case '0': ckStatusSimplified = true;break;
				case '1': if((allActionResponses[i].status != 'Withdrawn') && (allActionResponses[i].status != 'Completed')) ckStatusSimplified = true; break;
				case '2': if((allActionResponses[i].status == 'Withdrawn') || (allActionResponses[i].status == 'Completed')) ckStatusSimplified = true; break;
			}
			ckCategories = false;
			if(tabCategoriesSelected.length > 0)
			{
				if(allActionResponses[i].categories.length != 0)
				{
					// make a list with categories for each action
					
					aTab.length = 0;
					aTab = allActionResponses[i].categories.split(';');
					for(j=0;j<aTab.length;j++)
						for(k=0;k<tabCategoriesSelected.length;k++)
							if(tabCategoriesSelected[k] == aTab[j].split('___')[0]) ckCategories = true;
				}
				else ckCategories = true;	
			}else ckCategories = true;
			
			if(ckStatusSimplified && ckCategories)
			{
				if((allActionResponses[i].status == 'Withdrawn') || (allActionResponses[i].status == 'Completed')) status = 'Completed'; else status = 'Open';
				//contentCategories = convertIndexToString(allActionResponses[i].categories,tbCategories,'/');
				contentCategories = allActionResponses[i].categoriesExt;
				if(allActionResponses[i].sourcesIDs.indexOf(aResponse.responseID) == -1) alreadySelected = ' id="E4-tb'+i+'" class="aLink"';
				else alreadySelected = ' title="Action already selected for current response."';
				content += '<tr>'+
				'<td>'+counter+'</td>'+
				'<td class="preserveLines">'+allActionResponses[i].action+'</td>'+
				'<td>'+dateConverted(allActionResponses[i].dueDate)+'</td>'+
				'<td>'+allActionResponses[i].functionalTeam+'</td>'+
				'<td>'+contentCategories+'</td>'+
				'<td'+alreadySelected+'>'+allActionResponses[i].actionName+'</td>'+
				'<td>'+status+'</td>'+
				'</tr>';
				counter++;
			}
		}
		document.getElementById('E23-tblAllActions').innerHTML = content;
	}
function contentActionOwnerList(tagID)
	{
		// fulfill the dropdown component with the names of the action owners for a selected funtional team;
		var i, content = '';
		
		for(i=0;i<listActionOwner.length;i++)
			content += '<option value="'+listActionOwner[i]+'">'+listActionOwner[i]+'</option>';
		
		document.getElementById(tagID).innerHTML = content; // "if()" due SFDC initial rendering
	}
function contentStatusOverview()
	{
		document.getElementById('E3-tHeaderDetails').innerHTML = 'Hi '+currentUser.name.substr(0,currentUser.name.indexOf(' '));


	}

function eventsMainFormLeft()
	{
		// attach events to the left-side content (buttons, checkboxes)
		var i, ck, ckFunctionalTeam, parentTag;
	
		document.getElementById('E0-taTeamFeedback').onchange = function()
			{
				if(document.getElementById('E0-taTeamFeedback').value != '') document.getElementById('E2-ckMoreFeedback').checked = false;
				statusUpdate();
			}
		document.getElementById('E2-ckMoreFeedback').onclick = function()
			{
				if(document.getElementById('E2-ckMoreFeedback').checked) document.getElementById('E0-taTeamFeedback').value = '';
				statusUpdate();
			}
		document.getElementById('E2-btnTouchpointsGood').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '2. Select touchpoints which <span class="colorGreen fontBigger fontBold">exceeded expectations</span>';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'block';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'none';
				statusUpdate();
			}
		document.getElementById('E2-ckTouchpointsGood').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '&nbsp;';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'none';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'none';
				if(document.getElementById('E2-ckTouchpointsGood').checked)
				{
					unselectTouchpoints('good');
					document.getElementById('E12-sGoodTouchpoints').innerHTML = '';
					listSelectedGoodTouchpoints = '';
				}
				statusUpdate();
			}
		document.getElementById('E2-btnTouchpointsBad').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '3. Select touchpoints which <span class="colorHONred fontBigger fontBold">need improvement</span>';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'block';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'none';
				statusUpdate();
			}
		document.getElementById('E2-ckTouchpointsBad').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '&nbsp;';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'none';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'none';
				if(document.getElementById('E2-ckTouchpointsBad').checked)
				{
					unselectTouchpoints('bad');
					document.getElementById('E12-sBadTouchpoints').innerHTML = '';
					listSelectedBadTouchpoints = '';
					document.getElementById('E2-ckCategories').checked = true;
					unselectPointsImprove();
					document.getElementById('E12-sCategoriesSelected').innerHTML = '';
					listSelectedPoints = '';
					document.getElementById('E2-ckActions').checked = true;
					document.getElementById('E2-btnActions').disabled = false;
					thisActionResponses.length = 0;
					noNewActions = 0;
					contentSelectedActions();
				}
				statusUpdate();
			}
		document.getElementById('E2-btnCategories').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '4. Select categories and points to improve';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'none';
				document.getElementById('E2-sCategories').style.display = 'block';
				document.getElementById('E2-sActions').style.display = 'none';
				statusUpdate();
			}
		document.getElementById('E2-ckCategories').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '&nbsp;';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'none';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'none';
				if(document.getElementById('E2-ckCategories').checked)
				{
					unselectPointsImprove();
					document.getElementById('E12-sCategoriesSelected').innerHTML = '';
					listSelectedPoints = '';
					document.getElementById('E2-ckActions').checked = true;
					document.getElementById('E2-sSelectedActions').style.display = 'none';
					document.getElementById('E2-btnActions').disabled = false;						
					thisActionResponses.length = 0;
					noNewActions = 0;
					contentSelectedActions();
				}
				statusUpdate();	
			}
		document.getElementById('E2-btnActions').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '5. Select follow up actions';
				document.getElementById('E1-sStatusOverview').style.display = 'none';
				document.getElementById('E1-sTouchpoints').style.display = 'none';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'block';
				document.getElementById('E21-btnAllActions').disabled = false;
				document.getElementById('E21-btnNewAction').disabled = false;
				document.getElementById('E21-btnViewActions').disabled = true;
				arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','0,1');
				arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');

				document.getElementById('E21-sAllActions').style.display = 'none';
				document.getElementById('E2-sSelectedActions').style.display = 'block';
				document.getElementById('E2-sNewAction').style.display = 'none';
				statusUpdate();
			}
		document.getElementById('E2-ckActions').onclick = function()
			{
				document.getElementById('E3-tHeaderDetails').innerHTML = '&nbsp;';
				document.getElementById('E1-sTouchpoints').style.display = 'none';
				document.getElementById('E2-sCategories').style.display = 'none';
				document.getElementById('E2-sActions').style.display = 'none';
				if(document.getElementById('E2-ckActions').checked)
				{	
					document.getElementById('E2-btnActions').disabled = false;
					document.getElementById('E12-sActionsSelected').innerHTML = '';
					thisActionResponses.length = 0;
					noNewActions = 0;
					contentSelectedActions();
				}
				statusUpdate();	
			}	
	
		document.getElementById('E2-btnCancelAll').onclick = function(){goToFormPage();};
		document.getElementById('E2-btnSaveAll').onclick = function() {saveAllChanges();};
			
	}
function eventsMainFormRight()
	{
		// attach events to the right-side content (buttons, checkboxes, tables)
		var i, ck, ckFunctionalTeam, parentTag;

		document.getElementById('E21-btnViewActions').onclick = function()
			{
				document.getElementById('E21-sAllActions').style.display = 'none';
				document.getElementById('E2-sSelectedActions').style.display = 'block';
				document.getElementById('E2-sNewAction').style.display = 'none';
				document.getElementById('E21-btnAllActions').disabled = false;
				document.getElementById('E21-btnNewAction').disabled = false;
				document.getElementById('E21-btnViewActions').disabled = true;
				arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','0,1');
				arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
			}
		document.getElementById('E21-btnAllActions').onclick = function()
			{
				contentAllActions();
				eventsAllActions();
				document.getElementById('E21-sAllActions').style.display = 'block';
				document.getElementById('E2-sSelectedActions').style.display = 'none';
				document.getElementById('E2-sNewAction').style.display = 'none';
				document.getElementById('E21-btnAllActions').disabled = true;
				document.getElementById('E21-btnNewAction').disabled = false;
				document.getElementById('E21-btnViewActions').disabled = false;	
				arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','0,1');
				arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
			}
		document.getElementById('E21-btnNewAction').onclick = function()
			{
				document.getElementById('E21-sAllActions').style.display = 'none';
				document.getElementById('E2-sSelectedActions').style.display = 'none';
				document.getElementById('E2-sNewAction').style.display = 'block';
				document.getElementById('E21-btnAllActions').disabled = false;
				document.getElementById('E21-btnNewAction').disabled = true;
				document.getElementById('E21-btnViewActions').disabled = false;
				arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','0,1');

				document.getElementById('E22-hActionDetails').innerHTML = 'Create new action';
				
				document.getElementById('E22-btnSave').innerHTML = 'Create';
				document.getElementById('E22-btnSave').style.display = 'block';
				document.getElementById('E22-btnDelete').style.display = 'none';
				document.getElementById('E22-btnModify').style.display = 'none';
				document.getElementById('E22-btnAssign').style.display = 'none';

				anActionResponse.actionID = '';
				anActionResponse.actionName = getActionName()+'new'+(noNewActions+1);
				anActionResponse.actionType = listActionType[0];
				anActionResponse.action = '';
				anActionResponse.functionalTeam = document.getElementById('E22-listFunctionalTeam').options[0].value;
				anActionResponse.actionOwnerID = '';
				anActionResponse.actionOwner = '';
				anActionResponse.actionOwnerEmail = '';
				anActionResponse.dueDate =  today+(7*24*3600*1000);
				anActionResponse.status = listActionStatus[0];
				anActionResponse.touchpoints = convertIndexToString(listSelectedBadTouchpoints,tbE2ESteps,'___');
				anActionResponse.categories = convertIndexToString(listSelectedPoints,tbCategories,'___');
				anActionResponse.touchpointsExt = convertIndexToString(listSelectedBadTouchpoints,tbE2ESteps,'___');
				anActionResponse.categoriesExt = convertIndexToString(listSelectedPoints,tbCategories,'___');
				anActionResponse.sourcesIDs = aResponse.responseID;
				anActionResponse.sourcesNames = aResponse.responseName;
				anActionResponse.accounts = aResponse.account;

				actionFromExisting = -1; actionFromSelected = -1;
				displayAction('editAll');
			}
		
		document.getElementById('E22-btnSave').onclick = function()
			{
				ck = true;
				if(document.getElementById('E22-txtaActionObject').value == '')
				{
					ck = false;
					arrangeCSSclasses('E22-txtaActionLabel','colorHONred','1');
				} else arrangeCSSclasses('E22-txtaActionLabel','colorHONred','0');
				if(document.getElementById('E22-txtTouchpoints').innerHTML == '')
				{
					ck = false;
					arrangeCSSclasses('E22-txtTouchpointsLabel','colorHONred','1');
				} else arrangeCSSclasses('E22-txtTouchpointsLabel','colorHONred','0');
				if(document.getElementById('E22-txtCategories').innerHTML == '')
				{
					ck = false;
					arrangeCSSclasses('E22-txtCategoriesLabel','colorHONred','1');
				} else arrangeCSSclasses('E22-txtCategoriesLabel','colorHONred','0');
				if(ck)
				{
					document.getElementById('E21-sAllActions').style.display = 'none';
					document.getElementById('E2-sSelectedActions').style.display = 'block';
					document.getElementById('E2-sNewAction').style.display = 'none';
					document.getElementById('E21-btnAllActions').disabled = false;
					document.getElementById('E21-btnNewAction').disabled = false;
					document.getElementById('E21-btnViewActions').disabled = true;
					arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','0,1');
					arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
					arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
					
					addNewAction();
					contentSelectedActions();
					eventsSelectedActions();
				}
			}
		document.getElementById('E22-btnCancel').onclick = function()
			{
				if(actionFromExisting == -1)
				{
					document.getElementById('E21-sAllActions').style.display = 'none';
					document.getElementById('E2-sSelectedActions').style.display = 'block';
					document.getElementById('E2-sNewAction').style.display = 'none';
					document.getElementById('E21-btnAllActions').disabled = false;
					document.getElementById('E21-btnNewAction').disabled = false;
					document.getElementById('E21-btnViewActions').disabled = true;
					arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','0,1');
					arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
					arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
				}					
				else
				{
					document.getElementById('E21-sAllActions').style.display = 'block';
					document.getElementById('E2-sSelectedActions').style.display = 'none';
					document.getElementById('E2-sNewAction').style.display = 'none';
					document.getElementById('E21-btnAllActions').disabled = true;
					document.getElementById('E21-btnNewAction').disabled = false;
					document.getElementById('E21-btnViewActions').disabled = false;
					arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','1,0');
					arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','0,1');
					arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
				}
			}
		document.getElementById('E22-btnDelete').onclick = function()
			{
				if(listUnassignedActions == '') listUnassignedActions = thisActionResponses[actionFromSelected].actionID;
				else listUnassignedActions += ';' + thisActionResponses[actionFromSelected].actionID;
				deleteAction();
				contentSelectedActions();
				eventsSelectedActions();
				document.getElementById('E21-sAllActions').style.display = 'none';
				document.getElementById('E2-sSelectedActions').style.display = 'block';
				document.getElementById('E2-sNewAction').style.display = 'none';
				document.getElementById('E21-btnAllActions').disabled = false;
				document.getElementById('E21-btnNewAction').disabled = false;
				document.getElementById('E21-btnViewActions').disabled = true;
				arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','0,1');
				arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
			}
				
		document.getElementById('E22-btnModify').onclick = function()
			{
				document.getElementById('E21-sAllActions').style.display = 'none';
				document.getElementById('E2-sSelectedActions').style.display = 'none';
				document.getElementById('E2-sNewAction').style.display = 'block';
				document.getElementById('E21-btnAllActions').disabled = false;
				document.getElementById('E21-btnNewAction').disabled = true;
				document.getElementById('E21-btnViewActions').disabled = false;
				arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
				arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','0,1');

				document.getElementById('E22-hActionDetails').innerHTML = 'Create new action';
				
				document.getElementById('E22-btnSave').innerHTML = 'Create';
				document.getElementById('E22-btnSave').style.display = 'block';
				document.getElementById('E22-btnDelete').style.display = 'none';
				document.getElementById('E22-btnModify').style.display = 'none';
				document.getElementById('E22-btnAssign').style.display = 'none';
				
				anActionResponse.actionID = '';
				anActionResponse.actionName = getActionName()+'new'+(noNewActions+1);
				anActionResponse.actionType = allActionResponses[actionFromExisting].actionType;
				anActionResponse.action = allActionResponses[actionFromExisting].action;
				anActionResponse.functionalTeam = allActionResponses[actionFromExisting].functionalTeam;
				anActionResponse.actionOwnerID = allActionResponses[actionFromExisting].actionOwnerID;
				anActionResponse.actionOwner = allActionResponses[actionFromExisting].actionOwner;
				anActionResponse.actionOwnerEmail = allActionResponses[actionFromExisting].actionOwnerEmail;
				anActionResponse.dueDate =  today+(7*24*3600*1000);
				anActionResponse.status = listActionStatus[0];
				anActionResponse.touchpointsExt = convertIndexToString(listSelectedBadTouchpoints,tbE2ESteps,'___');
				anActionResponse.categoriesExt = convertIndexToString(listSelectedPoints,tbCategories,'___');
				anActionResponse.sourcesIDs = aResponse.responseID;
				anActionResponse.sourcesNames = aResponse.responseName;
				anActionResponse.accounts = aResponse.account;

				actionFromExisting = -1; actionFromSelected = -1;
				displayAction('editAll');
			}
		document.getElementById('E22-btnAssign').onclick = function()
			{
				if((listSelectedBadTouchpoints == '') || (listSelectedPoints == '')) 
				{
					document.getElementById('E22-txtMessages').innerHTML = 'You need to add touchpoints which needs improvements, or points to improve, or both !';
					arrangeCSSclasses('E22-txtMessages','colorHONred','1');
				}
				else
				{
					document.getElementById('E22-txtMessages').innerHTML = '&nbsp;';
					arrangeCSSclasses('E22-txtMessages','colorHONred,colorGreen','0,0');
					anActionResponse = cloneThis(allActionResponses[actionFromExisting]);
					anActionResponse.sourcesIDs += '; '+ aResponse.responseID;
					anActionResponse.sourcesNames += '; '+ aResponse.responseName;
					if(anActionResponse.accounts.indexOf(aResponse.account) == -1) 
						anActionResponse.accounts += '; '+ aResponse.account;

					//allActionResponses[actionFromExisting].sourcesIDs += '; '+ aResponse.responseID;
					//allActionResponses[actionFromExisting].sourcesNames += '; '+ aResponse.responseName;
					//if(allActionResponses[actionFromExisting].accounts.indexOf(aResponse.account) == -1) 
					//	allActionResponses[actionFromExisting].accounts += '; '+ aResponse.account;
					var tab1 = [], tab2 = [], i, j;
					
					tab1.length = 0; tab2.length = 0;
					tab1 = convertIndexToString(listSelectedBadTouchpoints,tbE2ESteps,'___').split(';');
					tab2 = anActionResponse.touchpointsExt.split(';');
					for(i=0;i<tab1.length;i++)
					{
						ck = true;
						for(j=0;j<tab2.length;j++) if(tab1[i] == tab2[j]) ck = false;
						if(ck) anActionResponse.touchpointsExt += ';' + tab1[i];
					}
					tab1.length = 0; tab2.length = 0;
					tab1 = convertIndexToString(listSelectedPoints,tbCategories,'___').split(';');
					tab2 = anActionResponse.categoriesExt.split(';');
					for(i=0;i<tab1.length;i++)
					{
						ck = true;
						for(j=0;j<tab2.length;j++) if(tab1[i] == tab2[j]) ck = false;
						if(ck) anActionResponse.categories += ';' + tab1[i];
					}
					if(listAssignedActions == '') listAssignedActions = anActionResponse.actionID;
					else listAssignedActions += ';' + anActionResponse.actionID;

					thisActionResponses[thisActionResponses.length] = cloneThis(anActionResponse);
					
					contentSelectedActions();
					eventsSelectedActions();
					
					document.getElementById('E21-sAllActions').style.display = 'none';
					document.getElementById('E2-sSelectedActions').style.display = 'block';					
					document.getElementById('E2-sNewAction').style.display = 'none';
					document.getElementById('E21-btnAllActions').disabled = false;
					document.getElementById('E21-btnNewAction').disabled = false;
					document.getElementById('E21-btnViewActions').disabled = true;
					arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','0,1');
					arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
					arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
				}
			}
		document.getElementById('E22-iDueDate').onchange = function()
			{
				document.getElementById('E22-iDueDate').value = dateConverted(Date.parse(document.getElementById('E22-iDueDate').value));
			}
	}

function eventsStepsExpantion()
	{
		var i;
		for(i=0;i<tbE2ESteps.length;i++)
			if(document.getElementById('E1-stepName'+i)) document.getElementById('E1-stepName'+i).onclick = function(){actOnSteps(this.id);};

	}
function eventsTouchpoints()
	{
		var i,j;
		for(i=0;i<tbE2ESteps.length;i++)
		{
			j = 0;
			while(document.getElementById('E1-tb'+i+'.'+j))
			{
				document.getElementById('E1-tb'+i+'.'+j).onclick = function() {selectTouchPoint(this.id,'');};
				j++;	
			}
		}
	}
function eventsCategories()
	{
		var i,j;
		for(i=0;i<tbCategories.length;i++)
		{
			j = 0;
			while(document.getElementById('E2-tb'+i+'.'+j))
			{
				document.getElementById('E2-tb'+i+'.'+j).onclick = function() {selectCategories(this.id);};
				j++;	
			}
		}
	}
function eventsSelectedActions()
	{
		var i;
		for(i=0;i<thisActionResponses.length;i++)
			document.getElementById('E3-tb'+i).onclick = function() {viewActionSelectedDetails(this.id);};
	}
function eventsAllActions()
	{
		var i = 0;
		for(i=0;i<allActionResponses.length;i++)
			if(document.getElementById('E4-tb'+i)) document.getElementById('E4-tb'+i).onclick = function() {viewActionSelectedAssignment(this.id);};
	}
function eventsFunctionalTeam()
	{
		document.getElementById('E22-listFunctionalTeam').onchange = function() 
			{
				fulfillActionOwnersList(document.getElementById('E22-listFunctionalTeam').options[document.getElementById('E22-listFunctionalTeam').selectedIndex].value,'E22-listActionOwners');
			}
	}

function extractAssociatedActions()
	{
		var i;
		
		thisActionResponses.length = 0;
		for(i=0;i<allActionResponses.length;i++)
			if(allActionResponses[i].sourcesIDs.indexOf(aResponse.responseID) != -1) 
				thisActionResponses[thisActionResponses.length] = cloneThis(allActionResponses[i]);
	}
function updateCurrentResponse()
	{
		// fulfills the front-end associated fields with data related to current selected response;
		var i;
		
		document.getElementById('E12-sGoodTouchpoints').innerHTML = '';
		document.getElementById('E12-sBadTouchpoints').innerHTML = '';
		document.getElementById('E12-sCategoriesSelected').innerHTML = '';
		document.getElementById('E12-sActionsSelected').innerHTML = '';

		/*if(aResponse.score != 0)
		{
			if(aResponse.score > 8)	arrangeCSSclasses('E0-txtScore','groundGreen,colorWhite','1,1');
			else
			{
				if(aResponse.score > 6)	arrangeCSSclasses('E0-txtScore','groundLightYellow','1');
				else arrangeCSSclasses('E0-txtScore','groundHONred,colorWhite','1,1');
			}
		}
		else arrangeCSSclasses('E0-txtScore','groundWhite,colorBlack','1,1');*/

		if(aResponse.moreFeedback == tbConst.NoNeedForMoreFeedback)
		{
			document.getElementById('E2-ckMoreFeedback').checked = true;
			document.getElementById('E0-taTeamFeedback').value = '';
		}
		else
		{
			document.getElementById('E2-ckMoreFeedback').checked = false;
			document.getElementById('E0-taTeamFeedback').value = aResponse.moreFeedback;
		}
		if(aResponse.touchpointsEE != null) convertStringToIndex(aResponse.touchpointsEE,tbE2ESteps,'good');
		if(aResponse.touchpointsNI != null) convertStringToIndex(aResponse.touchpointsNI,tbE2ESteps,'bad');
		if(aResponse.categories != null) convertStringToIndex(aResponse.categories,tbCategories,'category');
		if(aResponse.actionsCheck == '1') document.getElementById('E2-ckActions').checked = true;
			else document.getElementById('E2-ckActions').checked = false;

		for(i=0;i<allActionResponses.length;i++)
			if(allActionResponses[i].responseID == aResponse.responseID)
			{
				if(aResponse.listActionsID == '') aResponse.listActionsID = allActionResponses[i].actionID;
				else aResponse.listActionsID += ';'+allActionResponses[i].actionID;
			}
	}

function convertStringToIndex(aString, aTab, param)
	{
		var i, tab = [];
		
		function forEachSelection(anotherString, aTab, param)
			{
				
				var j, k, anotherTab = [], line = [], localBig, localSmall;
				line.length = 0;
				line = anotherString.split('___');
				for(j=0;j<aTab.length;j++)
				{
					if(aTab[j][0] == line[0]) 
					{
						localBig = j;
						anotherTab.length = 0;
						anotherTab = aTab[j][1].split(';');
						for(k=0;k<anotherTab.length;k++)
							if(anotherTab[k] == line[1]) 
								{
									localSmall = k;
									switch(param)
									{
										case 'good': {selectTouchPoint('E1-tb'+localBig+'.'+localSmall,'good');}break;
										case 'bad':  {selectTouchPoint('E1-tb'+localBig+'.'+localSmall,'bad');}break;
										case 'category': {selectCategories('E2-tb'+localBig+'.'+localSmall);}break;
									}
								}
					}
				}
			}

		if(aString.indexOf('NOT ENOUGH INFO') == -1)
		{
			if(aString.indexOf(';') != -1)
			{
				tab.length = 0;
				tab = aString.split(';');
				for(i=0;i<tab.length;i++)
					forEachSelection(tab[i], aTab, param);
			}
			else forEachSelection(aString, aTab, param); 
		}
		else 
		{
			switch(param)
			{
				case 'good': {document.getElementById('E2-ckTouchpointsGood').checked = 'true'; listSelectedGoodTouchpoints = '';};break;
				case 'bad': {document.getElementById('E2-ckTouchpointsBad').checked = 'true'; listSelectedBadTouchpoints = '';}break;
				case 'category': {document.getElementById('E2-ckCategories').checked = 'true';}break;
			}
		}
	}
function convertIndexToString(aString, refTable, ref)
	{
		var i, content = '', tab = [], tab1 = [], tab2 = [];
		
		if(aString.length != '')
		{
			tab.length = '';
			tab = aString.split(';');
			for(i=0;i<tab.length;i++)
			{
				tab1.length = 0;
				tab1 = tab[i].split(',');
				tab2.length = 0;
				tab2 = refTable[tab1[0]][1].split(';');
				if(ref == '/') content += '<li>'+refTable[tab1[0]][0]+' / '+tab2[tab1[1]]+'</li>';
				else content += refTable[tab1[0]][0]+'___'+tab2[tab1[1]]+';';
			}	
		}
		return content;
	}

function useCleanResponse()
	{
		aResponse.responseID = '';
		aResponse.responseName = '';
		aResponse.dateCreated = 0;
		aResponse.dateClosed = 0;
		aResponse.daysOpen = '';
		aResponse.score = 0;
		aResponse.commentsEE = '';
		aResponse.commentsNI = '';
		aResponse.touchpointsEE = '';
		aResponse.touchpointsNI = '';
		aResponse.categories = '';	
		aResponse.actionsCheck = '';
		aResponse.contactID = '';
		aResponse.contactName = '';
		aResponse.contactEmail = '';
		aResponse.contactPhone = '';
		aResponse.contactDEEPN = '';
		aResponse.contactType = '';
		aResponse.contactTouchpoints = '';
		aResponse.LOB = '';
		aResponse.accountID = '';
		aResponse.account = '';
		aResponse.accountOwnerID = '';
		aResponse.accountOwner = '';
		aResponse.parentAccount = '';
		aResponse.parentAccountOwnerID = '';
		aResponse.parentAccountOwner = '';
		aResponse.region = '';
		aResponse.moreFEEDback = '';
		aResponse.statusFeedback = '';
		aResponse.statusTouchpoints = '';
		aResponse.statusCategories = '';
		aResponse.statusActions = '';
		aResponse.listActionsID = '';
		aResponse.listActionsName = '';
		thisActionResponses.length = 0;
	}

function saveAllChanges()
	{
		var i, j, k, contentToUpload, tab1 = [], tab2 = [], aTab = [], anIndex, counter1, counter2, checkClose = 0, tabReturned = [], actionResponseID;
			
				transferResponse.id = aResponse.responseID;
			// response update
				transferResponse.NPS_Closed_Date__c = new Date(aResponse.dateClosed);
				
				//save more feedback
				if(document.getElementById('E2-ckMoreFeedback').checked) document.getElementById('E0-taTeamFeedback').value = tbConst.NoNeedForMoreFeedback;
				transferResponse.Customer_team_feedback__c = document.getElementById('E0-taTeamFeedback').value;
				aResponse.moreFeedback = document.getElementById('E0-taTeamFeedback').value;
				if(transferResponse.Customer_team_feedback__c != '') 
				{
					checkClose++;
					if(aResponse.dateClosed < Date.parse('2-Jan-1970')) transferResponse.NPS_Closed_Date__c = new Date(Date.now());
					else transferResponse.NPS_Closed_Date__c = new Date(aResponse.dateClosed);
				}
				aResponse.dateClosed = Date.parse(transferResponse.NPS_Closed_Date__c);
				//save good touchpoints
				contentToUpload = '';	
				if(document.getElementById('E2-ckTouchpointsGood').checked) contentToUpload = 'NOT ENOUGH INFO';
				else
				{
					if(listSelectedGoodTouchpoints.length>0)
					{
						aTab.length = 0;
						aTab = listSelectedGoodTouchpoints.split(';');
						for(i=0;i<aTab.length;i++)
						{
							tab1.length = 0;
							tab1 = aTab[i].split(',');
							tab2.length = 0;
							tab2 = tbE2ESteps[tab1[0]][1].split(';');
							contentToUpload += tbE2ESteps[tab1[0]][0]+'___'+tab2[tab1[1]]+';';
						}
						contentToUpload = contentToUpload.substr(0,contentToUpload.length-1);		
					}
				}
				if(contentToUpload != '') checkClose++;
				aResponse.touchpointsEE = contentToUpload;
				transferResponse.Touchpoints_EE__c = contentToUpload;
				//save bad touchpoints
				contentToUpload = '';	
				if(document.getElementById('E2-ckTouchpointsBad').checked) contentToUpload = 'NOT ENOUGH INFO';
				else
				{
					if(listSelectedBadTouchpoints.length>0)
					{
						aTab.length = 0;
						aTab = listSelectedBadTouchpoints.split(';');
						for(i=0;i<aTab.length;i++)
						{
							tab1.length = 0;
							tab1 = aTab[i].split(',');
							tab2.length = 0;
							tab2 = tbE2ESteps[tab1[0]][1].split(';');
							contentToUpload += tbE2ESteps[tab1[0]][0]+'___'+tab2[tab1[1]]+';';
						}
						contentToUpload = contentToUpload.substr(0,contentToUpload.length-1);		
					}
				}
				if(contentToUpload != '') checkClose++;
				aResponse.touchpointsNI = contentToUpload;
				transferResponse.Touchpoints_NI__c = contentToUpload;
				//save categories	
				contentToUpload = '';	
				if(document.getElementById('E2-ckCategories').checked) contentToUpload = 'NOT ENOUGH INFO';
				else
				{
					if(listSelectedPoints.length > 0)
					{
						aTab.length = 0;
						aTab = listSelectedPoints.split(';');
						for(i=0;i<aTab.length;i++)
						{
							tab1.length = 0;
							tab1 = aTab[i].split(',');
							tab2.length = 0;
							tab2 = tbCategories[tab1[0]][1].split(';');
							contentToUpload += tbCategories[tab1[0]][0]+'___'+tab2[tab1[1]]+';';
						}
						contentToUpload = contentToUpload.substr(0,contentToUpload.length-1);
					}
				}
				if(contentToUpload != '') checkClose++;
				aResponse.categories = contentToUpload;
				transferResponse.Categories__c = contentToUpload;
				// actions related things
				if(document.getElementById('E2-ckActions').checked) 
				{
					transferResponse.Actions_Checkbox__c = true;
					aResponse.actionsCheck = '1';
				}				
				else 
				{
					transferResponse.Actions_Checkbox__c = false;
					aResponse.actionsCheck = '0';
				}
				if(transferResponse.Actions_Checkbox__c || (thisActionResponses.length >0)) checkClose++;
				
				updateSFDCresponse(transferResponse);
				
			// save actions
				
				tab1.length = 0; tab2.length = 0;
				if(listUnassignedActions.length != '') tab1 = listUnassignedActions.split(';');
				if(listAssignedActions.length != '') tab2 = listAssignedActions.split(';');
				if((tab1.length != 0) && (tab2.length != 0))
				{
					for(i=0;i<tab1.length;i++)
						for(j=0;j<tab2.length;j++)
						{
							if(tab1[i] == tab2[j]) {tab1.splice(i,1); tab2.splice(j,1); i--; j--;}
						}
				}	
				
				// delete actionResponse
					i = 0; counter1 = 0;
					while((i<allActionResponses.length) && (counter1<tab1.length))
					{
						for(j=0;j<tab1.length;j++)
							if(allActionResponses[i].actionID == tab1[j])
							{											
								aTab.length = 0;
								aTab = allActionResponses[i].sourcesIDs.split(';');
								for(k=0;k<aTab.length;k++)
								{
									if(aTab[k].indexOf(aResponse.responseID) != -1) anIndex = k;
								}
								aTab.length = 0;
								aTab = allActionResponses[i].actionResponsesIDs.split(';');
								//deleteSFDCactionResponse(aTab[anIndex]);
								if(deleteSFDCactionResponse(aTab[anIndex]))
										{
											// delete the ID of deleted actionResponse from allActionResponses
											aTab.splice(anIndex,1);
											allActionResponses[i].actionResponsesIDs = '';
											for(k=0;k<aTab.length;k++)
												if(allActionResponses[i].actionResponsesIDs.length == 0) allActionResponses[i].actionResponsesIDs = aTab[k];
												else allActionResponses[i].actionResponsesIDs += ';' +aTab[k];
											
											// delete the ID of the response for which the action is unassigned from allActionResponses
											aTab.length = 0;
											aTab = allActionResponses[i].sourcesIDs.split(';');
											aTab.splice(anIndex,1);
											allActionResponses[i].sourcesIDs = '';
											for(k=0;k<aTab.length;k++)
												if(allActionResponses[i].sourcesIDs.length == 0) allActionResponses[i].sourcesIDs = aTab[k];
												else allActionResponses[i].sourcesIDs += ';' + aTab[k];

											// delete the name of the response for which the action is unassigned from allActionResponses
											aTab.length = 0;
											aTab = allActionResponses[i].sourcesNames.split(';');
											aTab.splice(anIndex,1);
											allActionResponses[i].sourcesNames = '';
											for(k=0;k<aTab.length;k++)
												if(allActionResponses[i].sourcesNames.length == 0) allActionResponses[i].sourcesNames = aTab[k];
												else allActionResponses[i].sourcesNames += ';' + aTab[k];
											
											// delete the name of the action from the current response actions names list
											aTab.length = 0;										
											aTab = aResponse.listActionsName.split(';');
											for(k=0;k<aTab.length;k++)
												if(aTab[k] == allActionResponses[i].actionName) anIndex = k;
											aResponse.listActionsName = '';
											aTab.splice(anIndex,1);
											for(k=0;k<aTab.length;k++)
												if(aResponse.listActionsName.length == 0) aResponse.listActionsName = aTab[k];
												else aResponse.listActionsName += ';' + aTab[k];
												
											// delete the ID of the action from the current response actions IDs list
											aTab.length = 0;
											aTab = aResponse.listActionsID.split(';');
											aTab.splice(anIndex,1);
											aResponse.listActionsID = '';
											for(k=0;k<aTab.length;k++)
												if(aResponse.listActionsID.length == 0) aResponse.listActionsID = aTab[k];
												else aResponse.listActionsID += ';' + aTab[k];
										
											updateModifiedResponse();
											callbackSelectionsResponses();
										}
								counter1++;
							}
						i++;
					}
				// create actionResponse for the existing actions assigned to the current response
					for(j=0;j<tab2.length;j++)
						for(k=0;k<thisActionResponses.length;k++)
							if(thisActionResponses[k].actionID == tab2[j])
							{
								transferActionResponse.Action__c = thisActionResponses[k].actionID;
								transferActionResponse.Net_Promoter_Score__c = aResponse.responseID;
								actionResponseID = createSFDCactionResponse(transferActionResponse);
								thisActionResponses[k].actionResponsesIDs += ';' + actionResponseID;
							}

				if(thisActionResponses.length>0)
				{
					for(i=0;i<thisActionResponses.length;i++) 
					{
						transferAction.id = thisActionResponses[i].actionID;
						transferAction.type__c = thisActionResponses[i].actionType;
						transferAction.Action__c = thisActionResponses[i].action;
						transferAction.Functional_Team__c = thisActionResponses[i].functionalTeam;
						transferAction.Due_Date__c = new Date(thisActionResponses[i].dueDate);
						if(thisActionResponses[i].actionOwnerID.length != 0) transferAction.Action_Owner__c = thisActionResponses[i].actionOwnerID;
						else transferAction.Action_Owner__c = null;
						transferAction.Status__c = thisActionResponses[i].status;
						
						if(thisActionResponses[i].actionName.indexOf('new') != -1)
						{
							transferActionResponse.Action__c = createSFDCaction(transferAction);
							transferActionResponse.Net_Promoter_Score__c = aResponse.responseID;
							
							actionResponseID = createSFDCactionResponse(transferActionResponse);
							
							thisActionResponses[i].actionName = callSFDCactionName(transferActionResponse.Action__c);
							thisActionResponses[i].actionID = transferActionResponse.Action__c;
							thisActionResponses[i].actionResponsesIDs = actionResponseID;
							allActionResponses[allActionResponses.length] = cloneThis(thisActionResponses[i]);

							if(transferActionResponse.Action__c) 
							{
								if(aResponse.listActionsID.length == 0) 
								{
									aResponse.listActionsID = thisActionResponses[i].actionID;
									aResponse.listActionsName = thisActionResponses[i].actionName;
								}
								else 
								{
									aResponse.listActionsID += ';'+thisActionResponses[i].actionID;
									aResponse.listActionsName += ';'+thisActionResponses[i].actionName;
								}
							}
						}
						else
						{
							updateSFDCactionForm(transferAction);
							updateModifiedAction(i);
							if(aResponse.listActionsID.indexOf(thisActionResponses[i].actionID) == -1)
							{
								if(aResponse.listActionsID == '') 
								{
									aResponse.listActionsID = thisActionResponses[i].actionID;
									aResponse.listActionsName = thisActionResponses[i].actionName;
								}
								else 
								{
									aResponse.listActionsID += ';'+thisActionResponses[i].actionID;
									aResponse.listActionsName += ';'+thisActionResponses[i].actionName;
								}
							}
						} 
					}					
					updateModifiedResponse();
				}
				sortActionsTable('dueDate','desc');
				callbackSelectionsActions();
	}

function updateModifiedResponse()
	{
		var i = -1, ck = true, realEEcomments = '', realNIcomments = '';
		while(ck && i<allResponses.length)
		{
			i++;
			if(allResponses[i].responseID == selectedResponse) ck = false;
		} 
		if(aResponse.moreFeedback.length != 0) aResponse.statusFeedback = '1'; else aResponse.statusFeedback = '0';
		if((aResponse.touchpointsEE.length != 0) && (aResponse.touchpointsNI.length != 0)) aResponse.statusTouchpoints = '1'; else aResponse.statusTouchpoints = '0';
		if(aResponse.categories.length != 0) aResponse.statusCategories = '1'; else aResponse.statusCategories = '0';

		if((aResponse.listActionsID == '') && (aResponse.actionsCheck == '0')) aResponse.statusActions = '0'; else aResponse.statusActions = '1';
		allResponses[i] = cloneThis(aResponse);
		
		callbackSelectionsResponses();
		selectMainMenu('A2-btnResponses');
	}
function updateModifiedAction(index) // update allActionResponses with modified ActionOj when SaveALL took place
	{
		var i;
		
		for(i=0;i<allActionResponses.length;i++)
				if(allActionResponses[i].actionID == thisActionResponses[index].actionID) 
					allActionResponses[i] = cloneThis(thisActionResponses[index]);
	}
function viewActionSelectedAssignment(id)
	{
		var index;
		
		document.getElementById('E21-btnAllActions').disabled = false;
		document.getElementById('E21-btnNewAction').disabled = false;
		document.getElementById('E21-btnViewActions').disabled = false;
		arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','1,0');
		arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
		arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
		
		document.getElementById('E21-sAllActions').style.display = 'none';
		document.getElementById('E2-sSelectedActions').style.display = 'none';
		document.getElementById('E2-sNewAction').style.display = 'block';
		
		document.getElementById('E22-btnSave').style.display = 'none';
		document.getElementById('E22-btnModify').style.display = 'block';
		document.getElementById('E22-btnAssign').style.display = 'block';
		document.getElementById('E22-btnDelete').style.display = 'none';
		
		document.getElementById('E22-hActionDetails').innerHTML = 'Assign action';
		index = id.replace('E4-tb','');
		actionFromExisting = index; actionFromSelected = -1;
		anActionResponse = cloneThis(allActionResponses[index]);
		displayAction('editNone');
	}
function viewActionSelectedDetails(id)
	{
		var i, index;

		document.getElementById('E21-btnAllActions').disabled = false;
		document.getElementById('E21-btnNewAction').disabled = false;
		document.getElementById('E21-btnViewActions').disabled = false;
		arrangeCSSclasses('E21-btnViewActions','buttonStyle,buttonInactive','1,0');
		arrangeCSSclasses('E21-btnAllActions','buttonStyle,buttonInactive','1,0');
		arrangeCSSclasses('E21-btnNewAction','buttonStyle,buttonInactive','1,0');
		
		document.getElementById('E21-sAllActions').style.display = 'none';
		document.getElementById('E2-sSelectedActions').style.display = 'none';
		document.getElementById('E2-sNewAction').style.display = 'block';
		
		document.getElementById('E22-btnSave').style.display = 'block';
		document.getElementById('E22-btnSave').innerHTML = 'Save';
		document.getElementById('E22-btnModify').style.display = 'none';
		document.getElementById('E22-btnAssign').style.display = 'none';
		
		
		document.getElementById('E22-hActionDetails').innerHTML = 'Edit action';
		index = id.replace('E3-tb','');
		actionFromExisting = -1; actionFromSelected = index;
		anActionResponse = cloneThis(thisActionResponses[index]);		
		if(anActionResponse.actionName.indexOf('new') == -1)
		{
			displayAction('editSome');
			if(anActionResponse.sourcesNames != aResponse.responseName)
			{
				document.getElementById('E22-btnDelete').style.display = 'block';
				document.getElementById('E22-btnDelete').innerHTML = 'Delete assignment';	
			}
			else document.getElementById('E22-btnDelete').style.display = 'none';
		}
		else
		{
			displayAction('editAll');
			document.getElementById('E22-btnDelete').style.display = 'block';
			document.getElementById('E22-btnDelete').innerHTML = 'Delete';
		}
	}
function displayAction(param)
	{
		var i;
		switch(param)
		{
			case 'editNone':
				{
					document.getElementById('E22-txtActionType').style.display = 'block';
					document.getElementById('E22-txtAction').style.display = 'block';
					document.getElementById('E22-txtFunctionalTeam').style.display = 'block';
					document.getElementById('E22-txtActionOwners').style.display = 'block';
					document.getElementById('E22-txtDueDate').style.display = 'block';
					document.getElementById('E22-txtActionStatus').style.display = 'block';
					
					document.getElementById('E22-rActionTypeContainer').style.display = 'none';
					document.getElementById('E22-txtaAction').style.display = 'none';
					document.getElementById('E22-listFunctionalTeam').style.display = 'none';
					document.getElementById('E22-listActionOwners').style.display = 'none';
					document.getElementById('E22-iDueDate').style.display = 'none';
					document.getElementById('E22-rActionStatusContainer').style.display = 'none';

				};break;
			case 'editAll':
				{
					document.getElementById('E22-txtActionType').style.display = 'none';
					document.getElementById('E22-txtAction').style.display = 'none';
					document.getElementById('E22-txtFunctionalTeam').style.display = 'none';
					document.getElementById('E22-txtActionOwners').style.display = 'none';
					document.getElementById('E22-txtDueDate').style.display = 'none';
					document.getElementById('E22-txtActionDueDateStatus').style.display = 'none';
					
					document.getElementById('E22-rActionTypeContainer').style.display = 'block';
					document.getElementById('E22-txtaAction').style.display = 'block';
					document.getElementById('E22-listFunctionalTeam').style.display = 'block';
					document.getElementById('E22-listActionOwners').style.display = 'block';
					document.getElementById('E22-iDueDate').style.display = 'block';
					document.getElementById('E22-rActionStatusContainer').style.display = 'block';
				};break;
			case 'editSome':
				{
					document.getElementById('E22-txtActionType').style.display = 'block';
					document.getElementById('E22-txtAction').style.display = 'block';
					document.getElementById('E22-txtFunctionalTeam').style.display = 'block';
					document.getElementById('E22-txtActionOwners').style.display = 'block';
					document.getElementById('E22-txtDueDate').style.display = 'none';
					document.getElementById('E22-txtActionDueDateStatus').style.display = 'none';
					
					document.getElementById('E22-rActionTypeContainer').style.display = 'none';
					document.getElementById('E22-txtaAction').style.display = 'none';
					document.getElementById('E22-listFunctionalTeam').style.display = 'none';
					document.getElementById('E22-listActionOwners').style.display = 'none';
					document.getElementById('E22-iDueDate').style.display = 'block';
					document.getElementById('E22-rActionStatusContainer').style.display = 'block';
				};break;
		}
		
		document.getElementById('E22-txtName').innerHTML = anActionResponse.actionName;
		document.getElementById('E22-txtSource').innerHTML = anActionResponse.sourcesNames;
		//document.getElementById('E22-txtTouchpoints').innerHTML = convertIndexToString(anActionResponse.touchpoints,tbE2ESteps,'/');
		document.getElementById('E22-txtTouchpoints').innerHTML = anActionResponse.touchpointsExt;
		//document.getElementById('E22-txtCategories').innerHTML = convertIndexToString(anActionResponse.categories,tbCategories,'/');
		document.getElementById('E22-txtCategories').innerHTML = anActionResponse.categoriesExt;
		document.getElementById('E22-txtAccounts').innerHTML = anActionResponse.accounts;
		
		// action type
		document.getElementById('E22-txtActionType').innerHTML = anActionResponse.actionType;
		
		i = 0;
		while(document.getElementById('E22-rActionType'+i))
		{
			if(listActionType[i] == anActionResponse.actionType)
				objSelFormActionType.forceSelection(i.toString());
			i++;
		}
		// action
		document.getElementById('E22-txtAction').innerHTML = anActionResponse.action;
		document.getElementById('E22-txtaActionObject').value = anActionResponse.action;
		// functional team
		document.getElementById('E22-txtFunctionalTeam').innerHTML = anActionResponse.functionalTeam;
		for(i=0;i<listFunctionalTeam.length;i++)
			if(listFunctionalTeam[i] == anActionResponse.functionalTeam)
			{
				document.getElementById('E22-listFunctionalTeam').selectedIndex = i-1; 
				fulfillActionOwnersList(listFunctionalTeam[i],'E22-listActionOwners');
			}

		// action owner
		document.getElementById('E22-txtActionOwners').innerHTML = anActionResponse.actionOwner;
		for(i=0;i<listActionOwner.length;i++)
			if(listActionOwner[i] == anActionResponse.actionOwner) 
				document.getElementById('E22-listActionOwners').selectedIndex = i;
		
		// due date
		document.getElementById('E22-txtDueDate').innerHTML = dateConverted(anActionResponse.dueDate);
		document.getElementById('E22-iDueDate').value = dateConverted(anActionResponse.dueDate);
		// status
		document.getElementById('E22-txtActionDueDateStatus').innerHTML = anActionResponse.dueDatestatus;
		i = 0;
		while(document.getElementById('E22-rActionStatus'+i))
		{				
			if(listActionStatus[i] == anActionResponse.status)
				objSelFormActionStatus.forceSelection(i.toString());
			i++;
		}
		arrangeCSSclasses('E22-txtaActionLabel','colorHONred','0');
		arrangeCSSclasses('E22-txtTouchpointsLabel','colorHONred','0');
		arrangeCSSclasses('E22-txtCategoriesLabel','colorHONred','0');
		document.getElementById('E22-txtMessages').innerHTML = '&nbsp;';
		arrangeCSSclasses('E22-txtMessages','colorHONred,colorGreen','0,0');
	}

function deleteAction()
	{
		var i, ck = true;
		i = 0;
		while(ck)
		{
			if(document.getElementById('E22-txtName').innerHTML == thisActionResponses[i].actionName) {thisActionResponses.splice(i,1); ck = false;}
			i++;
			if(i == thisActionResponses.length) ck = false;
		}
	}
function addNewAction()
	{
		var i, j, ck, selection, index;

		//anActionResponse.newAction = 'yes';
		anActionResponse.actionName = document.getElementById('E22-txtName').innerHTML;
		anActionResponse.sourcesNames = document.getElementById('E22-txtSource').innerHTML;
		i = 0;
		while(document.getElementById('E22-rActionType'+i))
		{
			if(document.getElementById('E22-rActionType'+i).checked) selection = listActionType[i]; 
			i++;
		}
		anActionResponse.actionType = selection;
		
		anActionResponse.action = document.getElementById('E22-txtaActionObject').value;
		
		anActionResponse.functionalTeam = document.getElementById('E22-listFunctionalTeam').options[document.getElementById('E22-listFunctionalTeam').selectedIndex].value;
		
		if((document.getElementById('E22-listActionOwners').selectedIndex != 0) && (listActionOwner.length>0))
		{
			
			for(i=0;i<listActionOwner.length;i++)
			if(listActionOwner[i] == document.getElementById('E22-listActionOwners').options[document.getElementById('E22-listActionOwners').selectedIndex].value)
			{
				j = 0; ck = true;

				while(ck && (j<allHONcontacts.length))
				{
					
					if(allHONcontacts[j].contactName == listActionOwner[i])
					{
						ck = false;
						anActionResponse.actionOwnerID = allHONcontacts[j].contactId;
						anActionResponse.actionOwner = allHONcontacts[j].contactName;
						anActionResponse.actionOwnerEmail = allHONcontacts[j].contactEmail;
					}
					j++;
				}
			}	
		}
		else
		{
			anActionResponse.actionOwnerID = '';
			anActionResponse.actionOwner = '';
			anActionResponse.actionOwnerEmail = '';
		}
		
		anActionResponse.dueDate = Date.parse(document.getElementById('E22-iDueDate').value);
		i = 0;
		while(document.getElementById('E22-rActionStatus'+i))
		{
			if(document.getElementById('E22-rActionStatus'+i).checked) selection = listActionStatus[i];
			i++;
		}
		anActionResponse.status = selection;
		//anActionResponse.touchpoints = listSelectedBadTouchpoints;
		//anActionResponse.categories = listSelectedPoints;
		anActionResponse.accounts = document.getElementById('E22-txtAccounts').innerHTML;

		index = thisActionResponses.length;
		for(i=0;i<thisActionResponses.length;i++)
			if(thisActionResponses[i].actionName == anActionResponse.actionName) index = i;
		if(document.getElementById('E22-btnSave').innerHTML == 'Create') 
			{
				noNewActions++;
				//if(anActionResponse.actionOwnerID.length != 0)sendEmailSFDC(anActionResponse);// exceptions : no email, no owner -> email to NPS Admin;

			}
		
		thisActionResponses[index] = cloneThis(anActionResponse);
	}

function actOnSteps(id)
	{
		index = id.replace('E1-stepName','');
		if(document.getElementById('E1-stepContent'+index).classList.contains('displayBlock'))
		{
			arrangeCSSclasses('E1-stepContent'+index,'displayBlock,displayNone','0,1');
			document.getElementById(id).innerHTML = '<span class="">'+tbE2ESteps[index][0]+'&nbsp;</span><span class="groundBlack colorWhite visibilityTrue">&nbsp;+&nbsp;</span>';
		}
		else 
		{
			arrangeCSSclasses('E1-stepContent'+index,'displayBlock,displayNone','1,0');
			document.getElementById(id).innerHTML = '<span class="">'+tbE2ESteps[index][0]+'&nbsp;</span><span class="groundBlack colorWhite visibilityFalse">&nbsp;+&nbsp;</span>';
		}

	}
function selectTouchPoint(id,param)
	{
		var containerID, containerIDcategory, containerIDresolution, feedback, numbers = [], tab = [], touchpoint;

		if(param == '') 
		{
			if(document.getElementById('E3-tHeaderDetails').innerHTML.indexOf('improvement') != -1) param = 'bad';
			else param = 'good';
		}

		numbers = id.match(/\d+/g);
		tab = tbE2ESteps[numbers[1]][1].split(';');
		touchpoint = tbE2ESteps[numbers[1]][0]+' / ' + tab[numbers[2]];

		if(param == 'good')
		{
			containerID = 'E12-sImprovementTouchpoints';
			if(document.getElementById(id).classList.contains('goodFeedback')) feedback = '';
			else feedback = 'goodFeedback';
		}
		else
		{
			containerID = 'E12-sExceededTouchpoints';
			if(document.getElementById(id).classList.contains('badFeedback')) feedback = '';
			else feedback = 'badFeedback';
		}
		
		arrangeCSSclasses(id,'goodFeedback,badFeedback','0,0'); 
		if(feedback != '') arrangeCSSclasses(id,feedback,'1');
		
		contentSelectedTouchpoints(); 
	}
function selectCategories(id)
	{
		var numbers, tab = [], category;
		numbers = id.match(/\d+/g);
		tab = tbCategories[numbers[1]][1].split(';');
		category = tbCategories[numbers[1]][0]+' / ' + tab[numbers[2]];

		if(document.getElementById(id).classList.contains('inputUnselected')) arrangeCSSclasses(id,'inputUnselected,inputSelected','0,1');
		else arrangeCSSclasses(id,'inputUnselected,inputSelected','1,0');
		
		contentSelectedPointsImprove();
	}
function unselectTouchpoints(touchpointType)
	{
		// remove the CSS classes from the unselected touchpoint
		var i, j, k, tab = [];
		if(touchpointType == 'good') k = 3; else k = 4;
		for(i=0;i<tbE2ESteps.length;i++)
		{
			j = 0;
			while(document.getElementById('E1-tb'+i+'.'+j))
			{
				arrangeCSSclasses('E1-tb'+i+'.'+j,touchpointType + 'Feedback','0');
				tbE2ESteps[i][k] = '';
				j++;	
			}
		}
	}
function unselectPointsImprove()
	{
		// remove the CSS classes from the unselected touchpoint
		var i,j;
		for(i=0;i<tbCategories.length;i++)
		{
			j = 0;
			while(document.getElementById('E2-tb'+i+'.'+j))
			{
				arrangeCSSclasses('E2-tb'+i+'.'+j,'inputSelected','0');
				j++;	
			}
		}
	}
function statusUpdate()
	{
		// evaluate the existing selections in order to diplay the status of the current response;
		var i, tab1 = [], tab2 = [], statusContent = '', statusContentOverview = '';
		var ckTouchpointsGood = false, ckTouchpointsBad = false, ckPoints = false, ckActions = false, checkHeader;
		
		if(document.getElementById('E12-sGoodTouchpoints').innerHTML != '') document.getElementById('E2-ckTouchpointsGood').checked = false;
		if(document.getElementById('E12-sBadTouchpoints').innerHTML != '') document.getElementById('E2-ckTouchpointsBad').checked = false;
		if(document.getElementById('E12-sCategoriesSelected').innerHTML != '' ) document.getElementById('E2-ckCategories').checked = false;
		if(document.getElementById('E12-sActionsSelected').innerHTML != '' ) document.getElementById('E2-ckActions').checked = false;

		if ((listSelectedGoodTouchpoints != '') || (document.getElementById('E2-ckTouchpointsGood').checked))
		{
			arrangeCSSclasses('E2-btnTouchpointsGood','buttonObvious,buttonStyle','0,1');
			ckTouchpointsGood = true;
		}
		else arrangeCSSclasses('E2-btnTouchpointsGood','buttonObvious,buttonStyle','1,0');	
			
		if ((listSelectedBadTouchpoints != '') || (document.getElementById('E2-ckTouchpointsBad').checked))
		{
			arrangeCSSclasses('E2-btnTouchpointsBad','buttonObvious,buttonStyle','0,1');	
			ckTouchpointsBad = true;
		}
		else arrangeCSSclasses('E2-btnTouchpointsBad','buttonObvious,buttonStyle','1,0');

		if((listSelectedPoints != '') || (document.getElementById('E2-ckCategories').checked))
		{
			arrangeCSSclasses('E2-btnCategories','buttonObvious,buttonStyle','0,1');
			ckPoints = true;				
		}
		else arrangeCSSclasses('E2-btnCategories','buttonObvious,buttonStyle','1,0');
		
		// preselect the categories selected in the filter for all existing action
		i = 0;
		while(document.getElementById('E2-ckCategories'+i))
		{
			document.getElementById('E2-ckCategories'+i).checked = false;
			arrangeCSSclasses('E2-ckCategories'+i+'label','inputSelected,inputUnselected','0,1');
			i++;
		}
		i = 0;
		if(listSelectedPoints != '')
		{
			tab1.length = 0;
			tab1 = listSelectedPoints.split(';');
			while(document.getElementById('E2-ckCategories'+i))
			{
				for(j=0;j<tab1.length;j++)
				{
					tab2.length = 0;tab2 = tab1[j].split(',');
					if(tbCategories[tab2[0]][0] == listCategories[i+1])
					{
						document.getElementById('E2-ckCategories'+i).checked = true;
						arrangeCSSclasses('E2-ckCategories'+i+'label','inputSelected,inputUnselected','1,0');
					}
				}
				i++;
			}	
		}

		if((thisActionResponses.length > 0) || (document.getElementById('E2-ckActions').checked)) 
		{
			arrangeCSSclasses('E2-btnActions','buttonObvious,buttonStyle','0,1');
			ckActions = true;
		}
		else arrangeCSSclasses('E2-btnActions','buttonObvious,buttonStyle','1,0'); 
		
		if((document.getElementById('E0-taTeamFeedback').value != '') || (document.getElementById('E2-ckMoreFeedback').checked)) 
		{
			statusContentOverview = '<p class="fontEvenBigger">Select touchpoints affected.</p>'
			statusContent = 'STATUS: <span class="fontBigger colorHONred fontBold"> Open </span><span>(select touchpoints affected)</span>';
			if(ckTouchpointsGood && ckTouchpointsBad) 
			{
				statusContentOverview = '<p class="fontEvenBigger">Select points to improve.</p>'
				statusContent = 'STATUS: <span class="fontBigger colorHONred fontBold"> Open </span><span>(select points to improve)</span>';					
				if(ckPoints)
				{
					statusContentOverview = '<p class="fontEvenBigger">Select follow up actions.</p>'
					statusContent = 'STATUS: <span class="fontBigger colorHONred fontBold"> Open </span><span>(select follow up actions)</span>';
					if(ckActions) 
					{
						statusContentOverview = '<p class="fontEvenBigger">Capturing customer response: Completed!</p><br/>';
						if(document.getElementById('E12-sActionsSelected').innerHTML.length == 0) statusContentOverview += '<p class="fontEvenBigger">No follow up actions.</p>';
						else statusContentOverview += '<p class="fontEvenBigger">Follow up actions:<br/></p>'+document.getElementById('E12-sActionsSelected').innerHTML;
						statusContent = 'STATUS: <span class="fontBigger colorGreen fontBold"> Completed </span>';
					}
				}
			}
		}
		else
		{
			statusContentOverview = '<p class="fontEvenBigger">Contact '+aResponse.contactName+' for more feedback.</p>'
			statusContent = 'STATUS: <span class="fontBigger colorHONred fontBold"> Open </span><span>(more feedback from customer)</span>';
		} 
		document.getElementById('E0-txtFormStatus').innerHTML = statusContent;
		//statusContentOverview = '<p>Hi '+currentUser.actionName.substr(0,currentUser.actionName.indexOf(' '))+',</p><br/>'+'<p>Next to be done:</p>'+
			statusContentOverview+'<br/><p>Due Date:'+dateConverted(aResponse.dateCreated+5*24*3600*1000)+'</p>';
		document.getElementById('E1-sStatusOverview').innerHTML = statusContentOverview;
		
		checkHeader = document.getElementById('E3-tHeaderDetails').innerHTML;
		
		if(checkHeader == '2. Select touchpoints which <span class="colorGreen fontBigger fontBold">exceeded expectations</span>')
			document.getElementById('E2-btnTouchpointsGood').disabled = true;
			else document.getElementById('E2-btnTouchpointsGood').disabled = false;
		if(checkHeader == '3. Select touchpoints which <span class="colorHONred fontBigger fontBold">need improvement</span>')
			document.getElementById('E2-btnTouchpointsBad').disabled = true;
			else document.getElementById('E2-btnTouchpointsBad').disabled = false;
		if(checkHeader == '4. Select categories and points to improve')
			document.getElementById('E2-btnCategories').disabled = true;
			else document.getElementById('E2-btnCategories').disabled = false;	
		if(checkHeader == '5. Select follow up actions')
			document.getElementById('E2-btnActions').disabled = true;
			else document.getElementById('E2-btnActions').disabled = false;
	}
function fulfillActionOwnersList(team,tagID)
	{
		// identify the action owner associated with an already selcted functional team;
		var i;
		listActionOwner.length = 0; listActionOwner[listActionOwner.length] = '';

		for(i=0;i<allHONcontacts.length;i++)
		{
			if(allHONcontacts[i].functionalTeam.indexOf(team) != -1) listActionOwner[listActionOwner.length] = allHONcontacts[i].contactName;
		}
		contentActionOwnerList(tagID);
	}

function callbackSelForm()
	{
		contentAllActions();
		eventsAllActions();
	}

