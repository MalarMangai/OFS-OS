
// specific variables for Home page
	var listChart1 = ['1 month rolling','12 months rolling'];
	var listChart2 = ['Alphabetically','Score descending'];
	
	var tbDateRef = [];
	var allNPStargets = [[]], otherNPStargets = [[]];
	var listObjectives = [];
		var anObjective =
			{
				name: '',
				type: '', // 0:ALL; LOB; Regions; Parent Account; Account
				targetNPS:'',
				targetCustomers:'',
				visibility: '',
				indexResponses: '',
				indexContacts: ''
			}
	var allHouses = [];
		var aHouse = 
			{	
				name: '', // objectives name
				type: '', // objectives type: LOB, Region, Parent Accounts, Account
			 	active:0,
			 	targetNPS:0,
			 	NPSnow:0,
			 	asked:0,
			 	responded:0,
			 	waiting:0,
			 	notResponded:0, // contacted in last 12 months, but still available;
			 	isNPS:'',
			 	openActionsList: '',
			 	openOverdueActionsList: ''
			 }
	var allMonthlyNPS = [];
		var monthlyNPS = 
			{
				name: '', // objectives name
				type: '', // objectives type: LOB, Region, Parent Accounts, Account
				region: '',
				NPS: '',
				dateRef:'',			
				req1:0,
				responses1:0,
				promoters1:0,
				detractors1:0,
				req12:0,
				responses12:0,
				promoters12:0,
				detractors12:0,
				closed: 0,
				days: 0,
				targetNPS:'',
				targetCustomers:'',
			 	openResponses:'',
			 	monthlyContacted:'', // list with the IDs of all contacts who responded in that month
			 	yearlyUniques:0,
			 	aboutMonthlyContacted: '', // list with chunks of info about responses: contactID, score, dateResponse
			 	closedThisMonth: '' // responses IDs for those closed;
			}

	var tbTouchpointsMap = [[]];
	var allTouchpointData = [];
		var aTouchpointData = new Object();
			aTouchpointData = 
			{
				phase: '',
				phaseIndex: '',
				touchpoint: '',			
				touchpointIndex: '',
				nrCommentsEE: '',
				nrCommentsNI: '',
				listCommentsEE: '',
				listCommentsNI: ''
			}

	var listSelectedAccounts = [[]]; // 0:account,1:succes_rate
	var listChildAccounts = [], selectedParentAccount, selectedChildAccount;
// JS objects
	function newDateRangePicker()
		{
			return {
				months: ['January','February','March','April','May','June','July','August','September','October','November','December'],
				tagId:'',
				startDateInt: 0, // inclusive
				endDateInt: 0, // exclusive  
				startDateString: '',
				endDateString: '',
				step: 0,
				interval: 0,
				leftSideLimit: 0, 
				rightSideLimit: 0,
				jump: 0,
				objCallBack: function(){alert('callback to be executed after onClick');},		
				
				initialize: function(tagId,step,interval,leftLimit,rightLimit,callback)
					{
						var today, todayConverted, aDay; 
						today = Date.now();		// now	
						todayConverted = new Date(today); // string	
						todayConverted.setMonth(todayConverted.getMonth()+1);
						this.tagId = tagId;
						this.endDateString = this.months[parseInt(todayConverted.getMonth())]+' '+todayConverted.getFullYear();
						aDay = new Date(todayConverted.getFullYear(),todayConverted.getMonth(),1);		
						this.endDateInt = Date.parse(aDay); 
						this.interval = interval;
						this.step = step; 
						aDay = new Date(todayConverted.getFullYear(),todayConverted.getMonth()-this.interval+1,1);
						this.startDateString = this.months[aDay.getMonth()]+' '+aDay.getFullYear();
						this.startDateInt = Date.parse(aDay);
						this.contentRangePicker(); 
						this.objCallBack = callback;
						this.jump = 0;			
					},
				contentRangePicker: function()
					{
						var content = '';
						content += '<span class="pushOutRight1 cursorPointer" title="Move visible area '+this.step+' months before"><i id="'+this.tagId+'leftArrow" class="fa fa-caret-square-o-left fa-lg" aria-hidden="true"></i></span>'+
			                            '<span id="'+this.tagId+'content" class="">'+this.startDateString+' - '+this.endDateString+'</span>'+
			                            '<span class="pushOutLeft1 cursorPointer" title="Move visible area '+this.step+' months after"><i id="'+this.tagId+'rightArrow" class="fa fa-caret-square-o-right fa-lg" aria-hidden="true"></i></span>';
						
						document.getElementById(this.tagId).innerHTML = content;
						this.eventsRangePicker();
					},
				eventsRangePicker: function()
					{
						var self = this;
						document.getElementById(this.tagId+'leftArrow').onclick = function(){self.changeDateInterval('decrease');};
						document.getElementById(this.tagId+'rightArrow').onclick = function(){self.changeDateInterval('increase');};			  
					},
				changeDateInterval: function(param)
					{
						var step, aDay, anotherDay; 
						switch(param)
						{
							case 'decrease': step = -1;break;
							case 'increase': step = 1;break;
						}
						this.jump = this.jump + step*this.step;
						
						aDay = new Date(this.endDateInt);
						aDay.setMonth(aDay.getMonth()+step*this.step);

						this.endDateInt = new Date(aDay.getFullYear(),aDay.getMonth(),1);	
						endDay = new Date(this.endDateInt);
						this.endDateString = this.months[endDay.getMonth()]+' '+endDay.getFullYear();				
						aDay = new Date(this.startDateInt);	

						aDay.setMonth(aDay.getMonth()+step*this.step);
						this.startDateInt = new Date(aDay.getFullYear(),aDay.getMonth(),1);
						startDay = new Date(this.startDateInt);  
						this.startDateString = this.months[startDay.getMonth()]+' '+startDay.getFullYear();
						
						document.getElementById(this.tagId+'content').innerHTML = this.startDateString+' - '+this.endDateString;
						this.objCallBack();
					}
			};
		}
	function newRangePicker()
		{
			return {
				tagId:'',
				startInt: 1,
				endInt: 20,
				step: 10,
				interval: 20,
				leftSideLimit: 1, 
				rightSideLimit: 20,
				
				objCallBack: function(){alert('callback to be executed after onClick');},		
				
				initialize: function(tagId,step,interval,rightLimit,callback)
					{
						this.tagId = tagId;
						this.startInt = 1;
						this.endInt = interval;
						this.interval = interval;
						this.step = step; 
						this.leftSideLimit = 1;
						this.rightSideLimit = rightLimit;
						this.contentRangePicker(); 
						this.objCallBack = callback;
					},
				contentRangePicker: function()
					{
						var content = '';
						content += '<span class="pushOutRight1 cursorPointer" title="Show previous '+this.step+' accounts"><i id="'+this.tagId+'leftArrow" class="fa fa-caret-square-o-left fa-lg" aria-hidden="true"></i></span>'+
			                            '<span id="'+this.tagId+'content" class="">'+this.startInt+' - '+this.endInt+' (out of '+this.rightSideLimit+')</span>'+
			                            '<span class="pushOutLeft1 cursorPointer" title="Shoe next '+this.step+' accounts"><i id="'+this.tagId+'rightArrow" class="fa fa-caret-square-o-right fa-lg" aria-hidden="true"></i></span>';
						document.getElementById(this.tagId).innerHTML = content;
						this.eventsRangePicker();
					},
				eventsRangePicker: function()
					{
						var self = this;
						document.getElementById(this.tagId+'leftArrow').onclick = function(){self.changeInterval('decrease');};
						document.getElementById(this.tagId+'rightArrow').onclick = function(){self.changeInterval('increase');};			  
					},
				changeInterval: function(param)
					{
						var direction, aDay, anotherDay; 
						switch(param)
						{
							case 'decrease': direction = -1;break;
							case 'increase': direction = 1;break;
						}
						this.startInt = this.startInt + direction*this.step;
						this.endInt = this.endInt + direction*this.step;

						if(this.startInt < 1) {this.startInt = 1; this.endInt = this.startInt + this.interval-1;}
						if(this.endInt > this.rightSideLimit) {this.endInt = this.rightSideLimit; this.startInt = this.endInt - this.interval+1;}
						
						this.contentRangePicker();
						this.objCallBack();
					}
			}
		}
	function newGraphPoints2()
		{
			return {
		 				tbPointsValues: [],
		 				objPoint: {value: '', dimension: '', target: '', label: '', title: '', date: '', x: -1, y: -1, r: -1, xt: -1, yt: -1, rt: -1},
		 				tagId: '',
		 				minY: 0,
		 				maxY:0,
		 				minR: 0,
		 				maxR:0,
		 				translation: 0,
		 				noPoints: 0,
		 				svgWidth: 0,
		 				svgHeight: 0,
		 				targetVisibility: '',
		 				cloneThis: function(proto_obj) {var ret = {}; for (var prop in proto_obj ) {ret[prop] = proto_obj[prop]; }	return ret;},
		 				initialize: function(tagId,visibility)
		 					{
		 						this.tagId = tagId;
		 						this.svgWidth = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("width"));
								this.svgHeight = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("height"));
								this.noPoints = parseInt((this.svgWidth)/60)+1;
								this.targetVisibility = visibility;
								this.tbPointsValues.length = 0;
								this.translation = 0;
		 					}, 					
		 				calculate: function(aTable)
			 				{
			 					var i, ck, x, y, r;
			 					this.tbPointsValues.length = 0;
			 					// data transfer
				 					for(i=0;i<this.noPoints;i++)
				 					{
				 						this.objPoint.value = aTable[i][0]; 
				 						this.objPoint.dimension = aTable[i][1]; 
				 						this.objPoint.target = aTable[i][2];
				 						this.objPoint.label = aTable[i][3];
				 						this.objPoint.title = aTable[i][4];
				 						this.objPoint.date = aTable[i][5];
				 						this.tbPointsValues[this.tbPointsValues.length] = cloneThis(this.objPoint);
				 					}
			 					// calculate min and max values
				 					i = 0; ck = true;
				 					while(ck && (i<this.tbPointsValues.length))
				 					{
				 						if(this.tbPointsValues[i].value.length != 0)
				 						{
				 							this.minY = parseFloat(this.tbPointsValues[i].value); 
											this.maxY = parseFloat(this.tbPointsValues[i].value);
											this.minR = parseFloat(this.tbPointsValues[i].dimension); 
											this.maxR = parseFloat(this.tbPointsValues[i].dimension);
											ck = false;
				 						}
				 						i++;
				 					}
				 					for(i=0;i<this.tbPointsValues.length;i++)
										if(this.tbPointsValues[i].value.length != 0)
										{
											if(this.minY > parseFloat(this.tbPointsValues[i].value)) this.minY = parseFloat(this.tbPointsValues[i].value);
											if(this.maxY < parseFloat(this.tbPointsValues[i].value)) this.maxY = parseFloat(this.tbPointsValues[i].value);
											if(this.targetVisibility)
											{
												if(this.minY > parseFloat(this.tbPointsValues[i].target)) this.minY = parseFloat(this.tbPointsValues[i].target);
												if(this.maxY < parseFloat(this.tbPointsValues[i].target)) this.maxY = parseFloat(this.tbPointsValues[i].target);	
											}
											if(this.minR > parseFloat(this.tbPointsValues[i].dimension)) this.minR = parseFloat(this.tbPointsValues[i].dimension);
											if(this.maxR < parseFloat(this.tbPointsValues[i].dimension)) this.maxR = parseFloat(this.tbPointsValues[i].dimension);
										}
									if(this.minY<0) this.translation = 0-this.minY; else this.translation = 0;
									this.minY = (this.minY + this.translation) * 0.8;
									this.maxY = (this.maxY + this.translation) * 1.2;
								// calculate coordinates
									for(i=0;i<this.tbPointsValues.length;i++)
					 				{
				 						if(this.tbPointsValues[i].value.length != 0)
					 					{
					 						x = 20+i*50;
					 						y = parseInt(this.svgHeight*0.9)-20-
					 						parseInt(((parseFloat(this.tbPointsValues[i].value)+this.translation)-this.minY)*(this.svgHeight*0.8)/(this.maxY-this.minY));
					 						/*if(this.minR != this.maxR) r = 5+parseInt(12*((this.tbPointsValues[i].dimension-this.minR)/(this.maxR-this.minR)));
					 						else*/ r = 11;
						 				}
						 				else
						 				{
						 					x = 20+i*50;
						 					y = parseInt(this.svgHeight*0.9)-20;
						 					r = 0;
						 				}
						 				this.tbPointsValues[i].x = x;
						 				this.tbPointsValues[i].y = y;
						 				this.tbPointsValues[i].r = r;
						 				// same for target values
				 						if(this.tbPointsValues[i].target.length != 0)
					 					{
					 						x = 20+i*50;
					 						y = parseInt(this.svgHeight*0.9)-20-
					 						parseInt(((parseFloat(this.tbPointsValues[i].target)+this.translation)-this.minY)*(this.svgHeight*0.8)/(this.maxY-this.minY));
					 						r = 5;
						 				}
						 				else
						 				{
						 					x = 20+i*60;
						 					y = parseInt(this.svgHeight*0.9)-20;
						 					r = 0;
						 				}
						 				this.tbPointsValues[i].xt = x;
						 				this.tbPointsValues[i].yt = y;
						 				this.tbPointsValues[i].rt = r;
					 				}						
			 				},
		 				contentGraph: function(aTable) 
			 				{
			 					var i, iStart, j, ck, content, r, x, y, xprev, yprev, xnext, ynext, aColor;
			 					
			 					this.calculate(aTable);
			 					
			 					content = '<text x="3" y="1.2em" fill="#BBBBBB">NPS</text>'+
			 					//'<text x="'+(this.svgWidth-40)+'" y="'+(this.svgHeight-2)+'" fill="#BBBBBB">time</text>'+
			 					'<line x1="0" y1="0" x2="0" y2="'+(this.svgHeight-15)+'" style="stroke:#EEEEEE;stroke-width:1" />'+
			 					'<line x1="0" y1="'+(this.svgHeight-15)+'" x2="100%" y2="'+(this.svgHeight-15)+'" style="stroke:#000000;stroke-width:1" />';

			 					for(i=0;i<this.noPoints;i++)
			 					{
			 						x = this.tbPointsValues[i].x;
			 						y = parseInt(this.svgHeight*1)-8;
			 						content +=	'<g><line x1="'+x+'" y1="'+(0)+'" x2="'+x+'" y2="'+y+'" style="stroke:#EEEEEE;stroke-width:1" /></g>'+
			 						'<g><line x1="'+x+'" y1="'+(y-15)+'" x2="'+x+'" y2="'+y+'" style="stroke:#BBBBBB;stroke-width:1" /></g>'+
			 						'<g>'+
				 					 	'<text transform="rotate(0 '+(x)+','+(y+5)+')" text-anchor="start" x="'+ (x-10) +'" y="'+ (y+5) +'">'+this.tbPointsValues[i].date+'</text>'+
				 					 '</g>'
			 					}
			 					
				 				if(this.targetVisibility) // line and circle for target
					 				for(i=0;i<this.tbPointsValues.length;i++)
					 					if(this.tbPointsValues[i].target.length != 0)
						 				{
						 					x = this.tbPointsValues[i].xt;
							 				y = this.tbPointsValues[i].yt;
						 					if(i < (this.tbPointsValues.length-1))
							 				{
							 					if(this.tbPointsValues[i+1].target.length != 0)
							 					{
							 						xnext = this.tbPointsValues[i+1].xt;
							 						ynext = this.tbPointsValues[i+1].yt;
							 						content += '<line x1="'+x+'" y1="'+y+'" x2="'+xnext+'" y2="'+ynext+'" style="stroke:lightgray;stroke-width:1" />';	
							 					}
											}
											r = this.tbPointsValues[i].rt;
											content += '<g>'+
												'<circle cx="'+ x +'" cy="'+ y +'" r="'+ r +'" fill="lightgray"> <title>'+this.tbPointsValues[i].title+'</title></circle>'+ 
											 	'</g>';	
						 				}
					 				
				 				for(i=0;i<this.tbPointsValues.length;i++)
				 				{
				 					
				 					if(this.tbPointsValues[i].value.length != 0)
					 				{
					 					x = this.tbPointsValues[i].x;
						 				y = this.tbPointsValues[i].y;
					 					if(i < (this.tbPointsValues.length-1))
						 				{
						 					if(this.tbPointsValues[i+1].value.length != 0)
						 					{
						 						xnext = this.tbPointsValues[i+1].x;
						 						ynext = this.tbPointsValues[i+1].y;
						 						content += '<line x1="'+x+'" y1="'+y+'" x2="'+xnext+'" y2="'+ynext+'" style="stroke:black;stroke-width:1" />';	
						 					}
										}
										if(this.tbPointsValues[i].value >= this.tbPointsValues[i].target) aColor = '#00A400'; else aColor = '#E41414';
										r = this.tbPointsValues[i].r;
											content += '<g>'+
											'<circle cx="'+ x +'" cy="'+ y +'" r="'+ r +'" fill="'+aColor+'"> <title>'+this.tbPointsValues[i].title+'</title></circle>'+ 
										 	'</g><g>'+								 	
											'<text transform="rotate(0 '+x+','+y+')" text-anchor="start" x="'+ (x+0) +'" y="'+ (y-parseInt(r/2)-7) +'">'+this.tbPointsValues[i].label+'</text>'+
										 	'<title>'+this.tbPointsValues[i].title+'</title>'+
										 	'</g>';	
					 				}
				 				}			 				
				 				document.getElementById(this.tagId).innerHTML = content;
			 				} 
		 			}
		}
	function newGraphPoints3()// dedicated for closure (number of days when a response is open)
		{
			return {
		 				tbPointsValues: [],
		 				objPoint: {value: '', dimension: '', target: '', label: '', title: '', date: '', x: -1, y: -1, r: -1, xt: -1, yt: -1, rt: -1},
		 				tagId: '',
		 				minY: 0,
		 				maxY:0,
		 				minR: 0,
		 				maxR:0,
		 				translation: 0,
		 				noPoints: 0,
		 				svgWidth: 0,
		 				svgHeight: 0,
		 				targetVisibility: '',
		 				cloneThis: function(proto_obj) {var ret = {}; for (var prop in proto_obj ) {ret[prop] = proto_obj[prop]; }	return ret;},
		 				initialize: function(tagId,visibility)
		 					{
		 						this.tagId = tagId;
		 						this.svgWidth = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("width"));
								this.svgHeight = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("height"));
								this.noPoints = parseInt((this.svgWidth)/60)+1;
								this.targetVisibility = visibility;
								this.tbPointsValues.length = 0;
								this.translation = 0;
		 					}, 					
		 				calculate: function(aTable)
			 				{
			 					var i, ck, x, y, r;
			 					this.tbPointsValues.length = 0;
			 					// data transfer
				 					for(i=0;i<this.noPoints;i++)
				 					{
				 						this.objPoint.value = aTable[i][0]; 
				 						this.objPoint.dimension = aTable[i][1]; 
				 						this.objPoint.target = aTable[i][2];
				 						this.objPoint.label = aTable[i][3];
				 						this.objPoint.title = aTable[i][4];
				 						this.objPoint.date = aTable[i][5];
				 						this.tbPointsValues[this.tbPointsValues.length] = cloneThis(this.objPoint);
				 					}
			 					// calculate min and max values
				 					i = 0; ck = true;
				 					while(ck && (i<this.tbPointsValues.length))
				 					{
				 						if(this.tbPointsValues[i].value.length != 0)
				 						{
				 							this.minY = parseFloat(this.tbPointsValues[i].value); 
											this.maxY = parseFloat(this.tbPointsValues[i].value);
											this.minR = parseFloat(this.tbPointsValues[i].dimension); 
											this.maxR = parseFloat(this.tbPointsValues[i].dimension);
											ck = false;
				 						}
				 						i++;
				 					}
				 					for(i=0;i<this.tbPointsValues.length;i++)
										if(this.tbPointsValues[i].value.length != 0)
										{
											if(this.minY > parseFloat(this.tbPointsValues[i].value)) this.minY = parseFloat(this.tbPointsValues[i].value);
											if(this.maxY < parseFloat(this.tbPointsValues[i].value)) this.maxY = parseFloat(this.tbPointsValues[i].value);
											if(this.targetVisibility)
											{
												if(this.minY > parseFloat(this.tbPointsValues[i].target)) this.minY = parseFloat(this.tbPointsValues[i].target);
												if(this.maxY < parseFloat(this.tbPointsValues[i].target)) this.maxY = parseFloat(this.tbPointsValues[i].target);	
											}
											if(this.minR > parseFloat(this.tbPointsValues[i].dimension)) this.minR = parseFloat(this.tbPointsValues[i].dimension);
											if(this.maxR < parseFloat(this.tbPointsValues[i].dimension)) this.maxR = parseFloat(this.tbPointsValues[i].dimension);
										}
									if(this.minY<0) this.translation = 0-this.minY; else this.translation = 0;
									this.minY = (this.minY + this.translation) * 0.8;
									this.maxY = (this.maxY + this.translation) * 1.2;
								// calculate coordinates
									for(i=0;i<this.tbPointsValues.length;i++)
					 				{
				 						if(this.tbPointsValues[i].value.length != 0)
					 					{
					 						x = 20+i*50;
					 						y = parseInt(this.svgHeight*0.9)-20-
					 						parseInt(((parseFloat(this.tbPointsValues[i].value)+this.translation)-this.minY)*(this.svgHeight*0.8)/(this.maxY-this.minY));
					 						/*if(this.minR != this.maxR) r = 5+parseInt(12*((this.tbPointsValues[i].dimension-this.minR)/(this.maxR-this.minR)));
					 						else*/ r = 11;
						 				}
						 				else
						 				{
						 					x = 20+i*50;
						 					y = parseInt(this.svgHeight*0.9)-20;
						 					r = 0;
						 				}
						 				this.tbPointsValues[i].x = x;
						 				this.tbPointsValues[i].y = y;
						 				this.tbPointsValues[i].r = r;
						 				// same for target values
				 						if(this.tbPointsValues[i].target.length != 0)
					 					{
					 						x = 20+i*50;
					 						y = parseInt(this.svgHeight*0.9)-20-
					 						parseInt(((parseFloat(this.tbPointsValues[i].target)+this.translation)-this.minY)*(this.svgHeight*0.8)/(this.maxY-this.minY));
					 						r = 5;
						 				}
						 				else
						 				{
						 					x = 20+i*60;
						 					y = parseInt(this.svgHeight*0.9)-20;
						 					r = 0;
						 				}
						 				this.tbPointsValues[i].xt = x;
						 				this.tbPointsValues[i].yt = y;
						 				this.tbPointsValues[i].rt = r;
					 				}						
			 				},
		 				contentGraph: function(aTable) 
			 				{
			 					var i, iStart, j, ck, content, r, x, y, xnext, ynext, aColor;
			 					
			 					this.calculate(aTable);
			 					
			 					content = '<text x="3" y="1.2em" fill="#BBBBBB">days</text>'+
			 					//'<text x="'+(this.svgWidth-40)+'" y="'+(this.svgHeight-2)+'" fill="#BBBBBB">time</text>'+
			 					'<line x1="0" y1="0" x2="0" y2="'+(this.svgHeight-15)+'" style="stroke:#EEEEEE;stroke-width:1" />'+
			 					'<line x1="0" y1="'+(this.svgHeight-15)+'" x2="100%" y2="'+(this.svgHeight-15)+'" style="stroke:#000000;stroke-width:1" />';

			 					for(i=0;i<this.noPoints;i++)
			 					{
			 						x = this.tbPointsValues[i].x;
			 						y = parseInt(this.svgHeight*1)-8;
			 						content +=	'<g><line x1="'+x+'" y1="'+(0)+'" x2="'+x+'" y2="'+y+'" style="stroke:#EEEEEE;stroke-width:1" /></g>'+
			 						'<g><line x1="'+x+'" y1="'+(y-15)+'" x2="'+x+'" y2="'+y+'" style="stroke:#BBBBBB;stroke-width:1" /></g>'+
			 						'<g>'+
				 					 	'<text transform="rotate(0 '+(x)+','+(y+5)+')" text-anchor="start" x="'+ (x-10) +'" y="'+ (y+5) +'">'+this.tbPointsValues[i].date+'</text>'+
				 					 '</g>'
			 					}
					 			if(this.targetVisibility) // line and circle for target
					 				for(i=0;i<this.tbPointsValues.length;i++)
					 					if(this.tbPointsValues[i].target.length != 0)
						 				{
						 					x = this.tbPointsValues[i].xt;
							 				y = this.tbPointsValues[i].yt;
						 					if(i < (this.tbPointsValues.length-1))
							 				{
							 					if(this.tbPointsValues[i+1].target.length != 0)
							 					{
							 						xnext = this.tbPointsValues[i+1].xt;
							 						ynext = this.tbPointsValues[i+1].yt;
							 						content += '<line x1="'+x+'" y1="'+y+'" x2="'+xnext+'" y2="'+ynext+'" style="stroke:lightgray;stroke-width:1" />';	
							 					}
											}
											r = this.tbPointsValues[i].rt;
											content += '<g>'+
												'<circle cx="'+ x +'" cy="'+ y +'" r="'+ r +'" fill="lightgray"> <title>'+this.tbPointsValues[i].title+'</title></circle>'+ 
											 	'</g>';	
						 				}
				 				for(i=0;i<this.tbPointsValues.length;i++)
				 				{
				 					if(this.tbPointsValues[i].value.length != 0)
					 				{
					 					x = this.tbPointsValues[i].x;
						 				y = this.tbPointsValues[i].y;
					 					if(i < (this.tbPointsValues.length-1))
						 				{
						 					if(this.tbPointsValues[i+1].value.length != 0)
						 					{
						 						xnext = this.tbPointsValues[i+1].x;
						 						ynext = this.tbPointsValues[i+1].y;
						 						content += '<line x1="'+x+'" y1="'+y+'" x2="'+xnext+'" y2="'+ynext+'" style="stroke:black;stroke-width:1" />';	
						 					}
										}
										if(this.tbPointsValues[i].value > this.tbPointsValues[i].target) aColor = '#E41414'; else aColor = '#00A400';
										r = this.tbPointsValues[i].r;
											content += '<g>'+
											'<circle cx="'+ x +'" cy="'+ y +'" r="'+ r +'" fill="'+aColor+'"> <title>'+this.tbPointsValues[i].title+'</title></circle>'+ 
										 	'</g><g>'+
										 	'<text transform="rotate(0 '+x+','+y+')" text-anchor="start" x="'+ (x+0) +'" y="'+ (y-parseInt(r/2)-7) +'">'+this.tbPointsValues[i].label+'</text>'+
										 	'<title>'+this.tbPointsValues[i].title+'</title>'+
										 	'</g>';	
					 				}
				 				}
				 				document.getElementById(this.tagId).innerHTML = content;
			 				} 
		 			}
		}
	function newPieChart1()
		{
			return {
						tagId: '',
						tbColors: ['red','#00A400','#FCD164','#8E0000'],
						objValue: {value:'',percentage:'',label:'',startA:'',endA:'',color:''},
						aBigLabel: [],
						tbValues: [[]],
						cloneThis: function(proto_obj) {var ret = {}; for (var prop in proto_obj ) {ret[prop] = proto_obj[prop]; }	return ret;},
			 			polarToCartesian: function(centerX, centerY, radius, angleInDegrees) 
							{
								var angleInRadians = (angleInDegrees-90) * Math.PI / 180.0;
								return {x: centerX + (radius * Math.cos(angleInRadians)), y: centerY + (radius * Math.sin(angleInRadians))};
							},
			 			describeArc: function(x, y, radius, startAngle, endAngle)
							{
								var start = this.polarToCartesian(x, y, radius, endAngle);
								var end = this.polarToCartesian(x, y, radius, startAngle);
								var largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
								var d = ["M0 0 ",start.x, start.y,"A", radius, radius, 0, largeArcFlag, 0, end.x, end.y,"L", x,y,"L", start.x, start.y].join(" ");
								return d;
							},
			 			initialize: function(tagId,table,donutNotPie,bandWidth,aBigLabel,tbColors)
			 				{
			 					var i, svgWidth, svgHeight, svgScreen, sumOfAll = 0, content = '', aName;
			 					var rBig, rSmall;
			 					this.tagId = tagId;

			 					svgWidth = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("width"));
								svgHeight = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("height"));
								svgScreen = parseInt(window.getComputedStyle(document.getElementsByTagName('body')[0],null).getPropertyValue("width"));
								if(svgScreen < 1300) {svgHeight = parseInt(0.8*svgHeight);bandWidth = parseInt(0.8*bandWidth);}

								rBig = parseInt((svgHeight-20)/2);
								rSmall = rBig-bandWidth;
								content = '<g transform="translate('+parseInt(svgHeight/2)+','+parseInt(svgHeight/2)+')">';

			 					this.aBigLabel.length = 0; this.aBigLabel = this.cloneThis(aBigLabel);
			 					
			 					if(tbColors.length != 0)
			 					{
			 						this.tbColors.length = tbColors.length; 
			 						for(i=0;i<tbColors.length;i++) this.tbColors[i] = tbColors[i];
			 					}

			 					this.tbValues.length = 0;
			 					for(i=0;i<table.length;i++)
			 					{
			 						sumOfAll += parseFloat(table[i][0]);
			 						this.objValue.value = table[i][0];
			 						this.objValue.label = table[i][1];
			 						this.objValue.color = this.tbColors[i % this.tbColors.length];
			 						this.tbValues[this.tbValues.length] = this.cloneThis(this.objValue);
			 					}
			 					if(sumOfAll != 0)
			 					{
			 						for(i=0;i<this.tbValues.length;i++)
				 					{
				 						this.tbValues[i].percentage = parseInt(100*this.tbValues[i].value/sumOfAll)/100;
				 						if(i == 0) this.tbValues[i].startA = 0;
				 						else this.tbValues[i].startA = this.tbValues[i-1].endA;
				 						if(i == (this.tbValues.length-1)) this.tbValues[i].endA = 360;
				 						else this.tbValues[i].endA = this.tbValues[i].startA + parseInt(360*this.tbValues[i].percentage);
				 						//alert(i+'/'+this.tbValues[i].percentage+': '+this.tbValues[i].startA+'  -  '+this.tbValues[i].endA);
				 						if((this.tbValues[i].startA == 0) && (this.tbValues[i].endA == 360))
				 							content += '<circle cx="0" cy="0" r="'+rBig+'" fill="'+this.tbValues[i].color+'"><title>'+this.tbValues[i].label+' ( '+(100*this.tbValues[i].percentage)+'% )</title></circle>';
				 						else
				 						content +='<path d="'+this.describeArc(0, 0, rBig, this.tbValues[i].startA, this.tbValues[i].endA)+'" fill="'+this.tbValues[i].color+
				 						'" ><title>'+this.tbValues[i].label+' ( '+(100*this.tbValues[i].percentage)+'% )</title></path>';
				 					}
			 					}
			 					else
			 					{
			 						content += '<circle cx="0" cy="0" r="'+rBig+'" fill="#FFFFFF"></circle>';
			 					}
			 					if(donutNotPie == 'true') content += '<circle cx="0" cy="0" r="'+rSmall+'" fill="#FFFFFF"></circle>';
			 					content += '</g>';
			 					
			 					for(i=0;i<this.tbValues.length;i++)
				 					{
				 						//content += '<g><circle cx="'+(svgHeight+5)+'" cy="'+(20+i*20)+'" r="8" fill="'+this.tbColors[i]+'"></circle>'+
				 						//'<text x="'+(svgHeight+25)+'" y="'+(24+i*20)+'"><a style="fill:#1792E5;cursor:pointer;" href="'+tbConst.rootLink+'/apex/nps_surveys" target="_self">'+this.tbValues[i].label+'</a></text></g>';
				 						
				 						content += '<g><circle cx="'+(svgHeight+5)+'" cy="'+(20+i*20)+'" r="8" fill="'+this.tbColors[i]+'"></circle>'+
				 						'<text x="'+(svgHeight+25)+'" y="'+(24+i*20)+'" class="aLink" id="" onClick="goToSurveyPage(&#39;'+tagId+'&#39;,'+i+');" style="fill:#1792E5;">'+this.tbValues[i].label+'</text></g>';
				 					}
			 					content += '<g><text x="'+(parseInt(svgHeight/2)-40)+'" y="'+parseInt(svgHeight/2)+'" style="font-size:3em;">'+this.aBigLabel[0]+'</text>'+
				 					'<text x="'+(parseInt(svgHeight/2)-55)+'" y="'+(parseInt(svgHeight/2)+30)+'" style="font-size:1.5em;"> '+this.aBigLabel[1]+'</text></g>';
				 					document.getElementById(tagId).innerHTML = content;
			 					
			 				}
					}
		}
	function newGraphBars2()
		{
			return {
						tbBarsValues: [],
						objBars: {value1: '', value2: '', label: '', title: ''},
						tagId: '',
						minY: 0,
						maxY:0,
						translation: 0,
						noBars: 0,
						svgWidth: 0,
						svgHeight: 0,
						cloneThis: function(proto_obj) {var ret = {}; for (var prop in proto_obj ) {ret[prop] = proto_obj[prop]; }	return ret;},
						initialize: function(tagId)
							{
								this.tagId = tagId;
								this.svgWidth = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("width"));
								this.svgHeight = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("height"));
								this.noBars = parseInt((this.svgWidth)/60)+1;
								this.translation = 0;
							}, 					
						calculate: function()
			 				{
			 					var i;
			 					this.minY = parseFloat(this.tbBarsValues[0].value1); 
								this.maxY = parseFloat(this.tbBarsValues[0].value1);
			 					for(i=0;i<this.tbBarsValues.length;i++)
									if(this.tbBarsValues[i].value != '')
									{
										if(this.minY > parseFloat(this.tbBarsValues[i].value1)) this.minY = parseFloat(this.tbBarsValues[i].value1);
										if(this.maxY < parseFloat(this.tbBarsValues[i].value1)) this.maxY = parseFloat(this.tbBarsValues[i].value1);
										if(this.minY > parseFloat(this.tbBarsValues[i].value2)) this.minY = parseFloat(this.tbBarsValues[i].value2);
										if(this.maxY < parseFloat(this.tbBarsValues[i].value2)) this.maxY = parseFloat(this.tbBarsValues[i].value2);
									}
								
								if(this.minY<0) this.translation = 0-this.minY; else this.translation = 0;
								this.minY = (this.minY + this.translation) * 0.8;
								this.maxY = (this.maxY + this.translation) * 1.2;;
			 				},
						contentGraph: function(aTable) 
		 				{
		 					var i, content, h1, h2, x, y1, y2, anY;
		 					this.tbBarsValues.length = 0;	 					
		 					for(i=0;i<this.noBars;i++)
		 					{
		 						this.objBars.value1 = aTable[i][0]; 
		 						this.objBars.value2 = aTable[i][1];
		 						this.objBars.label = aTable[i][2];
		 						this.objBars.title = aTable[i][3];
		 						this.objBars.date = aTable[i][4];
		 						this.tbBarsValues[this.tbBarsValues.length] = this.cloneThis(this.objBars);
		 					}
		 					this.calculate();

		 					content = '<text x="3" y="1.2em" fill="#BBBBBB">responses</text>'+
		 					//'<text x="'+(this.svgWidth-50)+'" y="'+(this.svgHeight-8)+'" fill="#BBBBBB">time</text>'+
		 						'<line x1="0" y1="0" x2="0" y2="'+(this.svgHeight-15)+'" style="stroke:#EEEEEE;stroke-width:1" />'+
			 					'<line x1="0" y1="'+(this.svgHeight-40)+'" x2="100%" y2="'+(this.svgHeight-40)+'" style="stroke:#000000;stroke-width:1" />';

		 					for(i=0;i<this.noBars;i++)
		 					{
		 						x = 20+i*50;
		 						y = parseInt(this.svgHeight*1)-23;
		 						content +=	'<g><line x1="'+x+'" y1="'+(0)+'" x2="'+x+'" y2="'+y+'" style="stroke:#EEEEEE;stroke-width:1" /></g>'+
		 						'<g><line x1="'+x+'" y1="'+(y-25)+'" x2="'+x+'" y2="'+(y-20)+'" style="stroke:#BBBBBB;stroke-width:1" /></g>'+
		 						'<g>'+
			 					 	'<text transform="rotate(0 '+(x)+','+(y-5)+')" text-anchor="start" x="'+ (x-10) +'" y="'+ (y-5) +'">'+this.tbBarsValues[i].date+'</text>'+
			 					 '</g>';
		 					}
		 					content += '<g><circle cx="5" cy="'+ (this.svgHeight - 5) +'" r="5" fill="lightblue"> </circle>'+
		 					'<text transform="rotate(0 15,'+(this.svgHeight - 1)+')" text-anchor="start" x="15" y="'+ (this.svgHeight - 1) +'">number of requests</text>'+
		 					'<circle cx="140" cy="'+ (this.svgHeight - 5) +'" r="5" fill="blue"> </circle>'+
		 					'<text transform="rotate(0 150,'+(this.svgHeight - 1)+')" text-anchor="start" x="150" y="'+ (this.svgHeight - 1) +'">number of responses</text>'+
		 					'</g>'; 
		 					
		 					
		 					//if(this.minY != this.maxY) 
		 					{
		 						for(i=0;i<this.tbBarsValues.length;i++)
				 				{
				 					if((this.tbBarsValues[i].value1.length != 0) && (this.minY != this.maxY))
					 					{
					 						h1 = parseInt(this.svgHeight*0.9*((parseFloat(this.tbBarsValues[i].value1)+this.translation)-this.minY)/(this.maxY-this.minY));
						 					x = 10+i*50;
						 					y1 = parseInt(this.svgHeight*0.9)-30-h1;
						 				}
						 				else
						 				{
						 					h1 = 0;
						 					x = 10+i*50;
						 					y1 = parseInt(this.svgHeight*0.9)-30-h1;
						 				}
					 				if((this.tbBarsValues[i].value2.length != 0) && (this.minY != this.maxY))
					 					{
					 						h2 = parseInt(this.svgHeight*0.9*((parseFloat(this.tbBarsValues[i].value2)+this.translation)-this.minY)/(this.maxY-this.minY));
						 					x = 10+i*50;
						 					y2 = parseInt(this.svgHeight*0.9)-30-h2;
						 				}
						 				else
						 				{
						 					h2 = 0;
						 					x = 10+i*50;
						 					y2 = parseInt(this.svgHeight*0.9)-30-h2;
						 				}
						 			if(y1<y2) anY = y1; else anY = y2;
									content += 
									'<g>'+
										'<rect x="'+x+'" y="'+y1+'" width="20" height="'+h1+'" style="fill:lightblue;">'+
										'<title>'+this.tbBarsValues[i].title+'</title>'+
									 '</g>'+
									 '<g>'+
										'<rect x="'+(x+10)+'" y="'+y2+'" width="20" height="'+h2+'" style="fill:blue;">'+
										'<title>'+this.tbBarsValues[i].title+'</title>'+
									 '</g>'+
									 '<g>'+
				 					 	//'<text transform="rotate(0 '+x+','+(anY-2)+')" text-anchor="start" x="'+ (x+0) +'" y="'+ (anY-2) +'" style="fill:black;">'+this.tbBarsValues[i].label+'</text>'+
				 					 	//'<text transform="rotate(0 '+x+','+(anY-2)+')" text-anchor="start" x="'+ (x-5) +'" y="'+ (y1-2) +'" style="fill:black;">'+this.tbBarsValues[i].label.split(' / ')[0]+'</text>'+
				 					 	'<text text-anchor="start" x="'+ (x-5) +'" y="'+ (y1-2) +'" style="fill:black;">'+this.tbBarsValues[i].label.split(' / ')[0]+'</text>'+
				 					 	'<title>'+this.tbBarsValues[i].title+'</title>'+
				 					 '</g>'+
									 '<g>'+
				 					 	//'<text transform="rotate(0 '+x+','+(anY-2)+')" text-anchor="start" x="'+ (x+0) +'" y="'+ (anY-2) +'" style="fill:black;">'+this.tbBarsValues[i].label+'</text>'+
				 					 	'<text text-anchor="start" x="'+ (x+15) +'" y="'+ (y2-2) +'" style="fill:black;">'+this.tbBarsValues[i].label.split(' / ')[1]+'</text>'+
				 					 	'<title>'+this.tbBarsValues[i].title+'</title>'+
				 					 '</g>';
				 				}	
		 					}
		 					
			 				document.getElementById(this.tagId).innerHTML = content;
		 				} 
					}
		}
	function newGraphBars3()
		{
			return {
		 				tbBarsValues: [],
		 				objBars: {value: '', label: '', title: ''},
		 				tagId: '',
		 				minY: 0,
		 				maxY:0,
		 				translation: 0,
		 				noBars: 0,
		 				svgWidth: 0,
		 				svgHeight: 0,
		 				cloneThis: function(proto_obj) {var ret = {}; for (var prop in proto_obj ) {ret[prop] = proto_obj[prop]; }	return ret;},
		 				initialize: function(tagId)
		 					{
		 						this.tagId = tagId;
		 						this.svgWidth = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("width"));
								this.svgHeight = parseInt(window.getComputedStyle(document.getElementById(tagId),null).getPropertyValue("height"));
								this.noBars = parseInt((this.svgWidth-50)/60)+1;

		 					},
		 				calculate: function()
			 				{
			 					var i;
			 					for(i=0;i<this.tbBarsValues.length;i++)
									if(this.tbBarsValues[i].value != '')
									{
										if(i == 0) 
										{
											this.minY = parseFloat(this.tbBarsValues[i].value); 
											this.maxY = parseFloat(this.tbBarsValues[i].value);
										}
										else
										{
											if(this.minY > parseFloat(this.tbBarsValues[i].value)) this.minY = parseFloat(this.tbBarsValues[i].value);
											if(this.maxY < parseFloat(this.tbBarsValues[i].value)) this.maxY = parseFloat(this.tbBarsValues[i].value);
										}	
									}
								
								if(this.minY < 0) this.translation = 0.0 - this.minY; 
								else this.translation = 0;
			 				},
			 			drawThis: function(i,x,y,h,y1,aColor)
				 				{
									var aContent = '';
				 					aContent = '<line x1="0" y1="'+y1+'" x2="100%" y2="'+y1+'" style="stroke:black;stroke-width:1" />';
									aContent += '<g>'+
										'<rect x="'+x+'" y="'+y+'" width="20" height="'+h+'" style="fill:'+aColor+';">'+
										'<title>'+this.tbBarsValues[i].title+'</title>'+
									 '</g>'+
									 '<g>'+
				 					 	'<text transform="rotate(-45 '+x+','+y+')" text-anchor="start" x="'+ (x+10) +'" y="'+ y +'">'+this.tbBarsValues[i].label+'</text>'+
				 					 	'<title>'+this.tbBarsValues[i].title+'</title>'+
				 					 '</g>';
				 					 return aContent;
				 				},
		 				contentGraph: function(aTable) 
			 				{
			 					var i, content, h, x, y, y1, aColor;
			 					this.tbBarsValues.length = 0;
			 					for(i=0;i<this.noBars;i++)
			 					{
			 						if(aTable[i] != undefined )
			 						{
			 							this.objBars.value = aTable[i][0];
			 							this.objBars.label = aTable[i][1];
			 							this.objBars.title = aTable[i][2]; 
			 						}
			 						else 
			 						{
			 							this.objBars.value = '';
			 							this.objBars.label = '';
			 							this.objBars.title = ''; 
			 						}
			 						this.tbBarsValues[this.tbBarsValues.length] = this.cloneThis(this.objBars);
			 					}
			 					
			 					this.calculate();
			 					content = '<text x="3" y="1.2em" fill="#BBBBBB">score fulfillment</text>'+
			 					'<text x="'+(this.svgWidth-50)+'" y="'+(this.svgHeight-8)+'" fill="#BBBBBB">account</text>'+
			 					'<line x1="0" y1="0" x2="0" y2="100%" style="stroke:rgb(150,150,150);stroke-width:1" />'+
			 					'<line x1="0" y1="100%" x2="100%" y2="100%" style="stroke:rgb(150,150,150);stroke-width:1" />';
			 					if(this.translation == 0)
			 					{
			 						y1 = this.svgHeight-20;
			 						for(i=0;i<this.tbBarsValues.length;i++)
					 					if(this.tbBarsValues[i].value != '')
				 						{
				 							h = parseInt((this.svgHeight-100)*((parseFloat(this.tbBarsValues[i].value)))/(this.maxY));
				 							x = 20+i*60;
				 							y = y1-h;
				 							this.tbBarsValues[i].title = this.tbBarsValues[i].title;
				 							aColor = '#00A400';//kind of green
				 							content += this.drawThis(i,x,y,h,y1,aColor);			 							
				 						}
			 					} 
			 					else 
			 					{
			 						if((this.maxY < 0))
			 						{
			 							y1 = 70;
			 							for(i=0;i<this.tbBarsValues.length;i++)
					 					if(this.tbBarsValues[i].value != '')
				 						{
				 							h = parseInt((this.svgHeight-100)*((parseFloat(this.tbBarsValues[i].value)))/(this.minY));
					 						x = 20+i*60;
					 						y = y1;
					 						this.tbBarsValues[i].title = this.tbBarsValues[i].title;// + ' : ' +h;
					 						aColor = '#E41414';//kind of red
					 						content += this.drawThis(i,x,y,h,y1,aColor);
				 						}
			 						}
			 						else
			 						{
			 							y1 = this.svgHeight-parseInt((this.svgHeight)*(this.translation/(this.maxY+this.translation)));
			 							if(y1<70) y1 = 70;
			 							if(y1>(this.svgHeight-20)) y1 = this.svgHeight-20;
			 							
			 							for(i=0;i<this.tbBarsValues.length;i++)
					 					if(this.tbBarsValues[i].value != '')
				 						{
				 							if(this.tbBarsValues[i].value >= 0)
				 							{
				 								h = parseInt(0.7*(y1)*((parseFloat(this.tbBarsValues[i].value)))/(this.maxY));
					 							x = 20+i*60;
					 							y = y1-h;
					 							aColor = '#00A400';//kind of green
				 							}
				 							else
				 							{
				 								h = parseInt(0.9*(this.svgHeight-y1)*((parseFloat(this.tbBarsValues[i].value)))/(this.minY));
						 						x = 20+i*60;
						 						y = y1;
						 						aColor = '#E41414';//kind of red
				 							}

				 							this.tbBarsValues[i].title = this.tbBarsValues[i].title;
					 						content += this.drawThis(i,x,y,h,y1,aColor);
				 						}		
			 						}
			 					}
				 				document.getElementById(this.tagId).innerHTML = content;
			 				} 
		 			}
		}

var objTrendDP = newDateRangePicker();
var objResponsesDP = newDateRangePicker();
var objRequestsDP = newDateRangePicker();
var objClosureDP = newDateRangePicker();
var objAccountsRP = newRangePicker();
var objTrendSVG = newGraphPoints2();
var objClosureSVG = newGraphPoints3();
var	objContactsAvailable = newPieChart1(); 
var	objContactsResponded = newPieChart1();
var objResponsesSVG = newGraphBars2();
var objRequestsSVG = newGraphBars2();
var objAccountsSVG = newGraphBars3();

var objSelectionChildAccounts = newInputRadioOrCheckbox();
var objSelectionChart1 = newInputRadioOrCheckbox();
var objSelectionChart2 = newInputRadioOrCheckbox();
var objSelectionObjectives = newInputRadioOrCheckbox();

function initializeTheRestOfThem() // function accessed from SFDC Home_page
	{
		var i, j, ck, aTable = [], listTempObjectives = [];
		
		createTouchpointsTables();
		createCategoriesTables();
		adjustActionResponses();
		
		listActionTypeAll.length = 0; 
		for(i=0;i<listActionType.length;i++) listActionTypeAll[listActionTypeAll.length] = listActionType[i]; 
		listActionTypeAll.unshift(tbConst.ALL);
		
		listActionStatusAll.length = 0; listActionStatusAll[0] = 'All Open';
		for(i=0;i<listActionStatus.length;i++) listActionStatusAll[listActionStatusAll.length] =listActionStatus[i]; 
		listActionStatusAll.unshift(tbConst.ALL);
		
		listFunctionalTeamAll.length = 0; 
		for(i=0;i<listFunctionalTeam.length;i++) listFunctionalTeamAll[listFunctionalTeamAll.length] = listFunctionalTeam[i]; 
		listFunctionalTeamAll.unshift(tbConst.ALL);

		createTargetsArray();
			listParentAccounts.sort();
            listRegionsAll.sort();
            listDEEPNall.sort();
            listLOBall.sort();
            listPlantsAll.sort();
            listAccounts.sort(function(a,b)
				{
					var x = a[0].toLowerCase();
					var y = b[0].toLowerCase();
					if(x > y) return 1;
					if(x < y) return -1;					
					else return 0;
				});

		// initialize listObjectives				
			listTempObjectives.length = 0;

			listTempObjectives[0] = cloneThis(anObjective);
			listTempObjectives[0].name = tbConst.ALL;
			listTempObjectives[0].type = tbConst.ALL;
			listTempObjectives[0].visibility = '2';
			listTempObjectives[0].indexResponses = '-1';
			listTempObjectives[0].indexContacts = '-1';
			
			for(i=1;i<listLOBall.length;i++)
				if(listLOBall[i][1] != '0') 
					{
						anObjective.name = listLOBall[i][0];
						anObjective.type = tbConst.LOB;
						anObjective.visibility = '0';
						anObjective.indexResponses = '-1';
						anObjective.indexContacts = '-1';
						listTempObjectives[listTempObjectives.length] = cloneThis(anObjective);
					}
			for(i=0;i<listDEEPNall.length;i++)
				{
					anObjective.name = listDEEPNall[i];
					anObjective.type = tbConst.DEEPN;
					anObjective.visibility = '0';
					anObjective.indexResponses = '-1';
					anObjective.indexContacts = '-1';
					listTempObjectives[listTempObjectives.length] = cloneThis(anObjective);
				}			
			for(i=1;i<listPlantsAll.length;i++)
				{				
					anObjective.name = listPlantsAll[i];
					anObjective.type = tbConst.Plant;
					anObjective.visibility = '0';
					anObjective.indexResponses = '-1';
					anObjective.indexContacts = '-1';
					listTempObjectives[listTempObjectives.length] = cloneThis(anObjective);
				}
			for(i=1;i<listRegionsAll.length;i++)
				if(listRegionsAll[i][1] != '0') 
					{
						anObjective.name = listRegionsAll[i][0];
						anObjective.type = tbConst.Region;
						anObjective.visibility = '0';
						anObjective.indexResponses = '-1';
						anObjective.indexContacts = '-1';
						listTempObjectives[listTempObjectives.length] = cloneThis(anObjective);
					}				
			for(i=0;i<listParentAccounts.length;i++)
				if(listParentAccounts[i][1] != '0') 
					{
						anObjective.name = listParentAccounts[i][0];
						anObjective.type = tbConst.ParentAccount;
						anObjective.visibility = '0';
						anObjective.indexResponses = '-1';
						anObjective.indexContacts = '-1';
						listTempObjectives[listTempObjectives.length] = cloneThis(anObjective);	
					}
			for(i=0;i<listAccounts.length;i++)
				if(listAccounts[i][1] != '0') 
					{
						anObjective.name = listAccounts[i][0];
						anObjective.type = tbConst.Account;
						anObjective.region = listAccounts[i][2];
						anObjective.visibility = '0';
						anObjective.indexResponses = '-1';
						anObjective.indexContacts = '-1';
						listTempObjectives[listTempObjectives.length] = cloneThis(anObjective);	
					}
		// associate each Objective with the indexes in allMonthlyNPS and allHouses
			for(i=0;i<listTempObjectives.length;i++)
			{
				for(j=0;j<allMonthlyNPS.length;j++)
					if((allMonthlyNPS[j][0].type == listTempObjectives[i].type) && (allMonthlyNPS[j][0].name == listTempObjectives[i].name)) 
						listTempObjectives[i].indexResponses = j;

				for(j=0;j<allHouses.length;j++)
					if((allHouses[j].type == listTempObjectives[i].type) && (allHouses[j].name == listTempObjectives[i].name)) 
						listTempObjectives[i].indexContacts = j;
			}
		// because from Contacts can not be check the accuracy of data related to NPS the next code was inserted
			listObjectives.length = 0;
			for(i=0;i<listTempObjectives.length;i++)
			{
				if((listTempObjectives[i].indexResponses != -1) && (listTempObjectives[i].indexContacts != -1))
					listObjectives[listObjectives.length] = cloneThis(listTempObjectives[i]);
			}
		// calcultate other values in allMonthlyNPS
			countMonthlyValues();
			calculateWeightedNPS();
	}
function createTargetsArray()
	{
		var i, j, ck, aList = [], aTable = [[]];
		
		var newMonth = Date.parse('1 January 2015 '), lastMonth = newMonth, dateConverted;
		for(i=0;i<allNPSobjectives.length;i++)
			if(lastMonth < allNPSobjectives[i].dateStart) lastMonth = allNPSobjectives[i].dateStart;

		dateConverted = new Date(lastMonth);
		lastMonth =  Date.parse(new Date(dateConverted.getFullYear(),11,1)); 
		
		allNPStargets.length = 0;otherNPStargets.length = 0;
		while(newMonth <= lastMonth)
		{
			allNPStargets[allNPStargets.length] = [newMonth,''];
			otherNPStargets[otherNPStargets.length] = [newMonth,''];
			dateConverted = new Date(newMonth);
			newMonth = Date.parse(new Date(dateConverted.getFullYear(),dateConverted.getMonth()+1,1)); 
		}
		allNPStargets[allNPStargets.length] = [newMonth,''];
		otherNPStargets[otherNPStargets.length] = [newMonth,''];
		
		for(i=0;i<allNPSobjectives.length;i++)
			if(allNPSobjectives[i].type != 'Other')
				for(j=0;j<allNPStargets.length;j++)
				{
					if(allNPStargets[j][1].indexOf(allNPSobjectives[i].objName) != -1)
					{
						if(allNPSobjectives[i].dateStart <= allNPStargets[j][0])
						{
							aList.length = 0;
							aList = allNPStargets[j][1].split(';');
							aTable.length = 0;
							for(k=0;k<aList.length;k++)
							{
								aTable[aTable.length] = [aList[k].split(':')[0],aList[k].split(':')[1],aList[k].split(':')[2]];
								if((aTable[aTable.length-1][0] == allNPSobjectives[i].objName) && (aTable[aTable.length-1][2] <= allNPSobjectives[i].dateStart))
								{
									aTable[aTable.length-1][1] = allNPSobjectives[i].objValue;
									aTable[aTable.length-1][2] = allNPSobjectives[i].dateStart;
								}
							}
							allNPStargets[j][1] = '';
							for(k=0;k<aTable.length;k++)
								if(allNPStargets[j][1].length == 0) allNPStargets[j][1] = aTable[k][0]+':'+aTable[k][1]+':'+aTable[k][2];
								else allNPStargets[j][1] += ';'+aTable[k][0]+':'+aTable[k][1]+':'+aTable[k][2];
						}
					}
					else
					{
						if(allNPSobjectives[i].dateStart <= allNPStargets[j][0])
						{
							if(allNPStargets[j][1].length == 0) allNPStargets[j][1] = allNPSobjectives[i].objName+':'+allNPSobjectives[i].objValue+':'+allNPSobjectives[i].dateStart;
							else allNPStargets[j][1] += ';'+allNPSobjectives[i].objName+':'+allNPSobjectives[i].objValue+':'+allNPSobjectives[i].dateStart;	
						}
					}
				}
			else
			{
				if(allNPSobjectives[i].objName != 'adminNPS')
				for(j=0;j<otherNPStargets.length;j++)
				{
					if(otherNPStargets[j][1].indexOf(allNPSobjectives[i].objName) != -1)
					{
						if(allNPSobjectives[i].dateStart <= otherNPStargets[j][0])
						{
							aList.length = 0;
							aList = otherNPStargets[j][1].split(';');
							aTable.length = 0;
							for(k=0;k<aList.length;k++)
							{
								aTable[aTable.length] = [aList[k].split(':')[0],aList[k].split(':')[1],aList[k].split(':')[2]];
								if((aTable[aTable.length-1][0] == allNPSobjectives[i].objName) && (aTable[aTable.length-1][2] <= allNPSobjectives[i].dateStart))
								{
									aTable[aTable.length-1][1] = allNPSobjectives[i].objValue;
									aTable[aTable.length-1][2] = allNPSobjectives[i].dateStart;
								}
							}
							otherNPStargets[j][1] = '';
							for(k=0;k<aTable.length;k++)
								if(otherNPStargets[j][1].length == 0) otherNPStargets[j][1] = aTable[k][0]+':'+aTable[k][1]+':'+aTable[k][2];
								else otherNPStargets[j][1] += ';'+aTable[k][0]+':'+aTable[k][1]+':'+aTable[k][2];
						}
					}
					else
					{
						if(allNPSobjectives[i].dateStart <= otherNPStargets[j][0])
						{
							if(otherNPStargets[j][1].length == 0) otherNPStargets[j][1] = allNPSobjectives[i].objName+':'+allNPSobjectives[i].objValue+':'+allNPSobjectives[i].dateStart;
							else otherNPStargets[j][1] += ';'+allNPSobjectives[i].objName+':'+allNPSobjectives[i].objValue+':'+allNPSobjectives[i].dateStart;	
							//if(allNPSobjectives[i].objName.indexOf('closureDaysResponse') != -1) alert(otherNPStargets[j][1]);
						}
					}
				}
			}
	}
function countMonthlyValues()
	{
		var i, j, k, kk, ck, earlyJ, aString = '', aTable = [], anotherTable = [[]], aCounter, aName, allTarget;
		for(i=0;i<allMonthlyNPS.length;i++)
			for(j=0;j<tbDateRef.length;j++)
			{
				// count for different things
				if(j>12) earlyJ = j-11; else earlyJ = 0;
				aString = ''; anotherTable.length = 0;
				
				//for(k=earlyJ;k<=j;k++)
				for(k=j;k>=earlyJ;k--)
				{
					if(allMonthlyNPS[i][k].monthlyContacted.length != 0)
					{
						if(aString.length == 0) aString = allMonthlyNPS[i][k].monthlyContacted;
						else aString += ';' + allMonthlyNPS[i][k].monthlyContacted;
					}
					if(allMonthlyNPS[i][k].aboutMonthlyContacted.length > 0)
					{
						aTable.length = 0;
						aTable = allMonthlyNPS[i][k].aboutMonthlyContacted.split(';');
						
						for(kk = 0; kk<aTable.length; kk++)
						{
							ck = true;
							for(kkk = 0;kkk<anotherTable.length;kkk++)
								if(aTable[kk].indexOf(anotherTable[kkk][0]) != -1) ck= false;
							if(ck) anotherTable[anotherTable.length] = [aTable[kk].split(',')[0],aTable[kk].split(',')[1],aTable[kk].split(',')[2]];
						}
					}
				}
				allMonthlyNPS[i][j].responses12 = 0;
				allMonthlyNPS[i][j].promoters12 = 0;
				allMonthlyNPS[i][j].detractors12 = 0;
				
				for(kk = 0; kk<anotherTable.length; kk++)
				{
					allMonthlyNPS[i][j].responses12++;
					if(parseInt(anotherTable[kk][1]) > 8) allMonthlyNPS[i][j].promoters12++;
					if(parseInt(anotherTable[kk][1]) < 7) allMonthlyNPS[i][j].detractors12++;
					if(allMonthlyNPS[i][j].responses12 > 0) allMonthlyNPS[i][j].NPS = parseInt(1000*(allMonthlyNPS[i][j].promoters12 - allMonthlyNPS[i][j].detractors12)/allMonthlyNPS[i][j].responses12)/10;
				}
				aTable.length = 0;aCounter = 0;
				aTable = aString.split(';');
				aTable.sort();
				for(k=0;k<aTable.length;k++)
					if(k<(aTable.length-1))
					{
						if(aTable[k] != aTable[k+1]) aCounter++; 
					}
					else aCounter++;
				allMonthlyNPS[i][j].yearlyUniques = aCounter;
				
				// add the targets
				if(allMonthlyNPS[i][j].type == tbConst.Account)
				{
					for(kk=0;kk<listParentAccounts.length;kk++)
						if(listParentAccounts[kk][2].indexOf(allMonthlyNPS[i][j].type) != -1) aName = listParentAccounts[kk][0];
				}
				else aName = allMonthlyNPS[i][j].name;

				for(k=0;k<allNPStargets.length;k++)
					//if(allMonthlyNPS[i][j].dateRef == Date.parse(allNPStargets[k][0]))
					if(allMonthlyNPS[i][j].dateRef == allNPStargets[k][0])
					{
						aTable.length = 0;
						aTable = allNPStargets[k][1].split(';');
						ck = true;

						for(kk=0;kk<aTable.length;kk++)
							{
								if(aName == aTable[kk].split(':')[0])
								{
									allMonthlyNPS[i][j].targetNPS = aTable[kk].split(':')[1];
									ck = false;
								}
								if(aTable[kk].split(':')[0] == tbConst.ALL) allTarget = aTable[kk].split(':')[1];
								
							}
						if(ck) allMonthlyNPS[i][j].targetNPS = allTarget;	
					}
			}
	}
function calculateWeightedNPS()
	{
		var i, j, k, indexLVD = -1, indexLVG = -1, indexCV = -1, indexIAM = -1, aTable = [], coeffLVG, coeffLVD, coeffIAM, coeffCV;
		var aux = 0;
		for(i=0;i<allMonthlyNPS.length;i++)
		{
			if((allMonthlyNPS[i][0].type == tbConst.LOB) && (allMonthlyNPS[i][0].name.indexOf('Gasoline') != -1)) indexLVG = i;
			if((allMonthlyNPS[i][0].type == tbConst.LOB) && (allMonthlyNPS[i][0].name.indexOf('Diesel') != -1)) indexLVD = i;
			if((allMonthlyNPS[i][0].type == tbConst.LOB) && (allMonthlyNPS[i][0].name.indexOf('Commercial') != -1)) indexCV = i;
			if((allMonthlyNPS[i][0].type == tbConst.LOB) && (allMonthlyNPS[i][0].name.indexOf('Aftermarket') != -1)) indexIAM = i;
		}
		if((indexLVG > 0) && (indexLVD > 0) && (indexCV > 0) && (indexIAM > 0))
			for(i=0;i<(tbDateRef.length-1);i++)
			{
				
				if((parseFloat(allMonthlyNPS[indexLVG][i].NPS) != 'NaN') && 
					(parseFloat(allMonthlyNPS[indexLVD][i].NPS) != 'NaN') && 
					(parseFloat(allMonthlyNPS[indexCV][i].NPS) != 'NaN') && 
					(parseFloat(allMonthlyNPS[indexIAM][i].NPS) != 'NaN'))
				{
					
					for(j=0;j<otherNPStargets.length;j++)
					{
						if((otherNPStargets[j][0] == tbDateRef[i]) && (otherNPStargets[j][1].indexOf('coeff') != -1))
						{
							aTable = otherNPStargets[j][1].split(';');
							for(k=0;k<aTable.length;k++)
							{
								if(aTable[k].indexOf('coeffLVG') != -1) coeffLVG = parseFloat(aTable[k].split(':')[1]);
								if(aTable[k].indexOf('coeffLVD') != -1) coeffLVD = parseFloat(aTable[k].split(':')[1]); 
								if(aTable[k].indexOf('coeffCV') != -1) coeffCV = parseFloat(aTable[k].split(':')[1]);
								if(aTable[k].indexOf('coeffIAM') != -1) coeffIAM = parseFloat(aTable[k].split(':')[1]);
							}
							allMonthlyNPS[0][i].NPS = parseInt(10*
							(allMonthlyNPS[indexLVG][i].NPS*coeffLVG + 
							allMonthlyNPS[indexLVD][i].NPS*coeffLVD + 
							allMonthlyNPS[indexCV][i].NPS*coeffCV + 
							allMonthlyNPS[indexIAM][i].NPS*coeffIAM)/(coeffLVG+coeffLVD+coeffCV+coeffIAM))/10;
						}
					}
				}
			}
	}

function initializeHome()
	{
		document.getElementById('B12-sSelectObjectives').style.display = 'block';
		document.getElementById('B2-sGraphicView').style.display = 'block';
		
		createTouchpointsMap();

		contentLiveInterval();
		contentSelectionsHome();

		eventsHome();
		selectThisObjective(0,'');
	}

function contentLiveInterval()
	{
		var dateConverted, ord;
		
		dateConverted = new Date(oneYearAgo);
		switch(dateConverted.getDate())
		{
			case '1': ord = 'st';break;
			case '2': ord = 'nd';break;
			case '3': ord = 'rd';break;
			default: ord = 'th';
		}
		document.getElementById('B2-txtStartingDate').innerHTML = '1<sup>st</sup> '+tbMonths[dateConverted.getMonth()]+' '+dateConverted.getFullYear();
	}
function contentAllObjectives()
	{
		var i, table = [];
		var j, table2 = [[]], anotherTable = [], index, content = '', name='B12-ckAllObjectives' ;
		var score12, targetMark = '';
		
		index = listObjectives[0].indexResponses; 
		score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
		target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;			
		if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
		else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';

		content = '<div class="sAreaSmall pushOut1 pushOutLeft05">'+
			'<label id="'+name+'0label" class="sAreaSmall pushOutRight1 noWrap inputUnselected"><input id="'+name+'0" type="radio" name="'+
				name+'" class="displayNone"></input>'+listObjectives[0].name+'&nbsp;&nbsp;&nbsp;&nbsp;'+targetMark+'&nbsp'+score12+'</label></div>';

		content += '<div class="sAreaSmall pushOut1 pushOutLeft05">'+
		'<p class="fontBold pushOutRight1">GBE:</p><div id="B12-ckGBEContainer">';
		 
		for(i=1;i<listObjectives.length;i++)
			if((listObjectives[i].type == tbConst.LOB) && (listObjectives[i].type != tbConst.ALL))
			{
				index = listObjectives[i].indexResponses; 
				score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
				//if(allMonthlyNPS[index][tbDateRef.length-2].target == null) target = '27'; else 
				target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;			
				if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
				else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';

				content += '<label id="'+name+(i)+'label" class="sAreaSmall pushOutRight1 noWrap inputUnselected"><input id="'+name+(i)+'" type="radio" name="'+
				name+'" class="displayNone"></input>'+listObjectives[i].name+'&nbsp;&nbsp;&nbsp;&nbsp;'+targetMark+'&nbsp'+score12+'</label>'; 
			}
		content += '</div></div>';
		// DEEPN start
		content += '<div class="sAreaSmall pushOut1 pushOutLeft05">'+
			'<p class="fontBold pushOutRight1">DEEPN:</p><div id="B12-ckDEEPNContainer">';
		 
		for(i=1;i<listObjectives.length;i++)
			if((listObjectives[i].type == tbConst.DEEPN) && (listObjectives[i].type != tbConst.ALL))
			{
				index = listObjectives[i].indexResponses; 
				score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
				//if(allMonthlyNPS[index][tbDateRef.length-2].target == null) target = '27'; else 
				target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;			
				if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
				else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';

				content += '<label id="'+name+(i)+'label" class="sAreaSmall pushOutRight1 noWrap inputUnselected"><input id="'+name+(i)+'" type="radio" name="'+
				name+'" class="displayNone"></input>'+listObjectives[i].name+'&nbsp;&nbsp;&nbsp;&nbsp;'+targetMark+'&nbsp'+score12+'</label>'; 
			}
		content += '</div></div>';
		// DEEPN end
		// Plant start
		content += '<div class="sAreaSmall pushOut1 pushOutLeft05">'+
			'<p class="fontBold pushOutRight1">Plant:</p><div id="B12-ckDEEPNContainer">';
		 
		for(i=1;i<listObjectives.length;i++)
			if((listObjectives[i].type == tbConst.Plant) && (listObjectives[i].type != tbConst.ALL))
			{
				index = listObjectives[i].indexResponses; 
				score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
				target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;			
				if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
				else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';

				content += '<label id="'+name+(i)+'label" class="sAreaSmall pushOutRight1 noWrap inputUnselected"><input id="'+name+(i)+'" type="radio" name="'+
				name+'" class="displayNone"></input>'+listObjectives[i].name+'&nbsp;&nbsp;&nbsp;&nbsp;'+targetMark+'&nbsp'+score12+'</label>'; 
			}
		content += '</div></div>';
		// Plant end
		content += '<div class="sAreaSmall pushOut1 pushOutLeft05">'+
						'<p class="fontBold pushOutRight1">Region:</p><div id="B12-ckRegionContainer">';
		for(i=1;i<listObjectives.length;i++)				
			if((listObjectives[i].type == tbConst.Region) && (listObjectives[i].type != tbConst.ALL))
			{
				index = listObjectives[i].indexResponses; 
				score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
				target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;
				if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
				else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';

				content += '<label id="'+name+(i)+'label" class="sAreaSmall pushOutRight1 noWrap inputUnselected"><input id="'+name+(i)+'" type="radio" name="'+
				name+'" class="displayNone"></input>'+listObjectives[i].name+'&nbsp;&nbsp;&nbsp;&nbsp;'+targetMark+'&nbsp'+score12+'</label>'; 
			}
		content += '</div></div>';

		table2.length = 0;  index = -1; // table2 contains the first letter and all accounts starting with that letter (as string of indexes)
		for(i=0;i<listObjectives.length;i++)
			if(listObjectives[i].type == tbConst.ParentAccount)
			{
				if(index == -1) {index = 0; table2[0] = [listObjectives[i].name[0],i+';'];}
				else
				{
					if(listObjectives[i].name[0] == table2[index][0]) table2[index][1] += i + ';';
					else
					{
						index++;
						table2[index] = [listObjectives[i].name[0],i+';'];
					}			
				}
			}
		
		content += '<div class="sAreaSmall pushOut1 pushOutLeft05">'+
						'<p class="fontBold pushOutRight1">Parent Account:</p><div id="B12-ckParentAccountContainer">'+
						'<table><tbody>';
		for(i=0;i<table2.length;i++)
		{
			content += '<tr><td class="textTop">'+table2[i][0]+'</td><td>';
			anotherTable.length = 0;
			anotherTable = table2[i][1].split(';');
			for(j=0;j<anotherTable.length-1;j++)
			{
				index = listObjectives[anotherTable[j]].indexResponses; 
				score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
				target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;			
				if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
				else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';
				content += '<label id="'+name+(anotherTable[j])+'label" class="sAreaSmall pushOutRight1 noWrap inputUnselected"><input id="'+name+(anotherTable[j])+
				'" type="radio" name="'+name+'" class="displayNone"></input>'+listObjectives[anotherTable[j]].name+'&nbsp;&nbsp;&nbsp;&nbsp;'+targetMark+'&nbsp'+score12+'</label>'; 
			}
			content += '</td></tr>';
		}
		content += '</tbody></table></div></div>';
		return content;
	}
function contentSelectionsHome()
	{
		objSelectionChart1.initialize('B2-rChart1','radio',listChart1,callBackDatePickerResponses,'inputSelected','inputUnselected','0');
		objSelectionChart2.initialize('B2-rChart2','radio',listChart2,callbackRangePickerAccounts,'inputSelected','inputUnselected','0');
		objSelectionObjectives.initialize('B12-ckAllObjectives','radio','',callbackObjectivesSelection,'inputSelected','inputUnselected','0');
			document.getElementById('B12-ckAllObjectivesContainer').innerHTML = contentAllObjectives();
			objSelectionObjectives.eventsSelections();
			document.getElementById('B12-ckAllObjectives0').checked = true;
			objSelectionObjectives.selectionMade('B12-ckAllObjectives0');
	}
function contentTouchpointsMap()
	{
		var i, j, index, content = '', someClass, aTitle;
		content = '<table class="width100 fontSmall"><thead>';
		for(i=0;i<tbE2ESteps.length;i++)
			content += '<td class="textCenter">'+tbE2ESteps[i][0]+'</td>';
		content += '</thead><tbody>';
		
		for(i=0;i<tbTouchpointsMap.length;i++)
		{
			content += '<tr>';
			for(j=0;j<tbTouchpointsMap[0].length;j++)
			{
				if(tbTouchpointsMap[i][j] != -1)
				{
					index = tbTouchpointsMap[i][j];
					
					if((allTouchpointData[index].nrCommentsEE + allTouchpointData[index].nrCommentsNI) > 0)
					{
						if(allTouchpointData[index].nrCommentsEE == allTouchpointData[index].nrCommentsNI) someClass = 'colorGreenRed';
						if(allTouchpointData[index].nrCommentsEE > allTouchpointData[index].nrCommentsNI) someClass = 'colorMoreGreen';
						if(allTouchpointData[index].nrCommentsEE < allTouchpointData[index].nrCommentsNI) someClass = 'colorMoreRed';
						if(allTouchpointData[index].nrCommentsEE == 0) someClass = 'colorRed';
						if(allTouchpointData[index].nrCommentsNI == 0) someClass = 'colorGreen';

						aTitle = allTouchpointData[index].phase+'-'+allTouchpointData[index].touchpoint + '\n---------------\n' +
							'Positive comments: '+ allTouchpointData[index].nrCommentsEE + '\n' +
							'Negative comments: '+ allTouchpointData[index].nrCommentsNI;
						content += '<td id="B31-cellM'+allTouchpointData[index].phaseIndex+'.'+allTouchpointData[index].touchpointIndex +
							'" class="textCenter cursorPointer" title="'+ aTitle +
							//'"><i class="fas fa-square '+someClass+' fontHuge"></i></td>';
							'"><i class="fa fa-square '+someClass+' fontHuge" aria-hidden="true"></i></td>';
					}
					else content += '<td class="textCenter" title="'+allTouchpointData[index].phase+'-'+allTouchpointData[index].touchpoint
						//+'"><i class="far fa-square fontHuge"></i></td>';
					+'"><i class="fa fa-square-o fontHuge"></i></td>';
				}
				else content += '<td class=""></td>'; 
			}
			content += '</tr>';
		}				
		content += '</tbody></table>';
		document.getElementById('B3-tbTouchpointsMap').innerHTML = content;

	}
function contentParetoDiagrams()
	{
		var i, ax, ay, content, someClass = '', aTitle = '', aTable = [[]];
		// positive comments
		content = '';

		aTable.length = 0;
		for(i=0;i<allTouchpointData.length;i++)
			aTable[aTable.length] = cloneThis(allTouchpointData[i]);
		aTable.sort(function(a,b)
			{
				var x = a.nrCommentsEE;
				var y = b.nrCommentsEE;
				if(x > y) return -1;
				if(x < y) return 1;
				else 
				{
					if(a.nrCommentsNI > b.nrCommentsNI) return 1;
					if(a.nrCommentsNI < b.nrCommentsNI) return -1;
					else return 0;
				}
			});			
		for(i=0;i<aTable.length;i++)
			if(aTable[i].nrCommentsEE > 0)
			{
				ax = aTable[i].phaseIndex;
				ay = aTable[i].touchpointIndex;
				aTitle = aTable[i].phase+'-'+aTable[i].touchpoint + '\n---------------\n' +
							'Positive comments: '+ aTable[i].nrCommentsEE;
				if(aTable[i].nrCommentsEE == aTable[i].nrCommentsNI) someClass = 'groundGreenRed';
				if(aTable[i].nrCommentsEE > aTable[i].nrCommentsNI) someClass = 'groundMoreGreen';
				if(aTable[i].nrCommentsEE < aTable[i].nrCommentsNI) someClass = 'groundMoreRed';
				if(aTable[i].nrCommentsEE == 0) someClass = 'groundRed';
				if(aTable[i].nrCommentsNI == 0) someClass = 'groundGreen';
				content += '<tr id="B31-cellP'+ax+'.'+ay+'" class="cursorPointer" title="'+aTitle+'">'+
				'<td class="textRight textMiddle"><span class="fontBold pushOutRight05">'+aTable[i].phase+':</span><br/> '+aTable[i].touchpoint.substr(0,35)+' </td>'+
				'<td><div class="pareto1 '+someClass+'" style="width:'+parseInt(10*aTable[i].nrCommentsEE/aTable[0].nrCommentsEE)+'em;"></div></td>'+
				'<td>'+
					'<span class="fontBold pushOutRight1">'+aTable[i].nrCommentsEE+' <i class="fa fa-thumbs-o-up colorGreen fa-2x"></i></span>'+
					'<span class="fontBold">'+aTable[i].nrCommentsNI+' <i class="fa fa-thumbs-o-down fa-lg colorHONred"></i></span>'+
				'</td></tr>';
			}
				
		document.getElementById('B31-tbParetoPositive').innerHTML = content;
		// negative comments
		content = '';
		aTable.sort(function(a,b)
			{
				var x = a.nrCommentsNI;
				var y = b.nrCommentsNI;
				if(x > y) return -1;
				if(x < y) return 1;
				else 
				{
					if(a.nrCommentsEE > b.nrCommentsEE) return 1;
					if(a.nrCommentsEE < b.nrCommentsEE) return -1;
					else return 0;
				}
			});			
		for(i=0;i<aTable.length;i++)
			if(aTable[i].nrCommentsNI > 0)
			{
				ax = aTable[i].phaseIndex;
				ay = aTable[i].touchpointIndex;
				aTitle = aTable[i].phase+'-'+aTable[i].touchpoint + '\n---------------\n' +
							'Negative comments: '+ aTable[i].nrCommentsNI;
				if(aTable[i].nrCommentsEE == aTable[i].nrCommentsNI) someClass = 'groundGreenRed';
				if(aTable[i].nrCommentsEE > aTable[i].nrCommentsNI) someClass = 'groundMoreGreen';
				if(aTable[i].nrCommentsEE < aTable[i].nrCommentsNI) someClass = 'groundMoreRed';
				if(aTable[i].nrCommentsEE == 0) someClass = 'groundRed';
				if(aTable[i].nrCommentsNI == 0) someClass = 'groundGreen';
				content += '<tr id="B31-cellN'+ax+'.'+ay+'" class="cursorPointer" title="'+aTitle+'">'+
				'<td class="textRight"><span class="fontBold pushOutRight05">'+aTable[i].phase+':</span><br/> '+aTable[i].touchpoint.substr(0,35)+' </td>'+
				'<td><div class="pareto1 '+someClass+'" style="width:'+parseInt(10*aTable[i].nrCommentsNI/aTable[0].nrCommentsNI)+'em;"></div></td>'+
				'<td>'+
					'<span class="fontBold pushOutRight1">'+aTable[i].nrCommentsNI+' <i class="fa fa-thumbs-o-down fa-2x colorHONred"></i></span>'+
					'<span class="fontBold">'+aTable[i].nrCommentsEE+' <i class="fa fa-thumbs-o-up fa-lg colorGreen"></i></span>'+						
				'</td></tr>';
			}
		document.getElementById('B31-tbParetoNegative').innerHTML = content;
	}
function contentNewTable(i)
	{
		var index, score12, scorePrevMonth, prevMonth, passives, content = '';
		var targetMark = '', trendMark = '', nrActions = 0, nrOverdueActions = 0, nrOpenResponses = 0;
		
		index = listObjectives[i].indexResponses; 
		score12 = allMonthlyNPS[index][tbDateRef.length-2].NPS;
		target = allMonthlyNPS[index][tbDateRef.length-2].targetNPS;
		scorePrevMonth = allMonthlyNPS[index][tbDateRef.length-3].NPS;
		
		if(score12 < parseInt(target)) targetMark = '<i class="fa fa-circle colorHONred" aria-hidden="true"></i>';
		else targetMark = '<i class="fa fa-square colorGreen" aria-hidden="true"></i>';
		
		if(score12 >= scorePrevMonth) trendMark = '&#8599;'; else trendMark = '&#8600;';
		prevMonth = tbMonths[(new Date(allMonthlyNPS[index][tbDateRef.length-3].dateRef)).getMonth()].substr(0,3) + '. ' + (new Date(allMonthlyNPS[index][tbDateRef.length-3].dateRef)).getFullYear();

		passives = allMonthlyNPS[index][tbDateRef.length-2].responses12 - allMonthlyNPS[index][tbDateRef.length-2].promoters12 - allMonthlyNPS[index][tbDateRef.length-2].detractors12;
		
		if(allMonthlyNPS[index][0].openResponses.length != 0) nrOpenResponses = allMonthlyNPS[index][0].openResponses.split(';').length;
		else nrOpenResponses = 0;
		
		if(allHouses[listObjectives[i].indexContacts].openActionsList.length != 0) nrActions = allHouses[listObjectives[i].indexContacts].openActionsList.split(';').length;
		else nrActions = 0;
		
		if(allHouses[listObjectives[i].indexContacts].openOverdueActionsList.length != 0) nrOverdueActions = allHouses[listObjectives[i].indexContacts].openOverdueActionsList.split(';').length;
		else nrOverdueActions = 0;
		
		content += '<tbody class="tablePattern0"><tr>'+
		'<td class="textTop"><p class="textTop"><span class="sAreaSmall">NPS: </span><span style="font-size:6em;">'+score12 +'</span></p><td>'+
		'<td>&nbsp;&nbsp;&nbsp;</td>'+
		'<td class="textTop"><table><tbody>'+
			'<tr><td class="textRight">Target&nbsp;score: </td><td class="textRight fontHuge">'+target+'</td><td class="fontHuge">'+targetMark+'</td></tr>'+
			'<tr><td class="textRight noWrap">'+prevMonth+': </td><td class="textRight fontHuge">'+scorePrevMonth+'</td><td class="fontHuge">'+trendMark+'</td></tr>'+
		'</tbody></table></td>'+
		'<td>&nbsp;&nbsp;&nbsp;</td>'+
		
		'<td class="textTop"><table><tbody>'+
			'<tr><td class="textRight">Responses:&nbsp;</td><td id="B21-txtAllResponses" class="aLink fontHuge textRight">'+allMonthlyNPS[index][tbDateRef.length-2].responses12+'</td></tr>'+
			'<tr><td class="textRight colorGreen" title="Promoters">Promoters:&nbsp;</td><td id="B21-txtPromoters" class="aLink fontHuge textRight">'+allMonthlyNPS[index][tbDateRef.length-2].promoters12+'</td></tr>'+
			'<tr><td class="textRight colorGreenRed" title="Passives">Passives:&nbsp;</td><td id="B21-txtPassives" class="aLink fontHuge textRight">'+passives+'</td></tr>'+
			'<tr><td class="textRight colorRed" title="Detractors">Detractors:&nbsp;</td><td id="B21-txtDetractors" class="aLink fontHuge textRight">'+allMonthlyNPS[index][tbDateRef.length-2].detractors12+'</td></tr>'+
		'</tbody></table></td>'+
		'<td>&nbsp;&nbsp;&nbsp;</td>'+
		'<td class="textTop"><table><tbody>'+
			'<tr><td class="textRight">Open responses:&nbsp;</td><td id="B21-txtOpenResponses" class="aLink fontHuge textRight">'+nrOpenResponses+'</td></tr>'+
			'<tr><td class="textRight">Open follow-up actions:&nbsp;</td><td id="B21-txtOpenActions" class="aLink fontHuge textRight">'+nrActions+'</td></tr>'+
			'<tr><td class="textRight">Past due actions:&nbsp;</td><td id="B21-txtOverdueActions" class="aLink fontHuge textRight">'+nrOverdueActions+'</td></tr>'+
		'</tbody></table></td>'+
		'</tr></tbody>';
		
		document.getElementById('B2-newTable').innerHTML = content;
	}

function eventsHome()
	{
		document.getElementById('B2-btnExportExcel').onclick = function(){exportExcel();}
	}
function eventsTouchpointsMap()
	{
		var i, j, someString = '';
		
		for(i=0;i<tbTouchpointsMap.length;i++)
			for(j=0;j<tbTouchpointsMap[0].length;j++)
				if(document.getElementById('B31-cellM'+j+'.'+i)) // sau j si i?
					document.getElementById('B31-cellM'+j+'.'+i).onclick = function() {goToResponsesPage('0',this.id);};
	}
function eventsParetoDiagrams()
	{
		var i, j, someString = '';
		for(i=0;i<allTouchpointData.length;i++)
		{
			x = allTouchpointData[i].phaseIndex;
			y = allTouchpointData[i].touchpointIndex;
			if(document.getElementById('B31-cellN'+x+'.'+y)) // sau j si i?
				document.getElementById('B31-cellN'+x+'.'+y).onclick = function() {goToResponsesPage('0',this.id);};
			if(document.getElementById('B31-cellP'+x+'.'+y)) // sau j si i?
				document.getElementById('B31-cellP'+x+'.'+y).onclick = function() {goToResponsesPage('0',this.id);};
		}
	}
function eventsNewTable()
	{
		document.getElementById('B21-txtAllResponses').onclick = function(){goToResponsesPage('0','')};
		document.getElementById('B21-txtPromoters').onclick = function(){goToResponsesPage('1','')};
		document.getElementById('B21-txtPassives').onclick = function(){goToResponsesPage('2','')};
		document.getElementById('B21-txtDetractors').onclick = function(){goToResponsesPage('3','')};
		document.getElementById('B21-txtOpenResponses').onclick = function(){goToResponsesPage('-1','');};
		document.getElementById('B21-txtOpenActions').onclick = function(){goToActionsPage('1','');};
		document.getElementById('B21-txtOverdueActions').onclick = function(){goToActionsPage('2','');};
	}

function selectThisObjective(index,source)
	{
		var i, j, ck, houseIndex,  anotherValue, targetNPS, tab = [];
		var theValues = {active:0,target:0,notTarget:0,now:0,waiting:0,asked:0,responded:0,notResponded:0,bigLabel1:0,bigLabel2:0}; 
		
		houseIndex = listObjectives[index].indexContacts;

		for(i=0;i<listObjectives.length;i++)
			if(i==index)listObjectives[i].visibility = 2; else listObjectives[i].visibility = 0;
		if(source != 'child')
		{				
			selectedChildAccount = -1;
			selectedParentAccount = listObjectives[index].name;
			document.getElementById('B2-txtObjective').innerHTML = listObjectives[index].name;			
			document.getElementById('B2-rChildAccountsContainer').style.display = 'none';
		}			
		arrangeCSSclasses('B2-sRightSide','tagAppearance,tagAppearance','0,1');	

		contentNewTable(index);
		eventsNewTable();

		fulfillTouchpointsMap();
		contentTouchpointsMap();
		contentParetoDiagrams();
		eventsTouchpointsMap();
		eventsParetoDiagrams();
	
		listSelectedAccounts.length = 0;
		if(listObjectives[index].indexResponses == 0)
		{
			for(i=0;i<allMonthlyNPS.length;i++)
			{
				if((allMonthlyNPS[i][0].type == tbConst.ParentAccount) && (allMonthlyNPS[i][tbDateRef.length-2].NPS.length != 0))
				{
					anotherValue = parseFloat(allMonthlyNPS[i][tbDateRef.length-2].NPS) - parseFloat(allMonthlyNPS[i][tbDateRef.length-2].targetNPS);
					anotherValue = parseInt(anotherValue);
					if(anotherValue != 'NaN')
					listSelectedAccounts[listSelectedAccounts.length] = 
						[
							allMonthlyNPS[i][tbDateRef.length-2].name,
							allMonthlyNPS[i][tbDateRef.length-2].targetNPS,
							allMonthlyNPS[i][tbDateRef.length-2].NPS,
							anotherValue
						];
				}
			}
		}
		else
		{
			switch(listObjectives[index].type)
			{
				case tbConst.ParentAccount:
					{
						
						for(j=0;j<listParentAccounts.length;j++)
							if(listParentAccounts[j][0] == listObjectives[index].name) 
							{
								tab.length = 0;
								tab = listParentAccounts[j][2].split(';');
							}
						tab.sort();
						if(tab.length > 2)
						{
							document.getElementById('B2-rChildAccountsContainer').style.display = 'block';
							
							tab[0] = tbConst.ALL;
							listChildAccounts.length = 0;listChildAccounts = cloneThis(tab);
							objSelectionChildAccounts.initialize('B2-rChildAccounts','radio',tab,selectChildAccount,'inputSelected','inputUnselected','0');
							for(j=0;j<tab.length;j++)
								for(i=0;i<allMonthlyNPS.length;i++)
									if((allMonthlyNPS[i][0].type == tbConst.Account) && (allMonthlyNPS[i][0].name == tab[j]) && (allMonthlyNPS[i][tbDateRef.length-2].NPS.length != 0))
									{
										anotherValue = parseFloat(allMonthlyNPS[i][tbDateRef.length-2].NPS) - parseFloat(allMonthlyNPS[i][tbDateRef.length-2].targetNPS);
										anotherValue = parseInt(anotherValue);
										if(anotherValue != 'NaN')
										listSelectedAccounts[listSelectedAccounts.length] = 
											[
												allMonthlyNPS[i][tbDateRef.length-2].name,
												allMonthlyNPS[i][tbDateRef.length-2].targetNPS,
												allMonthlyNPS[i][tbDateRef.length-2].NPS,
												anotherValue
											];
									}
						}
					}break;
				case tbConst.Region:
					{
						i = 0; targetNPS = -101;
						while((i<allMonthlyNPS.length) && (targetNPS == -101))
						{
							if((allMonthlyNPS[i][0].type == tbConst.Region) && (allMonthlyNPS[i][0].name == listObjectives[index].name)) targetNPS = allMonthlyNPS[i][tbDateRef.length-2].targetNPS;
							i++;
						}
						for(i=0;i<allMonthlyNPS.length;i++)
							if((allMonthlyNPS[i][0].type == tbConst.Account) && (allMonthlyNPS[i][0].region.indexOf(listObjectives[index].name) != -1) && (allMonthlyNPS[i][tbDateRef.length-2].NPS.length != 0))								
							{
								ck = true;
								for(j=0;j<listParentAccounts.length;j++)
									if(listParentAccounts[j][0] == allMonthlyNPS[i][tbDateRef.length-2].name) ck = false;
								if(ck)
								{
									anotherValue = parseFloat(allMonthlyNPS[i][tbDateRef.length-2].NPS - targetNPS);
									anotherValue = parseInt(anotherValue);
									if(anotherValue != 'NaN')
									listSelectedAccounts[listSelectedAccounts.length] = 
										[
											allMonthlyNPS[i][tbDateRef.length-2].name,
											targetNPS,
											allMonthlyNPS[i][tbDateRef.length-2].NPS,
											anotherValue
										];
								}
							};
						tab.length = 0;tab[0] = tbConst.ALL;
						for(i=0;i<listSelectedAccounts.length;i++)
							tab[tab.length] = listSelectedAccounts[i][0];
						tab.sort();
						//if(tab.length > 2)
						{
							document.getElementById('B2-rChildAccountsContainer').style.display = 'block';
							
							listChildAccounts.length = 0;listChildAccounts = cloneThis(tab);
							objSelectionChildAccounts.initialize('B2-rChildAccounts','radio',tab,selectChildAccount,'inputSelected','inputUnselected','0');
						}
					}break;
			}
		}
		
		theValues.active = parseInt(allHouses[houseIndex].active);
		theValues.target = parseInt(allHouses[houseIndex].targetNPS);
		theValues.notTarget = theValues.active - theValues.target;
		theValues.now = parseInt(allHouses[houseIndex].NPSnow);
		//theValues.waiting = parseInt(allHouses[houseIndex].targetNPS) - parseInt(allHouses[houseIndex].NPSnow);
		theValues.waiting = parseInt(allHouses[houseIndex].waiting);
		theValues.asked = parseInt(allHouses[houseIndex].asked);
		theValues.responded = parseInt(allHouses[houseIndex].responded);
		theValues.notResponded = parseInt(allHouses[houseIndex].notResponded);//theValues.asked - theValues.responded;
		theValues.bigValues1 = parseInt(100 * theValues.target/theValues.active);
		if(theValues.asked != 0) theValues.bigValues2 = parseInt(100 * theValues.responded/theValues.asked);
		else theValues.bigValues2 = ' - ';
		
		tab.length = 0; 
		tab = [
				[theValues.now, theValues.now + ' available now'],
				[theValues.waiting, theValues.waiting + ' waiting'],
				[theValues.notTarget, theValues.notTarget + ' not NPS target']];
		objContactsAvailable.initialize('B21-svgContactsAvailable',tab,'true',50,[theValues.bigValues1+' %','targets for NPS'],['#00A400','#FCD164','#8E0000']);
		tab.length = 0;
		tab = [
				[theValues.responded, theValues.responded + ' responded'],
				[theValues.notResponded, theValues.notResponded + ' didn\'t respond']];
		objContactsAvailable.initialize('B21-svgContactsResponded',tab,'true',50,[theValues.bigValues2+' %','responded'],['blue','lightblue']);

		objTrendSVG.initialize('B21-svgTrend',true);
		objTrendDP.initialize('B21-dpTrend',3,objTrendSVG.noPoints,0,0,callBackDatePickerTrend);
		fulfillChartTrendsData(0);

		objResponsesSVG.initialize('B21-svgResponses');			
		objResponsesDP.initialize('B21-dpResponses',3,objResponsesSVG.noBars,0,0,callBackDatePickerResponses);
		fulfillChartResponses(0);

		objRequestsSVG.initialize('B21-svgRequests');			
		objRequestsDP.initialize('B21-dpRequests',3,objRequestsSVG.noBars,0,0,callBackDatePickerRequests);
		fulfillChartRequests(0);

		objClosureSVG.initialize('B21-svgClosure',true);
		objClosureDP.initialize('B21-dpClosure',3,objClosureSVG.noPoints,0,0,callBackDatePickerClosure);
		fulfillChartDataClosure(0);

		if(listSelectedAccounts.length != 0)
		{
			if((index == 0)||(listObjectives[index].type == tbConst.Region)) arrangeCSSclasses('B2-sAccounts','sArea,sAreaSmall,width45','1,0,0');
			//if((index == 0)) arrangeCSSclasses('B2-sAccounts','sArea,sAreaSmall,width45','1,0,0');
			else arrangeCSSclasses('B2-sAccounts','sArea,sAreaSmall,width45','0,1,1');
			document.getElementById('B2-sAccounts').style.display = 'block';				
			objAccountsSVG.initialize('B21-svgAccounts');
			if(objAccountsSVG.noBars < listSelectedAccounts.length)
				objAccountsRP.initialize('B2-rpAccounts',parseInt(objAccountsSVG.noBars/2),objAccountsSVG.noBars,listSelectedAccounts.length,callbackRangePickerAccounts);

			fulfillChartAccounts(1);
		}
		else document.getElementById('B2-sAccounts').style.display = 'none';
	}
function selectChildAccount()
	{
		var i = 0, index;
		
		index = parseInt(objSelectionChildAccounts.indexSelected);
		if(index == 0)
		{
			for(i=0;i<listObjectives.length;i++)
				if((listObjectives[i].type == tbConst.ParentAccount) && (listObjectives[i].name == selectedParentAccount))
					selectThisObjective(i,'');
			for(i=0;i<listObjectives.length;i++)
				if((listObjectives[i].type == tbConst.Region) && (listObjectives[i].name == selectedParentAccount))
					selectThisObjective(i,'');
		}
		else
		{	
			for(i=0;i<listObjectives.length;i++)
				if((listObjectives[i].type == tbConst.Account) && (listObjectives[i].name == listChildAccounts[index]))
				{
					selectThisObjective(i,'child');
					selectedChildAccount = i;
				}
		}
	}

function fulfillChartTrendsData(step)
	{
		var i, noPoints, npsIndex, tab = [[]], index;
		var value, dimension, target, label, title, date, aRealDate;
			
			noPoints = objTrendSVG.noPoints; 
			aRealDate = new Date(objTrendDP.startDateInt);
			 			
			for(i=0;i<listObjectives.length;i++)
			if(listObjectives[i].visibility == 2) index = listObjectives[i].indexResponses;
		
		npsIndex =  tbDateRef.length-(1-step);
		tab.length = 0;
		
		for(i=(noPoints-1);i>=0;i--)
		{
			if(((npsIndex-i) >=0 ) && ((npsIndex-i) < tbDateRef.length-1))
			{
				value = allMonthlyNPS[index][npsIndex-i].NPS;
				dimension = allMonthlyNPS[index][npsIndex-i].responses12;
				target = allMonthlyNPS[index][npsIndex-i].targetNPS;
				label = value;
				title = tbMonths[aRealDate.getMonth()] + ' ' + aRealDate.getFullYear()+
						'\n------------'+
							'\nNPS: '+value+
							'\nNPS target: '+target+
							'\n------------'+
							'\nNPS responses: '+allMonthlyNPS[index][npsIndex-i].responses12+
							'\nPromoters: '+allMonthlyNPS[index][npsIndex-i].promoters12+
							'\nDetractors: '+allMonthlyNPS[index][npsIndex-i].detractors12;	
			}
			else
			{
				value = '';
				dimension = '';
				target = '';
				label = value;
				title = tbMonths[aRealDate.getMonth()] + ' ' + aRealDate.getFullYear()+
						'\n------------'+
							'\nNPS: NA'+
							'\nNPS target: '+target+
							'\n------------'+
							'\nNPS responses: NA'+
							'\nPromoters: NA'+
							'\nDetractors: NA';
			}				
			date = tbMonths[aRealDate.getMonth()].substr(0,3) + ' &#39;' + aRealDate.getFullYear().toString().substr(2,2);
			tab[tab.length] = [value,dimension,target,label,title, date];
			aRealDate.setMonth(aRealDate.getMonth()+1);
		}
			objTrendSVG.contentGraph(tab);
	}
function fulfillChartResponses(step)
	{			
		var i, noBars, npsIndex, tab = [[]], index;
		var value1, value2, dimension, target, label, title, date, aRealDate, responseRate;

			noBars = objResponsesSVG.noBars; 			
			aRealDate = new Date(objResponsesDP.startDateInt);
			for(i=0;i<listObjectives.length;i++)
			if(listObjectives[i].visibility == 2) index = listObjectives[i].indexResponses;
		
		npsIndex =  tbDateRef.length-(1-step);
		tab.length = 0;

		for(i=(noBars-1);i>=0;i--)
		{				
			if(((npsIndex-i) >=0 ) && ((npsIndex-i) < (tbDateRef.length-1)))
			{
				if(document.getElementById('B2-rChart10')) // at the beginning, the function is called before the creation of HTML tag (as callback function)
				{
					if(document.getElementById('B2-rChart10').checked)
					{
						value1 = allMonthlyNPS[index][npsIndex-i].req1;
						value2 = allMonthlyNPS[index][npsIndex-i].responses1;
					}
					else
					{
						value1 = allMonthlyNPS[index][npsIndex-i].req12;
						value2 = allMonthlyNPS[index][npsIndex-i].responses12;
					}	
				}
				else
				{
					value1 = allMonthlyNPS[index][npsIndex-i].req1;
					value2 = allMonthlyNPS[index][npsIndex-i].responses1;
				}
				
				if(value1 != 0) responseRate = (parseInt(1000*value2/value1)/10)+' %'; 
				else responseRate = '';
			}
			else
			{
				value1 = '';
				value2 = '';
				responseRate = '';
			}
			label = value1+' / '+value2;
			title = tbMonths[aRealDate.getMonth()] + ' ' + aRealDate.getFullYear()+
					'\n------------'+
					'\nResponses Rate: '+responseRate+
					'\n------------'+
					'\nRequests: '+value1+
					'\nResponses: '+value2;
			date = tbMonths[aRealDate.getMonth()].substr(0,3) + ' &#39;' + aRealDate.getFullYear().toString().substr(2,2);
			tab[tab.length] = [value1,value2,label,title,date];	
			aRealDate.setMonth(aRealDate.getMonth()+1);
		}
			objResponsesSVG.contentGraph(tab);
	}
function fulfillChartRequests(step)
	{			
		var i, noBars, npsIndex, tab = [[]], index;
		var value1, value2, dimension, target, label, title, date, aRealDate, responseRate;

			noBars = objRequestsSVG.noBars; 			
			aRealDate = new Date(objRequestsDP.startDateInt);
			for(i=0;i<listObjectives.length;i++)
			if(listObjectives[i].visibility == 2) index = listObjectives[i].indexResponses;
		
		npsIndex =  tbDateRef.length-(1-step);
		tab.length = 0;

		for(i=(noBars-1);i>=0;i--)
		{				
			if(((npsIndex-i) >=0 ) && ((npsIndex-i) < (tbDateRef.length-1)))
			{
				value1 = allMonthlyNPS[index][npsIndex-i].yearlyUniques;
				value2 = allMonthlyNPS[index][npsIndex-i].responses12;
				
				if(value1 != 0) responseRate = (parseInt(1000*value2/value1)/10)+' %'; 
				else responseRate = '';
			}
			else
			{
				value1 = '';
				value2 = '';
				responseRate = '';
			}
			label = value1+' / '+value2;
			title = tbMonths[aRealDate.getMonth()] + ' ' + aRealDate.getFullYear()+
					'\n------------'+
					'\nResponses Rate: '+responseRate+
					'\n------------'+
					'\nUnique requests: '+value1+
					'\nResponses: '+value2;
			date = tbMonths[aRealDate.getMonth()].substr(0,3) + ' &#39;' + aRealDate.getFullYear().toString().substr(2,2);
			tab[tab.length] = [value1,value2,label,title,date];	
			aRealDate.setMonth(aRealDate.getMonth()+1);
		}
			objRequestsSVG.contentGraph(tab);
	}
function fulfillChartDataClosure(step)
	{			
		var i, j, k, noPoints, npsIndex, tab = [[]], index, closureDaysResponse, aTable = [];
		var value, dimension, target, label, title, date, aRealDate, exportContent = '';;
			
			noPoints = objClosureSVG.noPoints; 
			aRealDate = new Date(objClosureDP.startDateInt);

			for(i=0;i<listObjectives.length;i++)
			if(listObjectives[i].visibility == 2) index = listObjectives[i].indexResponses;
		
		npsIndex =  tbDateRef.length-(1-step);
		tab.length = 0;
		exportContent += '<table><thead><td></td><td></td><td></td></thead><tbody>';
		for(i=(noPoints-1);i>=0;i--)
		{
			closureDaysResponse = '30';
			for(j=0;j<otherNPStargets.length;j++)
				if((otherNPStargets[j][0] == tbDateRef[npsIndex-i]) && (otherNPStargets[j][1].indexOf('closureDaysResponse') != -1))
				{
					aTable = otherNPStargets[j][1].split(';');
					for(k=0;k<aTable.length;k++)
						if(aTable[k].indexOf('closureDaysResponse') != -1) closureDaysResponse = aTable[k].split(':')[1];
				}
			
			if(((npsIndex-i) >=0 ) && ((npsIndex-i) < tbDateRef.length-1))
			{				
				if(allMonthlyNPS[index][npsIndex-i].closed != 0) 
					value = parseInt(10*parseInt(allMonthlyNPS[index][npsIndex-i].days)/parseInt(allMonthlyNPS[index][npsIndex-i].closed))/10;
				else value = '';					
				dimension = '5';
				target = closureDaysResponse;
				label = value;
				title = tbMonths[aRealDate.getMonth()] + ' ' + aRealDate.getFullYear()+
						'\n------------'+
						'\nNPS: '+value+
						'\nNPS closure target: '+target;
				exportContent += '<tr><td>'+index+'</td><td>'+new Date(allMonthlyNPS[index][npsIndex-i].dateRef)+'</td><td>'+allMonthlyNPS[index][npsIndex-i].closed+'</td><td>'+allMonthlyNPS[index][npsIndex-i].closedThisMonth+'</td></tr>';
			}
			else
			{
				value = '';
				dimension = '';
				target = closureDaysResponse;
				label = value;
				title = tbMonths[aRealDate.getMonth()] + ' ' + aRealDate.getFullYear()+
						'\n------------'+
						'\nNPS: '+value+
						'\nNPS closure target: '+target;
			}

			date = tbMonths[aRealDate.getMonth()].substr(0,3) + ' &#39;' + aRealDate.getFullYear().toString().substr(2,2);
			tab[tab.length] = [value,dimension,target,label,title, date];
			aRealDate.setMonth(aRealDate.getMonth()+1);				
		}
		exportContent += '</tbody></table>';
		//saveTextAsFile(exportContent,'closureTest.xls');
			objClosureSVG.contentGraph(tab);
	}
function fulfillChartAccounts(step)
	{			
		var i, tab = [[]];
		var aLength, value, label, title ;

			if(listSelectedAccounts.length != 0)
			{
				if(document.getElementById('B2-rChart21')) // at the beginning, the function is called before the creation of HTML tag (as callback function)
				{
 				if(document.getElementById('B2-rChart21').checked)
					listSelectedAccounts.sort(function(a,b)
					{
						if(parseFloat(a[3]) > parseFloat(b[3])) return -1;
						if(parseFloat(a[3]) < parseFloat(b[3])) return 1;
						else return 0;
					});
				else 
					listSelectedAccounts.sort(function(a,b)
						{
							if(a[0] > b[0]) return 1;
							if(a[0] < b[0]) return -1;
							else return 0;
						});	
				}
				else
				{
					listSelectedAccounts.sort(function(a,b)
					{
						if(parseFloat(a[3]) > parseFloat(b[3])) return -1;
						if(parseFloat(a[3]) < parseFloat(b[3])) return 1;
						else return 0;
					});
				}
				
			
			tab.length = 0;
			step = step-1;
			if(objAccountsSVG.noBars > listSelectedAccounts.length) 
			{
				aLength = listSelectedAccounts.length; 
				arrangeCSSclasses('B2-rpAccounts','visibilityTrue,visibilityFalse','0,1'); 
			}
			else
			{
				aLength = objAccountsSVG.noBars;
				arrangeCSSclasses('B2-rpAccounts','visibilityTrue,visibilityFalse','1,0'); 
			} 
			for(i=0;i<aLength;i++)
			{
				value = listSelectedAccounts[i+step][3];
				label = listSelectedAccounts[i+step][0];
				title = listSelectedAccounts[i+step][0]+'\nNPS: '+listSelectedAccounts[i+step][2]+'\nTarget NPS:'+listSelectedAccounts[i+step][1]+'\nAgainst the target: '+listSelectedAccounts[i+step][3];
				tab[tab.length] = [value,label,title];	
			}
 			objAccountsSVG.contentGraph(tab);
			}
	}

function fulfillTouchpointsMap()
	{
		var i, j, ck, aTab = [];
		function checkResponseLocal(index)
			{
				var i, ck;
				if((allResponses[index].dateCreated >= oneYearAgo) && ((allResponses[index].touchpointsEE != null) || (allResponses[index].touchpointsNI != null))) ck = true;
				else ck = false;
				if(ck)
				{
					for(i=0;i<listObjectives.length;i++)
						if(listObjectives[i].visibility == 2)
						{
							switch(listObjectives[i].type)
							{
								case tbConst.ALL:{;};break;
								case tbConst.LOB:{if(listObjectives[i].name == allResponses[index].LOB) ck = true; else ck = false;};break;
								case tbConst.DEEPN:{if(listObjectives[i].name == allResponses[index].contactDEEPN) ck = true; else ck = false;};break;
								case tbConst.Plant:{if(allResponses[index].categories.indexOf(listObjectives[i].name) != -1) ck = true; else ck = false;};break;
								case tbConst.Region:{if(allResponses[index].region.indexOf(listObjectives[i].name) != -1) ck = true; else ck = false;};break;
								case tbConst.ParentAccount:{if(listObjectives[i].name == allResponses[index].parentAccount) ck = true; else ck = false;};break;
								case tbConst.Account:{if(listObjectives[i].name == allResponses[index].account) ck = true; else ck = false;};break;
							}
						}
				}
				return ck;
			}
		
		for(j=0;j<allTouchpointData.length;j++)
			{
				allTouchpointData[j].nrCommentsEE = 0;
				allTouchpointData[j].listCommentsEE = '';
				allTouchpointData[j].nrCommentsNI = 0;
				allTouchpointData[j].listCommentsNI = '';
			}
		for(i=0;i<allResponses.length;i++)
			if(checkResponseLocal(i))
			{
				if(allResponses[i].touchpointsEE != null)
				{
					aTab.length = 0; aTab = allResponses[i].touchpointsEE.split(';');
					for(k=0;k<aTab.length;k++)
						for(j=0;j<allTouchpointData.length;j++)
						{
							if((aTab[k].split('___')[0].indexOf(allTouchpointData[j].phase) != -1) &&
								(aTab[k].split('___')[1].indexOf(allTouchpointData[j].touchpoint) != -1))
									allTouchpointData[j].nrCommentsEE++;										
						} 
				}
				if(allResponses[i].touchpointsNI != null)
				{
					aTab.length = 0; aTab = allResponses[i].touchpointsNI.split(';');
					for(k=0;k<aTab.length;k++)
						for(j=0;j<allTouchpointData.length;j++)
						{
							if((aTab[k].split('___')[0].indexOf(allTouchpointData[j].phase) != -1) &&
								(aTab[k].split('___')[1].indexOf(allTouchpointData[j].touchpoint) != -1))
									allTouchpointData[j].nrCommentsNI++;
						} 
				}
			}
	}	

function exportExcel()
	{
		var i, aDate, aName, aCounter, content1 = '', content2 = '';
		
		// contacts
			content1 = '<table><thead><td></td><td>Act</td><td>NPS</td><td>now</td><td>Asked</td><td>Respd</td></thead><tbody>';
			for(i=0;i<allHouses.length;i++)
			{
				content1 += '<tr><td>'+allHouses[i].type+': '+allHouses[i].name+'</td>'+
				'<td>'+allHouses[i].active+'</td>'+
				'<td>'+allHouses[i].targetNPS+'</td>'+
				'<td>'+allHouses[i].NPSnow+'</td>'+
				'<td>'+allHouses[i].asked+'</td>'+
				'<td>'+allHouses[i].responded+'</td></tr>';
			}
			content1 += '</tbody></table>';
			saveTextAsFile(content1,'NPS-Contacts.xls');
			

		// responses
			content2 = '<table><thead><tr><td></td>';
			for(i=tbDateRef.length-1;i>=0;i--)
			{
				aDate = new Date(parseInt(tbDateRef[i]));
				content2 += '<td>'+tbMonths[(aDate.getMonth())].substr(0,3)+'-'+aDate.getFullYear()+'</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>';
			}
			content2 += '</tr><tr><td></td>';
			for(i=0;i<(tbDateRef.length-1);i++)					
				content2 +='<td>Req1</td><td>Resp1</td><td>Prom1</td><td>Detr1</td>'+
							'<td>Req12</td><td>Resp12</td><td>Prom12</td><td>Detr12</td>'+
							'<td>closed</td><td>open days</td>';
			content2 += '</tr></thead><tbody>';

			for(i=0;i<allMonthlyNPS.length;i++)
			{					
				content2 += '<tr><td>'+allMonthlyNPS[i][0].type+':'+allMonthlyNPS[i][0].name+'</td>';
				
				for(j=(tbDateRef.length-2);j>=0;j--)
					content2 += '<td>'+allMonthlyNPS[i][j].req1+'</td>'+
					'<td>'+allMonthlyNPS[i][j].responses1+'</td>'+
					'<td>'+allMonthlyNPS[i][j].promoters1+'</td>'+
					'<td>'+allMonthlyNPS[i][j].detractors1+'</td>'+
					'<td>'+allMonthlyNPS[i][j].req12+'</td>'+
					'<td>'+allMonthlyNPS[i][j].responses12+'</td>'+
					'<td>'+allMonthlyNPS[i][j].promoters12+'</td>'+
					'<td>'+allMonthlyNPS[i][j].detractors12+'</td>'+
					'<td>'+allMonthlyNPS[i][j].closed+'</td>'+
					'<td>'+allMonthlyNPS[i][j].days+'</td>';
				content2 += '</tr>';
				;
			}
			content2 += '</tr></tbody></table>';		
			saveTextAsFile(content2,'NPS-Responses.xls');
	}

function createDateReferenceTable()
	{
		var newMonth = firstMonth, dateConverted;
		tbDateRef.length = 0;
		while(newMonth <= today)
		{
			tbDateRef[tbDateRef.length] = newMonth;
			//var startDate, endDate;
			dateConverted = new Date(newMonth);
			newMonth = Date.parse(new Date(dateConverted.getFullYear(),dateConverted.getMonth()+1,1)); 
		}
		tbDateRef[tbDateRef.length] = newMonth;
	}
function createTouchpointsMap()
	{
		var i, j, maxRows = 0, counter, tmpTable = [];
		allTouchpointData.length = 0;
		for(i=0;i<tbE2ESteps.length;i++)
		{
			tmpTable.length = 0;
			tmpTable = tbE2ESteps[i][1].split(';');
			if(maxRows<tmpTable.length) maxRows = tmpTable.length;
			for(j=0;j<tmpTable.length;j++)
			{
				aTouchpointData.phase = tbE2ESteps[i][0];
				aTouchpointData.phaseIndex = i;
				aTouchpointData.touchpoint = tmpTable[j];
				aTouchpointData.touchpointIndex = j;
				aTouchpointData.nrCommentsEE = 0;
				aTouchpointData.nrCommentsNI = 0;
				allTouchpointData[allTouchpointData.length] = cloneThis(aTouchpointData);
			}
		}
		maxRows += 1;
		
		tbTouchpointsMap.length = 0;
		for(i=0;i<maxRows;i++)
		{
			tbTouchpointsMap[i] = []; tbTouchpointsMap[i].length = 0;
			for(j=0;j<tbE2ESteps.length;j++) tbTouchpointsMap[i][j] = -1;
			//tbTouchpointsMap[tbTouchpointsMap.length] = tmpTable;
		}
		
		counter = 0; 
		for(j=0;j<tbE2ESteps.length;j++)
		{
			tmpTable.length = 0;
			tmpTable = tbE2ESteps[j][1].split(';');
			for(i=0;i<tmpTable.length;i++)
			{
				tbTouchpointsMap[i][j] = counter;
				counter++;
			}
		}
	}

function callBackDatePickerTrend()
	{
		fulfillChartTrendsData(objTrendDP.jump);
	}
function callBackDatePickerClosure()
	{
		fulfillChartDataClosure(objClosureDP.jump);
	}
function callBackDatePickerResponses()
	{
		fulfillChartResponses(objResponsesDP.jump);
	}
function callBackDatePickerRequests()
	{
		fulfillChartRequests(objRequestsDP.jump);
	}
function callbackRangePickerAccounts()
	{
		fulfillChartAccounts(objAccountsRP.startInt);
	}
function callbackObjectivesSelection()
	{
		selectThisObjective(objSelectionObjectives.indexSelected,'');
	}

