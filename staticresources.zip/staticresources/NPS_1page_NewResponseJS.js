
var listScoreOptions = ['None','1','2','3','4','5','6','7','8','9','10'];
var allContactsNewResponse = [];
	aContactNewResponse = 
		{
			contactID: '',
			fullName: '',
			accountID: ''
		}
var aResponseSet = 
	{
		Contact__c: '',
		Contact_Name__c: '',
		Account_ID__c: '',
		Score__c: '',
		NP_Score__c: '',
		Exceeded_Expectations__c: '',
		Improvement_Comments__c: ''
	}
var objSelNewResponseScore = newInputRadioOrCheckbox();

function initializeNewResponse()
	{
		
		objSelNewResponseScore.initialize('G11-rScore','radio',listScoreOptions,callbackNone,'inputSelected','inputUnselected','0');
		contentAccounts();
		contentContacts();

		eventsNewResponses();

		document.getElementById('G11-txtMessages').innerHTML = '&nbsp;';
		arrangeCSSclasses('G11-txtMessages','colorHONred','0');/**/
	}

function contentAccounts()
	{
		var i, content = '<option value=""></option>';
		for(i=0;i<listAccounts.length;i++)
			content += '<option value="'+listAccounts[i][0]+'">'+listAccounts[i][0]+'</option>';
		if(document.getElementById('G11-listAccounts')) document.getElementById('G11-listAccounts').innerHTML = content; // "if()" due SFDC initial rendering
		
	}
function contentContacts()
	{
		var i, content = '<option value=""></option>', accountSelected = '';
		allContactsNewResponse.length = 0;
		accountSelected = document.getElementById('G11-listAccounts').options[document.getElementById('G11-listAccounts').selectedIndex].value;
		for(i=0;i<allContacts.length;i++)
		{
			if((allContacts[i].active == 'yes') && (allContacts[i].account == accountSelected))
			{
				aContactNewResponse.contactID = allContacts[i].contactID;
				aContactNewResponse.fullName = allContacts[i].fullName;
				aContactNewResponse.accountID = allContacts[i].accountID;
				allContactsNewResponse[allContactsNewResponse.length] = cloneThis(aContactNewResponse);
			}
		}
		allContactsNewResponse.sort();
		for(i=0;i<allContactsNewResponse.length;i++)
			content += '<option value="'+allContactsNewResponse[i].fullName+'">'+allContactsNewResponse[i].fullName+'</option>';;
		if(document.getElementById('G11-listContacts')) document.getElementById('G11-listContacts').innerHTML = content; // "if()" due SFDC initial rendering
	}

function eventsNewResponses()
	{
		var i, ck;
		document.getElementById('G11-listAccounts').onchange = function() {contentContacts();}
		document.getElementById('G11-btnCancel').onclick = function() {selectMainMenu('A2-btnResponses');}
		document.getElementById('G11-btnSave').onclick = function() 
		{
			ck = false;

			if(!document.getElementById('G11-rScore0').checked) ck = true;
			if(document.getElementById('G11-txtaGood').value != '') ck = true;
			if(document.getElementById('G11-txtaBad').value != '') ck = true;
			if(document.getElementById('G11-listContacts').selectedIndex == 0) ck = false;
			if(ck) 
			{
				aResponseSet.Contact_Name__c = document.getElementById('G11-listContacts').options[document.getElementById('G11-listContacts').selectedIndex].value;
				for(i=0;i<allContactsNewResponse.length;i++)
					if(allContactsNewResponse[i].fullName == aResponseSet.Contact_Name__c) 
						{
							aResponseSet.Contact__c = allContactsNewResponse[i].contactID;
							aResponseSet.Account_ID__c = allContactsNewResponse[i].accountID;
						}
				if(document.getElementById('G11-rScore0').checked)
				{
					aResponseSet.Score__c = '';
					aResponseSet.NP_Score__c = '';
				}
				else						
					for(i=1;i<listScoreOptions.length;i++)
						if(document.getElementById('G11-rScore'+i).checked)
						{
							aResponseSet.Score__c = i.toString();
							aResponseSet.NP_Score__c = i;
						}
				aResponseSet.Exceeded_Expectations__c = document.getElementById('G11-txtaGood').value;
				aResponseSet.Improvement_Comments__c = document.getElementById('G11-txtaBad').value;
				
				createSFDCresponse(aResponseSet);
				selectMainMenu('A2-btnResponses');
			}
			else
			{
				if(document.getElementById('G11-listContacts').selectedIndex == 0)
				{
					document.getElementById('G11-txtMessages').innerHTML = 'Please select a customer name!';
					arrangeCSSclasses('G11-txtMessages','colorHONred','1');
					arrangeCSSclasses('G11-txtMessages','tagAppearance,tagAppearance','0,1');
				}
				else
				{
					document.getElementById('G11-txtMessages').innerHTML = 'Please add some sort of feedback!';
					arrangeCSSclasses('G11-txtMessages','tagAppearance,tagAppearance','0,1');
				}
				return false;
			}
		}
	}

