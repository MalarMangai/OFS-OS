

var listSelectedResponses = [], listSelectedPhase = [], listSelectedCategory = [];
var stringAllResponsesSelections = '';
var oldestResponse, newestResponse, startDateResponse, endDateResponse;

var listResponseStatus = ['ALL','Open','Completed'];
var listTimeInterval = ['ALL','Last 12 months','Older than 12 months','From <input id="D1-iDateStart" type="text" class="inputForDate" readonly/> until <input id="D1-iDateEnd" type="text" class="inputForDate"/>'];
var listRespondersType = ['ALL','Promoters','Passives','Detractors','VOCs'];
var listTouchpointsType = ['ALL','Exceeded Expectations','Need Improvements'];
var listFreeSearchResponses = ['ALL','Account','Parent Account','Owner','Customer Name','NPS ID','Customer Feedback'];

var objSelResponsesLOB = newInputRadioOrCheckbox();
var objSelResponsesRegion = newInputRadioOrCheckbox();
var objSelResponsesDEEPN = newInputRadioOrCheckbox();
var objSelResponsesPlant = newInputRadioOrCheckbox();
var objSelResponsesRespondersType = newInputRadioOrCheckbox();
var objSelResponsesTime = newInputRadioOrCheckbox();

var objSelResponsesStatusFeedback = newInputRadioOrCheckbox();
var objSelResponsesStatusTouchpoints = newInputRadioOrCheckbox();
var objSelResponsesStatusCategories = newInputRadioOrCheckbox();
var objSelResponsesStatusActions = newInputRadioOrCheckbox();

var objSelResponsesTouchpointsType = newInputRadioOrCheckbox();
var objSelResponsesPhases = newInputRadioOrCheckbox();
var objSelResponsesTouchpoints = newInputRadioOrCheckbox();
var objSelResponsesCategories = newInputRadioOrCheckbox();
var objSelResponsesPoints = newInputRadioOrCheckbox();
var objSelResponsesOwnership = newInputRadioOrCheckbox();
var objSelResponsesFreeSearch = newInputRadioOrCheckbox();

function initializeResponses()
	{
		allResponses.sort(function(a,b)
		{
			var x = a.dateCreated;
			var y = b.dateCreated;
			if(x > y) return -1;
			if(x < y) return 1;
			else return 0
		});
		oldestResponse = allResponses[allResponses.length-1].dateCreated;
		newestResponse = allResponses[0].dateCreated;
		fulfillTheRestOfResponses();
		
		contentSelectionsResponses();
		
		fillSelectedResponses();
		contentResponsesTable();

		eventsResponses();
		eventsResponsesTable();
		eventsSelectionsResponses();
	}
function contentSelectionsResponses()
	{
		var i, aTab = [];
	
		aTab.length = 0; for(i=0;i<listLOBall.length;i++) aTab[aTab.length] = listLOBall[i][0];
		objSelResponsesLOB.initialize('D1-rLOB','radio',aTab,callbackSelectionsResponses,'inputSelected','inputUnselected','0');

		aTab.length = 0; for(i=0;i<listRegionsAll.length;i++) aTab[aTab.length] = listRegionsAll[i][0]; 
		objSelResponsesRegion.initialize('D1-rRegions','radio',aTab,callbackSelectionsResponses,'inputSelected','inputUnselected','0');

		objSelResponsesDEEPN.initialize('D1-rDEEPN','radio',listDEEPNall,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesPlant.initialize('D1-rPlant','radio',listPlantsAll,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesRespondersType.initialize('D1-rResponders','radio',listRespondersType,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesTouchpointsType.initialize('D1-rTouchpointsType','radio',listTouchpointsType,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		
		objSelResponsesTime.initialize('D1-rTimeInterval','radio',listTimeInterval,callbackSelResponsesWithDate,'inputSelected','inputUnselected','1');
			document.getElementById('D1-iDateStart').disabled = true;
			document.getElementById('D1-iDateEnd').disabled = true;
			document.getElementById('D1-iDateStart').value = dateConverted(oldestResponse);
			startDateResponse = oldestResponse;	
			document.getElementById('D1-iDateEnd').value = dateConverted(newestResponse);
			endDateResponse = newestResponse;
		
		objSelResponsesStatusFeedback.initialize('D1-rStatusFeedback','radio',listResponseStatus,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesStatusTouchpoints.initialize('D1-rStatusTouchpoints','radio',listResponseStatus,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesStatusCategories.initialize('D1-rStatusCategories','radio',listResponseStatus,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesStatusActions.initialize('D1-rStatusActions','radio',listResponseStatus,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		
		objSelResponsesPhases.initialize('D1-rPhases','radio',listPhases,callbackSelectionsResponsesPhases,'inputSelected','inputUnselected','0')
		objSelResponsesCategories.initialize('D1-rCategories','radio',listCategories,callbackSelectionsResponsesCategories,'inputSelected','inputUnselected','0')
		objSelResponsesOwnership.initialize('D1-rOwnership','radio',listOwnership,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		objSelResponsesFreeSearch.initialize('D1-rFreeSearch','radio',listFreeSearchResponses,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
	}
function contentResponsesTable()
	{
		var i, j, ck, index, grResponseStatus, status1, status2, status3, status4, tab = [], aTab = [], oldIdA, oldActionSearch; 
		var goodStatus, badStatus, neutralStatus, groundScore, valueScore, improvementLength, excedeedLengt, actionNPS, content = '';
		var aux = 0;

		document.getElementById('B1-txtFilterTitles').innerHTML = stringAllResponsesSelections;
		arrangeCSSclasses('B1-txtFilterTitles','tagAppearance,tagAppearance','0,1');
		document.getElementById('D2-txtNumberSelectedResponses').innerHTML = listSelectedResponses.length +" response(s) selected";
		
		for(i=0;i<listSelectedResponses.length;i++)
		{
			j = 0; index = -1; // check if it s required
			while((index == -1) && (j<allResponses.length))
			{
				if(allResponses[j].index == listSelectedResponses[i]) index = j;
				j++;
			}
			index = listSelectedResponses[i];
			//dateConverted = new Date(parseInt(allNPS[index].dateCreated_SFDC));
			//document.getElementById('D2-txtNumberSelectedResponses').innerHTML = i+'/'+index+': '+SFDCresponses[index].Status_Action__c;
			goodStatus = '<span class=" colorGreen fontEvenBigger pushInRight01">&#9745;</span>';
			//goodStatus = '<i class="fa fa-check-circle fa-lg colorGreen fontBigger pushInRight01" aria-hidden="true"></i>';
			//goodStatus = '<i class="fa fa-check-circle-o fa-lg colorGreen fontBigger pushInRight01" aria-hidden="true"></i>';
			//goodStatus = '<i class="fa fa-check-square-o fa-lg colorGreen fontBigger pushInRight01" aria-hidden="true"></i>';
			//goodStatus = '<i class="fa fa-check-square fa-lg colorGreen fontBigger pushInRight01" aria-hidden="true"></i>';

			badStatus = '<span class=" colorHONred fontEvenBigger pushInRight01">&#9746;</span>';
			//badStatus = '<i class="fa fa-exclamation-circle fa-lg colorHONred fontBigger pushInRight01" aria-hidden="true"></i>';
			//badStatus = '<i class="fa fa-exclamation-triangle fa-lg colorHONred fontBigger pushInRight01" aria-hidden="true"></i>';
			
			neutralStatus = '<span class=" colorGreen fontEvenBigger pushInRight01">&#9744;</span>';
			//neutralStatus = '<i class="fa fa-square-o fa-lg colorGray20 fontBigger pushInRight01" aria-hidden="true"></i>';
			//neutralStatus = '<i class="fa fa-square fa-lg colorGray20 fontBigger pushInRight03" aria-hidden="true"></i>';
			//neutralStatus = '<i class="fa fa-circle fa-lg colorGray20 fontBigger pushInRight03" aria-hidden="true"></i>';
			//neutralStatus = '<i class="fa fa-circle-o fa-lg colorGray20 fontBigger pushInRight01" aria-hidden="true"></i>';
			//neutralStatus = '<i class="fa fa-circle-thin fa-lg colorGray20 fontBigger pushInRight03" aria-hidden="true"></i>';
			
			if(allResponses[index].statusFeedback == '1') status1 = '<span class="" title="Customer Team Comments.">'+goodStatus+'</span>';
				else status1 = '<span class="" title="Customer Team Comments.">'+badStatus+'</span>';
			if(allResponses[index].statusTouchpoints == '1') status2 = '<span class="" title="Touchpoints selection.">'+goodStatus+'</span>';
				else status2 = '<span class="" title="Touchpoints selection.">'+badStatus+'</span>';	
			if(allResponses[index].statusCategories == '1') status3 = '<span class="" title="Categories Selection.">'+goodStatus+'</span>';
				else status3 = '<span class="" title="Categories Selection.">'+badStatus+'</span>';
			if(allResponses[index].statusActions == '1') status4 = '<span class="" title="Assign follow up actions.">'+goodStatus+'</span>';
				else status4 = '<span class="" title="Assign follow up actions.">'+badStatus+'</span>';

			if(allResponses[index].score != 0)
			{
				if(allResponses[index].score >8) groundScore = 'goodFeedback';
				if((allResponses[index].score == 7) || (allResponses[index].score == 8)) groundScore = 'neutralFeedback';
				if(allResponses[index].score <7) groundScore = 'badFeedback';
				valueScore = allResponses[index].score.toString();
			}
			else {groundScore = '';valueScore = 'NA';}
			
			grResponseStatus = '<p class="pushOutLeft05 noWrap">' + status1 + status2 + status3 + status4 +'</p>';
			
			actionNPS = 'No actions assigned';
			if(allResponses[index].actionsCheck == '1') actionNPS = 'Not required';
			
			if(allResponses[index].listActionsName.length != 0)
			{
				ck = true;
				//actionNPS = allResponses[index].listActionsName;
				
				tab.length = 0; tab = allResponses[index].listActionsName.split(';');
				aTab.length = 0; aTab = allResponses[index].listActionsID.split(';');
				oldIdA = idA; //oldActionSearch = tbUrlFilterA[8];
				actionNPS = '<p id="D2-action'+listSelectedResponses[i]+'" >';
				for(j=0;j<tab.length;j++)
				{
					idA = aTab[j];
					//for(k=0;k<9;k++) tbUrlFilterA[k] = 0;
					//tbUrlFilterA[8] = allResponses[index].responseName;
					if((actionNPS.length != 0) && (j != 0)) actionNPS += '<br/>';
					
					actionNPS += '<span class="aLink">'+tab[j]+'</span>';
				}
				actionNPS += '</p>';
				idA = oldIdA; //tbUrlFilterA[8] = oldActionSearch;;
			}
			content +='<tr>'+
					'<td class="textCenter">'+(i+1)+'.</td><!-- Nr. -->'+
					'<td class="textCenter fontBigger"><p class="textCenter pushOutRight05 '+groundScore+'">'+valueScore+'</p></td><!-- Score -->'+
					'<td class="noWrap" title="'+allResponses[index].account+'">'+allResponses[index].account.substr(0,20)+'<br/><span class="colorDarkBlue20k">'+allResponses[index].accountOwner+'</span></td><!-- Account (Owner) -->'+
					'<td><a href="https://hon-ts.my.salesforce.com/'+allResponses[index].contactID+'" target="_blank" class="noWrap aLink">'+allResponses[index].contactName+'</a><br/><span class="colorGray40">'+allResponses[index].contactDEEPN+'</span></td><!-- Customer -->'+
					
					'<td class="textCenter noWrap">'+dateConverted(allResponses[index].dateCreated)+'</td><!-- Response Date -->'+
					'<td title="'+allResponses[index].commentsEE+'">&nbsp;'+allResponses[index].commentsEE/*.substr(0,35)*/+'...</td><!-- Needs Improvement -->'+
					'<td title="'+allResponses[index].commentsNI+'">'+allResponses[index].commentsNI+'</td><!-- Exceeded Expectations -->'+
					'<td class="noWrap aLink" id="D2-response'+listSelectedResponses[i]+'">'+allResponses[index].responseName+'</td><!-- NPS ID -->'+
					'<td class="noWrap" style="width:8em;" >'+grResponseStatus+'</td><!-- Status -->'+
					'<td class="noWrap">'+actionNPS+'</td><!-- Action list -->'+
				'</tr>';
		}

		document.getElementById('D2-tbResponses').innerHTML = content;
	} 

function eventsResponses()
	{
		document.getElementById('D1-btnSearch').onclick = function(){fillSelectedResponses();contentResponsesTable();eventsResponsesTable();return false;}
		document.getElementById('D1-iSearch').onkeyup = function(event) {if(event.keyCode == 13) fillSelectedResponses();contentResponsesTable();eventsResponsesTable();}
		document.getElementById('D1-iSearch').onkeydown = function(event) {if(event.keyCode == 13) fillSelectedResponses();contentResponsesTable();eventsResponsesTable();}
		document.getElementById('D2-btnNewResponse').onclick = function(){selectMainMenu('A2-btnNewResponse');return false;}
	}
function eventsSelectionsResponses()
	{
		document.getElementById('D1-iDateStart').onchange = function() 
			{
				startDateResponse = Date.parse(document.getElementById('D1-iDateStart').value);
				document.getElementById('D1-iDateStart').value = dateConverted(startDateResponse);
				if(startDateResponse > endDateResponse)
				{
					arrangeCSSclasses('D1-iDateStart','colorHONred','1');
					arrangeCSSclasses('D1-iDateEnd','colorHONred','1');
				}
				else
				{
					arrangeCSSclasses('D1-iDateStart','colorHONred','0');
					arrangeCSSclasses('D1-iDateEnd','colorHONred','0');
					fillSelectedResponses();contentResponsesTable();eventsResponsesTable();
				}
			};
		document.getElementById('D1-iDateEnd').onchange = function() 
			{
				endDateResponse = Date.parse(document.getElementById('D1-iDateEnd').value);
				document.getElementById('D1-iDateEnd').value = dateConverted(endDateResponse);
				if(startDateResponse > endDateResponse)
				{
					arrangeCSSclasses('D1-iDateStart','colorHONred','1');
					arrangeCSSclasses('D1-iDateEnd','colorHONred','1');
				}
				else
				{
					arrangeCSSclasses('D1-iDateStart','colorHONred','0');
					arrangeCSSclasses('D1-iDateEnd','colorHONred','0');
					fillSelectedResponses();contentResponsesTable();eventsResponsesTable();
				}
			};
	}	
function eventsResponsesTable()
	{
		var i;
		document.getElementById('D2-hcScore').onclick = function()
			{
				if(document.getElementById('D2-hcScore').innerHTML.indexOf('fa-sort-asc') != -1) sortResponsesTable('score','desc');
				else sortResponsesTable('score','asc');
			}
		document.getElementById('D2-hcAccount').onclick = function()
			{
				if(document.getElementById('D2-hcAccount').innerHTML.indexOf('fa-sort-asc') != -1) sortResponsesTable('account','desc');
				else sortResponsesTable('account','asc');
			}
		document.getElementById('D2-hcContact').onclick = function()
			{
				if(document.getElementById('D2-hcContact').innerHTML.indexOf('fa-sort-asc') != -1) sortResponsesTable('contact','desc');
				else sortResponsesTable('contact','asc');
			}
		document.getElementById('D2-hcDate').onclick = function()
			{
				if(document.getElementById('D2-hcDate').innerHTML.indexOf('fa-sort-desc') != -1) sortResponsesTable('date','asc');
				else sortResponsesTable('date','desc');
			}
		for(i=0;i<listSelectedResponses.length;i++)
			document.getElementById('D2-response'+listSelectedResponses[i]).onclick = function() {identifySelectedResponse(this.id);};
		for(i=0;i<listSelectedResponses.length;i++)
			if(document.getElementById('D2-action'+listSelectedResponses[i])) document.getElementById('D2-action'+listSelectedResponses[i]).onclick = function() {identifySelectedAction(this.id);};
	}

function fulfillTheRestOfResponses()
	{
		var i, j;
		
		for(i=0;i<allResponses.length;i++)
		{
			for(j=0;j<allActionResponses.length;j++)
			{
				if(allActionResponses[j].sourcesIDs.indexOf(allResponses[i].responseID) != -1)
				{
					
					if(allResponses[i].listActionsID == '') 
					{
						allResponses[i].listActionsID = allActionResponses[j].actionID;
						allResponses[i].listActionsName = allActionResponses[j].actionName;
					}
					else
					{
						allResponses[i].listActionsID += ';' + allActionResponses[j].actionID;
						allResponses[i].listActionsName += ';' + allActionResponses[j].actionName;	
					}
				}
			}
			if((allResponses[i].listActionsID == '') && (allResponses[i].actionsCheck == '0')) allResponses[i].statusActions = '0'; else allResponses[i].statusActions = '1';
		}
			
	}
function fillSelectedResponses()
	{
		function checkStatus(index,param)
			{
				var radioSelection, responseStatus;
				switch(param)
				{
					case 'Feedback': responseStatus = allResponses[index].statusFeedback; break;
					case 'Touchpoints': responseStatus = allResponses[index].statusTouchpoints; break;
					case 'Categories': responseStatus = allResponses[index].statusCategories; break;
					case 'Actions': responseStatus = allResponses[index].statusActions; break;
				}
				if(document.getElementById('D1-rStatus'+param+'0').checked) return true;
				else
				{
					if(document.getElementById('D1-rStatus'+param+'1').checked)
					{
						if(responseStatus == '0') return true;
						else return false;
					}
					if(document.getElementById('D1-rStatus'+param+'2').checked)
					{
						if(responseStatus == '1') return true;
						else return false;
					} 
				}
			}
		function checkTouchpointsSelection(index)
			{
				var i, ckEE, ckNI, tab = [], tab2 = [], aTab = [];
				if(phaseSelected != 0)
				{
					if((allResponses[index].touchpointsEE != '') || (allResponses[index].touchpointsNI != ''))
					{							
						if(allResponses[index].touchpointsNI != '')
						{
							aTab.length = 0; aTab = allResponses[index].touchpointsNI.split(';');
							ckNI = false;
							for(k=0;k<aTab.length;k++)
							{
								if(aTab[k].split('___')[0].indexOf(listPhases[phaseSelected]) != -1)
								{
									if(touchpointSelected == 0) ckNI = true;
									else
									{
										if(aTab[k].split('___')[1].indexOf(listSelectedPhase[touchpointSelected]) != -1) ckNI = true;
									}
								} 
							} 
						}
						if(allResponses[index].touchpointsEE != '')
						{
							aTab.length = 0; aTab = allResponses[index].touchpointsEE.split(';');
							ckEE = false;
							for(k=0;k<aTab.length;k++)
							{
								if(aTab[k].split('___')[0].indexOf(listPhases[phaseSelected]) != -1)
								{
									if(touchpointSelected == 0) ckEE = true;
									else
									{
										if(aTab[k].split('___')[1].indexOf(listSelectedPhase[touchpointSelected]) != -1) ckEE = true;
									}
								}
							} 
						}
						switch(selectedTouchpointsType)
						{
							case 'ALL':{if(ckEE || ckNI) return true; else return false;}; break;
							case 'Exceeded Expectations': {if(ckEE) return true; else return false;}; break;
							case 'Need Improvements':{if(ckNI) return true; else return false;}; break;
						}
					}
					else return false;
				}
				else return true;
			}
		function checkPointsSelection(index)
			{
				var i, ck, tab = [], tab2 = [], aTab = [];
				if(categorySelected != 0)
				{
					if(allResponses[index].categories != '')
					{
						aTab.length = 0; aTab = allResponses[index].categories.split(';');
						ck = false;
						for(k=0;k<aTab.length;k++)
						{
							if(aTab[k].split('___')[0].indexOf(listCategories[categorySelected]) != -1)
							{
								if(pointSelected == 0) ck = true;
								else
								{
									if(aTab[k].split('___')[1].indexOf(listSelectedCategory[pointSelected]) != -1) ck = true;
									
								}
							}
						}
						return ck;
					}
					else return false;
				}
				else return true;
			}
		/*function checkPlant(index)
			{
				var i, ck, tab = [], tab2 = [], aTab = [];
				if(categorySelected != 0)
				{
					if(allResponses[index].categories != '')
					{
						aTab.length = 0; aTab = allResponses[index].categories.split(';');
						ck = false;
						for(k=0;k<aTab.length;k++)
						{
							if(aTab[k].split('___')[0].indexOf(listCategories[categorySelected]) != -1)
							{
								if(pointSelected == 0) ck = true;
								else
								{
									if(aTab[k].split('___')[1].indexOf(listSelectedCategory[pointSelected]) != -1) ck = true;
									
								}
							}
						}
						return ck;
					}
					else return false;
				}
				else return true;
			}*/
		
		var checkLOB, checkRegion, checkDEEPN, checkPlant, checkResponders, checkTime, checkTouchpointsType, checkOwnership;
		var i, j, selectedLOB, selectedRegion, selectedDEEPN,  selectedPlant, selectedResponders, startDate, endDate, timeOption, selectedTouchpointsType;
		var phaseSelected, touchpointSelected, categorySelected, pointSelected, selectedOwnership, searchWord; 
		var tbStatus = ['Feedback','Touchpoints','Categories','Actions'];
		
		stringAllResponsesSelections = '';

		// check filters
			i = objSelResponsesLOB.indexSelected;
			if(i != 0)
			{
				selectedLOB = listLOBall[i][0];
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listLOBall[i][0];
				else stringAllResponsesSelections += '; ' + listLOBall[i][0];
			}
			
			i = objSelResponsesRegion.indexSelected;
			if(i != 0)
			{
				selectedRegion = listRegionsAll[i][0];
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listRegionsAll[i][0];
				else stringAllResponsesSelections += '; ' + listRegionsAll[i][0];
			}	

			i = objSelResponsesDEEPN.indexSelected;
			if(i != 0)
			{
				selectedDEEPN = listDEEPNall[i];
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listDEEPNall[i];
				else stringAllResponsesSelections += '; ' + listDEEPNall[i];
			}
			
			i = objSelResponsesPlant.indexSelected;
			if(i != 0)
			{
				selectedPlant = listPlantsAll[i];
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listPlantsAll[i];
				else stringAllResponsesSelections += '; ' + listPlantsAll[i];
			}

			timeOption = objSelResponsesTime.indexSelected.toString();
			switch(timeOption) 
				{
					case '0':{startDate = oldestResponse; endDate = newestResponse;} break;
					case '1':
					{
						startDate = oneYearAgo; endDate = newestResponse; 
						if(stringAllResponsesSelections == '') stringAllResponsesSelections = 'Last 12 months'; else stringAllResponsesSelections += '; Last 12 months';
					} break;
					case '2':
					{
						startDate = oldestResponse; endDate = oneYearAgo-24*3600*1000;
						if(stringAllResponsesSelections == '') stringAllResponsesSelections = 'Older than 12 months'; else stringAllResponsesSelections += '; Older than 12 months';
					} break;
					case '3':
					{
						if(startDateResponse < endDateResponse) 
						{
							startDate = startDateResponse; endDate = endDateResponse;
							if(stringAllResponsesSelections == '') stringAllResponsesSelections = 'From '+dateConverted(startDate)+' to '+dateConverted(endDate); 
							else stringAllResponsesSelections += '; From '+dateConverted(startDate)+' to '+dateConverted(endDate);
							endDate = endDate + 24*3600*1000;
						} 
						else startDate = -1;
					}break;
				}

			i = objSelResponsesRespondersType.indexSelected;
			if(i != 0)
			{
				selectedResponders = listRespondersType[i];
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listRespondersType[i];
				else stringAllResponsesSelections += '; ' + listRespondersType[i];	
			}
			
			for(i=0;i<tbStatus.length;i++)//status comments
				{
					if(document.getElementById('D1-rStatus'+tbStatus[i]+'1').checked)
					{
						if(stringAllResponsesSelections == '') stringAllResponsesSelections = tbStatus[i] + ' open';else  stringAllResponsesSelections += '; '+tbStatus[i] + ' open';
					}
					if(document.getElementById('D1-rStatus'+tbStatus[i]+'2').checked)
					{
						if(stringAllResponsesSelections == '') stringAllResponsesSelections = tbStatus[i] + ' completed';else  stringAllResponsesSelections += '; '+tbStatus[i] + ' completed';
					}
				}
			i = objSelResponsesTouchpointsType.indexSelected;
			selectedTouchpointsType = listTouchpointsType[i];
			if(i != 0)
			{				
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listTouchpointsType[i];
				else stringAllResponsesSelections += '; ' + listTouchpointsType[i];	
			}
			for(i=0;i<listPhases.length;i++)//touchpoints comments
				if(document.getElementById('D1-rPhases'+i).checked) 
				{
					phaseSelected = i;
					if(phaseSelected != 0)
					{
						if(stringAllResponsesSelections == '') stringAllResponsesSelections = listPhases[i];
						else stringAllResponsesSelections += '; ' + listPhases[i];
						
						for(j=0;j<listSelectedPhase.length;j++)
						{
							if(document.getElementById('D1-rTouchpoints'+j).checked)
							{							
								touchpointSelected = j;
								if(touchpointSelected != 0) stringAllResponsesSelections += '-' + listSelectedPhase[j];	
							} 
						}
					}
				}
			for(i=0;i<listCategories.length;i++)//categories comments
				if(document.getElementById('D1-rCategories'+i).checked) 
				{
					categorySelected = i;
					if(categorySelected != 0)
					{
						if(stringAllResponsesSelections == '') stringAllResponsesSelections = listCategories[i];
						else stringAllResponsesSelections += '; ' + listCategories[i];
						
						for(j=0;j<listSelectedCategory.length;j++)
						{
							if(document.getElementById('D1-rPoints'+j).checked)
							{							
								pointSelected = j;
								if(pointSelected != 0) stringAllResponsesSelections += '-' + listSelectedCategory[j];	
							} 
						}
					}
				}
			
			i = objSelResponsesOwnership.indexSelected;
			if(i != 0)
			{
				selectedOwnership = i;
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = listOwnership[i];
					else stringAllResponsesSelections += '; ' + listOwnership[i];
			}
			searchWord = document.getElementById('D1-iSearch').value;
			if(searchWord != '')
			{
				if(stringAllResponsesSelections == '') stringAllResponsesSelections = searchWord; 
				else stringAllResponsesSelections += '; ' + searchWord;
			}

		// apply filters
		listSelectedResponses.length = 0;
		for(i=0;i<allResponses.length;i++)
		{
			if(document.getElementById('D1-rLOB0').checked) checkLOB = true;
			else
			{
				if(allResponses[i].LOB.indexOf(selectedLOB) != -1) checkLOB = true;
				else checkLOB = false;
			}
			if(document.getElementById('D1-rRegions0').checked) checkRegion = true;
			else
			{
				if(allResponses[i].region.indexOf(selectedRegion) != -1) checkRegion = true;
				else checkRegion = false;	
			}
			if(document.getElementById('D1-rDEEPN0').checked) checkDEEPN = true;
			else
			{
				if(allResponses[i].contactDEEPN.indexOf(selectedDEEPN) != -1) checkDEEPN = true;
				else checkDEEPN = false;
			}
			if(document.getElementById('D1-rPlant0').checked) checkPlant = true;
			else
			{
				if(allResponses[i].categories.indexOf(selectedPlant) != -1) checkPlant = true;
				else checkPlant = false;
			}
			if(document.getElementById('D1-rResponders0').checked) checkResponders = true;
			else
			{
				switch(selectedResponders)
				{
					case 'Promoters':
					{
						if(allResponses[i].score > 8) checkResponders = true; else checkResponders = false;
					}break;
					case 'Passives':
					{
						if((allResponses[i].score == 8) || (allResponses[i].score == 7)) checkResponders = true; else checkResponders = false;
					}break;
					case 'Detractors':
					{
						if((allResponses[i].score >= 1) && (allResponses[i].score <= 6)) checkResponders = true; else checkResponders = false;
					}break;
					case 'VOCs':
					{
						if(allResponses[i].score == 0) checkResponders = true; else checkResponders = false;
					}break;
				}
			}
			if(startDate == -1) checkTime = true;
			else 
			{
				if((allResponses[i].dateCreated >= startDate) && (allResponses[i].dateCreated <= endDate)) checkTime = true;
				else checkTime = false;
			}
			if(document.getElementById('D1-rTouchpointsType0').checked) checkTouchpointsType = true;
			else
			{
				switch(selectedTouchpointsType)
				{
					case 'Exceeded Expectations':
					{
						if(allResponses[i].touchpointsEE.length != 0) checkResponders = true; else checkResponders = false;
					}break;
					case 'Need Improvements':
					{
						if(allResponses[i].touchpointsNI.length != 0) checkResponders = true; else checkResponders = false;
					}break;
				}
			}
			if(document.getElementById('D1-rOwnership0').checked) checkOwnership = true;
			else
			{
				switch(selectedOwnership.toString())
					{
						case '1':
							{
								checkOwnership = false;
								for(j=0;j<listUserAccounts.length;j++)
									if(allResponses[i].account == listUserAccounts[j]) checkOwnership = true;
							};break;
							case '2':
							{
								checkOwnership = false;
								for(j=0;j<listUserParentAccounts.length;j++)
									if(allResponses[i].parentAccount == listUserParentAccounts[j]) checkOwnership = true;
							};break;
					}
			}
			
			if(checkLOB && checkRegion && checkDEEPN && checkPlant && checkTime && checkResponders &&
				checkStatus(i,'Feedback') && checkStatus(i,'Touchpoints') && checkStatus(i,'Categories') && checkStatus(i,'Actions') &&
				checkTouchpointsSelection(i) && checkPointsSelection(i) && checkOwnership)
			{
				if(searchWord == '') listSelectedResponses[listSelectedResponses.length] = i;
				else
				{
					ck = false;
					if(document.getElementById('D1-rFreeSearch0').checked)
					{
						if(allResponses[i].account.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allResponses[i].parentAccount.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allResponses[i].accountOwner.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allResponses[i].contactName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allResponses[i].responseName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allResponses[i].commentsEE.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						if(allResponses[i].commentsNI.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
					}
					else
					{
						if((document.getElementById('D1-rFreeSearch1').checked) && (allResponses[i].account.toLowerCase() == searchWord.toLowerCase())) ck = true;
						if((document.getElementById('D1-rFreeSearch2').checked) && (allResponses[i].parentAccount.toLowerCase() == searchWord.toLowerCase())) ck = true;
						if((document.getElementById('D1-rFreeSearch3').checked) && (allResponses[i].accountOwner.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('D1-rFreeSearch4').checked) && (allResponses[i].contactName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('D1-rFreeSearch5').checked) && (allResponses[i].responseName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('D1-rFreeSearch6').checked) && (allResponses[i].commentsEE.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						if((document.getElementById('D1-rFreeSearch6').checked) && (allResponses[i].commentsNI.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
					}
					if(ck) listSelectedResponses[listSelectedResponses.length] = i;
				}	
			}
		}
		contentAccordion('myAccordion','');
		/*document.getElementById('A3-sFilters').style.height = document.getElementById('A3-sFilters').parentElement.scroll

		otherListTags = panel.parentElement.children;
		panel.parentElement.style.maxHeight = '0px';
		for(j=0;j<otherListTags.length;j++)
			panel.parentElement.style.maxHeight = 
				parseInt(panel.parentElement.style.maxHeight) + 
				otherListTags[j].scrollHeight + 
				parseInt(document.defaultView.getComputedStyle(otherListTags[j], '').getPropertyValue('margin-top')) + 
				parseInt(document.defaultView.getComputedStyle(otherListTags[j], '').getPropertyValue('margin-bottom'))+'px';

		var listTags = document.getElementById('A3-sFilters').children;
		var maxHeight = '0px';
		for(j=0;j<listTags.length;j++)
			maxHeight = 
				parseInt(maxHeight) + 
				listTags[j].scrollHeight + 
				parseInt(document.defaultView.getComputedStyle(listTags[j], '').getPropertyValue('margin-top')) + 
				parseInt(document.defaultView.getComputedStyle(listTags[j], '').getPropertyValue('margin-bottom'))+'px';*/
		document.getElementById('A3-sFilters').style.height = document.getElementById('A3-sFilters').parentElement.scrollHeight;
	}

function callbackSelectionsResponses()
	{
		fillSelectedResponses();contentResponsesTable();eventsResponsesTable();
	}
function callbackSelResponsesWithDate()
	{
		prepareTimeRangeSelectionResponses();
		fillSelectedResponses();contentResponsesTable();eventsResponsesTable();
	}
function callbackSelectionsResponsesPhases()
	{
		prepareTouchpointsSelection();		
		fillSelectedResponses();contentResponsesTable();eventsResponsesTable();	

	}
function callbackSelectionsResponsesCategories()
	{
		preparePointsImproveSelection();
		fillSelectedResponses();contentResponsesTable();eventsResponsesTable();	
	}

function prepareTimeRangeSelectionResponses()
	{
		var i, index;
		for(i=0;i<listTimeInterval.length;i++)
			if(document.getElementById('D1-rTimeInterval'+i).checked) index = i;
		if(index == 3)
		{
			document.getElementById('D1-iDateStart').disabled = false;
			document.getElementById('D1-iDateEnd').disabled = false;
		}
		else
		{
			document.getElementById('D1-iDateStart').disabled = true;
			document.getElementById('D1-iDateEnd').disabled = true;	
		}
	}
function prepareTouchpointsSelection()
	{
		var i, index;
		for(i=0;i<listPhases.length;i++)
			if(document.getElementById('D1-rPhases'+i).checked) index = i;
		if(index != 0)
		{
			listSelectedPhase.length = 0;
			listSelectedPhase = tbE2ESteps[index-1][1].split(';');
			listSelectedPhase.unshift('All');
			objSelResponsesTouchpoints.initialize('D1-rTouchpoints','radio',listSelectedPhase,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		}
		else document.getElementById('D1-rTouchpointsContainer').innerHTML = '<label class="inputDeselected">All</label>';
	}
function preparePointsImproveSelection()
	{
		var i, index;
		for(i=0;i<listCategories.length;i++)
			if(document.getElementById('D1-rCategories'+i).checked) index = i;
		if(index != 0)
		{
			listSelectedCategory.length = 0;
			listSelectedCategory = tbCategories[index-1][1].split(';');
			listSelectedCategory.unshift('All');
			objSelResponsesPoints.initialize('D1-rPoints','radio',listSelectedCategory,callbackSelectionsResponses,'inputSelected','inputUnselected','0');
		}
		else document.getElementById('D1-rPointsContainer').innerHTML = '<label class="inputDeselected">All</label>';
	}
function sortResponsesTable(param,direction)
	{
		var returnAsc, returnDesc;
		document.getElementById('D2-hcScore').innerHTML = 'Score&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('D2-hcAccount').innerHTML = 'Account / Owner&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('D2-hcContact').innerHTML = 'Customer&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('D2-hcDate').innerHTML = 'Date&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		if(direction == 'asc') {returnAsc = 1; returnDesc = -1;}
		else {returnAsc = -1; returnDesc = 1;}
		switch(param)
		{
			case 'score':
			{
				document.getElementById('D2-hcScore').innerHTML = 'Score&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allResponses.sort(function(a,b)
				{
					var x = a.score;
					var y = b.score;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.dateCreated > b.dateCreated) return -1;
						if(a.dateCreated < b.dateCreated) return 1;
						else return 0;
					}
				});
			};break;
			case 'account':
			{
				document.getElementById('D2-hcAccount').innerHTML = 'Account / Owner&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allResponses.sort(function(a,b)
				{
					var x = a.account;
					var y = b.account;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.dateCreated > b.dateCreated) return -1;
						if(a.dateCreated < b.dateCreated) return 1;
						else return 0;
					}
				});
			};break;
			case 'contact':
			{
				document.getElementById('D2-hcContact').innerHTML = 'Customer&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allResponses.sort(function(a,b)
				{
					var x = a.contactName;
					var y = b.contactName;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.dateCreated > b.dateCreated) return -1;
						if(a.dateCreated < b.dateCreated) return 1;
						else return 0;
					}
				});
			};break;
			case 'date':
			{
				document.getElementById('D2-hcDate').innerHTML = 'Date&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allResponses.sort(function(a,b)
				{
					var x = a.dateCreated;
					var y = b.dateCreated;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else return 0;
				});
			};break;
			

		}
		fillSelectedResponses();
		contentResponsesTable();
		eventsResponsesTable();
	}

function identifySelectedResponse(id)
	{
		selectedResponse = allResponses[parseInt(id.replace('D2-response',''))].responseID;
		goToFormPage();
	}
function identifySelectedAction(id)
	{
		selectedResponse = allResponses[parseInt(id.replace('D2-action',''))].responseName;
		goToActionsPage('-1',selectedResponse);
	}

