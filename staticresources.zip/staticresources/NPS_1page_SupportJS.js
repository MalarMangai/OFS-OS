
var allEmailTemplates = [];
	var anEmailTemplate = 
	{
		templateID: '',
		templateName: '',
		templateSubject: '',
		templateHtmlValue: ''
	}
var listEmailTemplates = ['Request','Additional','Thanks','Unsubscribe'];
var objSelSupportLanguages = new newInputRadioOrCheckbox();

function initializeSupport()
	{
		contentAllEmailTemplates();
		eventsSupport();
		objSelSupportLanguages.initialize('S1-rLanguages','radio',listLanguages,fulfillTemplates,'inputSelected','inputUnselected','0');
		fulfillTemplates();
		identifyNPSadmin(); // check NPS_1page_AdminJS.js
	}
function contentAllEmailTemplates()
	{
		var i, content = '';
		for(i=0;i<listEmailTemplates.length;i++)
			content += '<h3 id="S2-h'+listEmailTemplates[i]+'" class="sArea h3Style groundLyricWhite">NPS Survey '+listEmailTemplates[i]+'</h3>'+
				'<div class="table pushOutBottom2">'+
				'	<div class="row">'+
				'		<div class="column textTop">Title:</div>'+
				'		<div class="column" id="S2-s'+listEmailTemplates[i]+'Title"></div>'+
				'	</div>'+
				'	<div class="row">'+
				'		<div class="column textTop">Content:</div>'+
				'		<div class="column" id="S2-s'+listEmailTemplates[i]+'Content"></div>'+
				'	</div>'+
				'</div>';
		document.getElementById('S2-content').innerHTML = content;
	}
function eventsSupport()
	{
		document.getElementById('S3-btnCancel').onclick = function(){document.getElementById('S3-txtaMessage').value = '';};
		document.getElementById('S3-btnSend').onclick = function()
		{
			sendEmailToAdmin(document.getElementById('S3-txtaMessage').value);
			document.getElementById('S3-txtaMessage').value = '';
		};
	}

function fulfillTemplates()
	{
		var i, j, index = objSelSupportLanguages.indexSelected;

		for(i=0;i<allEmailTemplates.length;i++)
			if(allEmailTemplates[i].templateName.indexOf('English') != -1)
				for(j=0;j<listEmailTemplates.length;j++)
				{
					if(allEmailTemplates[i].templateName.indexOf(listEmailTemplates[j]) != -1)
					{
						document.getElementById('S2-h'+listEmailTemplates[j]).innerHTML = allEmailTemplates[i].templateName;
						document.getElementById('S2-s'+listEmailTemplates[j]+'Title').innerHTML = allEmailTemplates[i].templateSubject;
						document.getElementById('S2-s'+listEmailTemplates[j]+'Content').innerHTML = allEmailTemplates[i].templateHtmlValue;	
					}
				}
		for(i=0;i<allEmailTemplates.length;i++)
			if(allEmailTemplates[i].templateName.indexOf(listLanguages[index]) != -1)
				for(j=0;j<listEmailTemplates.length;j++)
				{
					if(allEmailTemplates[i].templateName.indexOf(listEmailTemplates[j]) != -1)
					{
						document.getElementById('S2-h'+listEmailTemplates[j]).innerHTML = allEmailTemplates[i].templateName;
						document.getElementById('S2-s'+listEmailTemplates[j]+'Title').innerHTML = allEmailTemplates[i].templateSubject;
						document.getElementById('S2-s'+listEmailTemplates[j]+'Content').innerHTML = allEmailTemplates[i].templateHtmlValue;	
					}
				}
		arrangeCSSclasses('S2-content','tagAppearance,tagAppearance','0,1');
	}