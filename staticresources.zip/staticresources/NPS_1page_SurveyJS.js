
// specific variables for Survey page	
	var listNPSstatus = ['ALL','Not NPS Target', 'NPS Target', 'NPS target, available now', 'NPS target, not available now', 'NPS target, more data needed']; 
	var listNPSactivity = ['ALL', 'Never Contacted', 'Contacted in last 12 months', 'Contacted in last 30 days', 'Contacted in last 7 days', 'From <input id="C1-iActDateStart" type="text" class="inputForDate" readonly/> until <input id="C1-iActDateEnd" type="text" class="inputForDate"/>'];
	var listNPSresponse = ['ALL', 'Never Responded', 'Responded in last 12 months', 'Responded in last 30 days', 'Responded in last 7 days', 'From <input id="C1-iResDateStart" type="text" class="inputForDate" readonly/> until <input id="C1-iResDateEnd" type="text" class="inputForDate"/>','Opt out from getting surveys'];
	var listFreeSearchSurvey = ['ALL','Account','Parent Account','Owner','Customer Name'];

	var stringAllContactsSelections = '', startDateAct, endDateAct, startDateRes, endDateRes, currentContact;
	var listSelectedContacts = [], listMassEmail = [], listNPSs = [];

	var objSelSurveyLOB = newInputRadioOrCheckbox();
	var objSelSurveyRegion = newInputRadioOrCheckbox();
	var objSelSurveyDEEPN = newInputRadioOrCheckbox();
	var objSelSurveyPlant = newInputRadioOrCheckbox();
	var objSelSurveyNPSstatus = newInputRadioOrCheckbox();
	var objSelSurveyNPSactivity = newInputRadioOrCheckbox();
	var objSelSurveyNPSresponse = newInputRadioOrCheckbox();
	var objSelSurveyOwnership = newInputRadioOrCheckbox();
	var objSelSurveyFreeSearch = newInputRadioOrCheckbox();

function initializeContacts()
	{
		fulfillOrganizationalEmails(); // function is located in VfP
		
		document.getElementById('C2-btnSendEmailAll').disabled = true;		
		document.getElementById('C22-sNPSavailability').style.display = 'none';
		document.getElementById('C21-selEmailLanguage').style.display = 'none';		
		document.getElementById('C22-btnNPSavailability').disabled = true;
		document.getElementById('C21-btnSendEmail').disabled = true;
		
		document.getElementById('C2-btnSendEmailAll').disabled = true;
		arrangeCSSclasses('C2-btnSendEmailAll','buttonObvious,buttonInactive','0,1');

		var i, j;
		for(i=0;i<allContacts.length;i++)
		{
			for(j=0;j<allResponses.length;j++)
				if(allResponses[j].contactID == allContacts[i].contactID)
				{
					if(allContacts[i].listResponses == '-1') allContacts[i].listResponses = allResponses[j].score+':'+allResponses[j].responseName+':'+allResponses[j].dateCreated;
					else allContacts[i].listResponses += ';'+allResponses[j].score+':'+allResponses[j].responseName+':'+allResponses[j].dateCreated;
				}

			for(j=0;j<allRequests.length;j++)
				if(allRequests[j].contactID == allContacts[i].contactID)
				{
					if(allContacts[i].listRequests == '-1') allContacts[i].listRequests = allRequests[j].dateCreated.toString();
					else allContacts[i].listRequests += ';'+allRequests[j].dateCreated;
				}
		}
		contentAccordion('myAccordion','');
		contentSelectionsContacts();
		eventsSelectionsContacts();
		//initializeFiltersSurvey();
		
		fillSelectedContacts(); // extract content&events from this 
		sortContactsTable('name','asc'); // after contacted
		
		eventsContacts();
    }

function contentSelectionsContacts()
	{
		var i, aTab = [], content = '';
		
		aTab.length = 0; for(i=0;i<listLOBall.length;i++) aTab[aTab.length] = listLOBall[i][0]; 
		objSelSurveyLOB.initialize('C1-rLOB','radio',aTab,fillSelectedContacts,'inputSelected','inputUnselected','0');

		aTab.length = 0; for(i=0;i<listRegionsAll.length;i++) aTab[aTab.length] = listRegionsAll[i][0]; 
		objSelSurveyRegion.initialize('C1-rRegion','radio',aTab,fillSelectedContacts,'inputSelected','inputUnselected','0');
		
		objSelSurveyDEEPN.initialize('C1-rDEEPN','radio',listDEEPNall,fillSelectedContacts,'inputSelected','inputUnselected','0');
		objSelSurveyPlant.initialize('C1-rPlant','radio',listPlantsAll,fillSelectedContacts,'inputSelected','inputUnselected','0');
		objSelSurveyNPSstatus.initialize('C1-rNPSstatus','radio',listNPSstatus,fillSelectedContacts,'inputSelected','inputUnselected','2');

		objSelSurveyNPSactivity.initialize('C1-rNPSactivity','radio',listNPSactivity,callbackSelectionWithDate,'inputSelected','inputUnselected','0');
			document.getElementById('C1-iActDateStart').disabled = true;
			document.getElementById('C1-iActDateEnd').disabled = true;
			document.getElementById('C1-iActDateStart').value = dateConverted(firstMonth);
			startDateAct = firstMonth;	
			document.getElementById('C1-iActDateEnd').value = dateConverted(today);
			endDateAct = today;

		objSelSurveyNPSresponse.initialize('C1-rNPSresponse','radio',listNPSresponse,callbackSelectionWithDate,'inputSelected','inputUnselected','0');
			document.getElementById('C1-iResDateStart').disabled = true;
			document.getElementById('C1-iResDateEnd').disabled = true;
			document.getElementById('C1-iResDateStart').value = dateConverted(firstMonth);
			startDateRes = firstMonth;	
			document.getElementById('C1-iResDateEnd').value = dateConverted(today);
			endDateRes = today;
		
		objSelSurveyOwnership.initialize('C1-rOwnership','radio',listOwnership,fillSelectedContacts,'inputSelected','inputUnselected','0');
		objSelSurveyFreeSearch.initialize('C1-rFreeSearch','radio',listFreeSearchSurvey,fillSelectedContacts,'inputSelected','inputUnselected','0');
		
		for(i=0;i<listLanguages.length;i++)
			content +='<option value="'+listLanguages[i]+'">'+listLanguages[i]+'</option>';
		document.getElementById('C21-selEmailLanguage').innerHTML = content;
		document.getElementById('C21-selEmailLanguage').options[0].selected = true;
	}
function callbackSelectionWithDate()
	{
		prepareTimeRangeSelectionContacts();
		fillSelectedContacts();
	}

function contentContactsTable()
	{
		var i, j, ck, index, content = '', someAccounts, aDate, indexSelected = -1, iconNPSstatus, disableCheck;
		
		document.getElementById('C1-txtFilterTitles').innerHTML = stringAllContactsSelections;
		document.getElementById('C2-txtNumberSelectedActions').innerHTML = listSelectedContacts.length + ' customer(s) selected';
		arrangeCSSclasses('C1-txtFilterTitles','tagAppearance,tagAppearance','0,1');
		
		for(i=0;i<listSelectedContacts.length;i++)
		{
			index = listSelectedContacts[i];

			someAccounts = allContacts[index].account;
			ck = true;while(ck){ck = false;if(someAccounts.indexOf(';') != -1){ck = true;someAccounts = someAccounts.replace(';',',<br/>');}}
			
			switch(allContacts[index].NPSstatus)
			{
				case 'NPS target, available now': 
				{
					disableCheck = '';
					iconNPSstatus = '<i class="fa fa-square fa-lg colorGreen" aria-hidden="true"></i>';
				}break;
				case 'NPS target, more data needed': 
				{
					disableCheck = 'disabled="true"';
					iconNPSstatus = '<i class="fa fa-exclamation-triangle fa-lg colorMoreRed" aria-hidden="true"></i>';
				}break;

				case 'NPS target, not available now': 
				{
					disableCheck = 'disabled="true"';
					iconNPSstatus = '<i class="fa fa-square fa-lg colorLightYellow" aria-hidden="true" title="NPS target, available from '+dateConverted(allContacts[index].availabilityDate)+'"></i>';
				}break;
				case 'Not NPS target': 
				{
					disableCheck = 'disabled="true"';
					iconNPSstatus = '<i class="fa fa-times fa-lg colorHONred" aria-hidden="true" title="Not target for NPS !"></i>';
				}break;

				default: iconNPSstatus = 'BOO';
			}
			if(dateConverted(allContacts[index].lastRequest) == '1-Jan-1970') aDate = 'never';
			else aDate = dateConverted(allContacts[index].lastRequest);
			
			content +='<tr id="C2-row'+index+'" class="cursorPointer">'+
					'<td class="textCenter">'+(i+1)+'</td>'+
					'<td>'+allContacts[index].fullName+'</td>'+
					'<td>'+allContacts[index].account+'</td>'+
					'<td>'+allContacts[index].accountOwner+'</td>'+ //???
					'<td class="textCenter" title="'+allContacts[index].NPSstatus+'">'+iconNPSstatus+'</td>'+ //???
					'<td class="textCenter noWrap">'+aDate+'</td>'+						
					'<td class="textCenter noWrap"><input id="C21-ckTabSelection'+index+'" name="C21-ckTabSelection" type="checkbox" '+disableCheck+'/></td>'+
				'</tr>';
		}
		document.getElementById('C2-tbContacts').innerHTML = content;
		
		//if(indexSelected != -1) contentActionDetails('C2-row'+indexSelected);
	}
function contentContactDetails(id)
	{
		var i, y, ck, tagStyle1, hDetails, hContainer, index, contactNPSs = '', contactReqs = '', anEmail = '', aLOB = '', HASstatus = '';
		var contentSender = '', contentDEEPN = '';
		
		document.getElementById('C21-txtEmailConfirmation').innerHTML = '';
		if(id != -1)
		{
			if(document.getElementById('C22-btnNPSavailability').disabled) 
			{
				document.getElementById('C22-btnNPSavailability').disabled = false;
				arrangeCSSclasses('C22-btnNPSavailability','buttonStyle,buttonInactive','1,0');
			}
			
			index = id.replace('C2-row','');
			currentContact = index;
			for(i=0;i<allContacts.length;i++)
				if(document.getElementById('C2-row'+i)) arrangeCSSclasses('C2-row'+i,'groundLightOrange','0');              
			arrangeCSSclasses(id,'groundLightOrange','1');
			
			contactNPSs = '';listNPSs.length = 0;
			for(i=0;i<allResponses.length;i++) // need readjustement
				if(allResponses[i].contactID == allContacts[index].contactID)
				{
					//if(allContacts[index].listResponses == '-1') allContacts[index].listResponses = i.toString();
					//else allContacts[index].listResponses += ';'+i.toString();
					listNPSs[listNPSs.length] = i;
					contactNPSs += '<p>&#8226;&nbsp;'+parseInt(allResponses[i].score)+'&nbsp;<span id="C221-aResponse'+i+'" class="aLink">'+allResponses[i].responseName+'</span>&nbsp;'+dateConverted(allResponses[i].dateCreated)+'</p>';
				}

			contactReqs = '';
			for(i=0;i<allRequests.length;i++)// need readjustement
				if(allRequests[i].contactID == allContacts[index].contactID)
				{
					//if(allContacts[index].listRequests == '-1') allContacts[index].listRequests = i.toString();
					//else allContacts[index].listRequests += ';'+i.toString();
					if(allRequests[i].dateCreated == undefined) alert('wow');
					contactReqs += dateConverted(allRequests[i].dateCreated)+'<br/>';
				} 

			// customer
			if(allContacts[index].email.length == 0) anEmail = '<span class="colorHONred">No email!</span><br/><span class="colorGray40 fontNormal">Click on name and update in SFDC!</span>';
			else anEmail = allContacts[index].email;
			if(allContacts[index].LOB == '_LOB unknown') aLOB = '<span class="colorHONred">No LOB!</span><br/><span class="colorGray40 fontNormal">Click on name and update in SFDC!</span>';
			else aLOB = allContacts[index].LOB;

			HASstatus = '';
			if(allContacts[index].HASflag) HASstatus += 'has CoVS flag on<br/>';
			if(allContacts[index].HASowner.length != 0) HASstatus += 'has CoVS owner ('+allContacts[index].HASowner+')<br/>';
			if(allContacts[index].LOB.indexOf('CoVS') != -1 ) HASstatus += 'CoVS included in LOB<br/>';
			if(HASstatus.length == 0) HASstatus = 'no';

			listEmailSender.length = 0; ck = true;
			for(i=0;i<listWideOrgEmails.length;i++)
				//if(listWideOrgEmails[i][0] == allContacts[index].parentAccountOwnerEmail) 
				{
					listEmailSender[listEmailSender.length] = listWideOrgEmails[i][0];
					if(currentUserEmail == listWideOrgEmails[i][0]) ck = false;
				}
			if(ck) listEmailSender[listEmailSender.length] = currentUserEmail;
			for(i=0;i<listEmailSender.length;i++)
				if(listEmailSender[i].indexOf('honeywell') == -1)
					contentSender += '<option value="'+listEmailSender[i]+'">'+listEmailSender[i]+'</option>';
			
			//if(allContacts[index].DEEPN.indexOf('Logistics') != -1) contentDEEPN = allContacts[index].DEEPN + ' (' +allContacts[index].plant + ')';
			//else contentDEEPN = allContacts[index].DEEPN;
			if(allContacts[index].plant != tbConst.NoPlant) contentDEEPN = allContacts[index].DEEPN + ' (' +allContacts[index].plant + ')';
			else contentDEEPN = allContacts[index].DEEPN;

			document.getElementById('C21-txtCustomer').innerHTML = '<a href="https://hon-ts.my.salesforce.com/'+allContacts[index].contactID+'" target="_blank" class="noWrap aLink">'+allContacts[index].fullName+'</a><br/>'+anEmail;
			document.getElementById('C21-txtAccount').innerHTML = allContacts[index].account +' ('+allContacts[index].accountOwner+')'+' <br/>'
				+allContacts[index].parentAccount +' ('+allContacts[index].parentAccountOwner+')';
			document.getElementById('C21-txtDEEPN').innerHTML = contentDEEPN;
			document.getElementById('C21-txtCounterpart').innerHTML = allContacts[index].counterpart;//allContacts[index].counterpart;
			document.getElementById('C21-txtLineOfBusiness').innerHTML = aLOB;
			document.getElementById('C21-txtTouchpoints').innerHTML = allContacts[index].contactTouchpoints;
			document.getElementById('C21-txtNPSsFulfilled').innerHTML = contactNPSs;
			document.getElementById('C21-txtRequestsReceived').innerHTML = contactReqs;
			document.getElementById('C21-txtHASstatus').innerHTML = HASstatus;
			if(allContacts[index].optOut == 'true') document.getElementById('C21-txtEmailOptOut').innerHTML = 'yes'; else document.getElementById('C21-txtEmailOptOut').innerHTML = 'no';
			document.getElementById('C21-txtTargetForNPS').innerHTML = allContacts[index].target;
			document.getElementById('C21-txtTargetObs').innerHTML = allContacts[index].observation;
			document.getElementById('C21-txtAvailability').innerHTML = dateConverted(allContacts[index].availabilityDate);
			document.getElementById('C22-iAvailabilityDate').value = dateConverted(allContacts[index].availabilityDate);
			document.getElementById('C21-txtEmailLanguage').innerHTML = allContacts[index].language;
			document.getElementById('C21-selEmailSender').innerHTML = contentSender;
			if(allContacts[index].NPSstatus == 'NPS target, available now') 
				{
					document.getElementById('C21-btnSendEmail').disabled = false;
					arrangeCSSclasses('C21-btnSendEmail','buttonInactive,buttonStyle','0,1');
				}
			else 
				{
					document.getElementById('C21-btnSendEmail').disabled = true;
					arrangeCSSclasses('C21-btnSendEmail','buttonInactive,buttonStyle','1,0');
				}

			hDetails = parseInt(window.getComputedStyle(document.getElementById('C21-sDetails'), null).getPropertyValue('height'));
			hContainer = parseInt(window.getComputedStyle(document.getElementById('C2-sBigContainer'), null).getPropertyValue('height'));
			y = getPosition(document.getElementById(id),'').y - getPosition(document.getElementById('C2-sDetailsContainer'),'').y;
			if((hDetails + y) > hContainer) y = hContainer - hDetails;
			document.getElementById('C21-sDetails').style.top = y+'px';

			arrangeCSSclasses('C21-sDetails','tagAppearance,tagAppearance','0,1');
		}   
		else 
		{
			listNPSs.length = 0;
			y = getPosition(document.getElementById('C2-sDetailsContainer'),'').y;
			document.getElementById('C21-sDetails').style.top = '32px';

			document.getElementById('C21-txtCustomer').innerHTML = '';
			document.getElementById('C21-txtAccount').innerHTML = '';
			document.getElementById('C21-txtDEEPN').innerHTML = '';
			document.getElementById('C21-txtCounterpart').innerHTML = '';
			document.getElementById('C21-txtLineOfBusiness').innerHTML = '';
			document.getElementById('C21-txtTouchpoints').innerHTML = '';
			document.getElementById('C21-txtNPSsFulfilled').innerHTML = '';
			document.getElementById('C21-txtRequestsReceived').innerHTML = '';
			document.getElementById('C21-txtHASstatus').innerHTML = '';
			document.getElementById('C21-txtEmailOptOut').innerHTML = '';
			document.getElementById('C21-txtTargetForNPS').innerHTML = '';
			document.getElementById('C22-btnNPSavailability').disabled = true;
			arrangeCSSclasses('C22-btnNPSavailability','buttonStyle,buttonInactive','0,1');
			document.getElementById('C21-txtTargetObs').innerHTML = '';
			document.getElementById('C21-txtAvailability').innerHTML = '';
			document.getElementById('C21-txtEmailLanguage').innerHTML = '';
			document.getElementById('C21-selEmailSender').innerHTML = '';
			document.getElementById('C21-btnSendEmail').disabled = true;
			arrangeCSSclasses('C21-btnSendEmail','buttonStyle,buttonInactive','0,1');

		}
		eventsContactDetails();
	}

function eventsSelectionsContacts()
	{
		document.getElementById('C1-iActDateStart').onchange = function() 
			{
				startDateAct = Date.parse(document.getElementById('C1-iActDateStart').value);
				document.getElementById('C1-iActDateStart').value = dateConverted(startDateAct);
				if(startDateAct > endDateAct)
				{
					arrangeCSSclasses('C1-iActDateStart','colorHONred','1');
					arrangeCSSclasses('C1-iActDateEnd','colorHONred','1');
				}
				else
				{
					arrangeCSSclasses('C1-iActDateStart','colorHONred','0');
					arrangeCSSclasses('C1-iActDateEnd','colorHONred','0');
					fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
				}
			};
		document.getElementById('C1-iActDateEnd').onchange = function() 
			{
				endDateAct = Date.parse(document.getElementById('C1-iActDateEnd').value);
				document.getElementById('C1-iActDateEnd').value = dateConverted(endDateAct);
				if(startDateAct > endDateAct)
				{
					arrangeCSSclasses('C1-iActDateStart','colorHONred','1');
					arrangeCSSclasses('C1-iActDateEnd','colorHONred','1');
				}
				else
				{
					arrangeCSSclasses('C1-iActDateStart','colorHONred','0');
					arrangeCSSclasses('C1-iActDateEnd','colorHONred','0');
					fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
				}
			};
		document.getElementById('C1-iResDateStart').onchange = function() 
			{
				startDateRes = Date.parse(document.getElementById('C1-iResDateStart').value);
				document.getElementById('C1-iResDateStart').value = dateConverted(startDateRes);
				if(startDateRes > endDateRes)
				{
					arrangeCSSclasses('C1-iResDateStart','colorHONred','1');
					arrangeCSSclasses('C1-iResDateEnd','colorHONred','1');
				}
				else
				{
					arrangeCSSclasses('C1-iResDateStart','colorHONred','0');
					arrangeCSSclasses('C1-iResDateEnd','colorHONred','0');
					fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
				}
			};
		document.getElementById('C1-iResDateEnd').onchange = function() 
			{
				endDateResponse = Date.parse(document.getElementById('C1-iResDateEnd').value);
				document.getElementById('C1-iResDateEnd').value = dateConverted(endDateResponse);
				if(startDateResponse > endDateResponse)
				{
					arrangeCSSclasses('C1-iResDateStart','colorHONred','1');
					arrangeCSSclasses('C1-iResDateEnd','colorHONred','1');
				}
				else
				{
					arrangeCSSclasses('C1-iResDateStart','colorHONred','0');
					arrangeCSSclasses('C1-iResDateEnd','colorHONred','0');
					fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
				}
			};
	}
function eventsContacts()
	{
		var selectedEmailSender;
		document.getElementById('C1-iSearch').onkeyup = function(event) {if(event.keyCode == 13) {fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
			}}
		document.getElementById('C1-iSearch').onkeydown = function(event) {if(event.keyCode == 13) {fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
			}}
		document.getElementById('C1-btnSearch').onclick = function(){fillSelectedContacts();//contentContactsTable(); eventsContactsTable();
				return false;}
		document.getElementById('C2-btnSendEmailAll').onclick = function() 
		{
			sendMassEmail();
			return false;
		}
		document.getElementById('C2-ckTabHeader').onclick = function() {updateCheckContacts();};
		document.getElementById('C22-btnNPSavailability').onclick = function() 
			{
				document.getElementById('C22-btnNPSavailability').disabled = true;
				document.getElementById('C22-sNPSavailability').style.display = 'block';
				return false;
			}
		document.getElementById('C22-btnNPSavailabilityCancel').onclick = function() 
			{
				document.getElementById('C22-btnNPSavailability').disabled = false;
				document.getElementById('C22-sNPSavailability').style.display = 'none';
				return false;
			}
		document.getElementById('C22-btnNPSavailabilitySave').onclick = function() 
			{
				document.getElementById('C22-btnNPSavailability').disabled = false;
				document.getElementById('C22-sNPSavailability').style.display = 'none';
				
				allContacts[currentContact].availabilityDate = Date.parse(document.getElementById('C22-iAvailabilityDate').value);
				if(allContacts[currentContact].availabilityDate < today) allContacts[currentContact].NPSstatus = 'NPS target, available now';
				else allContacts[currentContact].NPSstatus = 'NPS target, not available now';
				
				updateSFDCcontactAvailabilityNPS(allContacts[currentContact].contactID,new Date(allContacts[currentContact].availabilityDate));

				fillSelectedContacts();
				// change the NPS target flag, change reason for not being, update in SFDC, filter, table, tablevents, no details display;
				return false;
			}
		document.getElementById('C22-iAvailabilityDate').onchange = function()
			{
				document.getElementById('C22-iAvailabilityDate').value = dateConverted(Date.parse(document.getElementById('C22-iAvailabilityDate').value));
			}
		document.getElementById('C21-btnSendEmail').onclick = function() 
			{
				selectedEmailSender = document.getElementById('C21-selEmailSender').options[document.getElementById('C21-selEmailSender').selectedIndex].value;
				if(selectedEmailSender == currentUserEmail)
					sendIndividualEmail(allContacts[currentContact].contactID,adminNPS.email,'-');
				else sendIndividualEmail(allContacts[currentContact].contactID,adminNPS.email,selectedEmailSender);
				document.getElementById('C21-txtEmailConfirmation').innerHTML = 'Survey sent.';

				allContacts[currentContact].availabilityDate = Date.parse(today+24*3600);
				allContacts[currentContact].NPSstatus = 'NPS target, not available now';
				
				fillSelectedContacts();
				return false;
			}

	}
function eventsContactsTable()
	{
		var i;
		document.getElementById('C2-hcName').onclick = function()
			{
				if(document.getElementById('C2-hcName').innerHTML.indexOf('fa-sort-asc') != -1) sortContactsTable('name','desc');
				else sortContactsTable('name','asc');
			}
		document.getElementById('C2-hcAccount').onclick = function()
			{
				if(document.getElementById('C2-hcAccount').innerHTML.indexOf('fa-sort-asc') != -1) sortContactsTable('account','desc');
				else sortContactsTable('account','asc');
			}
		document.getElementById('C2-hcOwner').onclick = function()
			{
				if(document.getElementById('C2-hcOwner').innerHTML.indexOf('fa-sort-asc') != -1) sortContactsTable('owner','desc');
				else sortContactsTable('owner','asc');
			}
		document.getElementById('C2-hcStatus').onclick = function()
			{
				if(document.getElementById('C2-hcStatus').innerHTML.indexOf('fa-sort-asc') != -1) sortContactsTable('status','desc');
				else sortContactsTable('status','asc');
			}
		document.getElementById('C2-hcContacted').onclick = function()
			{
				if(document.getElementById('C2-hcContacted').innerHTML.indexOf('fa-sort-asc') != -1) sortContactsTable('contacted','desc');
				else sortContactsTable('contacted','asc');
			}
		for(i=0;i<allContacts.length;i++)
			if(document.getElementById('C2-row'+i))
				document.getElementById('C2-row'+i).onclick = function() {contentContactDetails(this.id);};
		
	}
function eventsContactDetails()
	{
		var i;
		for(i=0;i<listNPSs.length;i++)
			document.getElementById('C221-aResponse'+listNPSs[i]).onclick = function() {selectAresponse(this.id);}
	}

function fillSelectedContacts()
	{
		var i, aList = [];
		var selectedLOB, selectedRegion, selectedDEEPN, selectedPlant, selectedNPSstatus, selectedNPSactivity, selectedNPSresponse, selectedOwnership, searchWorld;
		var checkLOB, checkRegion, checkDEEPN, checkPlant, checkNPSstatus, checkNPSactivity, checkNPSresponse, checkOwnership;
		stringAllContactsSelections = '';

		// check filters:
			i = objSelSurveyLOB.indexSelected;
			if(i != 0)
			{
				selectedLOB = listLOBall[i][0];
				if(stringAllContactsSelections == '') stringAllContactsSelections = listLOBall[i][0];
				else stringAllContactsSelections += '; ' + listLOBall[i][0];	
			}
			
			i = objSelSurveyRegion.indexSelected;
			if(i != 0)
			{
				selectedRegion = listRegionsAll[i][0];
				if(stringAllContactsSelections == '') stringAllContactsSelections = listRegionsAll[i][0];
				else stringAllContactsSelections += '; ' + listRegionsAll[i][0];	
			}

			i = objSelSurveyDEEPN.indexSelected;
			if(i != 0)
			{
				selectedDEEPN = listDEEPNall[i];
				if(stringAllContactsSelections == '') stringAllContactsSelections = listDEEPNall[i];
				else stringAllContactsSelections += '; ' + listDEEPNall[i];	
			}

			i = objSelSurveyPlant.indexSelected;
			if(i != 0)
			{
				selectedPlant = listPlantsAll[i];
				if(stringAllContactsSelections == '') stringAllContactsSelections = listPlantsAll[i];
				else stringAllContactsSelections += '; ' + listPlantsAll[i];	
			}
			
			i = objSelSurveyNPSstatus.indexSelected;
			if(i != 0)
			{
				selectedNPSstatus = listNPSstatus[i];
				if(stringAllContactsSelections == '') stringAllContactsSelections = listNPSstatus[i];
				else stringAllContactsSelections += '; ' + listNPSstatus[i];
			}

			i = objSelSurveyNPSactivity.indexSelected;
			if(i != 0)
			{
				selectedNPSactivity = i;
				if(selectedNPSactivity == 5)
				{
					startDateAct = Date.parse(document.getElementById('C1-iActDateStart').value); 
					endDateAct = Date.parse(document.getElementById('C1-iActDateEnd').value);
					if(startDateAct < endDateAct) 
					{
						if(stringAllContactsSelections == '') stringAllContactsSelections = 'Contacted between '+dateConverted(startDateAct)+' and '+dateConverted(endDateAct); 
						else stringAllContactsSelections += '; Contacted between '+dateConverted(startDateAct)+' and '+dateConverted(endDateAct);
						endDateAct = endDateAct + 24*3600*1000;
					}
				}
				else
				{
					if(stringAllContactsSelections == '') stringAllContactsSelections = listNPSactivity[i];
						else stringAllContactsSelections += '; ' + listNPSactivity[i];
				};
			}			
			
			i = objSelSurveyNPSresponse.indexSelected;
			if(i != 0)
			{
				selectedNPSresponse = i;
				if(selectedNPSresponse == 5)
				{
					startDateRes = Date.parse(document.getElementById('C1-iResDateStart').value); 
					endDateRes = Date.parse(document.getElementById('C1-iResDateEnd').value);
					if(startDateRes < endDateRes) 
					{
						if(stringAllContactsSelections == '') stringAllContactsSelections = 'Responded between '+dateConverted(startDateRes)+' and '+dateConverted(endDateRes); 
						else stringAllContactsSelections += '; Responded '+dateConverted(startDateRes)+' and '+dateConverted(endDateRes);
						endDateRes = endDateRes + 24*3600*1000;
					}
				}
				else
				{
					if(stringAllContactsSelections == '') stringAllContactsSelections = listNPSresponse[i];
					else stringAllContactsSelections += '; ' + listNPSresponse[i];
				}
			}
			
			i = objSelSurveyOwnership.indexSelected;
			if(i != 0)
			{
				selectedOwnership = i;
				if(stringAllContactsSelections == '') stringAllContactsSelections = listOwnership[i];
					else stringAllContactsSelections += '; ' + listOwnership[i];
			}
			
			searchWord = document.getElementById('C1-iSearch').value;
			if(searchWord != '')
			{
				if(stringAllContactsSelections == '') stringAllContactsSelections = searchWord; 
				else stringAllContactsSelections += '; ' + searchWord;
			}

		// apply filters:
			listSelectedContacts.length = 0;
			for(i=0;i<allContacts.length;i++)
			{
				if(document.getElementById('C1-rLOB0').checked) checkLOB = true;
				else
				{
					if(allContacts[i].LOB.indexOf(selectedLOB) != -1) checkLOB = true;
					else checkLOB = false;
				}
				if(document.getElementById('C1-rRegion0').checked) checkRegion = true;
				else
				{
					if(allContacts[i].region.indexOf(selectedRegion) != -1) checkRegion = true;
					else checkRegion = false;
				}
				if(document.getElementById('C1-rDEEPN0').checked) checkDEEPN = true;
				else
				{
					if(allContacts[i].DEEPN.indexOf(selectedDEEPN) != -1) checkDEEPN = true;
					else checkDEEPN = false;
				}
				if(document.getElementById('C1-rPlant0').checked) checkPlant = true;
				else
				{
					if(allContacts[i].plant.indexOf(selectedPlant) != -1) checkPlant = true;
					else checkPlant = false;
				}
				if(document.getElementById('C1-rNPSstatus0').checked) checkNPSstatus = true;
				else
				{
					switch(selectedNPSstatus)
					{
						case 'Not NPS Target':
						{
							if((allContacts[i].active != 'no') && (allContacts[i].target.toLowerCase() == 'no')) checkNPSstatus = true; else checkNPSstatus = false;
						};break;
						case 'NPS Target':
						{
							if((allContacts[i].active != 'no') && allContacts[i].target.toLowerCase() != 'no') checkNPSstatus = true; else checkNPSstatus = false;
						};break;
						default:
						{
							if((allContacts[i].active != 'no') && (allContacts[i].NPSstatus == selectedNPSstatus)) checkNPSstatus = true; else checkNPSstatus = false;
						} 
					}
				}
				if(document.getElementById('C1-rNPSactivity0').checked) checkNPSactivity = true;
				else
				{
					switch(selectedNPSactivity.toString())
					{
						case '1':
						{
							if(allContacts[i].lastRequest == 0) checkNPSactivity = true; else checkNPSactivity = false;
						};break;
						case '2':
						{
							if(allContacts[i].lastRequest >= oneYearAgo) checkNPSactivity = true; else checkNPSactivity = false;
						};break;
						case '3':
						{
							if(allContacts[i].lastRequest >= oneMonthAgo) checkNPSactivity = true; else checkNPSactivity = false;
						};break;
						case '4':
						{
							if(allContacts[i].lastRequest >= oneWeekAgo) checkNPSactivity = true; else checkNPSactivity = false;
						};break;
						case '5':
						{
							checkNPSactivity = false;
							if(allContacts[i].listRequests != '-1')
							{
								aList.length = 0;aList = allContacts[i].listRequests.split(';');
								for(j=0;j<aList.length;j++)
									if((aList[j] >= startDateAct) && (aList[j] <= endDateAct)) checkNPSactivity = true;
							}
						};break;
					}
				}
				if(document.getElementById('C1-rNPSresponse0').checked) checkNPSresponse = true;
				else
				{
					switch(selectedNPSresponse.toString())
					{
						case '1':
						{
							if(allContacts[i].lastResponse == 0) checkNPSresponse = true; else checkNPSresponse = false;

						};break;						
						case '2':
						{
							if(allContacts[i].lastResponse > oneYearAgo) checkNPSresponse = true; else checkNPSresponse = false;
						};break;
						case '3':
						{
							if(allContacts[i].lastResponse > oneMonthAgo) checkNPSresponse = true; else checkNPSresponse = false;
						};break;
						case '4':
						{
							if(allContacts[i].lastResponse > oneWeekAgo) checkNPSresponse = true; else checkNPSresponse = false;
						};break;
						case '5':
						{
							checkNPSresponse = false;
							if(allContacts[i].listResponses != '-1')
							{
								aList.length = 0; aList = allContacts[i].listResponses.split(';');
								for(j=0;j<aList.length;j++)
									if((aList[j].split(':')[2] >= startDateRes) && (aList[j].split(':')[2] <= endDateRes)) checkNPSresponse = true;
							}
						};break;
						case '6':
						{
							if(allContacts[i].optOut == 'true') checkNPSresponse = true; else checkNPSresponse = false;
						};break;
					}
				}
				if(document.getElementById('C1-rOwnership0').checked) checkOwnership = true;
				else
				{
					switch(selectedOwnership.toString())
						{
							case '1':
							{
								checkOwnership = false;
								for(j=0;j<listUserAccounts.length;j++)
									if(allContacts[i].account == listUserAccounts[j]) checkOwnership = true;
							};break;
							case '2':
							{
								checkOwnership = false;
								for(j=0;j<listUserParentAccounts.length;j++)
									if(allContacts[i].parentAccount == listUserParentAccounts[j]) checkOwnership = true;
							};break;
						}
				}
				if(checkLOB && checkRegion && checkDEEPN && checkPlant && checkNPSstatus && checkNPSactivity && checkNPSresponse && checkOwnership)
				{
					if(searchWord == '') listSelectedContacts[listSelectedContacts.length] = i;
					else
					{	
						ck = false;
						if(document.getElementById('C1-rFreeSearch0').checked)
						{
							if(allContacts[i].account.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
							if(allContacts[i].parentAccount.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)
							if(allContacts[i].accountOwner.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
							if(allContacts[i].fullName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1) ck = true;
						}
						else
						{
							if((document.getElementById('C1-rFreeSearch1').checked) && (allContacts[i].account.toLowerCase() == searchWord.toLowerCase())) ck = true;
							if((document.getElementById('C1-rFreeSearch2').checked) && (allContacts[i].parentAccount.toLowerCase() == searchWord.toLowerCase())) ck = true;	
							if((document.getElementById('C1-rFreeSearch3').checked) && (allContacts[i].accountOwner.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
							if((document.getElementById('C1-rFreeSearch4').checked) && (allContacts[i].fullName.toLowerCase().indexOf(searchWord.toLowerCase()) != -1)) ck = true;
						}
						if(ck) listSelectedContacts[listSelectedContacts.length] = i;
					}	
				}
			}
		
		contentContactDetails(-1);
		contentContactsTable();
		eventsContactsTable();
	}
function sortContactsTable(param,direction)
	{
		var returnAsc, returnDesc;
		document.getElementById('C2-hcName').innerHTML = 'Name&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('C2-hcAccount').innerHTML = 'Account&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('C2-hcOwner').innerHTML = 'Owner&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('C2-hcStatus').innerHTML = 'Status&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		document.getElementById('C2-hcContacted').innerHTML = 'Contacted&nbsp;<i class="fa fa-sort" aria-hidden="true"></i>';
		if(direction == 'asc') {returnAsc = 1; returnDesc = -1;}
		else {returnAsc = -1; returnDesc = 1;}
		switch(param)
		{
			case 'name':
			{
				document.getElementById('C2-hcName').innerHTML = 'Name&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allContacts.sort(function(a,b)
				{
					var x = a.fullName; 
					var y = b.fullName; 
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else return 0;
			});
			};break;
			case 'account':
			{
				document.getElementById('C2-hcAccount').innerHTML = 'Account&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allContacts.sort(function(a,b)
				{
					var x = a.account;
					var y = b.account;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.fullName > b.fullName) return 1;
						if(a.fullName < b.fullName) return -1;
						else return 0;
					}
				});
			};break;
			case 'owner':
			{
				document.getElementById('C2-hcOwner').innerHTML = 'Owner&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allContacts.sort(function(a,b)
				{
					var x = a.accountOwner;
					var y = b.accountOwner;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else 
					{
						if(a.fullName > b.fullName) return 1;
						if(a.fullName < b.fullName) return -1;
						else return 0;
					}
				});
			};break;
			case 'status':
			{
				document.getElementById('C2-hcStatus').innerHTML = 'Status&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allContacts.sort(function(a,b)
				{
					var x = a.NPSstatus;
					var y = b.NPSstatus;
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else
					{
						if(a.fullName > b.fullName) return 1;
						if(a.fullName < b.fullName) return -1;
						else return 0;
					}
				});
			};break;
			case 'contacted':
			{
				document.getElementById('C2-hcContacted').innerHTML = 'Contacted&nbsp;<i class="fa fa-sort-'+direction+' colorLime" aria-hidden="true"></i>';
				allContacts.sort(function(a,b)
				{
					var x = a.lastRequest; 
					var y = b.lastRequest; 
					if(x > y) return returnAsc;
					if(x < y) return returnDesc;
					else
					{
						if(a.fullName > b.fullName) return 1;
						if(a.fullName < b.fullName) return -1;
						else return 0;
					}
				});
			};break;			
		}

		fillSelectedContacts();
		contentContactsTable();
		eventsContactsTable();
	}
function updateCheckContacts()
	{
		var i,value;
		value = document.getElementById('C2-ckTabHeader').checked;
		for(i=0;i<listSelectedContacts.length;i++)
			if(!document.getElementById('C21-ckTabSelection'+listSelectedContacts[i]).disabled) 
				document.getElementById('C21-ckTabSelection'+listSelectedContacts[i]).checked = value;

	}        
function prepareTimeRangeSelectionContacts()
	{
		var i, index;
		for(i=0;i<listNPSactivity.length;i++)
			if(document.getElementById('C1-rNPSactivity'+i).checked) index = i;
		if(index == 5)
		{
			document.getElementById('C1-iActDateStart').disabled = false;
			document.getElementById('C1-iActDateEnd').disabled = false;
		}
		else
		{
			document.getElementById('C1-iActDateStart').disabled = true;
			document.getElementById('C1-iActDateEnd').disabled = true;	
		}

		for(i=0;i<listNPSresponse.length;i++)
			if(document.getElementById('C1-rNPSresponse'+i).checked) index = i;
		if(index == 5)
		{
			document.getElementById('C1-iResDateStart').disabled = false;
			document.getElementById('C1-iResDateEnd').disabled = false;
		}
		else
		{
			document.getElementById('C1-iResDateStart').disabled = true;
			document.getElementById('C1-iResDateEnd').disabled = true;	
		}
	}
function sendMassEmail()
	{
		var i;
		listMassEmail.length = 0;
		for(i=0;i<listSelectedContacts.length;i++)
			if(document.getElementById('C21-ckTabSelection'+listSelectedContacts[i]).checked) listMassEmail[listMassEmail.length] = listSelectedContacts[i];
		
	}
function checkContactAvailability(ind)
	{
		if(allContacts[ind].target.toLowerCase().indexOf('no') != -1) allContacts[ind].NPSstatus = 'Not NPS target';
		else
		{
			if(allContacts[ind].NPSstatus.indexOf('data') == -1)
			{
				if(allContacts[ind].availabilityDate >= today) allContacts[ind].NPSstatus = 'NPS target, available now';
				else allContacts[ind].NPSstatus = 'NPS target, not available now';
			}
		}
	}
function selectAresponse(id)
	{
		var index;
		index = parseInt(id.replace('C221-aResponse',''));
		selectedResponse = allResponses[index].responseID;
		goToFormPage();
	}
