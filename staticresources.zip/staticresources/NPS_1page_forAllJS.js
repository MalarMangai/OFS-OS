
var tbConst = 
	{
		ALL:'ALL',
		Account:'Account',
		LOB:'LOB',
		Region:'Region',		
		ParentAccount:'Parent Account',
		DEEPN:'DEEPN',
		NoNeedForMoreFeedback: 'No need for more feedback',
		Plant: 'Plant',
		NoPlant: '_No Plant',
		rootLink:'https://hon-ts--c.na79.visual.force.com' //https://hon-ts--tsfull--c.cs68.visual.force.com    https://hon-ts--c.na79.visual.force.com
	};
var adminNPS = {name:'',email:''};

var tbMonths = ['January','February','March','April','May','June','July','August','September','October','November','December'];
var listMainMenu = ['Home','Survey','Responses','Actions','Support','Admin','NewResponse','Form'];
var aTest = 'gogo';
var allContacts = [];
	aContact = 
		{
			contactID: '',
			type: '',
			active: '',
			fullName:'',
			email: '',
			counterpart: '',
			DEEPN: '',
			plant: '',
			HASflag: '',
			HASowner: '',
			optOut: '',
			observation: '',
			LOB: '',
			language: '',
			lastResponse: -1,
			lastRequest: -1,
			availabilityDate: -1,
			NPSstatus: '',
			target: '',
			contactTouchpoints: '',
			accountID: '',
			account: '',
			accountOwner: '',
			accountOwnerEmail: '',
			region: '',
			parentAccount: '',
			parentAccountOwner: '',
			parentAccountOwnerEmail: '',
			probability: '',
			listResponses: '-1',
			listRequests: '-1'
		}
var allResponses = [];
	var aResponse = 
		{
			responseID: '',
			responseName: '',
			dateCreated: 0,
			dateClosed: 0,
			daysOpen: '',
			score: '',
			commentsEE: '',
			commentsNI: '',
			touchpointsEE: '',
			touchpointsNI: '',
			categories: '',	
			actionsCheck: '',
			contactID: '',
			contactName: '',
			contactEmail: '',
			contactPhone: '',
			contactDEEPN: '',
			contactType: '',
			contactTouchpoints: '',
			LOB: '',
			accountID: '',
			account: '',
			accountOwnerID: '',
			accountOwner: '',
			parentAccount: '',
			parentAccountOwnerID: '',
			parentAccountOwner: '',
			region: '',
			moreFEEDback: '',
			statusFeedback: '',
			statusTouchpoints: '',
			statusCategories: '',
			statusActions: '',
			listActionsID: '',
			listActionsName: ''
		}
var allRequests = [];
	var aRequest = 
		{
			requestID: '',
			dateCreated: '',
			contactID: '',
			type: '',
			LOB: '',
			DEEPN:'',
			plant:'',
			contactTouchpoints: '',
			region: '',
			account: '',
			parentAccount: ''
		}
var allActionResponses = [];
	var anActionResponse = 
		{
			actionID: '',
			actionName: '',
			dateCreated: '',			
			dueDate: 0,
			dueDateStatus: '',
			actionType: '',
			status: '',
			action: '',
			functionalTeam: '',
			actionOwner: '',
			actionOwnerID: '',
			contactID: '',
			contactType: '',
			contactTouchpoints: '',			
			account: '',
			parentAccount: '',
			region: '',
			LOBs: '',		
			actionResponsesIDs: '',
			sourcesIDs: '',
			sourcesNames: '',
			touchpoints: '',
			categories: '',
			touchpointsExt: '',
			categoriesExt: '',
			accounts: '',
			parentAccounts: '',
			listDEEPNs: '',
			listRegions: '',
			listFeedback: ''
		}
var allHONcontacts = [];
	var aHONcontact = 
	{
		contactId: '',
		contactName: '',
		contactEmail: '',
		functionalTeam: ''
	}
var allNPSobjectives = [];
	var aNPSobjective = 
		{
			type: '', //ALL,GBE,Region,Parent Account,Account,Other
			objName: '',
			target: '',//none,NPS
			objValue: '',
			dateStart: 0
		}

// values read from SFDC picklist fields:
	var listLOB = []; 				// Contact --> LOB__c
	var listDEEPN = []; 			// Contact --> DEEP_Category__c
	var listLanguages = [];			// Contact --> Preferred_Language__c
	var listFullTouchpoints = []; 	// NPS__c --> Touchpoints_EE__c
	var listFullCategories = [];	// NPS__c -->
	var listActionType = [];		// 
	var listActionStatus = [];		//	
	var listFunctionalTeam = [];	// 
	var listPlants = [];			// 	
	var listWideOrgEmails = [[]], listEmailSender = [];

	var SFDCactionResponses = []; //SFDCactionResponses.length = 0;
	var SFDCcontactsHON = []; //SFDCcontactsHON.length = 0;
	var SFDCactionHistory = []; //SFDCactionHistory.length = 0;

// global variables 
	var listRegionsAll = [[]], listDEEPNall = [], listUserAccounts = [], listUserParentAccounts = [], listPlantsAll = [];
	var listActionTypeAll = [], listActionStatusAll = [], listFunctionalTeamAll = [], listActionStatusAll = [];	

	var tbE2ESteps = [[]]; //0:phase; 1:touchpoints list; 2:default visibility (0:not;1:true);
	var listCategories = [], listPhases = [];
	var tbCategories = [[]]; //0:category; 1:points to improve list;
	var listAccounts = [[]]; // 0: name of the account, 1: number of contacts who responded; 2: regions
	var listParentAccounts = [[]]; // 0: name of the account, 1: number of contacts who responded; 2: regions
	
	var listLOBall = [[]];
	var listOwnership = ['ALL', 'My Account(s)', 'My Parent Account(s)'];

// about date
	var today = Date.now(); // integer
	var todayConverted = new Date(today); // string

	todayConverted.setMonth(todayConverted.getMonth()-11)
	var oneYearAgo = Date.parse(new Date(todayConverted.getFullYear(),todayConverted.getMonth(),'1'));
	todayConverted = new Date(today);

	todayConverted.setMonth(todayConverted.getMonth()-1)
	var oneMonthAgo = Date.parse(todayConverted);
	todayConverted = new Date(today);

	todayConverted.setMonth(todayConverted.getMonth()-2)
	var threeMonthsAgo = Date.parse(new Date(todayConverted.getFullYear(),todayConverted.getMonth(),'1'));
	todayConverted = new Date(today);

	var	oneWeekAgo = today - 6*24*3600*1000; // the seventh day is the current day
	var	todayConverted = new Date(today); // date
	var	firstMonth = Date.parse('1 June 2015 '); // integer

var addressBlob, currentUserName, currentUserId, currentUserEmail, selectedResponse, idA, idR, idS;

// initialize data
	function initializeLists() // function accessed from SFDC Home_page
		{
			var i, aTable = [];
			allContacts.length = 0;
			allResponses.length = 0;
			allRequests.length = 0;
			allActionResponses.length = 0;
			allEmailTemplates.length = 0;
			allNPSobjectives.length = 0;

			listWideOrgEmails.length = 0;
			listEmailSender.length = 0;

			listFullTouchpoints.length = 0;  // together with "phases" as they are read from SFDC ;
			listFullCategories.length = 0; // together with "points to improve" as they are read from SFDC
			
			listLOB.length = 0;
			listDEEPN.length = 0; 
			listLanguages.length = 0;
			
			listDEEPNall.length = 0; listDEEPNall[0] = [tbConst.ALL];
			listLOBall.length = 0; listLOBall[0] = [tbConst.ALL,'0'];
			listRegionsAll.length = 0; listRegionsAll[0] = [tbConst.ALL,'0'];
			listUserAccounts.length = 0;
			listUserParentAccounts.length = 0;

			listAccounts.length = 0;
			listParentAccounts.length = 0;
 			
 			listActionType.length = 0; 
			listActionStatus.length = 0; 
			listFunctionalTeam.length = 0; 
			listPlants.length = 0;
			

			SFDCcontactsHON.length = 0;
			SFDCactionHistory.length = 0;

			createDateReferenceTable();
			
			allHouses.length = 0;
			aHouse.name = tbConst.ALL;
			aHouse.type = tbConst.ALL;
			aHouse.visibility = '0';
			allHouses[allHouses.length] = cloneThis(aHouse);

			allMonthlyNPS.length = 0;
			aTable.length = 0;
			for(i=0;i<tbDateRef.length;i++)
			{
				aTable[i] = cloneThis(monthlyNPS);
				aTable[i].name = tbConst.ALL;
				aTable[i].type = tbConst.ALL;
				aTable[i].dateRef = tbDateRef[i];
				aTable[i].targetCustomers = '';
				aTable[i].openResponses = '';
			}
			allMonthlyNPS[allMonthlyNPS.length] = cloneThis(aTable);
	    }
	function fulfillLists(table,ind) // function accessed from SF page NPS_Home
		{
			var i, k, ck;
			var tab = [];
			
			// build list with all Accounts
				ck = true;
				for(i=0;i<listAccounts.length;i++)
					if(listAccounts[i][0] == table[ind].account) 
					{
						ck = false; 
						if(table[ind].lastResponse != 0) listAccounts[i][1]++;
					}
				if(ck) 
					{
						if(table[ind].lastResponse != 0) listAccounts[listAccounts.length] = [table[ind].account,1,table[ind].region];
						else listAccounts[listAccounts.length] = [table[ind].account,0,table[ind].region];
					}
						
			// build list with all Parent Accounts for OEM contacts;
				if(table[ind].type.indexOf('OEM') != -1)
				{
					ck = true;
					for(i=0;i<listParentAccounts.length;i++)
						if(listParentAccounts[i][0] == table[ind].parentAccount) 
							{
								ck = false; 
								if(table[ind].lastResponse != 0) 
								{
									listParentAccounts[i][1]++;
									if(listParentAccounts[i][2].indexOf(table[ind].account) == -1)
										listParentAccounts[i][2] += table[ind].account + ';';
								}
							}
					if(ck) 
					{
						if(table[ind].lastResponse != 0) listParentAccounts[listParentAccounts.length] = [table[ind].parentAccount,1,table[ind].account+';'];
						else listParentAccounts[listParentAccounts.length] = [table[ind].parentAccount,0,''];
					}
				}

			// build list with Regions;
				tab.length = 0;
				tab = table[ind].region.split(';');

				for(k=0;k<tab.length;k++)
					if(tab[k]!='')
					{
						ck = true;
						for(i=0;i<listRegionsAll.length;i++)
							if(listRegionsAll[i][0].indexOf(tab[k]) != -1) 
							{
								ck = false; 
								if(table[ind].lastResponse != 0) listRegionsAll[i][1] = parseInt(listRegionsAll[i][1])+1;
							}
						if(ck) 
						{
							if(table[ind].lastResponse != 0) listRegionsAll[listRegionsAll.length] = [tab[k],1];
							else listRegionsAll[listRegionsAll.length] = [tab[k],0];
						}
					}

			// build list with LOBs;
				tab.length = 0;
				tab = table[ind].LOB.split(';');
				for(k=0;k<tab.length;k++)
					if(tab[k]!='')
					{
						ck = true;
						for(i=0;i<listLOBall.length;i++)
							if(listLOBall[i][0].indexOf(tab[k]) != -1) 
							{
								ck = false; 
								if(table[ind].lastResponse != 0) listLOBall[i][1] = parseInt(listLOBall[i][1])+1;
							}
						if(ck) 
						{
							if(table[ind].lastResponse != 0) listLOBall[listLOBall.length] = [tab[k],1];
							else listLOBall[listLOBall.length] = [tab[k],0];
						}	
					}

			// DEEPN all 
				ck = true;
				for(i=0;i<listDEEPNall.length;i++)
					if(table[ind].DEEPN == listDEEPNall[i]) ck = false;
				if(ck) listDEEPNall[listDEEPNall.length] = table[ind].DEEPN;
		}
	
	function fulfillResponseData(ind) // function accessed from SFDC Home_page
		{
			var i, aIndexesTable = [[]];
			
			function addData(i)
				{					
					var j, oneYearLimit;
					oneYearLimit = afterOneYear(allResponses[ind].dateCreated);
					
					for(j=0;j<(tbDateRef.length-1);j++)
					{
						if((parseInt(allResponses[ind].score) > 0) && (parseInt(allResponses[ind].score) < 11))
						{
							allMonthlyNPS[i][j].region = allResponses[ind].region;
							if((allResponses[ind].dateCreated >= tbDateRef[j]) && (allResponses[ind].dateCreated < tbDateRef[j+1]))
							{
								allMonthlyNPS[i][j].responses1++;
								if(parseInt(allResponses[ind].score) > 8) allMonthlyNPS[i][j].promoters1++;
								if(parseInt(allResponses[ind].score) < 7) allMonthlyNPS[i][j].detractors1++;

								allMonthlyNPS[i][j].responses12++;
								if(parseInt(allResponses[ind].score) > 8) allMonthlyNPS[i][j].promoters12++;
								if(parseInt(allResponses[ind].score) < 7) allMonthlyNPS[i][j].detractors12++;

								if(allMonthlyNPS[i][j].monthlyContacted.length == 0) allMonthlyNPS[i][j].monthlyContacted = allResponses[ind].contactID;
								else
								{
									if(allMonthlyNPS[i][j].monthlyContacted.indexOf(allResponses[ind].contactID) == -1)allMonthlyNPS[i][j].monthlyContacted += ';'+allResponses[ind].contactID;
								}
								if(allMonthlyNPS[i][j].aboutMonthlyContacted.length == 0) 
									allMonthlyNPS[i][j].aboutMonthlyContacted = allResponses[ind].contactID+','+allResponses[ind].score+','+allResponses[ind].dateCreated;
								else
									allMonthlyNPS[i][j].aboutMonthlyContacted += ';'+allResponses[ind].contactID+','+allResponses[ind].score+','+allResponses[ind].dateCreated;
							}
							if((allResponses[ind].dateCreated < tbDateRef[j] ) && (tbDateRef[j+1] <= oneYearLimit))
							{
								allMonthlyNPS[i][j].responses12++;
								if(parseInt(allResponses[ind].score) > 8) allMonthlyNPS[i][j].promoters12++;
								if(parseInt(allResponses[ind].score) < 7) allMonthlyNPS[i][j].detractors12++;
							}
							if(allMonthlyNPS[i][j].responses12 > 0) allMonthlyNPS[i][j].NPS = parseInt(1000*(allMonthlyNPS[i][j].promoters12 - allMonthlyNPS[i][j].detractors12)/allMonthlyNPS[i][j].responses12)/10;

							if(j > 3)
							{
								if(j == (tbDateRef.length-2))
								{
									if((allResponses[ind].dateClosed >= threeMonthsAgo) && (allResponses[ind].dateClosed <= today))
									{
										allMonthlyNPS[i][j].closedThisMonth += allResponses[ind].responseID+' '+allResponses[ind].daysOpen+';';
										allMonthlyNPS[i][j].closed++;
										if(allResponses[ind].daysOpen != '') allMonthlyNPS[i][j].days = parseFloat(allMonthlyNPS[i][j].days)+
											(parseFloat(allResponses[ind].daysOpen)-2*parseInt(parseFloat(allResponses[ind].daysOpen)/7));// eliminates 2 days at every 7;
										else alert('E inchisa dar nu e inchisa !');
									}	
								}
								else
								if((allResponses[ind].dateClosed >= tbDateRef[j-2]) && (allResponses[ind].dateClosed < tbDateRef[j+1]))
								{
									allMonthlyNPS[i][j].closedThisMonth += allResponses[ind].responseID+' '+allResponses[ind].daysOpen+';';
									allMonthlyNPS[i][j].closed++;
									if(allResponses[ind].daysOpen != '') allMonthlyNPS[i][j].days = parseFloat(allMonthlyNPS[i][j].days)+
										(parseFloat(allResponses[ind].daysOpen)-2*parseInt(parseFloat(allResponses[ind].daysOpen)/7));// eliminates 2 days at every 7;
									else alert('E inchisa dar nu e inchisa !');
								}
							}
							else
							{
								if(allResponses[ind].dateClosed < tbDateRef[j+1])
								{
									allMonthlyNPS[i][j].closedThisMonth += allResponses[ind].responseID+' '+allResponses[ind].daysOpen+';';
									allMonthlyNPS[i][j].closed++;
									if(allResponses[ind].daysOpen != '') allMonthlyNPS[i][j].days = parseFloat(allMonthlyNPS[i][j].days)+
										(parseFloat(allResponses[ind].daysOpen)-2*parseInt(parseFloat(allResponses[ind].daysOpen)/7));// eliminates 2 days at every 7;
									else alert('E inchisa dar nu e inchisa !');
								}
							}
						}
						
					}
					if(allResponses[ind].statusFeedback == '0') 
					{
						if(allMonthlyNPS[i][0].openResponses.length == 0) allMonthlyNPS[i][0].openResponses = allResponses[ind].responseID;
						else
						{
							if(allMonthlyNPS[i][0].openResponses.indexOf(allResponses[ind].responseID) == -1) allMonthlyNPS[i][0].openResponses += ';' + allResponses[ind].responseID;
						}
					}
				}
			function checkReportsIndexes(value,type) //type = LOB, Region, Account, Parent Accounts
				{
					var i, j, k, ck, values = [], aTable = [];
					
					aIndexesTable.length = 0;
					values.length = 0;
					values = value.split(';');
					for(i=0;i<values.length;i++)
					{
						ck = true;
						for(j=0;j<allMonthlyNPS.length;j++)
						{
							if((allMonthlyNPS[j][0].type == type) && (allMonthlyNPS[j][0].name == values[i])) 
							//if((allMonthlyNPS[j][0].type == type) && (values[i].indexOf(allMonthlyNPS[j][0].name) != -1)) 
								{
									ck = false;
									aIndexesTable[aIndexesTable.length] = j; 
								}
						}
						if(ck)
						{
							aTable.length = 0;
							for(j=0;j<tbDateRef.length;j++)
							{
								aTable[j] = cloneThis(monthlyNPS);
								aTable[j].name = values[i];
								aTable[j].type = type;
								aTable[j].dateRef = tbDateRef[j];
								//aTable[j].targetNPS = 27;
								aTable[j].targetCustomers = '';
							}
							allMonthlyNPS[allMonthlyNPS.length] = cloneThis(aTable);
							aIndexesTable[aIndexesTable.length] = allMonthlyNPS.length-1; 
						}
					}
				}
			function checkReportsIndexesSpecial(value,type) //type = LOB, Region, Account, Parent Accounts
				{
					var i, j, k, ck, values = [], aTable = [], theValue = '';
					
					if(value.length != '')
					{
						
						aIndexesTable.length = 0;
						values.length = 0;
						values = value.split(';');
						
						for(i=0;i<values.length;i++)
						{
							
							ck = true;
							for(j=0;j<allMonthlyNPS.length;j++)
							{
								//if((allMonthlyNPS[j][0].type == type) && (allMonthlyNPS[j][0].name == values[i])) 
								//if(allMonthlyNPS[j][0].type == type)alert(j+': '+allMonthlyNPS[j][0].type+' ---- aici nu e sir gol: '+allMonthlyNPS[j][0].name);
								if((allMonthlyNPS[j][0].type == type) && (allMonthlyNPS[j][0].name.length != 0) && (values[i].indexOf(allMonthlyNPS[j][0].name) != -1)) 
									{
										ck = false;
										
										aIndexesTable[aIndexesTable.length] = j; 
									}
							}
							if(ck)
							{
								aTable.length = 0;
								theValue = '';
								//alert(values[i]+' --- '+listPlantsAll);
								for(j=2;j<listPlantsAll.length;j++)
								{
									//alert(values[i]+' --- '+listPlantsAll[j]);
									if(values[i].indexOf(listPlantsAll[j]) != -1) theValue = listPlantsAll[j];
								}
								if(theValue.length != 0)//listPlantsAll[j]
								{
									for(j=0;j<tbDateRef.length;j++)
									{
										aTable[j] = cloneThis(monthlyNPS);
										aTable[j].name = theValue;
										aTable[j].type = type;
										aTable[j].dateRef = tbDateRef[j];
										//aTable[j].targetNPS = 27;
										aTable[j].targetCustomers = '';
									}
									allMonthlyNPS[allMonthlyNPS.length] = cloneThis(aTable);
									aIndexesTable[aIndexesTable.length] = allMonthlyNPS.length-1; 	
									//alert(allMonthlyNPS[allMonthlyNPS.length-1].type+'  ---  '+allMonthlyNPS[allMonthlyNPS.length-1].name);
								}
								
							}
						}
					}
					
				}	
			
			addData(0);
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allResponses[ind].LOB,tbConst.LOB);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allResponses[ind].contactDEEPN,tbConst.DEEPN);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexesSpecial(allResponses[ind].categories,tbConst.Plant);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allResponses[ind].region,tbConst.Region);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);	

			aIndexesTable.length = 0;
			checkReportsIndexes(allResponses[ind].parentAccount,tbConst.ParentAccount);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allResponses[ind].account,tbConst.Account);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
		}
	function fulfillRequestData(ind) // function accessed from SFDC Home_page
		{
			var i, aIndexesTable = [[]];
			
			function addData(i)
				{
					
					var j, oneYearLimit;
					oneYearLimit = afterOneYear(allRequests[ind].dateCreated);
					
					for(j=0;j<(tbDateRef.length-1);j++)
					{
						if((allRequests[ind].dateCreated >= tbDateRef[j]) && (allRequests[ind].dateCreated < tbDateRef[j+1]))
						{
							allMonthlyNPS[i][j].req1++;
							allMonthlyNPS[i][j].req12++;
							if(allMonthlyNPS[i][j].monthlyContacted.length == 0) allMonthlyNPS[i][j].monthlyContacted = allRequests[ind].contactID;
							else
							{
								if(allMonthlyNPS[i][j].monthlyContacted.indexOf(allRequests[ind].contactID) == -1)allMonthlyNPS[i][j].monthlyContacted += ';'+allRequests[ind].contactID;
							}
						}
						if((allRequests[ind].dateCreated < tbDateRef[j] ) && (tbDateRef[j+1] <= oneYearLimit))
						{
							allMonthlyNPS[i][j].req12++;
						}
					}
				}
			function checkReportsIndexes(value,type) //type = LOB, Region, Account, Parent Accounts
				{
					var i, j, k, ck, values = [], aTable = [];
					
					aIndexesTable.length = 0;
					values.length = 0;
					values = value.split(';');
					for(i=0;i<values.length;i++)
					{
						ck = true;
						for(j=0;j<allMonthlyNPS.length;j++)
							if((allMonthlyNPS[j][0].type == type) && (allMonthlyNPS[j][0].name == values[i])) 
								{
									ck = false;
									aIndexesTable[aIndexesTable.length] = j; 
								}
						//if(ck) alert('ERROR - req: something is terrible wrong ! ' + allRequests[ind].responseID);						
						/*{
							aTable.length = 0;
							for(j=0;j<tbDateRef.length;j++)
							{
								aTable[j] = cloneThis(monthlyNPS);
								aTable[j].name = values[i];
								aTable[j].type = type;
								aTable[j].dateRef = tbDateRef[j];
								aTable[j].targetNPS = 27;
								aTable[j].targetCustomers = '';
							}
							allMonthlyNPS[allMonthlyNPS.length] = cloneThis(aTable);
						}*/
					}
				}
			addData(0);
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allRequests[ind].LOB,tbConst.LOB);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allRequests[ind].DEEPN,tbConst.DEEPN);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allRequests[ind].plant,tbConst.Plant);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);	

			aIndexesTable.length = 0;
			checkReportsIndexes(allRequests[ind].region,tbConst.Region);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allRequests[ind].parentAccount,tbConst.ParentAccount);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allRequests[ind].account,tbConst.Account);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
		}
	function fulfillContactData(ind) // function accessed from SFDC Home_page
		{
			var i, aIndexesTable = [];
			function addData(i)
				{
					
					//if(allContacts[ind].lastResponse > allContacts[ind].lastRequest)
					//{
					//	allContacts[ind].lastRequest = allContacts[ind].lastResponse;
					//} 
					if(allContacts[ind].active.toLowerCase() != 'no') allHouses[i].active = allHouses[i].active+1;
					if((allContacts[ind].active.toLowerCase() != 'no') && (allContacts[ind].target.toLowerCase() != 'no'))
					{
						allHouses[i].targetNPS = allHouses[i].targetNPS+1;
						//if(allContacts[ind].lastResponse < oneYearAgo) allHouses[i].NPSnow = allHouses[i].NPSnow+1;
						if(allContacts[ind].NPSstatus == 'NPS target, available now') allHouses[i].NPSnow = allHouses[i].NPSnow+1;
						if(allContacts[ind].NPSstatus == 'NPS target, not available now') allHouses[i].waiting = allHouses[i].waiting+1;
					}
					if(allContacts[ind].lastResponse >= oneYearAgo) 
					{
						allHouses[i].responded = allHouses[i].responded+1;
						allHouses[i].asked = allHouses[i].asked+1;
					}
					else
					{
						if(allContacts[ind].lastRequest >= oneYearAgo) 
						{
							allHouses[i].asked = allHouses[i].asked+1;
						}
					}
					if  (
							(allContacts[ind].lastRequest >= oneYearAgo) && 
							(allContacts[ind].active.toLowerCase() != 'no') && 
							(allContacts[ind].NPSstatus == 'NPS target, available now')
						) allHouses[i].notResponded = allHouses[i].notResponded + 1;
					if((allContacts[ind].lastRequest+allContacts[ind].lastResponse) > 0) allHouses[i].hasNPSdata = 'true';
				}
			function checkReportsIndexes(value,type) //type = LOB, Region, Account, Parent Accounts
				{
					var i, j, ck, values = [];
					aIndexesTable.length = 0;
					values.length = 0;
					values = value.split(';');
					for(i=0;i<values.length;i++)
					{
						ck = true;
						for(j=0;j<allHouses.length;j++)
							if((allHouses[j].type == type) && (allHouses[j].name == values[i])) 
								{
									ck = false;
									aIndexesTable[aIndexesTable.length] = j; 
								}
						if(ck && (values[i].length > 0))
						{
							aIndexesTable[aIndexesTable.length] = allHouses.length;
							aHouse.name = values[i];
							aHouse.type = type;							
							allHouses[allHouses.length] = cloneThis(aHouse);
						}	
					}
				}
			
			addData(0);

			aIndexesTable.length = 0;
			checkReportsIndexes(allContacts[ind].LOB,tbConst.LOB);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allContacts[ind].DEEPN,tbConst.DEEPN);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allContacts[ind].plant,tbConst.Plant);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);	

			aIndexesTable.length = 0;
			checkReportsIndexes(allContacts[ind].region,tbConst.Region);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allContacts[ind].parentAccount,tbConst.ParentAccount);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allContacts[ind].account,tbConst.Account);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
		}
	function fulfillActionResponseData(ind) // function accessed from SFDC Home_page
		{
			var i, aIndexesTable = [];
			function addData(i)
				{
					if((allActionResponses[ind].status != 'Completed') && (allActionResponses[ind].status != 'Withdrawn')) 
					{
						if(allHouses[i].openActionsList.length == 0) allHouses[i].openActionsList = allActionResponses[ind].actionID;
						else 
						{
							if(allHouses[i].openActionsList.indexOf(allActionResponses[ind].actionID) == -1) allHouses[i].openActionsList += ';' + allActionResponses[ind].actionID;
						}
						if(allActionResponses[ind].dueDate < today)
						{
							if(allHouses[i].openOverdueActionsList.length == 0) allHouses[i].openOverdueActionsList = allActionResponses[ind].actionID;
							else 
							{
								if(allHouses[i].openOverdueActionsList.indexOf(allActionResponses[ind].actionID) == -1) allHouses[i].openOverdueActionsList += ';' + allActionResponses[ind].actionID;
							}
						}
					}
				}
			function checkReportsIndexes(value,type) //type = LOB, Region, Account, Parent Accounts
				{
					var i, j, ck, values = [];
					aIndexesTable.length = 0;
					values.length = 0;
					values = value.split(';');
					for(i=0;i<values.length;i++)
					{
						ck = true;
						for(j=0;j<allHouses.length;j++)
							if((allHouses[j].type == type) && (allHouses[j].name == values[i])) 
								{
									ck = false;
									aIndexesTable[aIndexesTable.length] = j; 
								}
						if(ck && (values[i].length > 0))
						{
							// should not be executed for actionResponses;
							aIndexesTable[aIndexesTable.length] = allHouses.length;
							aHouse.name = values[i];
							aHouse.type = type;							
							allHouses[allHouses.length] = cloneThis(aHouse);
						}	
					}
				}
			function checkReportsIndexesSpecial(value,type) //type = LOB, Region, Account, Parent Accounts
				{
					var i, j, ck, values = [], aTable = [], theValue = '';
					aIndexesTable.length = 0;
					values.length = 0;
					values = value.split(';');
					for(i=0;i<values.length;i++)
					{
						ck = true;
						for(j=0;j<allHouses.length;j++)
							if((allHouses[j].type == type) && (allHouses[j].name.length != 0) && (values[i].indexOf(allHouses[j].name) != -1)) 
								{
									ck = false;
									aIndexesTable[aIndexesTable.length] = j; 
								}						
						if(ck)
						{
							aTable.length = 0;
							theValue = '';
								
							for(j=2;j<listPlantsAll.length;j++)
							{
								if(values[i].indexOf(listPlantsAll[j]) != -1) theValue = listPlantsAll[j];
							}
							if(theValue.length != 0)
							{
								// should not be executed for actionResponses;
								aIndexesTable[aIndexesTable.length] = allHouses.length;
								aHouse.name = theValue;
								aHouse.type = type;
								allHouses[allHouses.length] = cloneThis(aHouse);
							}
						}
					}
				}
			
			addData(0);

			aIndexesTable.length = 0;
			checkReportsIndexes(allActionResponses[ind].LOBs,tbConst.LOB);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allActionResponses[ind].listDEEPNs,tbConst.DEEPN);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
			
			aIndexesTable.length = 0;
			checkReportsIndexesSpecial(allActionResponses[ind].categories,tbConst.Plant);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);

			aIndexesTable.length = 0;
			checkReportsIndexes(allActionResponses[ind].listRegions,tbConst.Region);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allActionResponses[ind].parentAccounts,tbConst.ParentAccount);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
			
			
			aIndexesTable.length = 0;
			checkReportsIndexes(allActionResponses[ind].accounts,tbConst.Account);
			for(i=0;i<aIndexesTable.length;i++) addData(aIndexesTable[i]);
		}
	
	function initialize1page()
		{
			var i;			

			for(i=0;i<listMainMenu.length;i++)
				document.getElementById('A3-s'+listMainMenu[i]).style.display = 'none';
			document.getElementById('A3-sHome').style.display = 'block';
			eventsMainMenu();
		}
	function eventsMainMenu()
		{
			var i;
			for(i=0;i<(listMainMenu.length-2);i++)
				document.getElementById('A2-btn'+listMainMenu[i]).onclick = function() {selectMainMenu(this.id);}
			window.onscroll = function() {scrollFunction()};
		}
	function selectMainMenu(id)
		{
			var i, index;

			index = id.replace('A2-btn','');
			for(i=0;i<listMainMenu.length;i++)
			{
				document.getElementById('A3-s'+listMainMenu[i]).style.display = 'none';	
				if(i < (listMainMenu.length-2)) 
				{
					arrangeCSSclasses('A2-btn'+listMainMenu[i],'buttonInactive,buttonStyle','0,1');
					document.getElementById('A2-btn'+listMainMenu[i]).disabled = false;
				}
			}
			document.getElementById('A3-s'+index).style.display = 'block';
			arrangeCSSclasses('A3-s'+index,'tagAppearance,tagAppearance','0,1');
			if((index != 'NewResponse') && (index != 'Form')) 
			{
				arrangeCSSclasses('A2-btn'+index,'buttonInactive,buttonStyle','1,0');
				document.getElementById('A2-btn'+index).disabled = true;
			}
			switch(index)
			{
				case 'Home': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home'; break;
				case 'Survey': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Survey'; break;
				case 'Responses': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Responses'; break;
				case 'Actions': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Actions'; break;
				case 'Support': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Support'; break;
				case 'Admin': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Admin'; break;
				case 'NewResponse': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Responses > New Response'; break;
				case 'Form': document.getElementById('A1-sBreadcrumbs').innerHTML = 'Home > Responses > ' + aResponse.responseName; break;
			}
		}
	function adjustActionResponses()
		{
			var i, j, tab = [], aString; 
			function eliminateDuplicates(aString)
				{
					var j, k, ck, tab = [], newTab = [];
					if(aString != null)
					{
						tab.length = 0; newTab.length = 0;
						tab = aString.split(';');
						for(j=0;j<tab.length;j++)
						{
							ck = true;
							for(k=0;k<newTab.length;k++)
								if(newTab[k] == tab[j]) ck = false;
							if(ck) newTab[newTab.length] = tab[j];
						}
						aString = '';
						for(k=0;k<newTab.length;k++)
							if(aString.length == 0) aString = newTab[k]; else aString += ';'+newTab[k]; 	
						return aString;
					}
					else {return '';}
				}
			
			for(i=0;i<allActionResponses.length;i++)
			{
				//if(allActionResponses[i].accounts == null) alert(i+' actionID:'+allActionResponses[i].actionID+' response ID:'+allActionResponses[i].responseID);
				allActionResponses[i].accounts = eliminateDuplicates(allActionResponses[i].accounts);
				//if(allActionResponses[i].parentAccounts == null)  alert(i+' actionID:'+allActionResponses[i].actionID+' response ID:'+allActionResponses[i].responseID);;
				allActionResponses[i].parentAccounts = eliminateDuplicates(allActionResponses[i].parentAccounts);
				//if(allActionResponses[i].touchpoints == null)  alert(i+' actionID:'+allActionResponses[i].actionID+' response ID:'+allActionResponses[i].responseID);;
				allActionResponses[i].touchpointsExt = eliminateDuplicates(allActionResponses[i].touchpoints);
				//if(allActionResponses[i].categories == null)  alert(i+' actionID:'+allActionResponses[i].actionID+' response ID:'+allActionResponses[i].responseID);;
				allActionResponses[i].categoriesExt = eliminateDuplicates(allActionResponses[i].categories);
				//if(allActionResponses[i].listDEEPNs == null)  alert(i+' actionID:'+allActionResponses[i].actionID+' response ID:'+allActionResponses[i].responseID);;
				allActionResponses[i].listDEEPNs = eliminateDuplicates(allActionResponses[i].listDEEPNs);
				fulfillActionResponseData(i);	
				aString = '';
				tab.length = 0; tab = allActionResponses[i].categories.split(';');
				for(j=0;j<tab.length;j++)
					if(aString.length == 0) aString = tab[j].substr(0,tab[j].indexOf('___'));
					else aString += ';'+tab[j].substr(0,tab[j].indexOf('___'));
				allActionResponses[i].categories = aString;
				allActionResponses[i].categories = eliminateDuplicates(allActionResponses[i].categories);
				aString = '';
				if(allActionResponses[i].touchpoints != null)
				{
					tab.length = 0; tab = allActionResponses[i].touchpoints.split(';');
					for(j=0;j<tab.length;j++)
						if(aString.length == 0) aString = tab[j].substr(0,tab[j].indexOf('___'));
						else aString += ';'+tab[j].substr(0,tab[j].indexOf('___'));
					allActionResponses[i].touchpoints = aString;
					allActionResponses[i].touchpoints = eliminateDuplicates(allActionResponses[i].touchpoints);
				}
			}
		}
		
// custom objects
	//.initialize('B2-rChildAccounts','radio',tab,selectChildAccount,'inputSelected','inputUnselected','0');
	function newInputRadioOrCheckbox()
		{
			return {
						tagId:'',
						selectionType: '',
						options: [],
						inputSelected:'',
						inputUnselected:'',
						defaultSelections: '',//coma separated, empty = none
						indexSelected: '',//coma separated, empty = none
						objCallBack: function(){alert('callback to be executed after onClick');},
						initialize: function(tagId,type,listOptions,callback,classSelected,classUnselected,defaultSelections)
							{
								var i;
								this.tagId = tagId;
								this.selectionType = type;
								this.options.length = 0;
								for(i=0;i<listOptions.length;i++)
									this.options[i] = listOptions[i];
								this.objCallBack = callback;
								this.inputSelected = classSelected;
								this.inputUnselected = classUnselected;
								this.defaultSelections = defaultSelections;
								this.indexSelected =  defaultSelections;
								this.contentSelections();						
								this.eventsSelections();
							},
						contentSelections: function()
							{
								var i, id = this.tagId+'Container', content = '', aTab = [];
								
								if((this.selectionType == 'radio') || (this.selectionType == 'checkbox'))
								{
									
									for(i=0;i<this.options.length;i++)
										content += '<label id="'+this.tagId+i+'label" style="display:block;position:relative;float:left;white-space: nowrap;margin-right:1em;" class="'+this.inputUnselected+'"><input id="'+this.tagId+i+'" type="'+this.selectionType+'" name="'+this.tagId+'" style="display:none;"/>'+this.options[i]+'</label>'; 
									
									if(!document.getElementById(id)) alert(id);
									document.getElementById(id).innerHTML = content;

									if(this.defaultSelections.length > 0)
									{
										aTab.length = 0;
										aTab = this.defaultSelections.split(',');
										if(this.selectionType == 'radio') aTab.length = 1;
										for(i=0;i<aTab.length;i++)
											if(parseInt(aTab[i]) < this.options.length)
											{
												document.getElementById(this.tagId+aTab[i]).checked = true;
												this.arrangeCSSclasses(this.tagId+aTab[i]+'label',this.inputUnselected+','+this.inputSelected,'0,1');
											}
									}
								}
							},
						eventsSelections: function()
							{
								var i = 0;
								var self = this;
								while(document.getElementById(self.tagId+i))
								{
									document.getElementById(self.tagId+i).onclick = function() {self.selectionMade(this.id);};
									i++;
								}
							},
						selectionMade: function(id) 
							{
								var i;
								this.indexSelected = '';
								if(document.getElementById(id).type == 'radio')
								{
									i = 0;
									while(document.getElementById(this.tagId+i))
									{
										this.arrangeCSSclasses(this.tagId+i+'label',this.inputUnselected+','+this.inputSelected,'1,0');
										i++;
									}
									this.arrangeCSSclasses(id+'label',this.inputUnselected+','+this.inputSelected,'0,1');
									this.indexSelected = id.replace(this.tagId,'');
								}
								else
								{
									if(document.getElementById(id+'label').classList.contains(this.inputUnselected))
									{
										this.arrangeCSSclasses(id+'label',this.inputUnselected+','+this.inputSelected,'0,1');
										this.indexSelected += id.replace(this.tagId,'');
									} 									
									else this.arrangeCSSclasses(id+'label',this.inputUnselected+','+this.inputSelected,'1,0');
								}
								this.objCallBack();
							},
						forceSelection: function(list)
							{
								var i, aTable = [];
								i = 0;
								while(document.getElementById(this.tagId+i))
								{
									document.getElementById(this.tagId+i).checked = false;
									this.arrangeCSSclasses(this.tagId+i+'label',this.inputUnselected+','+this.inputSelected,'1,0');
									i++;
								}
								if(list.indexOf(';') == -1)
								{
									if(document.getElementById(this.tagId+list))
									{
										document.getElementById(this.tagId+list).checked = true;
										this.arrangeCSSclasses(this.tagId+list+'label',this.inputUnselected+','+this.inputSelected,'0,1');
									}
								}
								else 
								{
									aTable.length = 0;
									aTable = list.split(';');
									for(i=0;i<aTable.length;i++)
										if(document.getElementById(this.tagId+aTable[i]))
										{
											document.getElementById(this.tagId+aTable[i]).checked = true;
											this.arrangeCSSclasses(this.tagId+aTable[i]+'label',this.inputUnselected+','+this.inputSelected,'0,1');
										}
								}
								this.indexSelected = list; // must be tested at least for checkbox (not know how behave if there are values out of the range);
							},
						arrangeCSSclasses: function(tagName,classesList,opList)
							{
								var i,tag,cList=[],oList=[];
								cList = classesList.split(",");
								oList = opList.split(",");
								
								tag = document.getElementById(tagName);
								if(cList.length!=oList.length) return "-3";
								else
								{
									if(tag)
									{
										for(i=0;i<cList.length;i++)
										{
											switch(oList[i])
											{
												case "0":
												{
													if(tag.classList.contains(cList[i]))
													{
														tag.classList.remove(cList[i]);
														tag.offsetWidth = tag.offsetWidth;
													}
												}break;
												case "1":
												{
													if(!tag.classList.contains(cList[i])) tag.classList.add(cList[i]);
												}break;
											}
										}
									}
								}
							}
					}
		}
	function contentAccordion(refName,param)
		{
			var i, j, panel, otherPanel, listTags = document.getElementsByClassName(refName);
			for(i=0;i<listTags.length;i++)
			{
				panel = listTags[i].nextElementSibling;
				panel.id = refName+i;
				panel.style.height = panel.scrollHeight + 'px';
				if(panel.classList.contains(refName+'Extended')) panel.style.height = panel.scrollHeight + 'px';
				else panel.style.height = '0px';
			}
			for(i=0;i<listTags.length;i++)
			{
				listTags[i].onclick = function() 
				{
					panel = this.nextElementSibling;
					if (panel.style.height != '0px') 
					{
						arrangeCSSclasses(panel.id,refName+'Extended,'+refName+'Collapsed','0,1');
						panel.style.height = '0px';
					}
					else 
					{
						arrangeCSSclasses(panel.id,refName+'Extended,'+refName+'Collapsed','1,0');
						panel.style.height = panel.scrollHeight + 'px';
					}
					if(param == 'connected')
						for(j=0;j<listTags.length;j++)
						{
							if(listTags[j] != this)
							{
								panel = listTags[j].nextElementSibling;
								if(panel.classList.contains(refName+'Extended')) 
								{
									arrangeCSSclasses(panel.id,refName+'Extended,'+refName+'Collapsed','0,1');
									panel.style.height = '0px';
								}
							}
						}
				}
			}
		}
	function newTextInputUpgraded()
		{
			var anObject = 
			{
				theLimit: 0,
				theCounter: 0,
				tagID: '',
				textType: '',
				theLabel: '',
				initialize: function(tagID,theLimit,textType,theLabel)
				{
					this.tagID = tagID;
					this.theLimit = theLimit;
					this.theCounter = 0;
					this.textType = textType;
					this.contentTheObject();
					this.theLabel = theLabel;
				},
				contentTheObject: function()
				{
					var content;
					content = '<label for="'+this.tagID+'">'+this.theLabel+'<span id="'+this.tagID+
							'Counter">'+this.theCounter+'</span>/'+this.theLimit+'</label><br/>';
					if(this.textType == 'textarea')
						content += '<textarea id="'+this.tagID+'Object" style="width:100%;"></textarea>';
					else content += '<input id="'+this.tagID+'Object" type="text"/>';
					document.getElementById(this.tagID).innerHTML = content;
					this.eventsTheObject();
				},
				eventsTheObject: function()
				{
					var self = this;
					document.getElementById(this.tagID+'Object').onkeyup = function(event) {self.keysStroke(event)};
					document.getElementById(this.tagID+'Object').onkeydown = function(event) {self.keysStroke(event)};
				},
				keysStroke: function(event)
				{
					if(document.getElementById(this.tagID + 'Object').value.length > this.theLimit)
						document.getElementById(this.tagID + 'Object').value = 
								document.getElementById(this.tagID + 'Object').value.substr(0,this.theLimit);
					document.getElementById(this.tagID+'Counter').innerHTML = 
						document.getElementById(this.tagID + 'Object').value.length;
					if(event.keyCode == 13) {;}
				}
			}
			return anObject;
		}

// various functions (related to clean contacts SFDC data, add content, )	
	function adjustLOBValues(LOB, type, region, touchpoints)
		{
			var i, ck;
			
			ck = true;
			while(ck)
			{
				ck = false;
				if(LOB.indexOf('; ')!=-1){ck = true; LOB = LOB.replace('; ',';');}
				if(LOB.indexOf(' ;')!=-1){ck = true; LOB = LOB.replace(' ;',';');}
			}
			if((LOB.indexOf('Aftermarket') != -1) && (type.indexOf('OEM') != -1)) LOB.replace('Aftermarket','OEM-Aftermarket');
			/*if((region == 'India') || (region == 'China'))
			{
			 if(LOB == '') LOB = 'HGR(India+China)'; else LOB += ';HGR(India+China)';
			}*/
			if(touchpoints.indexOf('OES') != -1) 
			{	
				if(LOB == '') LOB = 'OES'; else LOB += ';OES';
			}
			return LOB;
		}
	function contentFreeSearchList()
		{
			var i, content = '';
			for(i=0;i<listAccounts.length;i++)
				content += '<option value="'+listAccounts[i][0]+'">'+listAccounts[i][0]+'</option>';
			document.getElementById('C1-listSearch').innerHTML = content;
			document.getElementById('D1-listSearch').innerHTML = content;
			document.getElementById('F1-listSearch').innerHTML = content;
		}

// functions related to responses
	function createTouchpointsTables()
		{
			var i, j, ck, tab = [];
			
			listPhases.length = 0;
			tbE2ESteps.length = 0;
			for(i=1;i<listFullTouchpoints.length;i++)
			{
				tab = listFullTouchpoints[i].split('___');
				ck = true;
				for(j=0;j<tbE2ESteps.length;j++)
					if(tbE2ESteps[j][0] == tab[0])
					{
						ck = false;
						tbE2ESteps[tbE2ESteps.length-1][1] += tab[1];
					} 
				if(ck) 
				{
					tbE2ESteps[tbE2ESteps.length] = [tab[0],tab[1],'0'];
					listPhases[listPhases.length] = tab[0];
					if(tab[0] == 'Design') tbE2ESteps[tbE2ESteps.length-1][2] = '1';
				}
			}
			for(i=0;i<tbE2ESteps.length;i++)
				tbE2ESteps[i][1] = tbE2ESteps[i][1].substr(0,tbE2ESteps[i][1].length-1);
			listPhases.unshift(tbConst.ALL);
		}
	function createCategoriesTables()
		{
			var i, j, ck, tab = [];

			listCategories.length = 0;
			tbCategories.length = 0;
			for(i=1;i<listFullCategories.length;i++)
			{
				tab = listFullCategories[i].split('___');
				ck = true;
				for(j=0;j<tbCategories.length;j++)
					if(tbCategories[j][0] == tab[0])
					{
						ck = false;
						tbCategories[tbCategories.length-1][1] += tab[1];
					} 
				if(ck) 
				{
					tbCategories[tbCategories.length] = [tab[0],tab[1]];
					listCategories[listCategories.length] = tab[0];
				}
			}
			for(i=0;i<tbCategories.length;i++)
				tbCategories[i][1] = tbCategories[i][1].substr(0,tbCategories[i][1].length-1);

			listCategories.unshift(tbConst.ALL);
		}
	function doSomeConversion(aListTable,aString,refTab)
		{
			// completes (add only if it's not already there) the indexes list of "aListTable" with the touchpoints/categories included in "aString" using the reference table provided by "refTab";
			var i, j, k, ck, aTab = [], anotherTab = [], otherTab = [], newTab = [];
			
			newTab.length = 0;
			aTab.length = 0;
			aTab = aString.split(';');
			
			for(i=0;i<aTab.length;i++)
			{
				anotherTab.length = 0;
				anotherTab = aTab[i].split('___');
				for(j=0;j<refTab.length;j++)
					if(refTab[j][0] == anotherTab[0])
					{
						otherTab.length = 0;
						otherTab = refTab[j][1].split(';');
						for(k=0;k<otherTab.length;k++)
							if(otherTab[k] == anotherTab[1]) newTab[newTab.length] = j+','+k;
					}
			}
			aTab.length = 0;
			aTab = aListTable.split(';');
			for(i=0;i<newTab.length;i++)
			{
				ck = true;
				for(j=0;j<aTab.length;j++)
					if(aTab[j] == newTab[i]) ck = false;
				if(ck) aTab[aTab.length] = newTab[i];
			}
			var texty = '';
			for(i=0;i<aTab.length;i++)
				if(texty == '')	texty += aTab[i]; else texty += ';' + aTab[i];
			return texty;
		} 

// go to other pages
	function goToSurveyPage(tagId,index)
		{
			var i;
			
			objSelSurveyLOB.forceSelection('0');
			objSelSurveyRegion.forceSelection('0');
			objSelSurveyDEEPN.forceSelection('0');
			objSelSurveyPlant.forceSelection('0');
			objSelSurveyOwnership.forceSelection('0');
			document.getElementById('C1-iSearch').value = '';
			objSelSurveyFreeSearch.forceSelection('0');
			
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.LOB)
			{
				for(i=0;i<listLOBall.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listLOBall[i][0]) 
						objSelSurveyLOB.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.DEEPN)
			{
				for(i=0;i<listDEEPNall.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listDEEPNall[i]) 
						objSelSurveyDEEPN.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Plant)
			{
				for(i=0;i<listPlantsAll.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listPlantsAll[i]) 
						objSelSurveyPlant.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Region)
			{
				for(i=0;i<listRegionsAll.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listRegionsAll[i][0]) objSelSurveyRegion.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.ParentAccount)
			{
				if(selectedChildAccount == -1)
				{
					document.getElementById('C1-iSearch').value = listObjectives[objSelectionObjectives.indexSelected].name;
					objSelSurveyFreeSearch.forceSelection('2');
				}
				else
				{
					document.getElementById('C1-iSearch').value = listObjectives[selectedChildAccount].name;
					objSelSurveyFreeSearch.forceSelection('1');	
				}
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Region)
			{
				if(selectedChildAccount != -1)
				{
					document.getElementById('C1-iSearch').value = listObjectives[selectedChildAccount].name;
					objSelSurveyFreeSearch.forceSelection('1');	
				}
			}

			if((tagId == 'B21-svgContactsResponded') && (index == 0))
			{
				objSelSurveyNPSstatus.forceSelection('0');
				objSelSurveyNPSactivity.forceSelection('0');
				objSelSurveyNPSresponse.forceSelection('2');
			}
			if((tagId == 'B21-svgContactsResponded') && (index == 1))
			{
				objSelSurveyNPSstatus.forceSelection('3');
				objSelSurveyNPSactivity.forceSelection('2');
				objSelSurveyNPSresponse.forceSelection('0');
			}
			if((tagId == 'B21-svgContactsAvailable') && (index == 0))
			{
				objSelSurveyNPSstatus.forceSelection('3');
				objSelSurveyNPSactivity.forceSelection('0');
				objSelSurveyNPSresponse.forceSelection('0');
			}
			if((tagId == 'B21-svgContactsAvailable') && (index == 1))
			{
				objSelSurveyNPSstatus.forceSelection('4');
				objSelSurveyNPSactivity.forceSelection('0');
				objSelSurveyNPSresponse.forceSelection('0');
			}
			if((tagId == 'B21-svgContactsAvailable') && (index == 2))
			{
				objSelSurveyNPSstatus.forceSelection('1');
				objSelSurveyNPSactivity.forceSelection('0');
				objSelSurveyNPSresponse.forceSelection('0');
			}
			fillSelectedContacts();
			selectMainMenu('A2-btnSurvey');
		}
	function goToResponsesPage(index,id)
		{
			var i;
			
			objSelResponsesLOB.forceSelection('0');
			objSelResponsesRegion.forceSelection('0');
			objSelResponsesDEEPN.forceSelection('0');
			objSelResponsesPlant.forceSelection('0');
			//if(index != '-1') objSelResponsesTime.forceSelection('1');
			//else objSelResponsesTime.forceSelection('0');
			objSelResponsesTime.forceSelection('1');
			objSelResponsesCategories.forceSelection('0');
			objSelResponsesPoints.forceSelection('0');


			if(index != '-1') objSelResponsesRespondersType.forceSelection(index); // promoters, passives, detractors
			else objSelResponsesRespondersType.forceSelection('0');

			if(index == '-1') objSelResponsesStatusFeedback.forceSelection('1'); // 
			else objSelResponsesStatusFeedback.forceSelection('0');
			
			objSelResponsesStatusTouchpoints.forceSelection('0');
			objSelResponsesStatusCategories.forceSelection('0');
			objSelResponsesStatusActions.forceSelection('0');

			objSelResponsesTouchpointsType.forceSelection('0');
			objSelResponsesPhases.forceSelection('0');
			objSelResponsesTouchpoints.forceSelection('0');
			objSelResponsesOwnership.forceSelection('0');
			document.getElementById('D1-iSearch').value = '';
			objSelResponsesFreeSearch.forceSelection('0');

			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.LOB)
			{
				for(i=0;i<listLOBall.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listLOBall[i][0]) objSelResponsesLOB.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.DEEPN)
			{
				for(i=0;i<listDEEPNall.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listDEEPNall[i]) objSelResponsesDEEPN.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Plant)
			{
				for(i=0;i<listPlantsAll.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listPlantsAll[i]) objSelResponsesPlant.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Region)
			{
				for(i=0;i<listRegionsAll.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listRegionsAll[i][0]) objSelResponsesRegion.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.ParentAccount)
			{
				if(selectedChildAccount == -1)
				{
					document.getElementById('D1-iSearch').value = listObjectives[objSelectionObjectives.indexSelected].name;
					objSelResponsesFreeSearch.forceSelection('2');
				}
				else
				{
					document.getElementById('D1-iSearch').value = listObjectives[selectedChildAccount].name;
					objSelResponsesFreeSearch.forceSelection('1');	
				}
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Region)
			{
				if(selectedChildAccount != -1)
				{
					document.getElementById('D1-iSearch').value = listObjectives[selectedChildAccount].name;
					objSelResponsesFreeSearch.forceSelection('1');	
				}
			}
			
			if(id.length != 0)
			{
				objSelResponsesPhases.forceSelection((parseInt(id.substr(9,id.length).split('.')[0])+1).toString());
				prepareTouchpointsSelection();
				objSelResponsesTouchpoints.forceSelection((parseInt(id.substr(9,id.length).split('.')[1])+1).toString())	
			}		
			callbackSelectionsResponses();
			contentAccordion('myAccordion','');
			selectMainMenu('A2-btnResponses');
		}
	function goToActionsPage(id,param)
		{
			objSelActionsLOB.forceSelection('0');
			objSelActionsRegion.forceSelection('0');
			objSelActionsDEEPN.forceSelection('0');
			objSelActionsPlant.forceSelection('0');
			objSelActionsType.forceSelection('0');
			objSelActionsStatus.forceSelection('0');
			objSelActionsDueDateStatus.forceSelection('0');
			objSelActionsPhases.forceSelection('0');
			objSelActionsCategories.forceSelection('0');
			objSelActionsFunctionalTeam.forceSelection('0');
			objSelActionsOwnership.forceSelection('0');
			document.getElementById('F1-iSearch').value = '';
			objSelActionsFreeSearch.forceSelection('0');
			
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.LOB)
			{
				for(i=0;i<listLOBall.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listLOBall[i][0]) objSelActionsLOB.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Region)
			{
				for(i=0;i<listRegionsAll.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listRegionsAll[i][0]) objSelActionsRegion.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.DEEPN)
			{
				for(i=0;i<listDEEPNall.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listDEEPNall[i]) objSelActionsDEEPN.forceSelection(i.toString());
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Plant)
			{
				for(i=0;i<listPlantsAll.length;i++)
					if(listObjectives[objSelectionObjectives.indexSelected].name == listPlantsAll[i]) objSelActionsPlant.forceSelection(i.toString());
			}
			
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.ParentAccount)
			{
				if(selectedChildAccount == -1)
				{
					document.getElementById('F1-iSearch').value = listObjectives[objSelectionObjectives.indexSelected].name;
					objSelActionsFreeSearch.forceSelection('2');
				}
				else
				{
					document.getElementById('F1-iSearch').value = listObjectives[selectedChildAccount].name;
					objSelActionsFreeSearch.forceSelection('1');	
				}
			}
			if(listObjectives[objSelectionObjectives.indexSelected].type == tbConst.Region)
			{
				if(selectedChildAccount != -1)
				{
					document.getElementById('F1-iSearch').value = listObjectives[selectedChildAccount].name;
					objSelActionsFreeSearch.forceSelection('1');	
				}
			}

			if(id == '1') objSelActionsStatus.forceSelection('1');	
			if(id == '2') 
			{
				objSelActionsStatus.forceSelection('1');
				objSelActionsDueDateStatus.forceSelection('2');
			}
			
			if(param.length > 5)
			{
				objSelActionsLOB.forceSelection('0');
				objSelActionsType.forceSelection('0');
				objSelActionsStatus.forceSelection('0');
				objSelActionsDueDateStatus.forceSelection('0');
				objSelActionsPhases.forceSelection('0');
				objSelActionsCategories.forceSelection('0');
				objSelActionsFunctionalTeam.forceSelection('0');
				objSelActionsOwnership.forceSelection('0');
				document.getElementById('F1-iSearch').value = param;
				objSelActionsFreeSearch.forceSelection('5');
			}
			callbackSelectionsActions();
			selectMainMenu('A2-btnActions');

		}
	function goToFormPage()
		{
			var i=0, ck = true;
			useCleanResponse();
			while(ck && i<allResponses.length)
			{
				if(allResponses[i].responseID == selectedResponse) {ck = false;aResponse = cloneThis(allResponses[i]);}
				i++;
			}
			/*if((aResponse.commentsNI.indexOf('[more]') != -1) || (aResponse.commentsEE.indexOf('[more]') != -1)) */
			readSFDCfullComment(aResponse.responseID);
			//readSFDCfullComment(selectedResponse);
			initializeForm();
			selectMainMenu('A2-btnForm');
		}

// When the user scrolls down 20px from the top of the document, show the button
	function scrollFunction() 
		{
			if ((document.body.scrollTop > 20) || (document.documentElement.scrollTop > 20)) 
			{
				if(document.getElementById("A-btnGoToTop").style.display == 'none')
				{
					document.getElementById("A-btnGoToTop").style.display = "block";
					arrangeCSSclasses('A-btnGoToTop','tagAppearanceButton,tagAppearanceButton','0,1');	
				}
			} 
			else document.getElementById("A-btnGoToTop").style.display = "none";
		}

		// When the user clicks on the button, scroll to the top of the document
	function topFunction() 
		{
			document.body.scrollTop = 0; // For Safari
			document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
		}

// other functions
	function arrangeCSSclasses(tagName,classesList,opList)
		{
			var i,tag,cList=[],oList=[];
			cList = classesList.split(",");
			oList = opList.split(",");
			
			tag = document.getElementById(tagName);
			if(cList.length!=oList.length) return "-3";
			else
			{
				if(tag)
				{
					for(i=0;i<cList.length;i++)
					{
						switch(oList[i])
						{
							case "0":
							{
								if(tag.classList.contains(cList[i]))
								{
									tag.classList.remove(cList[i]);
									tag.offsetWidth = tag.offsetWidth;
								}
							}break;
							case "1":
							{
								if(!tag.classList.contains(cList[i])) tag.classList.add(cList[i]);
							}break;
						}
					}
				}
			}
		}
	function cloneThis(proto_obj) {var ret = {}; for (var prop in proto_obj ) {ret[prop] = proto_obj[prop]; }	return ret;}
	function getActionName()
		{
			var today, todayConverted, actionName = 'A';
			today = Date.now();			
			todayConverted = new Date(today);			
			actionName += todayConverted.getFullYear().toString().substr(2,2);
			if(todayConverted.getMonth() < 9) actionName += '0'+(todayConverted.getMonth()+1); else actionName += (todayConverted.getMonth()+1);
			if(todayConverted.getDate() < 10) actionName += '0'+todayConverted.getDate(); else actionName += todayConverted.getDate();			
			actionName += '-';
			return actionName;
		}
	function dateConverted(intDate)
		{
			var aDate;
			
			if(!isNaN(intDate))
			{
				aDate = new Date(parseInt(intDate));
				return (aDate.getDate()+'-'+tbMonths[aDate.getMonth()].substr(0,3)+'-'+aDate.getFullYear());	
			}
			else return 'no date';
		}
	function dateSFDCformat(intDate)
		{
			var aDate;
			
			if(!isNaN(intDate))
			{
				aDate = new Date(parseInt(intDate));
				return (aDate.getDate()+' '+tbMonths[aDate.getMonth()]+' '+aDate.getFullYear());	
			}
			else return 'no date';
		}
	function afterOneYear(intDate)
        {
            var aDate, result;
            aDate = new Date(parseInt(intDate));
            //return Date.parse(new Date(aDate.getFullYear()+1,aDate.getMonth(),aDate.getDate()));
            return Date.parse(new Date(aDate.getFullYear()+1,aDate.getMonth(),1));
        }
	function afterOneMonth(intDate)
        {
            var aDate, result;
            aDate = new Date(parseInt(intDate));
            aDate.setMonth(aDate.getMonth()+1);
            return Date.parse(new Date(aDate.getFullYear(),aDate.getMonth(),aDate.getDate()));
        }
	function saveTextAsFile(content,fileName)
		{
			var textToWrite = content;
			var textFileAsBlob = new Blob([textToWrite], {type:'text/plain'});
			var fileNameToSaveAs = fileName;

			var downloadLink = document.createElement("a");
			downloadLink.download = fileNameToSaveAs;
			downloadLink.innerHTML = "Download File";
			if (window.webkitURL != null)
			{
				// Chrome allows the link to be clicked
				// without actually adding it to the DOM.
				downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
			}
			else
			{
				// Firefox requires the link to be added to the DOM
				// before it can be clicked.
				downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
				downloadLink.onclick = destroyClickedElement;
				downloadLink.style.display = "none";
				document.body.appendChild(downloadLink);
			}
			downloadLink.click();
		}
	function getPosition(element,param)
		{
			var xPosition = 0;
			var yPosition = 0;
			
			while(element) 
			{
				xPosition += (element.offsetLeft+ element.clientLeft); //xPosition += (element.offsetLeft + element.scrollLeft + element.clientLeft);
				if(param == 'noScroll') yPosition += (element.offsetTop + element.clientTop);
				else yPosition += (element.offsetTop - element.scrollTop + element.clientTop);
				element = element.offsetParent;
			}	
			return { x: xPosition, y: yPosition };
		}
	function callbackNone() {;}
	
